import base64
import json
import os
import re
import socket
import threading
import time
import uuid
from copy import deepcopy
from contextlib import contextmanager
from http.client import HTTPConnection, HTTPSConnection, IncompleteRead, RemoteDisconnected
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, List, Optional, Tuple
from urllib import error, request as urllib_request

from app.core.config import AppSettings, TaskRoute, default_config_path, load_settings, load_config_payload
from app.core.runtime_paths import resolve_runtime_paths
from app.core.errors import (
    AdapterError,
    ProviderAuthError,
    ProviderMidStreamDisconnectError,
    ProviderTimeoutError,
    ProviderUnavailableError,
)
from app.core.logging import get_logger
from app.core.models import (
    ExcelAnalysisRequest,
    ExcelFormulaAssistantRequest,
    ExcelSmartFillRequest,
    PptStructureReviewRequest,
)
from app.services.excel.smart_fill import (
    build_excel_smart_fill_prompt,
    excel_smart_fill_response_format,
    parse_excel_smart_fill_answer,
    validate_smart_fill_result_limits,
)
from app.services.workflow_profiles import WorkflowProfileError, WorkflowProfileStore
from app.services.model_configurations import (
    ACCESS_DIRECT_MODEL,
    ACCESS_WORKFLOW_PLATFORM,
    DEFAULT_CONTEXT_WINDOW_TOKENS,
    DEFAULT_RESERVED_OUTPUT_TOKENS,
    ModelConfigurationError,
    ModelConfigurationStore,
    direct_model_input_budget,
)
from app.services.system_prompts import SystemPromptError, SystemPromptStore
from app.services.direct_services import (
    DirectServiceError,
    DirectServiceStore,
    normalize_service_base_url,
)
from app.core.features import (
    direct_streaming_enabled,
    streaming_capability_validated,
)
from app.services.direct_text_stream import read_direct_text_stream
from app.services.long_task_coordinator import LongTaskCancelled
from app.services.ppt.document_text_extractor import extract_staged_document_text
from app.services.word.image_semantics import ImageSemanticConfigStore


class StreamingUnsupportedError(Exception):
    """Raised when direct streaming probe receives non-streaming or unsupported response."""
    pass


logger = get_logger(__name__)


@contextmanager
def _cancellable_urlopen(request, timeout, control):
    state = {"connection": None, "socket": None, "response": None, "cancelled": False}
    lock = threading.Lock()

    def interrupt():
        with lock:
            state["cancelled"] = True
            connection, response = state["connection"], state["response"]
            response_socket = getattr(connection, "sock", None) or state["socket"]
            if response is not None:
                raw = getattr(getattr(response, "fp", None), "raw", None)
                response_socket = getattr(raw, "_sock", None) or response_socket
        if response_socket is not None:
            try:
                response_socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            response_socket.close()
        elif response is not None:
            response.close()

    def connection_factory(connection_type):
        def create(*args, **kwargs):
            connection = connection_type(*args, **kwargs)
            connect = connection.connect
            with lock:
                state["connection"] = connection

            def checked_connect():
                with lock:
                    cancelled = state["cancelled"]
                if cancelled:
                    raise error.URLError("request cancelled")
                connect()
                with lock:
                    state["socket"] = connection.sock
                    cancelled = state["cancelled"]
                if cancelled:
                    interrupt()
                    raise error.URLError("request cancelled")

            connection.connect = checked_connect
            return connection
        return create

    class TrackedHTTPHandler(urllib_request.HTTPHandler):
        def http_open(self, req):
            return self.do_open(connection_factory(HTTPConnection), req)

    class TrackedHTTPSHandler(urllib_request.HTTPSHandler):
        def https_open(self, req):
            return self.do_open(connection_factory(HTTPSConnection), req,
                                context=self._context)

    opener = urllib_request.build_opener(TrackedHTTPHandler(), TrackedHTTPSHandler())
    control.set_cancel_callback(interrupt)
    try:
        with opener.open(request, timeout=timeout) as response:
            with lock:
                state["response"] = response
                cancelled = state["cancelled"]
            if cancelled:
                interrupt()
                raise error.URLError("request cancelled")
            yield response
    finally:
        control.clear_cancel_callback(interrupt)


def _open_task_response(request, timeout, task_type, control):
    if (task_type in ("word.material_composer", "ppt.material_outline") and control is not None
            and hasattr(control, "set_cancel_callback") and hasattr(control, "clear_cancel_callback")):
        return _cancellable_urlopen(request, timeout, control)
    return urllib_request.urlopen(request, timeout=timeout)
LOCAL_KEY_PATH = Path(__file__).resolve().parents[3] / "run" / "provider_api_key"
ROUTE_KEY_DIR = Path(__file__).resolve().parents[3] / "run" / "provider_api_keys"
_LAST_PROVIDER_DEBUG: Dict = {}
_TRACE_PROVIDER_DEBUG: Dict[str, Dict] = {}
_TRACE_PROVIDER_PERFORMANCE: Dict[str, Dict] = {}
_LAST_PROVIDER_DEBUG_LOCK = threading.Lock()
_MAX_TRACE_DEBUG_ITEMS = 50
DOCUMENT_REVIEW_TIMEOUT_SECONDS = 1800
EXCEL_ANALYSIS_TIMEOUT_SECONDS = DOCUMENT_REVIEW_TIMEOUT_SECONDS
EXCEL_FORMULA_ASSISTANT_TIMEOUT_SECONDS = EXCEL_ANALYSIS_TIMEOUT_SECONDS
EXCEL_SMART_FILL_TIMEOUT_SECONDS = EXCEL_ANALYSIS_TIMEOUT_SECONDS
PPT_SLIDE_ASSISTANT_TIMEOUT_SECONDS = EXCEL_ANALYSIS_TIMEOUT_SECONDS
PPT_STRUCTURE_REVIEW_TIMEOUT_SECONDS = EXCEL_ANALYSIS_TIMEOUT_SECONDS
PPT_DOCUMENT_SLIDE_COUNTS = (5, 8, 10, 12, 15)
INTERACTIVE_WRITING_TIMEOUT_SECONDS = 600
MAX_STREAMING_PROBE_RESPONSE_BYTES = 5 * 1024 * 1024
DIFY_INPUT_MODE_LEGACY = "legacy-input-query"
DIFY_INPUT_MODE_USER_INPUT = "user-input-node"
DIFY_INPUT_MODES = (DIFY_INPUT_MODE_LEGACY, DIFY_INPUT_MODE_USER_INPUT)
_PROVIDER_INPUT_MODE_CACHE: Dict[str, str] = {}


class FullDocumentReviewAnswer(str):
    """String-compatible full-review answer carrying the provider finish reason."""

    def __new__(cls, value: str, finish_reason: str = ""):
        result = str.__new__(cls, value)
        result.finishReason = finish_reason
        return result


_WRITING_POLICY_DEBUG_BOOLEAN_FIELDS = (
    "writingPolicyApplied",
    "writingPolicyDegraded",
)
_WRITING_POLICY_DEBUG_COUNT_FIELDS = (
    "writingPolicyTermCount",
    "writingPolicyStyleCount",
    "writingPolicyTruncatedCount",
    "writingPolicyElapsedMs",
)
_WRITING_POLICY_ERROR_CODE_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
_WRITING_POLICY_ITEM_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_PROVIDER_DEBUG_STAGE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
_MAX_WRITING_POLICY_DEBUG_ITEM_IDS = 20


def _mock_provider_enabled() -> bool:
    return os.environ.get("AI_WPS_ENABLE_MOCK_PROVIDER", "").strip() == "1"


def _direct_content_text(content) -> str:
    if isinstance(content, str):
        cleaned = re.sub(r"(?is)<think\b[^>]*>.*?(?:</think\s*>|$)", "", content)
        return strip_think_tag_content(cleaned).strip()
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict) and item.get("type") in {"text", "output_text"}:
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        combined = "\n".join(parts)
        cleaned = re.sub(r"(?is)<think\b[^>]*>.*?(?:</think\s*>|$)", "", combined)
        return strip_think_tag_content(cleaned).strip()
    return ""


def _estimate_direct_tokens(system_prompt: str, user_prompt: str) -> int:
    text = "{0}\n{1}".format(system_prompt or "", user_prompt or "")
    # Chinese text is close to one token per character; UTF-8/4 is safer for mixed text.
    return max(len(text), (len(text.encode("utf-8")) + 3) // 4) + 128


STYLE_TEXT = {
    "standard": "采用国企技术方案常用的正式、准确、克制表达，术语统一，避免口语化和夸张表述",
    "default": "采用国企技术方案常用的正式、准确、克制表达，术语统一，避免口语化和夸张表述",
    "formal": "采用国企技术方案常用的正式、准确、克制表达，术语统一，避免口语化和夸张表述",
    "structured": "按“背景、问题、措施、结论”组织内容，强化层级、逻辑连接和可执行表述",
    "reporting": "采用汇报材料表达，先给结论，再说明进展、问题、风险和下一步安排，语言稳健",
}

FOCUS_TEXT = {
    "complete": "保留原文关键信息、事实、条件和约束，不遗漏责任、时间、对象和结论",
    "default": "保留原文关键信息、事实、条件和约束，不遗漏责任、时间、对象和结论",
    "conclusion": "优先突出核心结论、关键判断、主要风险、影响范围和需要关注的问题",
    "risk": "优先突出核心结论、关键判断、主要风险、影响范围和需要关注的问题",
    "conclusion_risk": "优先突出核心结论、关键判断、主要风险、影响范围和需要关注的问题",
    "next_step": "优先突出解决措施、实施路径、责任分工、时间节点和下一步安排",
    "implementation": "优先突出解决措施、实施路径、责任分工、时间节点和下一步安排",
    "plan_next": "优先突出解决措施、实施路径、责任分工、时间节点和下一步安排",
    "acceptance": "优先突出交付物、验收标准、问题闭环、证据材料和后续跟踪要求",
}

LENGTH_TEXT = {
    "same": "保持与原文相近的篇幅，只优化措辞、结构和信息组织",
    "default": "保持与原文相近的篇幅，只优化措辞、结构和信息组织",
    "concise": "压缩冗余表达，保留关键信息和必要限定，输出更短更直接的版本",
    "expanded": "在不编造事实的前提下补足必要背景、逻辑衔接、措施说明和结论表达",
}

DOCUMENT_TYPE_TEXT = {
    "technical_solution": "技术方案",
    "contract_acceptance": "合同验收文档",
    "test_outline": "测试大纲和细则",
}

DOCUMENT_REVIEW_PROMPTS = {
    "technical_solution": "\n".join(
        [
            "请从以下维度审查技术方案内容：",
            "1. 功能描述准确性：检查功能边界、输入输出、前置条件、异常流程、权限和依赖是否描述清楚，避免夸大或遗漏关键约束。",
            "2. 术语专业性：检查技术术语、产品名称、接口名称、模块名称是否准确、一致，避免口语化和同一概念多种叫法。",
            "3. 设计合理性：检查方案是否说明架构边界、模块职责、数据流、容错机制、安全性、可扩展性和部署约束。",
            "4. 要求明确性：检查需求、验收标准和测试要求是否可执行、可验证、无歧义，避免“尽快、友好、高效、支持多种”等不可验收表述。",
            "请优先指出影响理解、实现、验收或交付风险的问题，并给出可直接落地的修改建议。",
        ]
    ),
    "contract_acceptance": "\n".join(
        [
            "请从以下维度审查合同验收文档内容：",
            "1. 验收范围：检查验收对象、交付边界、版本范围、排除项和依赖条件是否明确。",
            "2. 验收证据：检查是否明确交付物清单、测试记录、签署材料、问题闭环记录和可追溯证明。",
            "3. 判定标准：检查通过/不通过标准、缺陷等级、整改时限、复验方式和例外处理是否可执行。",
            "4. 合同一致性：检查文档表述是否与合同条款、技术协议、变更单和项目范围保持一致。",
            "5. 风险闭环：检查遗留问题、限制条件、责任归属和后续计划是否清楚，避免留下验收争议。",
            "请优先指出可能影响验收签署、责任划分或后续交付的风险，并给出可落地修改建议。",
        ]
    ),
    "test_outline": "\n".join(
        [
            "请从以下维度审查测试大纲和细则内容：",
            "1. 测试范围：检查测试对象、版本、环境、接口、模块边界和不测范围是否明确。",
            "2. 测试目标：检查测试目标是否与需求、设计、验收标准对应，是否覆盖关键业务路径和异常场景。",
            "3. 用例完整性：检查前置条件、输入数据、操作步骤、预期结果、判定准则和清理步骤是否可复现。",
            "4. 覆盖充分性：检查功能、性能、安全、兼容、异常、边界值和回归测试是否按风险分层覆盖。",
            "5. 缺陷闭环：检查缺陷记录、等级划分、复测策略、通过条件和测试报告输出是否明确。",
            "请优先指出会导致测试不可执行、不可复现、不可验收或覆盖不足的问题，并给出可落地修改建议。",
        ]
    ),
}

DEFAULT_DOCUMENT_REVIEW_PROMPT = DOCUMENT_REVIEW_PROMPTS["technical_solution"]


def build_rewrite_prompt(
    text: str,
    mode: str,
    user_instruction: str = "",
    style: str = "default",
    focus: str = "default",
    length: str = "default",
) -> str:
    mode_text = "续写" if mode == "continue" else "改写"
    lines = [
        "你是一名企业办公文档助手。",
        "请对下面内容进行{0}。".format(mode_text),
        "要求：",
        "1. 保留原意，不编造事实。",
        "2. {0}。".format(STYLE_TEXT.get(style, STYLE_TEXT["standard"])),
        "3. {0}。".format(FOCUS_TEXT.get(focus, FOCUS_TEXT["complete"])),
        "4. {0}。".format(LENGTH_TEXT.get(length, LENGTH_TEXT["same"])),
        "5. 输出结果直接给出正文，不要解释你的处理过程。",
        "6. 不要原样返回待处理内容；如果原文已经较好，也必须在措辞、结构或信息组织上做出有效优化。",
    ]

    if user_instruction.strip():
        lines.extend(
            [
                "",
                "用户附加要求：",
                user_instruction.strip(),
            ]
        )

    lines.extend(
        [
            "",
            "待处理内容：",
            text.strip(),
        ]
    )
    return "\n".join(lines)


def build_smart_write_prompt(
    text: str,
    action: str,
    user_prompt: str = "",
    style: str = "default",
    focus: str = "default",
    length: str = "default",
    writing_policy_block: str = "",
) -> str:
    action_text = {
        "rewrite": "改写润色",
        "continue": "续写扩展",
        "summarize": "提炼总结",
        "custom": "自定义编写",
    }.get(action, "改写润色")
    lines = [
        "你是企业办公文档智能编写助手。",
        "任务类型：{0}".format(action_text),
        "表达风格：{0}".format(STYLE_TEXT.get(style, STYLE_TEXT["standard"])),
        "侧重点：{0}".format(FOCUS_TEXT.get(focus, FOCUS_TEXT["complete"])),
        "篇幅要求：{0}".format(LENGTH_TEXT.get(length, LENGTH_TEXT["same"])),
    ]
    if user_prompt.strip():
        lines.extend(["用户补充要求：", user_prompt.strip()])
    if writing_policy_block.strip():
        lines.extend(["", writing_policy_block.strip()])
    lines.extend(
        [
            "",
            "待处理原文：",
            text.strip(),
            "",
            "要求：",
            "1. 必须基于待处理原文生成新内容。",
            "2. 不允许原样返回原文。",
            "3. 保持待处理原文的段落数量和换行结构，适合直接替换用户选中的段落。",
            "4. 如果原文有多个段落，输出也应保留相近分段；不要把连续多个段落压成一整段。",
            "5. 原文已有标题、列表、序号、表格或强调格式时，应尽量保持对应结构和层级。",
            "6. 不要额外新增原文没有、用户也未要求的 Markdown 标题、项目符号、编号列表或表格。",
            "7. 只输出最终正文，不要解释处理过程。",
        ]
    )
    return "\n".join(lines)


def build_smart_imitation_prompt(
    template_text: str,
    requirement: str,
    reference_material: str = "",
    writing_policy_block: str = "",
) -> str:
    reference_text = reference_material.strip() or "未提供参考素材。"
    lines = ["你是企业办公文档智能仿写助手。"]
    if writing_policy_block.strip():
        lines.extend(["", writing_policy_block.strip()])
    lines.extend(
        [
            "",
            "仿写模板：",
            template_text.strip(),
            "",
            "仿写需求：",
            requirement.strip(),
            "",
            "参考素材：",
            reference_text,
            "",
            "要求：",
            "1. 学习仿写模板的句式、层次、表达节奏和段落结构。",
            "2. 生成内容必须服务于仿写需求。",
            "3. 如提供参考素材，应优先基于参考素材，不编造事实、数据、结论或机构名称。",
            "4. 不要照抄模板中的具体事实、对象、项目名称或数字，除非用户明确要求保留。",
            "5. 尽量保持模板的段落数量、标题层级、列表结构和语气风格。",
            "6. 只输出仿写后的正文，不解释仿写过程。",
        ]
    )
    return "\n".join(lines)


def _provider_safe_str(value) -> str:
    if value is None:
        return ""
    if isinstance(value, (str, int, float, bool)):
        return str(value)
    return ""


def build_excel_analysis_prompt(request: ExcelAnalysisRequest) -> str:
    headers = ", ".join(request.table.headers) if request.table.headers else "未识别到表头"
    sample_lines = []
    for row in request.table.rows[:30]:
        sample_lines.append(" | ".join(_provider_safe_str(cell) for cell in row))
    sample_text = "\n".join(sample_lines) if sample_lines else "无可用样本行。"
    requirement = request.options.analysis_requirement.strip() or "请基于表格数据生成通用分析报告。"
    truncated_text = "是，数据已截断，只能基于样本和统计信息分析。" if request.table.truncated else "否。"
    scope_type_text = "选区" if request.scope.scope_type == "selection" else "当前工作表已用区域"
    return "\n".join(
        [
            "你是企业表格数据分析助手。",
            "请基于用户提交的 WPS 表格数据生成中文分析报告。",
            "",
            "工作簿：{0}".format(request.workbook_id),
            "工作表：{0}".format(request.scope.sheet_name or "未命名工作表"),
            "范围：{0}".format(request.scope.address or "未识别"),
            "范围类型：{0}".format(scope_type_text),
            "行数：{0}".format(request.table.row_count),
            "列数：{0}".format(request.table.column_count),
            "数据已截断：{0}".format(truncated_text),
            "表头：{0}".format(headers),
            "",
            "用户分析要求：",
            requirement,
            "",
            "样本数据：",
            sample_text,
            "",
            "输出要求：",
            "1. 只基于表格数据和用户分析要求，不编造不存在的事实、原因、结论或数据。",
            "2. 默认输出一个 JSON 对象，字段为 structuredReport 和 plainText。",
            "3. structuredReport 包含 overview、findings、risks、actions。",
            "4. findings、risks、actions 均为字符串数组。",
            "5. plainText 为可直接复制到 Word 或 PPT 的中文汇报段落。",
            "6. 如果数据已截断，必须说明分析基于有限样本。",
            "7. 不要输出公式，不要声称已经修改单元格，不要要求前端自动写回 Excel。",
        ]
    )


def build_excel_formula_prompt(request: ExcelFormulaAssistantRequest) -> str:
    selection = request.selection
    mode = request.options.mode
    cell_lines = []
    for row in selection.cells:
        items = []
        for cell in row:
            item = "{0}: text={1}; type={2}".format(
                cell.address or "未识别地址",
                cell.text,
                cell.value_type,
            )
            if cell.formula:
                item += "; formula={0}".format(cell.formula)
            items.append(item)
        if items:
            cell_lines.append(" | ".join(items))
    mode_lines = (
        [
            "当前模式：解释排错。",
            "解释选区中的已有公式，逐项说明组件和引用范围，并仅在有明确依据时给出修正公式。",
            "originalFormula 必须引用选区中真实存在的原公式；primaryFormula 是建议保留或修正后的主公式。",
        ]
        if mode == "explain"
        else [
            "当前模式：生成公式。",
            "只根据用户明确框选的 WPS 表格上下文和计算需求推荐公式。",
        ]
    )
    return "\n".join(
        [
            "你是企业表格公式助手。",
        ]
        + mode_lines
        + [
            "",
            "工作簿：{0}".format(request.workbook_id),
            "工作表：{0}".format(selection.sheet_name or "未命名工作表"),
            "明确选区：{0}".format(selection.address),
            "原始行列：{0} 行 × {1} 列".format(
                selection.row_count,
                selection.column_count,
            ),
            "上下文已截断：{0}".format("是" if selection.truncated else "否"),
            "表头：{0}".format(", ".join(selection.headers) or "未识别到表头"),
            "",
            "用户补充要求：",
            request.options.requirement or "无补充要求",
            "",
            "单元格上下文：",
            "\n".join(cell_lines) or "无可用单元格上下文。",
            "",
            "输出要求：",
            "1. 只输出一个 JSON 对象，不输出深度思考过程。",
            "2. 字段固定为 mode、originalFormula、primaryFormula、alternativeFormula、suggestedTarget、explanation、components、referenceRanges、issues、assumptions、compatibilityNotes。",
            "3. primaryFormula 必须是一个以 = 开头的主推荐公式；不要返回多个并列主方案。",
            "4. alternativeFormula 最多一个，且仅在与 primaryFormula 确有差异并有明确依据时返回，否则返回空字符串。",
            "5. suggestedTarget 说明建议放置的单元格或范围；无法可靠判断时明确说明需用户确认。",
            "6. explanation 用通俗中文解释整体逻辑；components、referenceRanges、issues、assumptions 和 compatibilityNotes 均为字符串数组。",
            "7. 如上下文已截断，必须在 assumptions 中说明只基于截断后的选区上下文。",
            "8. 不声称已经写入单元格，不要求前端自动填充范围、创建工作表或修改计算模式。",
            "9. 不编造未出现在选区中的列、地址、业务事实或计算规则；不声称静态检查能够证明公式或计算结果正确。",
        ]
    )


def build_ppt_slide_prompt(context: Dict, user_instruction: str, mode: str) -> str:
    text_blocks = context.get("textBlocks") or context.get("text_blocks") or []
    if not isinstance(text_blocks, list):
        text_blocks = []
    body = "\n".join(
        _provider_safe_str(item).strip()
        for item in text_blocks
        if _provider_safe_str(item).strip()
    )
    mode_text = "优化当前页已有内容" if mode == "optimize" else "根据当前页信息和补充要求生成本页内容"
    return "\n".join(
        [
            "你是企业汇报材料 PPT 单页内容助手。",
            "任务模式：{0}。".format(mode_text),
            "",
            "当前页序号：{0}".format(context.get("index", 1)),
            "当前页主标题：{0}".format(_provider_safe_str(context.get("title")).strip() or "未识别"),
            "当前页副标题：{0}".format(_provider_safe_str(context.get("subtitle")).strip() or "无"),
            "前一页主标题：{0}".format(
                _provider_safe_str(context.get("previousTitle") or context.get("previous_title")).strip() or "无"
            ),
            "后一页主标题：{0}".format(
                _provider_safe_str(context.get("nextTitle") or context.get("next_title")).strip() or "无"
            ),
            "当前页内容已截断：{0}".format("是" if context.get("truncated") else "否"),
            "",
            "用户补充要求：",
            _provider_safe_str(user_instruction).strip() or "无",
            "",
            "当前页正文：",
            body or "无有效正文",
            "",
            "输出要求：",
            "1. 只输出建议标题、核心要点和本页结论。",
            "2. 核心要点必须为 3 至 5 条。",
            "3. 不输出配色、版式、图标、图片、动画或页面操作建议。",
            "4. 不声称已经修改 PPT，不输出深度思考过程。",
            "5. 前后页标题只用于避免重复和保持衔接，不扩写相邻页面。",
            "6. 使用固定 Markdown 分区：## 建议标题、## 核心要点、## 本页结论。",
            "7. 不编造当前页和用户补充要求中没有的事实、数据、进度或结论。",
        ]
    )


def build_ppt_document_prompt(requested_slide_count: int, user_instruction: str = "") -> str:
    slide_count = _normalize_ppt_document_slide_count(requested_slide_count)
    return "\n".join(
        [
            "你是企业汇报材料智能总结助手。模型后台已收到一份文档附件。",
            "请根据附件内容生成整套 PPT 方案，不得声称已经创建或修改幻灯片。",
            "建议页数：{0}".format(slide_count),
            "用户补充要求：{0}".format(_provider_safe_str(user_instruction).strip() or "无"),
            "只返回 JSON 对象，字段固定为 deckTitle、documentSummary、recommendedSlideCount、slides、globalStyleAdvice、plainText。",
            "slides 每项固定包含 index、role、title、subtitle、bullets、conclusion、layoutSuggestion、visualSuggestion。",
            "subtitle 和 conclusion 可为空；bullets 每页 2 至 5 条；不得编造附件中不存在的事实和数据；不得输出深度思考过程。",
        ]
    )


def build_ppt_structure_review_prompt(request: PptStructureReviewRequest) -> str:
    scope = request.scope
    slide_lines = []
    for slide in request.slides:
        line = "第 {0} 页 | 主标题：{1} | 副标题：{2}".format(
            slide.index,
            slide.title or "未识别",
            slide.subtitle or "无",
        )
        if slide.body_fallback:
            line += " | 无标题页正文兜底：{0}".format(slide.body_fallback)
        elif slide.body_fallback_omitted:
            line += " | 正文兜底：未读取（已达 10 页上限，仅报告信息不足）"
        slide_lines.append(line)
    return "\n".join(
        [
            "你是企业汇报材料 PPT 结构审查助手。",
            "请只基于给定页码、主标题、可选副标题和少量无标题页正文，审查叙事结构。",
            "审查范围：第 {0}-{1} 页；演示文稿共 {2} 页。".format(
                scope.start_slide, scope.end_slide, scope.total_slides
            ),
            "",
            "页面结构：",
            "\n".join(slide_lines),
            "",
            "输出要求：",
            "1. 只输出一个 JSON 对象，不输出深度思考过程。",
            "2. 字段固定为 overallStoryline、inferredChapters、highPriorityIssues、generalSuggestions、slideRecommendations、recommendedOutline。",
            "3. inferredChapters 每项包含 title、startSlide、endSlide。",
            "4. highPriorityIssues 和 generalSuggestions 每项包含 code、message、slideNumbers；slideNumbers 必须可追溯到本次范围。",
            "5. slideRecommendations 每项包含 slideNumber、suggestion；recommendedOutline 每项包含 order、title、slideNumbers。",
            "6. 评估整体主线、推断章节、页面顺序、内容重复和内容缺口；不要重复报告同一问题。",
            "7. 不返回数值总分，不声称已经创建、删除、重排或修改幻灯片。",
            "8. 不编造输入中没有的事实、数据、进度或结论。",
            "9. 标记正文兜底未读取的页面只报告信息不足，不推断该页内容或提出内容建议。",
        ]
    )


def get_default_document_review_prompt(document_type: str = "technical_solution") -> str:
    return DOCUMENT_REVIEW_PROMPTS.get(document_type, DEFAULT_DOCUMENT_REVIEW_PROMPT)


def build_document_review_prompt(
    text: str,
    document_type: str,
    review_prompt: str = "",
    writing_policy_block: str = "",
) -> str:
    prompt_text = review_prompt.strip() or get_default_document_review_prompt(document_type)
    document_type_text = DOCUMENT_TYPE_TEXT.get(document_type, "技术方案")
    lines = [
        "你是一名企业文档审查专家。",
        "请审查下面的文档内容，重点发现错别字、语言逻辑表达、通畅性和对应文档类型的专业性问题。",
        "文档类型：{0}".format(document_type_text),
        "",
        "审查重点：",
        prompt_text,
        "",
        "输出要求：",
        "1. 只返回一个 Markdown json 代码块，不要输出代码块以外的解释性文字。",
        "2. json 顶层字段为 summary 和 issues。",
        "3. issues 为数组，每项包含 category、severity、location、originalText、problem、suggestion、suggestedRewrite。",
        "4. category 只能使用 typo、expression、logic、fluency、professional。",
        "5. severity 只能使用 high、medium、low。",
        "6. location 可用章节名、段落号或“选中文本”描述；无法定位时写“未定位”。",
        "7. suggestedRewrite 只针对可直接替换的局部文本给出，无法直接改写时留空字符串。",
        "8. 不要检查字体、字号、行距、页边距等格式合规问题。",
        "9. 只输出本次审查发现的问题列表；不要输出前端处理状态、复制动作或处理记录。",
    ]
    if writing_policy_block.strip():
        lines.extend(["", writing_policy_block.strip()])
    lines.extend(
        [
            "",
            "待审查内容：",
            text.strip(),
        ]
    )
    return "\n".join(lines)


def infer_payload_style(path: str, provider_type: str = "") -> str:
    normalized = (path or "").rstrip("/")
    if normalized.endswith("/workflows/run"):
        return "workflow"
    if normalized.endswith("/chat-messages"):
        return "chat"
    if provider_type == "enterprise-dify-workflow":
        return "workflow"
    return "chat"


def is_workflow_provider(settings: AppSettings) -> bool:
    return infer_payload_style(settings.provider_chat_path, settings.provider_type) == "workflow"


def build_provider_request_payload(
    settings: AppSettings,
    input_data: Dict,
    query: str,
    input_mode: str = DIFY_INPUT_MODE_LEGACY,
    files: Optional[List[Dict]] = None,
    response_mode: Optional[str] = None,
) -> Dict:
    inputs = {"query": query} if input_mode == DIFY_INPUT_MODE_LEGACY else {}
    return {
        "inputs": inputs,
        "query": query,
        "conversation_id": "",
        "response_mode": response_mode or settings.provider_mode,
        "user": "wps-ai-assistant",
        "files": list(files or []),
    }


def encode_dify_file_upload(content: bytes, extension: str, mime_type: str) -> Tuple[bytes, str]:
    safe_extension = str(extension or "").strip().lower().lstrip(".")
    if safe_extension not in ("md", "docx", "png"):
        raise ValueError("Unsupported PPT document extension.")
    safe_mime_type = str(mime_type or "").strip()
    if not safe_mime_type or "\r" in safe_mime_type or "\n" in safe_mime_type:
        safe_mime_type = "application/octet-stream"
    boundary = "----ai-wps-{0}".format(uuid.uuid4().hex)
    chunks = [
        (
            "--{0}\r\n"
            "Content-Disposition: form-data; name=\"user\"\r\n\r\n"
            "wps-ai-assistant\r\n"
        ).format(boundary).encode("utf-8"),
        (
            "--{0}\r\n"
            "Content-Disposition: form-data; name=\"file\"; filename=\"source.{1}\"\r\n"
            "Content-Type: {2}\r\n\r\n"
        ).format(boundary, safe_extension, safe_mime_type).encode("utf-8"),
        bytes(content),
        "\r\n--{0}--\r\n".format(boundary).encode("ascii"),
    ]
    return b"".join(chunks), "multipart/form-data; boundary={0}".format(boundary)


def build_route_request_payload(settings: AppSettings, route: TaskRoute, input_data: Dict, query: str) -> Dict:
    response_mode = route.response_mode or settings.provider_mode
    return {
        "inputs": {"query": query},
        "query": query,
        "conversation_id": "",
        "response_mode": response_mode,
        "user": "wps-ai-assistant",
        "files": [],
    }


def _preview_text(value: str, limit: int = 4) -> str:
    text = (value or "").replace("\r", " ").replace("\n", " ").strip()
    if not text:
        return ""
    return text[:limit] + "..."


def _provider_input_mode_cache_key(
    settings: AppSettings,
    task_type: str,
    api_key_ref: str,
    provider_base_url: str = "",
    provider_chat_path: str = "",
) -> str:
    return "|".join(
        [
            provider_base_url or settings.provider_base_url.rstrip("/"),
            provider_chat_path or settings.provider_chat_path or "/chat-messages",
            task_type,
            api_key_ref,
        ]
    )


def _sanitize_provider_error_body(
    raw: str,
    query: str = "",
    api_key: str = "",
    limit: int = 480,
) -> str:
    del query, api_key
    raw_text = str(raw or "")
    byte_length = len(raw_text.encode("utf-8", errors="replace"))
    try:
        parsed = json.loads(raw_text)
    except (TypeError, json.JSONDecodeError):
        sanitized = json.dumps(
            {
                "summary": "provider_error_body_redacted",
                "byteLength": byte_length,
            },
            separators=(",", ":"),
        )
    else:
        sanitized_fields = {}
        if isinstance(parsed, dict):
            for field in ("code", "status", "type"):
                value = parsed.get(field)
                if isinstance(value, bool):
                    continue
                if isinstance(value, (str, int)):
                    identifier = str(value)
                    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,63}", identifier):
                        sanitized_fields[field] = identifier
        sanitized_fields["message"] = "[redacted]"
        sanitized = json.dumps(
            sanitized_fields,
            ensure_ascii=False,
            separators=(",", ":"),
        )
    return str(sanitized)[:limit]


def _read_http_error_raw_result(exc: error.HTTPError, control=None) -> Tuple[str, bool]:
    cancel_callback = None
    if control is not None and hasattr(control, "set_cancel_callback") and hasattr(control, "clear_cancel_callback"):
        def interrupt_error_read():
            response = getattr(exc, "fp", None)
            raw = getattr(getattr(response, "fp", None), "raw", None)
            response_socket = getattr(raw, "_sock", None)
            if response_socket is not None:
                try:
                    response_socket.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                response_socket.close()
            else:
                exc.close()
        cancel_callback = interrupt_error_read
        control.set_cancel_callback(cancel_callback)
    try:
        preview = exc.read(4096)
        has_more = bool(exc.read(4096))
        return preview.decode("utf-8", errors="replace"), not has_more
    except Exception:
        return "", False
    finally:
        if cancel_callback is not None:
            control.clear_cancel_callback(cancel_callback)


def _read_http_error_raw(exc: error.HTTPError) -> str:
    raw, _complete = _read_http_error_raw_result(exc)
    return raw


def _read_http_error_body(
    exc: error.HTTPError,
    query: str = "",
    api_key: str = "",
    limit: int = 480,
) -> str:
    raw = _read_http_error_raw(exc)
    return _sanitize_provider_error_body(
        raw,
        query=query,
        api_key=api_key,
        limit=limit,
    )


def _response_format_is_explicitly_unsupported(raw: str) -> bool:
    text = str(raw or "").lower()
    names_extension = "response_format" in text or "json_schema" in text
    rejects_extension = any(
        marker in text
        for marker in (
            "not supported",
            "unsupported",
            "unknown field",
            "unknown parameter",
            "unrecognized",
            "extra inputs are not permitted",
            "不支持",
            "未知字段",
            "未知参数",
        )
    )
    return names_extension and rejects_extension


def _should_retry_without_response_format(
    status: int,
    response_format: Optional[Dict],
    allow_fallback: bool,
    raw_error_body: str,
) -> bool:
    if response_format is None or not allow_fallback:
        return False
    if status in (502, 503):
        return True
    return status == 400 and _response_format_is_explicitly_unsupported(raw_error_body)


def _sanitize_provider_body(body: Dict) -> Dict:
    inputs = body.get("inputs") if isinstance(body.get("inputs"), dict) else {}
    query = str(body.get("query", "") or "")
    result = {
        "bodyKeys": sorted(body.keys()),
        "inputsKeys": sorted(inputs.keys()),
        "queryLength": len(query),
        "responseMode": body.get("response_mode", body.get("mode", "")),
        "conversationIdSet": bool(body.get("conversation_id")),
        "filesCount": len(body.get("files") or []),
        "user": body.get("user", ""),
    }

    if isinstance(body.get("messages"), list):
        messages = body["messages"]
        result["queryLength"] = sum(len(m.get("content", "")) if isinstance(m.get("content"), str)
                                    else sum(len(str(p.get("text") or "")) for p in (m.get("content") or []) if isinstance(p, dict) and p.get("type") == "text")
                                    for m in messages if isinstance(m, dict) and m.get("role") == "user")
        result["messageCount"] = len(messages)
        result["stream"] = body.get("stream") is True
        result["maxOutputTokens"] = body.get("max_tokens")
        result["modelName"] = str(body.get("model") or "")
    return result


def _summarize_answer_format(answer: str) -> Dict:
    value = str(answer or "")
    features = {
        "containsHeading": bool(re.search(r"(?m)^\s{0,3}#{1,6}\s+\S", value)),
        "containsOrderedList": bool(re.search(r"(?m)^\s*\d+\.\s+\S", value)),
        "containsUnorderedList": bool(re.search(r"(?m)^\s*[-*+]\s+\S", value)),
        "containsBold": bool(re.search(r"\*\*[^*\n]+\*\*", value)),
        "containsParagraphBreak": "\n\n" in value,
    }
    return {
        "containsMarkdown": any(features.values()),
        **features,
    }


def _sanitize_provider_response(body: Dict) -> Dict:
    answer = str(body.get("answer", "") or "") if isinstance(body, dict) else ""
    data = body.get("data", {}) if isinstance(body, dict) else {}
    outputs = data.get("outputs", {}) if isinstance(data, dict) else {}
    output_answer = ""
    if isinstance(outputs, dict):
        output_answer = str(outputs.get("answer", outputs.get("result", "")) or "")
    result_answer = answer or output_answer
    sanitized = {
        "bodyKeys": sorted(body.keys()) if isinstance(body, dict) else [],
        "answerLength": len(result_answer),
        "answerFormat": _summarize_answer_format(result_answer),
        "conversationIdSet": bool(body.get("conversation_id")) if isinstance(body, dict) else False,
        "messageIdSet": bool(body.get("message_id") or body.get("id")) if isinstance(body, dict) else False,
    }
    if isinstance(body, dict):
        finish_reason = body.get("finishReason")
        if isinstance(finish_reason, str):
            sanitized["finishReason"] = _safe_finish_reason(finish_reason)
        content_type = body.get("contentType")
        if content_type in {"string", "array", "object", "null", "other"}:
            sanitized["contentType"] = content_type
        if isinstance(body.get("reasoningContentPresent"), bool):
            sanitized["reasoningContentPresent"] = body["reasoningContentPresent"]
        usage = body.get("usage")
        if isinstance(usage, dict):
            safe_usage = {}
            for key in ("promptTokens", "completionTokens", "totalTokens"):
                value = usage.get(key)
                if type(value) is int and value >= 0:
                    safe_usage[key] = value
            if safe_usage:
                sanitized["usage"] = safe_usage
    return sanitized


def _safe_finish_reason(value) -> str:
    finish_reason = str(value or "").strip().lower()
    if finish_reason in {
        "stop",
        "length",
        "content_filter",
        "tool_calls",
        "function_call",
    }:
        return finish_reason
    return "other" if finish_reason else ""


def _direct_response_diagnostics(body: Dict, choice: Dict, message: Dict) -> Dict:
    content = message.get("content") if isinstance(message, dict) else None
    if content is None:
        content_type = "null"
    elif isinstance(content, str):
        content_type = "string"
    elif isinstance(content, list):
        content_type = "array"
    elif isinstance(content, dict):
        content_type = "object"
    else:
        content_type = "other"
    raw_usage = body.get("usage") if isinstance(body, dict) else None
    usage = {}
    if isinstance(raw_usage, dict):
        for source_key, target_key in (
            ("prompt_tokens", "promptTokens"),
            ("completion_tokens", "completionTokens"),
            ("total_tokens", "totalTokens"),
        ):
            value = raw_usage.get(source_key)
            if type(value) is int and value >= 0:
                usage[target_key] = value
    return {
        "finishReason": _safe_finish_reason(choice.get("finish_reason", ""))
        if isinstance(choice, dict)
        else "",
        "contentType": content_type,
        "reasoningContentPresent": bool(
            isinstance(message, dict)
            and (message.get("reasoning_content") or message.get("reasoning"))
        ),
        "usage": usage,
    }


def _missing_final_content_error(finish_reason: str) -> AdapterError:
    if finish_reason == "length":
        return AdapterError(
            "MODEL_FINAL_CONTENT_TOKEN_LIMIT",
            "模型输出 Token 预算已用尽但未返回最终结果，请检查最大输出 Token 与模型支持上限，或在模型服务中关闭深度思考后重试。",
            status_code=502,
        )
    if finish_reason == "content_filter":
        return AdapterError(
            "MODEL_FINAL_CONTENT_FILTERED",
            "模型最终结果被内容策略过滤，请调整输入或检查模型服务策略。",
            status_code=502,
        )
    return AdapterError(
        "MODEL_FINAL_CONTENT_MISSING",
        "模型未返回最终结果，请检查模型推理模式和输出配置。",
        status_code=502,
    )


def reset_provider_debug() -> None:
    with _LAST_PROVIDER_DEBUG_LOCK:
        _LAST_PROVIDER_DEBUG.clear()
        _TRACE_PROVIDER_DEBUG.clear()
        _TRACE_PROVIDER_PERFORMANCE.clear()


def _merge_trace_provider_performance_locked(trace_id: str, debug: Dict) -> None:
    if not trace_id:
        return
    attempt = debug.get("performance")
    if isinstance(attempt, dict):
        total = _TRACE_PROVIDER_PERFORMANCE.setdefault(trace_id, {})
        total["providerAttempts"] = int(total.get("providerAttempts", 0)) + 1
        for name in (
            "providerHeadersMs",
            "providerFirstVisibleMs",
            "providerCompleteMs",
            "parseMs",
        ):
            value = attempt.get(name)
            if isinstance(value, int) and not isinstance(value, bool):
                previous = total.get(name)
                total[name] = (
                    previous + value
                    if isinstance(previous, int) and not isinstance(previous, bool)
                    else value
                )
            elif name not in total:
                total[name] = None
    total = _TRACE_PROVIDER_PERFORMANCE.get(trace_id)
    if total:
        debug["performance"] = deepcopy(total)


def _project_smart_fill_debug(event: Dict) -> Dict:
    debug = {
        "traceId": event.get("traceId", ""),
        "taskType": "excel.smart_fill",
    }
    stage = event.get("stage")
    if isinstance(stage, str) and _PROVIDER_DEBUG_STAGE_RE.fullmatch(stage):
        debug["stage"] = stage
    if "attemptCount" in event:
        debug["attemptCount"] = event["attemptCount"]
    if "compatibilityFallback" in event:
        debug["compatibilityFallback"] = event["compatibilityFallback"]

    perf = event.get("performance")
    if isinstance(perf, dict):
        safe_perf = {}
        for key in ("providerHeadersMs", "providerFirstVisibleMs", "providerCompleteMs", "parseMs"):
            if key in perf:
                val = perf[key]
                if val is None or (isinstance(val, int) and not isinstance(val, bool) and val >= 0):
                    safe_perf[key] = val
        if safe_perf:
            debug["performance"] = safe_perf

    request_info = event.get("request", {})
    if isinstance(request_info, dict):
        body = request_info.get("body", {})
        if isinstance(body, dict):
            req_sanitized = {}
            if "query" in body:
                req_sanitized["queryLength"] = len(str(body.get("query", "") or ""))
            elif "messages" in body and isinstance(body.get("messages"), list):
                user_msg = next(
                    (
                        m.get("content")
                        for m in body.get("messages", [])
                        if isinstance(m, dict) and m.get("role") == "user"
                    ),
                    "",
                )
                req_sanitized["queryLength"] = len(str(user_msg or ""))
            if "response_mode" in body or "mode" in body:
                req_sanitized["responseMode"] = body.get("response_mode", body.get("mode", ""))
            debug["request"] = req_sanitized

    response_info = event.get("response", {})
    if isinstance(response_info, dict) and response_info:
        res_body = response_info.get("body", {})
        res_sanitized = {
            "status": response_info.get("status", 200),
        }
        if isinstance(res_body, dict):
            answer = str(res_body.get("answer", "") or "")
            data = res_body.get("data", {})
            if isinstance(data, dict):
                outputs = data.get("outputs", {})
                if isinstance(outputs, dict):
                    answer = answer or str(outputs.get("answer", outputs.get("result", "")) or "")
            if not answer and "choices" in res_body and isinstance(res_body.get("choices"), list):
                choices = res_body.get("choices")
                if choices and isinstance(choices[0], dict):
                    msg = choices[0].get("message", {})
                    if isinstance(msg, dict):
                        answer = str(msg.get("content", "") or "")
            res_sanitized["answerLength"] = len(answer)
            usage = res_body.get("usage")
            if isinstance(usage, dict):
                safe_usage = {}
                for key in ("promptTokens", "completionTokens", "totalTokens", "prompt_tokens", "completion_tokens", "total_tokens"):
                    v = usage.get(key)
                    if type(v) is int and v >= 0:
                        norm_key = key
                        if key == "prompt_tokens":
                            norm_key = "promptTokens"
                        elif key == "completion_tokens":
                            norm_key = "completionTokens"
                        elif key == "total_tokens":
                            norm_key = "totalTokens"
                        safe_usage[norm_key] = v
                if safe_usage:
                    res_sanitized["usage"] = safe_usage
        debug["response"] = res_sanitized

    error_info = event.get("error", {})
    if isinstance(error_info, dict) and error_info:
        debug["error"] = {
            "type": str(error_info.get("type", "")),
            "status": error_info.get("status", ""),
        }
        if "code" in error_info:
            debug["error"]["code"] = str(error_info.get("code", ""))

    validation_info = event.get("validation", {})
    if isinstance(validation_info, dict) and validation_info:
        debug["validation"] = validation_info

    return debug


def record_provider_debug(event: Dict) -> None:
    if event.get("taskType") == "excel.smart_fill":
        debug = _project_smart_fill_debug(event)
        trace_id = str(debug.get("traceId", "")).strip()
        with _LAST_PROVIDER_DEBUG_LOCK:
            _merge_trace_provider_performance_locked(trace_id, debug)
            _LAST_PROVIDER_DEBUG.clear()
            _LAST_PROVIDER_DEBUG.update(debug)
            if trace_id:
                _TRACE_PROVIDER_DEBUG[trace_id] = deepcopy(debug)
                while len(_TRACE_PROVIDER_DEBUG) > _MAX_TRACE_DEBUG_ITEMS:
                    expired_trace_id = next(iter(_TRACE_PROVIDER_DEBUG))
                    _TRACE_PROVIDER_DEBUG.pop(expired_trace_id, None)
                    _TRACE_PROVIDER_PERFORMANCE.pop(expired_trace_id, None)
        return
    debug = {
        "traceId": event.get("traceId", ""),
        "taskType": event.get("taskType", ""),
        "url": event.get("url", ""),
    }
    perf = event.get("performance")
    if isinstance(perf, dict):
        safe_perf = {}
        for key in ("providerHeadersMs", "providerFirstVisibleMs", "providerCompleteMs", "parseMs"):
            if key in perf:
                val = perf[key]
                if val is None or (isinstance(val, int) and not isinstance(val, bool) and val >= 0):
                    safe_perf[key] = val
        if safe_perf:
            debug["performance"] = safe_perf
    request_info = event.get("request", {})
    if isinstance(request_info, dict):
        body = request_info.get("body", {})
        if isinstance(body, dict):
            debug["request"] = _sanitize_provider_body(body)
    response_info = event.get("response", {})
    if isinstance(response_info, dict) and response_info:
        debug["response"] = {
            "status": response_info.get("status", 200),
            **_sanitize_provider_response(response_info.get("body", {})),
        }
    error_info = event.get("error", {})
    if isinstance(error_info, dict) and error_info:
        debug["error"] = {
            "type": str(error_info.get("type", "")),
            "status": error_info.get("status", ""),
            "message": _preview_text(str(error_info.get("message", "")), 160),
        }
        if "bodyPreview" in error_info:
            debug["error"]["bodyPreview"] = _sanitize_provider_error_body(
                str(error_info.get("bodyPreview", "")),
                limit=480,
            )
    compatibility_error_info = event.get("compatibilityError", {})
    if isinstance(compatibility_error_info, dict) and compatibility_error_info:
        debug["compatibilityError"] = {
            "type": str(compatibility_error_info.get("type", "")),
            "status": compatibility_error_info.get("status", ""),
            "message": _preview_text(
                str(compatibility_error_info.get("message", "")),
                160,
            ),
        }
        if "bodyPreview" in compatibility_error_info:
            debug["compatibilityError"]["bodyPreview"] = (
                _sanitize_provider_error_body(
                    str(compatibility_error_info.get("bodyPreview", "")),
                    limit=480,
                )
            )
    validation_info = event.get("validation", {})
    if isinstance(validation_info, dict) and validation_info:
        debug["validation"] = validation_info
    stage = event.get("stage")
    if isinstance(stage, str) and _PROVIDER_DEBUG_STAGE_RE.fullmatch(stage):
        debug["stage"] = stage
    for field in (
        "provider",
        "providerName",
        "providerType",
        "skipReason",
        "providerBaseUrlConfigured",
        "authSource",
        "taskAuthSource",
        "taskApiKeyRef",
        "workflowProfileId",
        "workflowProfileName",
        "inputMode",
        "compatibilityFallback",
        "attemptCount",
    ):
        if field in event:
            debug[field] = event[field]
    with _LAST_PROVIDER_DEBUG_LOCK:
        trace_id = str(debug.get("traceId", "")).strip()
        if event.get("taskType") == "ppt.material_outline" and "request" not in event:
            previous = _TRACE_PROVIDER_DEBUG.get(trace_id, {})
            if previous.get("request"):
                debug["request"] = deepcopy(previous["request"])
        _merge_trace_provider_performance_locked(trace_id, debug)
        _LAST_PROVIDER_DEBUG.clear()
        _LAST_PROVIDER_DEBUG.update(debug)
        if trace_id:
            _TRACE_PROVIDER_DEBUG[trace_id] = deepcopy(debug)
            while len(_TRACE_PROVIDER_DEBUG) > _MAX_TRACE_DEBUG_ITEMS:
                expired_trace_id = next(iter(_TRACE_PROVIDER_DEBUG))
                _TRACE_PROVIDER_DEBUG.pop(expired_trace_id, None)
                _TRACE_PROVIDER_PERFORMANCE.pop(expired_trace_id, None)


def merge_provider_debug(trace_id: str, patch: Dict) -> None:
    if not isinstance(patch, dict):
        return

    sanitized = {}
    for field in _WRITING_POLICY_DEBUG_BOOLEAN_FIELDS:
        value = patch.get(field)
        if isinstance(value, bool):
            sanitized[field] = value
    for field in _WRITING_POLICY_DEBUG_COUNT_FIELDS:
        value = patch.get(field)
        if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
            sanitized[field] = value

    if "writingPolicyErrorCode" in patch:
        error_code = patch.get("writingPolicyErrorCode")
        if error_code == "" or (
            isinstance(error_code, str)
            and _WRITING_POLICY_ERROR_CODE_RE.fullmatch(error_code)
        ):
            sanitized["writingPolicyErrorCode"] = error_code

    item_ids = patch.get("writingPolicyItemIds")
    if isinstance(item_ids, (list, tuple)):
        safe_ids = []
        for item_id in item_ids:
            if len(safe_ids) >= _MAX_WRITING_POLICY_DEBUG_ITEM_IDS:
                break
            if isinstance(item_id, str) and _WRITING_POLICY_ITEM_ID_RE.fullmatch(item_id):
                safe_ids.append(item_id)
        sanitized["writingPolicyItemIds"] = safe_ids

    with _LAST_PROVIDER_DEBUG_LOCK:
        if _LAST_PROVIDER_DEBUG.get("traceId") == trace_id:
            _LAST_PROVIDER_DEBUG.update(sanitized)
        if trace_id in _TRACE_PROVIDER_DEBUG:
            _TRACE_PROVIDER_DEBUG[trace_id].update(sanitized)


def get_last_provider_debug(trace_id: Optional[str] = None) -> Dict:
    with _LAST_PROVIDER_DEBUG_LOCK:
        if trace_id:
            return deepcopy(_TRACE_PROVIDER_DEBUG.get(trace_id, {}))
        return deepcopy(_LAST_PROVIDER_DEBUG)


def _provider_performance_metrics(
    started_at: float,
    headers_at: Optional[float] = None,
    completed_at: Optional[float] = None,
    parsed_at: Optional[float] = None,
    parse_ms: Optional[int] = None,
    first_visible_at: Optional[float] = None,
    first_visible_ms: Optional[int] = None,
) -> Dict:
    calc_first_visible = (
        max(0, int((first_visible_at - started_at) * 1000))
        if first_visible_at is not None
        else first_visible_ms
    )
    return {
        "providerHeadersMs": (
            max(0, int((headers_at - started_at) * 1000))
            if headers_at is not None
            else None
        ),
        "providerFirstVisibleMs": calc_first_visible,
        "providerCompleteMs": (
            max(0, int((completed_at - started_at) * 1000))
            if completed_at is not None
            else None
        ),
        "parseMs": (
            max(0, int((parsed_at - completed_at) * 1000))
            if parsed_at is not None and completed_at is not None
            else parse_ms
        ),
    }


def _publish_provider_performance(progress_callback, metrics: Dict) -> None:
    attempt_recorder = getattr(progress_callback, "record_provider_attempt", None)
    if callable(attempt_recorder):
        attempt_recorder(metrics)
        return
    recorder = getattr(progress_callback, "record_metric", None)
    if callable(recorder):
        for key, value in metrics.items():
            recorder(key, value)


def _extract_json_payload(answer: str):
    raw = (answer or "").strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    fence = re.search(r"```(?:json)?\s*(.*?)```", raw, re.IGNORECASE | re.DOTALL)
    if fence:
        try:
            return json.loads(fence.group(1).strip())
        except json.JSONDecodeError:
            pass

    object_start = raw.find("{")
    array_start = raw.find("[")
    if array_start >= 0 and (object_start < 0 or array_start < object_start):
        array_end = raw.rfind("]")
        if array_end >= array_start:
            try:
                return json.loads(raw[array_start:array_end + 1])
            except json.JSONDecodeError:
                return None

    object_end = raw.rfind("}")
    if object_start >= 0 and object_end >= object_start:
        try:
            return json.loads(raw[object_start:object_end + 1])
        except json.JSONDecodeError:
            pass

    if array_start >= 0:
        array_end = raw.rfind("]")
        if array_end >= array_start:
            try:
                return json.loads(raw[array_start:array_end + 1])
            except json.JSONDecodeError:
                return None
    return None


def _extract_document_review_payload_text(payload: Dict) -> str:
    if not isinstance(payload, dict):
        return ""
    for key in ("result", "answer", "text", "output", "content", "message"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    outputs = payload.get("outputs")
    if isinstance(outputs, dict):
        return _extract_document_review_payload_text(outputs)
    return ""


def _document_review_parse_fallback(raw_answer: str, reason: str, fallback_text: str = "") -> Dict:
    raw_text = (fallback_text or raw_answer or "").strip()
    return {
        "summary": "模型后台已返回内容，但未解析为标准问题列表；下方显示原始回复。",
        "issues": [],
        "rawAnswer": raw_text,
        "parseFallbackReason": reason,
    }


def _normalize_document_review_category(value: str) -> str:
    text = str(value or "").strip().lower()
    if text in {"typo", "expression", "logic", "fluency", "professional"}:
        return text
    if "错" in text or "别字" in text or "typo" in text:
        return "typo"
    if "逻辑" in text or "logic" in text or "因果" in text or "矛盾" in text:
        return "logic"
    if "通畅" in text or "通顺" in text or "fluency" in text:
        return "fluency"
    if "专业" in text or "术语" in text or "professional" in text:
        return "professional"
    return "expression"


def _normalize_review_severity(value: str) -> str:
    text = str(value or "").strip().lower()
    if text in {"high", "medium", "low"}:
        return text
    if text in {"高", "严重", "critical", "error"}:
        return "high"
    if text in {"低", "提示", "info"}:
        return "low"
    return "medium"


def parse_document_review_answer(answer: str) -> Dict:
    raw_answer = (answer or "").strip()
    payload = _extract_json_payload(answer)
    if payload is None:
        if raw_answer:
            return _document_review_parse_fallback(raw_answer, "non_json_answer")
        return {"summary": "", "issues": [], "rawAnswer": "", "parseFallbackReason": ""}

    if isinstance(payload, list):
        raw_issues = payload
        summary = ""
    elif isinstance(payload, dict):
        raw_issues = payload.get("issues", [])
        summary = str(payload.get("summary", "")).strip()
        if not isinstance(raw_issues, list):
            return _document_review_parse_fallback(
                raw_answer,
                "unsupported_json_shape",
                _extract_document_review_payload_text(payload),
            )
        if not raw_issues and not summary:
            fallback_text = _extract_document_review_payload_text(payload)
            if fallback_text:
                return _document_review_parse_fallback(
                    raw_answer,
                    "unsupported_json_shape",
                    fallback_text,
                )
    else:
        return _document_review_parse_fallback(raw_answer, "unsupported_json_shape")

    if not isinstance(raw_issues, list):
        raw_issues = []

    issues = []
    for item in raw_issues:
        if not isinstance(item, dict):
            continue
        problem = str(item.get("problem", "")).strip()
        suggestion = str(item.get("suggestion", "")).strip()
        if not problem and not suggestion:
            continue
        issues.append(
            {
                "category": _normalize_document_review_category(item.get("category", "")),
                "severity": _normalize_review_severity(item.get("severity", "")),
                "location": str(item.get("location", "") or "未定位").strip(),
                "originalText": str(item.get("originalText", "")).strip(),
                "problem": problem or "未说明具体问题。",
                "suggestion": suggestion or "请补充明确、可验证的表述。",
                "suggestedRewrite": str(item.get("suggestedRewrite", "")).strip(),
            }
        )

    if not summary:
        summary = "发现 {0} 项文档审查问题。".format(len(issues)) if issues else "未发现明显文档审查问题。"
    return {
        "summary": summary,
        "issues": issues,
        "rawAnswer": "",
        "parseFallbackReason": "",
    }


def strip_think_tag_content(value: str) -> str:
    return re.sub(
        r"<think\b[^>]*>.*?(?:</think\s*>|$)",
        "",
        str(value or ""),
        flags=re.IGNORECASE | re.DOTALL,
    ).strip()


def extract_answer(body: Dict, output_key: str = "") -> str:
    answer = body.get("answer")
    if isinstance(answer, str) and answer.strip():
        cleaned_answer = strip_think_tag_content(answer)
        if cleaned_answer:
            return cleaned_answer

    data = body.get("data", {})
    if isinstance(data, dict):
        outputs = data.get("outputs")
        if isinstance(outputs, dict):
            keys = [output_key] if output_key else []
            keys.extend(["result", "answer", "text", "output", "rewrittenText"])
            for key in keys:
                value = outputs.get(key)
                if isinstance(value, str) and value.strip():
                    cleaned_value = strip_think_tag_content(value)
                    if cleaned_value:
                        return cleaned_value
                if isinstance(value, (dict, list)):
                    return json.dumps(value, ensure_ascii=False)
        for key in ("answer", "text", "rewrittenText"):
            value = data.get(key)
            if isinstance(value, str) and value.strip():
                cleaned_value = strip_think_tag_content(value)
                if cleaned_value:
                    return cleaned_value

    raise AdapterError(
        "MODEL_FINAL_CONTENT_MISSING",
        "模型未返回最终结果，请检查模型推理模式和输出配置。",
        status_code=502,
    )


def _excel_text_list(value) -> List[str]:
    if not isinstance(value, list):
        return []
    return [_provider_safe_str(item).strip() for item in value if _provider_safe_str(item).strip()]


def parse_excel_analysis_answer(answer: str) -> Dict:
    cleaned = strip_think_tag_content(answer or "").strip()
    payload = _extract_json_payload(cleaned)
    if isinstance(payload, dict):
        report = payload.get("structuredReport") or payload.get("structured_report") or {}
        if not isinstance(report, dict):
            report = {}
        return {
            "structuredReport": {
                "overview": _provider_safe_str(report.get("overview")).strip(),
                "findings": _excel_text_list(report.get("findings")),
                "risks": _excel_text_list(report.get("risks")),
                "actions": _excel_text_list(report.get("actions")),
            },
            "plainText": _provider_safe_str(payload.get("plainText") or payload.get("plain_text") or cleaned).strip(),
        }

    return {
        "structuredReport": {
            "overview": "模型后台已返回表格分析结果，但未按结构化 JSON 输出。",
            "findings": [],
            "risks": [],
            "actions": [],
        },
        "plainText": cleaned,
    }


def parse_excel_formula_answer(answer: str) -> Dict:
    cleaned = strip_think_tag_content(answer or "").strip()
    payload = _extract_json_payload(cleaned)
    if isinstance(payload, dict):
        mode = _provider_safe_str(payload.get("mode")).strip()
        if mode not in {"generate", "explain"}:
            mode = "generate"
        has_primary_formula = (
            "primaryFormula" in payload or "primary_formula" in payload
        )
        raw_primary_formula = (
            payload.get("primaryFormula")
            if "primaryFormula" in payload
            else payload.get("primary_formula")
        )
        primary_formula = _provider_safe_str(raw_primary_formula).strip()
        compatibility_notes = _excel_text_list(
            payload.get("compatibilityNotes")
            or payload.get("compatibility_notes")
        )
        invalid_primary_formula = (
            not isinstance(raw_primary_formula, str)
            or not re.fullmatch(r"=[^\r\n]+", primary_formula)
        )
        parse_diagnostic = ""
        if not has_primary_formula:
            parse_diagnostic = (
                "模型后台结构化结果缺少主公式字段，已保留原始最终结果供复制和人工核对。"
            )
        elif invalid_primary_formula:
            parse_diagnostic = (
                "模型后台结构化结果中的主公式为空或格式无效，已保留原始最终结果供复制和人工核对。"
            )
        if parse_diagnostic:
            primary_formula = ""
            compatibility_notes.append(
                "模型后台未返回单个有效公式，请补充需求后重试并人工核对。"
            )
        alternative_formula = _provider_safe_str(
            payload.get("alternativeFormula") or payload.get("alternative_formula")
        ).strip()
        if (
            not re.fullmatch(r"=[^\r\n]+", alternative_formula)
            or alternative_formula == primary_formula
        ):
            alternative_formula = ""
        return {
            "mode": mode,
            "originalFormula": _provider_safe_str(
                payload.get("originalFormula") or payload.get("original_formula")
            ).strip(),
            "primaryFormula": primary_formula,
            "alternativeFormula": alternative_formula,
            "suggestedTarget": _provider_safe_str(
                payload.get("suggestedTarget") or payload.get("suggested_target")
            ).strip(),
            "explanation": _provider_safe_str(payload.get("explanation")).strip(),
            "components": _excel_text_list(payload.get("components")),
            "referenceRanges": _excel_text_list(
                payload.get("referenceRanges") or payload.get("reference_ranges")
            ),
            "issues": _excel_text_list(payload.get("issues")),
            "assumptions": _excel_text_list(payload.get("assumptions")),
            "compatibilityNotes": compatibility_notes,
            "rawFinalResult": cleaned if parse_diagnostic else "",
            "parseDiagnostic": parse_diagnostic,
            "copyText": cleaned if parse_diagnostic else primary_formula,
        }
    formula_match = re.search(r"(?m)^\s*(=[^\r\n]+)", cleaned)
    primary_formula = formula_match.group(1).strip() if formula_match else ""
    return {
        "mode": "generate",
        "originalFormula": "",
        "primaryFormula": primary_formula,
        "alternativeFormula": "",
        "suggestedTarget": "",
        "explanation": cleaned,
        "components": [],
        "referenceRanges": [],
        "issues": [],
        "assumptions": [],
        "compatibilityNotes": ["模型后台未按结构化 JSON 输出，请人工核对。"],
        "rawFinalResult": cleaned,
        "parseDiagnostic": "模型后台最终结果未按结构化 JSON 输出，已保留原始最终结果供复制和人工核对。",
        "copyText": cleaned,
    }


def _ppt_text_list(value) -> List[str]:
    if not isinstance(value, list):
        return []
    return [_provider_safe_str(item).strip() for item in value if _provider_safe_str(item).strip()]


def _build_ppt_plain_text(title: str, bullets: List[str], conclusion: str) -> str:
    sections = []
    if title:
        sections.append(title)
    if bullets:
        sections.append("\n".join("{0}. {1}".format(index, item) for index, item in enumerate(bullets, 1)))
    if conclusion:
        sections.append(conclusion)
    return "\n\n".join(sections)


def _normalize_ppt_bullet(line: str) -> str:
    return re.sub(r"^\s*(?:[-*+]\s+|\d+[.)、]\s*)", "", line or "").strip()


def parse_ppt_slide_answer(answer: str) -> Dict:
    cleaned = strip_think_tag_content(answer or "").strip()
    payload = _extract_json_payload(cleaned)
    if isinstance(payload, dict):
        title = _provider_safe_str(payload.get("suggestedTitle") or payload.get("suggested_title")).strip()
        bullets = _ppt_text_list(payload.get("bullets"))
        conclusion = _provider_safe_str(payload.get("conclusion")).strip()
        if title or bullets or conclusion:
            return {
                "suggestedTitle": title,
                "bullets": bullets,
                "conclusion": conclusion,
                "plainText": _provider_safe_str(payload.get("plainText") or payload.get("plain_text")).strip()
                or _build_ppt_plain_text(title, bullets, conclusion),
                "rawAnswer": None,
                "parseFallbackReason": None,
            }

    section_matches = list(
        re.finditer(
            r"^\s*#{1,6}\s*(建议标题|核心要点|本页结论)\s*$",
            cleaned,
            flags=re.MULTILINE,
        )
    )
    sections = {}
    for index, match in enumerate(section_matches):
        end = section_matches[index + 1].start() if index + 1 < len(section_matches) else len(cleaned)
        sections[match.group(1)] = cleaned[match.end():end].strip()
    if sections:
        title = next(
            (line.strip() for line in sections.get("建议标题", "").splitlines() if line.strip()),
            "",
        )
        bullets = [
            normalized
            for normalized in (_normalize_ppt_bullet(line) for line in sections.get("核心要点", "").splitlines())
            if normalized
        ]
        conclusion = "\n".join(
            line.strip()
            for line in sections.get("本页结论", "").splitlines()
            if line.strip()
        )
        if title or bullets or conclusion:
            return {
                "suggestedTitle": title,
                "bullets": bullets,
                "conclusion": conclusion,
                "plainText": _build_ppt_plain_text(title, bullets, conclusion),
                "rawAnswer": None,
                "parseFallbackReason": None,
            }

    return {
        "suggestedTitle": "",
        "bullets": [],
        "conclusion": "",
        "plainText": cleaned,
        "rawAnswer": cleaned,
        "parseFallbackReason": "ppt_output_not_structured",
    }


def _normalize_ppt_document_slide_count(value, fallback: int = 10) -> int:
    try:
        slide_count = int(value)
    except (TypeError, ValueError):
        slide_count = 0
    if slide_count in PPT_DOCUMENT_SLIDE_COUNTS:
        return slide_count
    return fallback if fallback in PPT_DOCUMENT_SLIDE_COUNTS else 10


def _ppt_document_text(value) -> str:
    return strip_think_tag_content(_provider_safe_str(value)).strip()


def _ppt_document_text_list(value) -> List[str]:
    if not isinstance(value, list):
        return []
    return [text for text in (_ppt_document_text(item) for item in value) if text]


def _build_ppt_document_plain_text(
    deck_title: str,
    document_summary: str,
    slides: List[Dict],
    global_style_advice: str,
) -> str:
    sections = []
    if deck_title:
        sections.append(deck_title)
    if document_summary:
        sections.append(document_summary)
    for slide in slides:
        slide_lines = ["第 {0} 页：{1}".format(slide["index"], slide.get("title") or "未命名页面")]
        if slide.get("subtitle"):
            slide_lines.append(slide["subtitle"])
        slide_lines.extend("- {0}".format(item) for item in slide.get("bullets", []))
        if slide.get("conclusion"):
            slide_lines.append(slide["conclusion"])
        sections.append("\n".join(slide_lines))
    if global_style_advice:
        sections.append("整体风格建议：{0}".format(global_style_advice))
    return "\n\n".join(sections)


def parse_ppt_document_answer(answer: str, requested_slide_count: int = 10) -> Dict:
    requested_count = _normalize_ppt_document_slide_count(requested_slide_count)
    cleaned = strip_think_tag_content(answer or "").strip()
    payload = _extract_json_payload(cleaned)
    if isinstance(payload, dict):
        slides = []
        raw_slides = payload.get("slides")
        if isinstance(raw_slides, list):
            for item in raw_slides:
                if not isinstance(item, dict):
                    continue
                slides.append(
                    {
                        "index": len(slides) + 1,
                        "role": _ppt_document_text(item.get("role")),
                        "title": _ppt_document_text(item.get("title")),
                        "subtitle": _ppt_document_text(item.get("subtitle")),
                        "bullets": _ppt_document_text_list(item.get("bullets")),
                        "conclusion": _ppt_document_text(item.get("conclusion")),
                        "layoutSuggestion": _ppt_document_text(
                            item.get("layoutSuggestion") or item.get("layout_suggestion")
                        ),
                        "visualSuggestion": _ppt_document_text(
                            item.get("visualSuggestion") or item.get("visual_suggestion")
                        ),
                    }
                )
        deck_title = _ppt_document_text(payload.get("deckTitle") or payload.get("deck_title"))
        document_summary = _ppt_document_text(
            payload.get("documentSummary") or payload.get("document_summary")
        )
        global_style_advice = _ppt_document_text(
            payload.get("globalStyleAdvice") or payload.get("global_style_advice")
        )
        plain_text = _ppt_document_text(payload.get("plainText") or payload.get("plain_text"))
        if deck_title or document_summary or slides or global_style_advice or plain_text:
            return {
                "resultType": "document",
                "deckTitle": deck_title,
                "documentSummary": document_summary,
                "recommendedSlideCount": requested_count,
                "slides": slides,
                "globalStyleAdvice": global_style_advice,
                "plainText": plain_text
                or _build_ppt_document_plain_text(
                    deck_title,
                    document_summary,
                    slides,
                    global_style_advice,
                ),
                "rawAnswer": None,
                "parseFallbackReason": None,
            }

    return {
        "resultType": "document",
        "deckTitle": "",
        "documentSummary": "模型后台已返回结果，但未按结构化 JSON 输出。",
        "recommendedSlideCount": requested_count,
        "slides": [],
        "globalStyleAdvice": "",
        "plainText": cleaned,
        "rawAnswer": cleaned,
        "parseFallbackReason": "模型后台未返回可解析的 PPT 文档总结 JSON。",
    }


def _ppt_structure_dict_list(value) -> List[Dict]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


def parse_ppt_structure_review_answer(answer: str) -> Dict:
    cleaned = strip_think_tag_content(answer or "").strip()
    unclosed_think = re.search(r"<think\b[^>]*>", cleaned, flags=re.IGNORECASE)
    if unclosed_think:
        cleaned = cleaned[: unclosed_think.start()].strip()
    if not cleaned:
        raise AdapterError(
            "MODEL_FINAL_CONTENT_MISSING",
            "模型未返回最终结果，请检查模型推理模式和输出配置。",
            status_code=502,
        )
    payload = _extract_json_payload(cleaned)
    if isinstance(payload, dict):
        storyline = _ppt_document_text(
            payload.get("overallStoryline") or payload.get("overall_storyline")
        )
        chapters = _ppt_structure_dict_list(
            payload.get("inferredChapters") or payload.get("inferred_chapters")
        )
        high = _ppt_structure_dict_list(
            payload.get("highPriorityIssues") or payload.get("high_priority_issues")
        )
        general = _ppt_structure_dict_list(
            payload.get("generalSuggestions") or payload.get("general_suggestions")
        )
        recommendations = _ppt_structure_dict_list(
            payload.get("slideRecommendations") or payload.get("slide_recommendations")
        )
        outline = _ppt_structure_dict_list(
            payload.get("recommendedOutline") or payload.get("recommended_outline")
        )
        if storyline or chapters or high or general or recommendations or outline:
            return {
                "overallStoryline": storyline,
                "inferredChapters": chapters,
                "highPriorityIssues": high,
                "generalSuggestions": general,
                "slideRecommendations": recommendations,
                "recommendedOutline": outline,
                "rawAnswer": None,
                "parseFallbackReason": None,
            }
    return {
        "overallStoryline": "模型后台已返回内容，但未解析为结构化审查结果。",
        "inferredChapters": [],
        "highPriorityIssues": [],
        "generalSuggestions": [],
        "slideRecommendations": [],
        "recommendedOutline": [],
        "rawAnswer": cleaned,
        "parseFallbackReason": "ppt_structure_output_not_structured",
    }


def build_ppt_unconfigured_result(context: Dict, mode: str, prompt: str) -> Dict:
    return {
        "modeUsed": mode,
        "suggestedTitle": context.get("title") or "PPT 单页内容建议",
        "bullets": [
            "已读取当前第 {0} 页内容。".format(context.get("index", 1)),
            "当前尚未配置智能总结工作流。",
            "请在设置页保存并启用 ppt.slide_assistant 的工作流配置。",
        ],
        "conclusion": "完成模型后台配置后，可生成正式的本页标题、要点和结论。",
        "plainText": "当前尚未配置智能总结工作流，请先在设置页完成配置。",
        "rawAnswer": None,
        "parseFallbackReason": None,
        "provider": "mock",
        "prompt": prompt,
    }


def get_local_api_key_path(path: Optional[Path] = None) -> Path:
    return Path(path) if path is not None else resolve_runtime_paths().local_api_key_path


def get_route_api_key_path(api_key_ref: str, base_path: Optional[Path] = None) -> Path:
    safe_ref = "".join(ch for ch in (api_key_ref or "default") if ch.isalnum() or ch in ("-", "_", "."))
    safe_ref = safe_ref or "default"
    if base_path is not None:
        return Path(base_path) / "provider_api_keys" / safe_ref
    return resolve_runtime_paths().api_key_dir / safe_ref


def _write_private_api_key(target: Path, api_key: str) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(str(target.parent), 0o700)
    temporary = target.parent / ".{0}.{1}.tmp".format(target.name, uuid.uuid4().hex)
    descriptor = os.open(
        str(temporary),
        os.O_WRONLY | os.O_CREAT | os.O_EXCL,
        0o600,
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(api_key.strip())
        os.replace(str(temporary), str(target))
        os.chmod(str(target), 0o600)
    finally:
        if temporary.exists():
            temporary.unlink()


def save_local_api_key(api_key: str, path: Optional[Path] = None) -> None:
    target = get_local_api_key_path(path)
    _write_private_api_key(target, api_key)


def clear_local_api_key(path: Optional[Path] = None) -> None:
    target = get_local_api_key_path(path)
    if target.exists():
        target.unlink()


def load_local_api_key(path: Optional[Path] = None) -> str:
    target = get_local_api_key_path(path)
    if not target.exists():
        return ""
    return target.read_text(encoding="utf-8").strip()


def save_route_api_key(api_key_ref: str, api_key: str, base_path: Optional[Path] = None) -> None:
    target = get_route_api_key_path(api_key_ref, base_path)
    _write_private_api_key(target, api_key)


def clear_route_api_key(api_key_ref: str, base_path: Optional[Path] = None) -> None:
    target = get_route_api_key_path(api_key_ref, base_path)
    if target.exists():
        target.unlink()


def load_route_api_key(api_key_ref: str, base_path: Optional[Path] = None) -> str:
    target = get_route_api_key_path(api_key_ref, base_path)
    if not target.exists():
        return ""
    return target.read_text(encoding="utf-8").strip()


def normalize_task_api_key_ref(task_type: str) -> str:
    return "".join(ch if ch.isalnum() else "_" for ch in (task_type or "default")).strip("_") or "default"


_VALIDATION_PROBES = {
    "word.material_composer": '只依据片段 frag-1「信息化处负责部署」编写职责。只返回 JSON：{"paragraphs":[{"text":"信息化处负责部署。","fragmentIds":["frag-1"],"missingItems":[]}]}',
    "word.smart_write": "请将以下文字正式化，只输出最终正文：系统已完成部署。",
    "word.smart_imitation": "模板：项目已完成部署。要求：仿写为系统已完成联调。只输出最终正文。",
    "word.document_review": (
        '请审查“系统应尽快完成联调”。只返回 JSON：'
        '{"summary":"一句话结论","issues":[]}'
    ),
    "excel.analysis": (
        '分析表格：表头为“状态”，数据为“已完成”。只返回 JSON：'
        '{"overview":"概述","findings":[],"risks":[],"actions":[]}'
    ),
    "excel.formula_assistant": (
        '生成 A1 与 B1 求和公式。只返回 JSON：'
        '{"mode":"generate","primaryFormula":"=SUM(A1:B1)",'
        '"alternativeFormula":"","suggestedTarget":"C1","explanation":"求和",'
        '"components":[],"referenceRanges":["A1:B1"],"issues":[],"assumptions":[],"compatibilityNotes":[]}'
    ),
    "excel.smart_fill": (
        '根据来源“已完成”为 item-0001 生成填写值。只返回 JSON：'
        '{"schemaVersion":"excel.smart_fill.v2","items":[{"itemId":"item-0001",'
        '"status":"completed","valueType":"text","value":"已填写"}]}'
    ),
    "ppt.slide_assistant": (
        'sourceMode=currentSlide。标题“项目进展”，正文“已完成部署”。只返回 JSON：'
        '{"suggestedTitle":"项目进展","summary":"已完成部署","keyPoints":[],"layoutAdvice":[],"plainText":"已完成部署"}'
    ),
    "ppt.structure_review": (
        '审查第1页，标题“项目概况”。只返回 JSON：'
        '{"overallStoryline":"项目概况","inferredChapters":[],"highPriorityIssues":[],"generalSuggestions":[],"slideRecommendations":[],"recommendedOutline":[]}'
    ),
}


def _validate_probe_answer(task_type: str, answer: str) -> None:
    if not str(answer or "").strip():
        raise AdapterError("MODEL_FINAL_CONTENT_MISSING", "模型未返回最终结果。", status_code=502)
    if task_type in {"word.smart_write", "word.smart_imitation"}:
        return
    if task_type == "word.material_composer":
        parsed = _extract_json_payload(answer)
        paragraphs = parsed.get("paragraphs") if isinstance(parsed, dict) else None
        if not isinstance(paragraphs, list) or not paragraphs or any(
            not isinstance(item, dict)
            or not isinstance(item.get("text"), str)
            or not item["text"].strip()
            or not isinstance(item.get("fragmentIds"), list)
            or not item["fragmentIds"]
            or not isinstance(item.get("missingItems"), list)
            for item in paragraphs
        ):
            raise AdapterError("MATERIAL_COMPOSER_INVALID_RESULT", "模型未返回有效资料编写结构。", status_code=502)
        return
    parsers = {
        "word.document_review": parse_document_review_answer,
        "excel.analysis": parse_excel_analysis_answer,
        "excel.formula_assistant": parse_excel_formula_answer,
        "excel.smart_fill": lambda value: parse_excel_smart_fill_answer(
            value, expected_item_ids=["item-0001"]
        ),
        "ppt.slide_assistant": parse_ppt_slide_answer,
        "ppt.structure_review": parse_ppt_structure_review_answer,
    }
    parser = parsers.get(task_type)
    if parser is None:
        raise AdapterError("MODEL_CONFIG_TASK_UNSUPPORTED", "不支持的任务类型。", status_code=400)
    parsed = parser(answer)
    if not isinstance(parsed, dict):
        raise AdapterError("MODEL_RESULT_INVALID", "模型返回结果不符合任务契约。", status_code=502)
    if task_type == "excel.formula_assistant":
        primary_formula = str(parsed.get("primaryFormula") or "").strip()
        if parsed.get("parseDiagnostic") or not re.fullmatch(r"=[^\r\n]+", primary_formula):
            raise AdapterError(
                "MODEL_RESULT_INVALID",
                "模型返回结果不符合公式任务契约。",
                status_code=502,
            )


def _full_document_review_chunk_response_format() -> Dict:
    issue_properties = {
        "category": {
            "type": "string",
            "enum": ["typo", "expression", "logic", "fluency", "professional"],
        },
        "severity": {"type": "string", "enum": ["high", "medium", "low"]},
        "anchorId": {"type": "string", "minLength": 1, "maxLength": 96},
        "anchorStart": {"type": "integer", "minimum": 0, "maximum": 120000},
        "originalText": {"type": "string", "minLength": 1, "maxLength": 1000},
        "problem": {"type": "string", "minLength": 1, "maxLength": 2000},
        "suggestion": {"type": "string", "minLength": 1, "maxLength": 3000},
        "suggestedRewrite": {"type": "string", "maxLength": 4000},
    }
    return {
        "type": "json_schema",
        "json_schema": {
            "name": "word_document_review_full_chunk_v2",
            "strict": True,
            "schema": {
                "type": "object",
                "additionalProperties": False,
                "required": [
                    "schemaVersion",
                    "chunkId",
                    "summary",
                    "enumerationStatus",
                    "hasMoreIssues",
                    "facts",
                    "crossChecks",
                    "issues",
                ],
                "properties": {
                    "schemaVersion": {
                        "type": "string",
                        "const": "word.document_review.full.chunk.v2",
                    },
                    "chunkId": {"type": "string", "minLength": 1, "maxLength": 96},
                    "summary": {"type": "string", "maxLength": 4000},
                    "enumerationStatus": {
                        "type": "string",
                        "enum": ["complete", "limited"],
                    },
                    "hasMoreIssues": {"type": "boolean"},
                    "facts": {
                        "type": "array",
                        "maxItems": 80,
                        "items": {
                            "type": "object",
                            "additionalProperties": False,
                            "required": ["factId", "kind", "statement", "anchorIds"],
                            "properties": {
                                "factId": {"type": "string", "minLength": 1, "maxLength": 96},
                                "kind": {"type": "string", "minLength": 1, "maxLength": 48},
                                "statement": {"type": "string", "minLength": 1, "maxLength": 1200},
                                "anchorIds": {
                                    "type": "array",
                                    "minItems": 1,
                                    "maxItems": 8,
                                    "items": {"type": "string", "minLength": 1, "maxLength": 96},
                                },
                            },
                        },
                    },
                    "crossChecks": {
                        "type": "array",
                        "maxItems": 40,
                        "items": {
                            "type": "object",
                            "additionalProperties": False,
                            "required": ["checkId", "statement", "anchorIds"],
                            "properties": {
                                "checkId": {"type": "string", "minLength": 1, "maxLength": 96},
                                "statement": {"type": "string", "minLength": 1, "maxLength": 1200},
                                "anchorIds": {
                                    "type": "array",
                                    "minItems": 1,
                                    "maxItems": 8,
                                    "items": {"type": "string", "minLength": 1, "maxLength": 96},
                                },
                            },
                        },
                    },
                    "issues": {
                        "type": "array",
                        "maxItems": 200,
                        "items": {
                            "type": "object",
                            "additionalProperties": False,
                            "required": list(issue_properties.keys()),
                            "properties": issue_properties,
                        },
                    },
                },
            },
        },
    }


def _format_semantic_response_format(operation: str) -> Dict:
    from app.services.word.format_semantics import FormatSemanticContract

    return {
        "type": "json_schema",
        "json_schema": {
            "name": "word_format_semantics_{0}_v1".format(operation),
            "strict": True,
            "schema": FormatSemanticContract.response_json_schema(operation),
        },
    }


def _format_semantic_prompt_with_schema(prompt: str, operation: str) -> str:
    schema = _format_semantic_response_format(operation)["json_schema"]["schema"]
    return "{0}\n\n允许的响应字段及类型（不得增加其它字段）：\n{1}".format(
        str(prompt or "").strip(),
        json.dumps(schema, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
    )


def _full_document_review_aggregate_response_format() -> Dict:
    finding_properties = {
        "findingId": {"type": "string", "minLength": 1, "maxLength": 96},
        "kind": {"type": "string", "minLength": 1, "maxLength": 48},
        "severity": {"type": "string", "enum": ["high", "medium", "low"]},
        "summary": {"type": "string", "minLength": 1, "maxLength": 2000},
        "issueIds": {
            "type": "array", "maxItems": 20,
            "items": {"type": "string", "minLength": 1, "maxLength": 96},
        },
        "factIds": {
            "type": "array", "maxItems": 20,
            "items": {"type": "string", "minLength": 1, "maxLength": 120},
        },
        "anchorIds": {
            "type": "array", "maxItems": 20,
            "items": {"type": "string", "minLength": 1, "maxLength": 96},
        },
    }
    return {
        "type": "json_schema",
        "json_schema": {
            "name": "word_document_review_full_aggregate_v1",
            "strict": True,
            "schema": {
                "type": "object",
                "additionalProperties": False,
                "required": ["schemaVersion", "summary", "findings"],
                "properties": {
                    "schemaVersion": {
                        "type": "string",
                        "const": "word.document_review.full.aggregate.v1",
                    },
                    "summary": {"type": "string", "maxLength": 4000},
                    "findings": {
                        "type": "array",
                        "maxItems": 100,
                        "items": {
                            "type": "object",
                            "additionalProperties": False,
                            "required": list(finding_properties.keys()),
                            "properties": finding_properties,
                        },
                    },
                },
            },
        },
    }



def validate_composer_multimodal_input(auth: dict, system_prompt: str, query: str, images: list) -> dict:
    """Validate known limits without pretending text estimates cover images."""
    budget, _ = direct_model_input_budget(
        int(auth.get("contextWindowTokens") or DEFAULT_CONTEXT_WINDOW_TOKENS),
        int(auth.get("maxOutputTokens") or DEFAULT_RESERVED_OUTPUT_TOKENS))
    estimated = _estimate_direct_tokens(system_prompt, query)
    if estimated > budget:
        raise AdapterError("MODEL_INPUT_OVER_BUDGET", "全文超过当前模型容量，请更换大容量模型或主动缩减资料；未截断内容。", status_code=413)
    for image in images:
        _composer_image_data_uri(image)
    return {"estimatedTextTokens": estimated, "imageCount": len(images),
            "imageBudgetKnown": not bool(images),
            "warning": "图片容量由模型服务核验；当前无法预估图片 Token，超限会明确报错，不会删图重试。" if images else ""}


def _composer_image_data_uri(image: dict) -> str:
    from app.services.word.material_document import _image_mime
    data = image.get("data")
    mime = image.get("mimeType")
    if not isinstance(data, bytes) or not data or _image_mime(data) != mime:
        raise AdapterError("IMAGE_ASSET_TYPE_INVALID", "资料图片格式无效，未跳过图片。", status_code=409)
    if len(data) > 5 * 1024 * 1024:
        raise AdapterError("IMAGE_ASSET_SIZE_LIMIT", "资料原图超过当前图片通道 5 MiB 上限，未压缩或删图。", status_code=413)
    return "data:" + mime + ";base64," + base64.b64encode(data).decode("ascii")


class ProviderClient:
    def __init__(
        self,
        settings: Optional[AppSettings] = None,
        workflow_profile_store: Optional[WorkflowProfileStore] = None,
        model_configuration_store: Optional[ModelConfigurationStore] = None,
        system_prompt_store: Optional[SystemPromptStore] = None,
        direct_service_store: Optional[DirectServiceStore] = None,
    ) -> None:
        self.settings = settings or load_settings()
        self.reload_settings = settings is None
        self.workflow_profile_store = workflow_profile_store or (
            WorkflowProfileStore() if settings is None else None
        )
        self.model_configuration_store = model_configuration_store or (
            ModelConfigurationStore() if settings is None else None
        )
        self.direct_service_store = direct_service_store or (
            DirectServiceStore()
            if (settings is None or model_configuration_store is not None)
            else None
        )
        self.system_prompt_store = system_prompt_store or SystemPromptStore()

    def refresh_settings(self) -> None:
        if self.reload_settings:
            self.settings = load_settings()

    def image_semantic_settings(self) -> Dict:
        config_path = (
            self.model_configuration_store.config_path
            if self.model_configuration_store is not None
            else default_config_path()
        )
        return ImageSemanticConfigStore(config_path).get()

    def resolve_task_auth(self, task_type: str) -> Dict:
        self.refresh_settings()
        if self.direct_service_store is not None:
            try:
                resolved_selection = (
                    self.direct_service_store.resolve_active_task_selection(
                        task_type, include_secret=True
                    )
                )
                if resolved_selection:
                    service = resolved_selection["directService"]
                    selection = resolved_selection["taskModelSelection"]
                    effective_model = str(selection.get("modelName") or service.get("defaultModel") or "").strip()
                    if not effective_model:
                        raise AdapterError(
                            "DIRECT_SERVICE_MODEL_REQUIRED",
                            "直连服务未指定有效模型，无法执行任务。",
                            status_code=400,
                        )
                    is_custom = bool(selection.get("customModel", False))

                    if is_custom and not selection.get("customModelValidated"):
                        raise AdapterError(
                            "DIRECT_SERVICE_CUSTOM_MODEL_UNVERIFIED",
                            "高级手填模型尚未通过真实任务调用验证，不能执行新任务。",
                            status_code=400,
                        )

                    model_availability = str(
                        selection.get("modelAvailability", "")
                    )
                    if model_availability == "expired":
                        raise AdapterError(
                            "DIRECT_SERVICE_MODEL_CATALOG_EXPIRED",
                            "模型目录缓存已过期，请先刷新目录后再提交任务。",
                            status_code=400,
                        )
                    if model_availability == "unavailable":
                        reason = str(
                            selection.get("modelUnavailableReason", "")
                        )
                        if reason == "catalog_usable":
                            raise AdapterError(
                                "DIRECT_SERVICE_CUSTOM_MODEL_NOT_ALLOWED",
                                "模型目录当前可用时不能使用高级手填模型。",
                                status_code=400,
                            )
                        if reason == "disappeared":
                            raise AdapterError(
                                "DIRECT_SERVICE_MODEL_DISAPPEARED",
                                f"所选模型 {effective_model} 已从服务目录中移除，请重新选择模型。",
                                status_code=400,
                            )
                        if reason in {"catalog_unavailable", "catalog_empty"}:
                            raise AdapterError(
                                "DIRECT_SERVICE_MODEL_CATALOG_UNAVAILABLE",
                                "模型目录当前不可用，请刷新目录或先验证高级手填模型。",
                                status_code=400,
                            )

                    base_url = str(service.get("serviceBaseUrl", "")).rstrip("/")
                    call_path = "/chat/completions"
                    api_key = str(service.get("apiKey", "")).strip()
                    auth_source = "task-file" if service.get("keyConfigured") else "none"

                    image_mode = selection.get(
                        "imageInputMode",
                        "openai_image_url" if task_type == "word.format_review" else "disabled",
                    )
                    image_auth = selection.get("imageExternalAuthorization")
                    image_val = selection.get("imageSemanticValidation")
                    image_readiness = selection.get("imageSemanticReadiness")
                    format_val = selection.get("formatSemanticValidation")
                    format_readiness = selection.get("formatSemanticReadiness")
                    streaming_cap = selection.get("streamingCapability")
                    if isinstance(streaming_cap, dict):
                        streaming_cap = dict(streaming_cap)
                    elif self.direct_service_store is not None:
                        try:
                            streaming_cap = self.direct_service_store._evaluate_streaming_capability(
                                self.direct_service_store._load_payload_recovering(),
                                service,
                                effective_model,
                            )
                        except Exception:
                            streaming_cap = None

                    resolved_auth = {
                        "providerBaseUrl": base_url,
                        "providerChatPath": call_path,
                        "providerMode": "blocking",
                        "providerName": str(service.get("name", "模型直连")),
                        "providerType": ACCESS_DIRECT_MODEL,
                        "providerInputMode": DIFY_INPUT_MODE_LEGACY,
                        "accessMethod": ACCESS_DIRECT_MODEL,
                        "serviceBaseUrl": base_url,
                        "serviceName": str(service.get("name", "")),
                        "modelConfiguration": None,
                        "modelConfigurationId": service["id"],
                        "modelConfigurationName": str(service.get("name", "")),
                        "modelName": effective_model,
                        "temperature": selection.get("temperature"),
                        "maxOutputTokens": selection.get("maxOutputTokens"),
                        "contextWindowTokens": int(
                            selection.get("contextWindowTokens")
                            or DEFAULT_CONTEXT_WINDOW_TOKENS
                        ),
                        "contextWindowTokensExplicit": selection.get("contextWindowTokens") is not None,
                        "formatSemanticValidation": format_val,
                        "formatSemanticReadiness": format_readiness,
                        "imageSemantics": self.image_semantic_settings(),
                        "imageInputMode": image_mode,
                        "imageExternalAuthorization": image_auth,
                        "imageSemanticValidation": image_val,
                        "imageSemanticReadiness": image_readiness,
                        "apiKeyRef": service["id"],
                        "apiKey": api_key,
                        "authSource": auth_source,
                        "directService": service,
                        "taskModelSelection": selection,
                        "streamingCapability": streaming_cap,
                    }
                    if task_type == "word.format_review":
                        resolved_auth["modelConfiguration"] = {
                            "id": service["id"],
                            "name": str(service.get("name", "模型直连")),
                            "taskType": "word.format_review",
                            "accessMethod": ACCESS_DIRECT_MODEL,
                            "serviceBaseUrl": base_url,
                            "modelName": effective_model,
                            "temperature": selection.get("temperature"),
                            "maxOutputTokens": selection.get("maxOutputTokens"),
                            "contextWindowTokens": int(
                                selection.get("contextWindowTokens")
                                or DEFAULT_CONTEXT_WINDOW_TOKENS
                            ),
                            "contextWindowTokensExplicit": selection.get("contextWindowTokens") is not None,
                            "imageInputMode": image_mode,
                            "imageExternalAuthorization": image_auth,
                            "imageSemanticValidation": image_val,
                            "imageSemanticReadiness": image_readiness,
                            "formatSemanticValidation": format_val,
                            "formatSemanticReadiness": format_readiness,
                            "configVersion": int(service.get("revision", 1)),
                            "streamingCapability": streaming_cap,
                        }
                    elif task_type == "word.document_review":
                        resolved_auth["modelConfiguration"] = {
                            "id": service["id"],
                            "name": str(service.get("name", "模型直连")),
                            "taskType": "word.document_review",
                            "accessMethod": ACCESS_DIRECT_MODEL,
                            "serviceBaseUrl": base_url,
                            "modelName": effective_model,
                            "temperature": selection.get("temperature"),
                            "maxOutputTokens": selection.get("maxOutputTokens"),
                            "contextWindowTokens": int(
                                selection.get("contextWindowTokens")
                                or DEFAULT_CONTEXT_WINDOW_TOKENS
                            ),
                            "contextWindowTokensExplicit": selection.get("contextWindowTokens") is not None,
                            "configVersion": int(service.get("revision", 1)),
                            "streamingCapability": streaming_cap,
                        }
                    return resolved_auth
            except DirectServiceError as exc:
                if exc.code == "DIRECT_SERVICE_SELECTION_MISMATCH":
                    raise AdapterError(exc.code, exc.message, status_code=409) from exc
                pass

        model_configuration = self.get_active_model_configuration(task_type, include_secret=True)
        if model_configuration:
            access_method = str(model_configuration.get("accessMethod", ACCESS_WORKFLOW_PLATFORM))
            base_url = str(model_configuration.get("serviceBaseUrl", "")).rstrip("/")
            call_path = (
                "/chat/completions"
                if access_method == ACCESS_DIRECT_MODEL
                else "/chat-messages"
            )
            api_key_ref = str(model_configuration.get("apiKeyRef", ""))
            input_mode_cache_key = _provider_input_mode_cache_key(
                self.settings,
                task_type,
                api_key_ref,
                provider_base_url=base_url,
                provider_chat_path=call_path,
            )
            return {
                "providerBaseUrl": base_url,
                "providerChatPath": call_path,
                "providerMode": "blocking",
                "providerName": "模型后台",
                "providerType": access_method,
                "providerInputMode": _PROVIDER_INPUT_MODE_CACHE.get(
                    input_mode_cache_key, DIFY_INPUT_MODE_LEGACY
                ),
                "accessMethod": access_method,
                "modelConfiguration": model_configuration,
                "modelConfigurationId": str(model_configuration.get("id", "")),
                "modelConfigurationName": str(model_configuration.get("name", "")),
                "modelName": str(model_configuration.get("modelName", "")),
                "temperature": model_configuration.get("temperature"),
                "maxOutputTokens": model_configuration.get("maxOutputTokens"),
                "contextWindowTokens": int(
                    model_configuration.get("contextWindowTokens")
                    or DEFAULT_CONTEXT_WINDOW_TOKENS
                ),
                "contextWindowTokensExplicit": bool(
                    model_configuration.get("contextWindowTokensExplicit", False)
                ),
                "formatSemanticValidation": model_configuration.get(
                    "formatSemanticValidation"
                ),
                "formatSemanticReadiness": model_configuration.get(
                    "formatSemanticReadiness"
                ),
                "imageSemantics": self.image_semantic_settings(),
                "imageInputMode": model_configuration.get("imageInputMode", "disabled"),
                "imageExternalAuthorization": model_configuration.get(
                    "imageExternalAuthorization"
                ),
                "imageSemanticValidation": model_configuration.get(
                    "imageSemanticValidation"
                ),
                "apiKeyRef": api_key_ref,
                "apiKey": str(model_configuration.get("apiKey", "")),
                "authSource": "task-file",
            }
        if self.model_configuration_store is not None:
            return {
                "providerBaseUrl": "",
                "providerChatPath": "/chat-messages",
                "providerMode": "blocking",
                "providerName": "模型后台",
                "providerType": ACCESS_WORKFLOW_PLATFORM,
                "providerInputMode": DIFY_INPUT_MODE_LEGACY,
                "accessMethod": ACCESS_WORKFLOW_PLATFORM,
                "modelConfiguration": None,
                "modelConfigurationId": "",
                "modelConfigurationName": "",
                "modelName": "",
                "apiKeyRef": "",
                "apiKey": "",
                "authSource": "none",
            }
        workflow_profile = self.get_active_workflow_profile(task_type)
        if workflow_profile and workflow_profile.get("apiKeyRef"):
            api_key_ref = str(workflow_profile.get("apiKeyRef", ""))
        else:
            refs = self.settings.task_api_key_refs or {}
            api_key_ref = refs.get(task_type) or normalize_task_api_key_ref(task_type)

        task_api_key = ""
        if workflow_profile and self.workflow_profile_store is not None:
            safe_ref = "".join(
                ch for ch in api_key_ref if ch.isalnum() or ch in ("-", "_", ".")
            )
            if safe_ref == api_key_ref:
                profile_key_path = self.workflow_profile_store.key_dir / safe_ref
                if profile_key_path.exists():
                    task_api_key = profile_key_path.read_text(encoding="utf-8").strip()
        if not task_api_key:
            task_api_key = load_route_api_key(api_key_ref)
        auth_source = "task-file" if task_api_key else self.get_auth_source()
        if not task_api_key:
            task_api_key = self.get_api_key("default")
        provider_base_url = self.settings.provider_base_url.rstrip("/")
        provider_chat_path = self.settings.provider_chat_path or "/chat-messages"
        input_mode_cache_key = _provider_input_mode_cache_key(
            self.settings,
            task_type,
            api_key_ref,
            provider_base_url=provider_base_url,
            provider_chat_path=provider_chat_path,
        )
        return {
            "providerBaseUrl": provider_base_url,
            "providerChatPath": provider_chat_path,
            "providerMode": self.settings.provider_mode,
            "providerName": self.settings.provider_name,
            "providerType": self.settings.provider_type,
            "providerInputMode": _PROVIDER_INPUT_MODE_CACHE.get(
                input_mode_cache_key, DIFY_INPUT_MODE_LEGACY
            ),
            "workflowProfile": workflow_profile,
            "workflowProfileId": str((workflow_profile or {}).get("id", "")),
            "workflowProfileName": str((workflow_profile or {}).get("name", "")),
            "apiKeyRef": api_key_ref,
            "apiKey": task_api_key,
            "authSource": auth_source,
            "accessMethod": ACCESS_WORKFLOW_PLATFORM,
            "modelConfiguration": None,
            "modelConfigurationId": "",
            "modelConfigurationName": "",
            "modelName": "",
        }

    def resolve_configuration_auth(self, configuration_id: str) -> Dict:
        if self.model_configuration_store is None:
            raise AdapterError(
                "MODEL_CONFIG_NOT_FOUND", "未找到指定的模型配置。", status_code=404
            )
        try:
            configuration = self.model_configuration_store.get_configuration(
                configuration_id, include_secret=True
            )
        except ModelConfigurationError as exc:
            status = 404 if exc.code == "MODEL_CONFIG_NOT_FOUND" else 400
            raise AdapterError(exc.code, exc.message, status_code=status) from exc
        if not configuration.get("complete"):
            raise AdapterError(
                "MODEL_CONFIG_INCOMPLETE", "该模型配置尚不完整，不能执行验证。", status_code=400
            )
        access_method = str(configuration.get("accessMethod", ACCESS_WORKFLOW_PLATFORM))
        call_path = (
            "/chat/completions" if access_method == ACCESS_DIRECT_MODEL else "/chat-messages"
        )
        api_key_ref = str(configuration.get("apiKeyRef", ""))
        base_url = str(configuration.get("serviceBaseUrl", "")).rstrip("/")
        return {
            "providerBaseUrl": base_url,
            "providerChatPath": call_path,
            "providerMode": "blocking",
            "providerName": "模型后台",
            "providerType": access_method,
            "providerInputMode": _PROVIDER_INPUT_MODE_CACHE.get(
                _provider_input_mode_cache_key(
                    self.settings,
                    str(configuration.get("taskType", "")),
                    api_key_ref,
                    provider_base_url=base_url,
                    provider_chat_path=call_path,
                ),
                DIFY_INPUT_MODE_LEGACY,
            ),
            "accessMethod": access_method,
            "modelConfiguration": configuration,
            "modelConfigurationId": str(configuration.get("id", "")),
            "modelConfigurationName": str(configuration.get("name", "")),
            "modelName": str(configuration.get("modelName", "")),
            "temperature": configuration.get("temperature"),
            "maxOutputTokens": configuration.get("maxOutputTokens"),
            "contextWindowTokens": int(
                configuration.get("contextWindowTokens") or DEFAULT_CONTEXT_WINDOW_TOKENS
            ),
            "apiKeyRef": api_key_ref,
            "apiKey": str(configuration.get("apiKey", "")),
            "authSource": "task-file",
            "imageSemantics": self.image_semantic_settings(),
            "imageInputMode": configuration.get("imageInputMode", "disabled"),
            "imageExternalAuthorization": configuration.get("imageExternalAuthorization"),
            "imageSemanticValidation": configuration.get("imageSemanticValidation"),
        }

    def resolve_task_route(self, task_type: str) -> TaskRoute:
        routes = self.settings.task_routes or {}
        route = routes.get(task_type) or TaskRoute(task_id=task_type, enabled=True)
        if not route.path:
            route.path = self.settings.provider_chat_path
        if not route.payload_style:
            route.payload_style = infer_payload_style(route.path, self.settings.provider_type)
        if not route.response_mode:
            route.response_mode = self.settings.provider_mode
        if not route.api_key_ref:
            route.api_key_ref = "default"
        return route

    def build_task_input_data(self, task_type: str, trace_id: str, payload: Optional[Dict] = None) -> Dict:
        route = self.resolve_task_route(task_type)
        input_data = {
            "scene": "word",
            "task_id": route.task_id,
            "taskType": task_type,
            "trace_id": trace_id,
        }
        if payload:
            input_data.update(payload)
        return input_data

    def is_configured(self, key_base_path: Optional[Path] = None) -> bool:
        self.refresh_settings()
        if self.model_configuration_store is not None:
            return any(
                item.get("configured")
                for item in self.build_task_api_key_status(key_base_path).values()
            )
        return bool(self.settings.provider_base_url.strip() and self.get_api_key("default", key_base_path))

    def is_task_configured(self, task_type: str, key_base_path: Optional[Path] = None) -> bool:
        self.refresh_settings()
        if self.direct_service_store is not None:
            try:
                payload = load_config_payload(self.direct_service_store.config_path)
                active_map = payload.get("activeModelConfigurations") or {}
                active_id = str(active_map.get(task_type, "")).strip()
                services = payload.get("directServices") or {}
                if active_id and active_id in services:
                    service = services[active_id]
                    selection = self.direct_service_store.get_task_model_selection(task_type)
                    effective_model = str(selection.get("modelName") or service.get("defaultModel") or "").strip()
                    if (
                        bool(str(service.get("serviceBaseUrl", "")).strip())
                        and bool(self.direct_service_store.has_api_key(active_id))
                        and bool(effective_model)
                    ):
                        return selection.get("modelAvailable") is not False
            except Exception:
                pass
        if self.model_configuration_store is not None:
            try:
                return self.model_configuration_store.get_active_configuration(task_type) is not None
            except ModelConfigurationError:
                return False
        return bool(self.settings.provider_base_url.strip() and self.get_api_key_for_task(task_type, key_base_path))

    def get_auth_source(self, key_base_path: Optional[Path] = None) -> str:
        if os.getenv(self.settings.provider_api_key_env):
            return "env"
        if load_local_api_key(key_base_path / "provider_api_key" if key_base_path else None):
            return "file"
        return "none"

    def get_route_auth_source(self, api_key_ref: str) -> str:
        if load_route_api_key(api_key_ref):
            return "route-file"
        if api_key_ref and api_key_ref != "default":
            return "none"
        return self.get_auth_source()

    def get_task_api_key_ref(self, task_type: str) -> str:
        profile = self.get_active_workflow_profile(task_type)
        if profile and profile.get("apiKeyRef"):
            return str(profile["apiKeyRef"])
        refs = self.settings.task_api_key_refs or {}
        return refs.get(task_type) or normalize_task_api_key_ref(task_type)

    def get_active_workflow_profile(self, task_type: str) -> Optional[Dict]:
        if self.workflow_profile_store is None:
            return None
        try:
            return self.workflow_profile_store.get_active_profile(task_type)
        except WorkflowProfileError:
            return None

    def get_active_model_configuration(
        self, task_type: str, include_secret: bool = False
    ) -> Optional[Dict]:
        if self.model_configuration_store is None:
            return None
        try:
            return self.model_configuration_store.get_active_configuration(
                task_type, include_secret=include_secret
            )
        except ModelConfigurationError:
            return None

    def get_auth_source_for_task(self, task_type: str, key_base_path: Optional[Path] = None) -> str:
        api_key_ref = self.get_task_api_key_ref(task_type)
        if load_route_api_key(api_key_ref, key_base_path):
            return "task-file"
        return self.get_auth_source(key_base_path)

    def get_api_key(self, api_key_ref: str = "default", key_base_path: Optional[Path] = None) -> str:
        route_key = load_route_api_key(api_key_ref, key_base_path)
        if route_key:
            return route_key
        return os.getenv(self.settings.provider_api_key_env) or load_local_api_key(
            key_base_path / "provider_api_key" if key_base_path else None
        )

    def get_task_api_key(self, route: TaskRoute, key_base_path: Optional[Path] = None) -> str:
        return self.get_api_key_for_task(route.task_id, key_base_path)

    def get_api_key_for_task(self, task_type: str, key_base_path: Optional[Path] = None) -> str:
        api_key_ref = self.get_task_api_key_ref(task_type)
        task_key = load_route_api_key(api_key_ref, key_base_path)
        if task_key:
            return task_key
        return self.get_api_key("default", key_base_path)

    def build_task_api_key_status(self, key_base_path: Optional[Path] = None) -> Dict:
        tasks = [
            ("word.smart_write", "智能编写"),
            ("word.smart_imitation", "智能仿写"),
            ("word.material_composer", "按需编写"),
            ("word.document_review", "文档审查"),
            ("word.format_review", "格式审查"),
            ("excel.analysis", "智能分析"),
            ("excel.formula_assistant", "公式助手"),
            ("excel.smart_fill", "智能填写"),
            ("excel.material_ledger", "任务台账"),
            ("ppt.slide_assistant", "智能总结"),
            ("ppt.structure_review", "结构审查"),
            ("ppt.material_outline", "资料大纲"),
            ("ppt.template_page", "模板正文页"),
        ]
        status = {}
        for task_type, label in tasks:
            if self.direct_service_store is not None:
                try:
                    payload = load_config_payload(self.direct_service_store.config_path)
                    active_map = payload.get("activeModelConfigurations") or {}
                    active_id = str(active_map.get(task_type, "")).strip()
                    services = payload.get("directServices") or {}
                    if active_id and active_id in services:
                        service = self.direct_service_store.get_service(active_id)
                        selection = self.direct_service_store.get_task_model_selection(task_type)
                        effective_model = str(selection.get("modelName") or service.get("defaultModel") or "").strip()
                        key_configured = bool(service.get("keyConfigured"))
                        status[task_type] = {
                            "label": label,
                            "apiKeyRef": active_id,
                            "taskKeyConfigured": key_configured,
                            "configured": bool(
                                service.get("serviceBaseUrl")
                                and key_configured
                                and effective_model
                                and selection.get("modelAvailable") is not False
                            ),
                            "authSource": "task-file" if key_configured else "none",
                            "activeProfileId": active_id,
                            "activeProfileName": str(service.get("name", "")),
                            "profileCount": len(services),
                            "activeConfigurationId": active_id,
                            "activeConfigurationName": str(service.get("name", "")),
                            "configurationCount": len(services),
                            "accessMethod": ACCESS_DIRECT_MODEL,
                            "modelName": effective_model,
                            "serviceId": active_id,
                            "modelAvailability": selection.get("modelAvailability"),
                            "modelAvailable": selection.get("modelAvailable"),
                            "modelUnavailableReason": selection.get(
                                "modelUnavailableReason", ""
                            ),
                            "modelCatalogStatus": selection.get(
                                "modelCatalogStatus", "unavailable"
                            ),
                            "modelCatalogCacheStatus": selection.get(
                                "modelCatalogCacheStatus", "empty"
                            ),
                        }
                        continue
                except Exception:
                    pass
            if self.model_configuration_store is not None:
                try:
                    model_data = self.model_configuration_store.list_for_task(task_type)
                except ModelConfigurationError:
                    model_data = None
                if model_data is not None:
                    active_id = str(model_data.get("activeConfigurationId", ""))
                    active_configuration = next(
                        (
                            item
                            for item in model_data.get("configurations", [])
                            if item.get("id") == active_id
                        ),
                        {},
                    )
                    status[task_type] = {
                        "label": label,
                        "apiKeyRef": str(active_configuration.get("apiKeyRef", "")),
                        "taskKeyConfigured": bool(active_configuration.get("keyConfigured")),
                        "configured": bool(active_configuration.get("complete")),
                        "authSource": "task-file"
                        if active_configuration.get("keyConfigured")
                        else "none",
                        "activeProfileId": active_id,
                        "activeProfileName": str(active_configuration.get("name", "")),
                        "profileCount": int(model_data.get("configurationCount", 0)),
                        "activeConfigurationId": active_id,
                        "activeConfigurationName": str(active_configuration.get("name", "")),
                        "configurationCount": int(model_data.get("configurationCount", 0)),
                        "accessMethod": str(active_configuration.get("accessMethod", "")),
                        "modelName": str(active_configuration.get("modelName", "")),
                    }
                    continue
            profile_data = None
            if self.workflow_profile_store is not None:
                try:
                    profile_data = self.workflow_profile_store.list_for_task(task_type)
                except WorkflowProfileError:
                    profile_data = None
            active_id = str((profile_data or {}).get("activeProfileId", ""))
            active_profile = next(
                (
                    item
                    for item in (profile_data or {}).get("profiles", [])
                    if item.get("id") == active_id
                ),
                {},
            )
            api_key_ref = self.get_task_api_key_ref(task_type)
            task_key_configured = bool(load_route_api_key(api_key_ref, key_base_path))
            status[task_type] = {
                "label": label,
                "apiKeyRef": api_key_ref,
                "taskKeyConfigured": task_key_configured,
                "configured": bool(self.settings.provider_base_url.strip() and self.get_api_key_for_task(task_type, key_base_path)),
                "authSource": "task-file" if task_key_configured else self.get_auth_source(key_base_path),
                "activeProfileId": active_id,
                "activeProfileName": str(active_profile.get("name", "")),
                "profileCount": int((profile_data or {}).get("profileCount", 0)),
            }
        return status

    def build_route_url(self, route: TaskRoute) -> str:
        return "{0}{1}".format(self.settings.provider_base_url.rstrip("/"), route.path or self.settings.provider_chat_path)

    def task_route_configured_count(self, key_base_path: Optional[Path] = None) -> int:
        return 0

    def build_route_diagnostics(self, key_base_path: Optional[Path] = None) -> Dict:
        path = self.settings.provider_chat_path or "/chat-messages"
        url = "{0}{1}".format(self.settings.provider_base_url.rstrip("/"), path) if self.settings.provider_base_url.strip() else ""
        return {
            "version": "0.26.0-preview.1",
            "providerBaseUrlConfigured": bool(self.settings.provider_base_url.strip()),
            "providerChatPath": path,
            "url": url,
            "path": path,
            "payloadStyle": "chat",
            "responseMode": self.settings.provider_mode,
            "configured": self.is_configured(key_base_path),
            "authSource": self.get_auth_source(key_base_path),
            "taskApiKeys": self.build_task_api_key_status(key_base_path),
            "taskRouteCount": 0,
            "taskRouteConfiguredCount": 0,
            "routes": {},
        }

    def build_debug_metadata(
        self,
        task_type: str,
        provider: str = "enterprise-dify-chat",
        workflow_profile: Optional[Dict] = None,
        api_key_ref: str = "",
        task_auth: Optional[Dict] = None,
    ) -> Dict:
        if task_auth is not None:
            profile = task_auth.get("workflowProfile")
            resolved_api_key_ref = str(task_auth.get("apiKeyRef", ""))
            auth_source = str(task_auth.get("authSource", "")) or "none"
            profile_id = str(task_auth.get("workflowProfileId", ""))
            profile_name = str(task_auth.get("workflowProfileName", ""))
            provider_base_url_configured = bool(
                str(task_auth.get("providerBaseUrl", "")).strip()
            )
            model_configuration_id = str(task_auth.get("modelConfigurationId", ""))
            model_configuration_name = str(task_auth.get("modelConfigurationName", ""))
            access_method = str(task_auth.get("accessMethod", ACCESS_WORKFLOW_PLATFORM))
            model_name = str(task_auth.get("modelName", ""))
        else:
            profile = workflow_profile if workflow_profile is not None else self.get_active_workflow_profile(task_type)
            resolved_api_key_ref = api_key_ref or self.get_task_api_key_ref(task_type)
            auth_source = self.get_auth_source_for_task(task_type)
            profile_id = str((profile or {}).get("id", ""))
            profile_name = str((profile or {}).get("name", ""))
            provider_base_url_configured = bool(self.settings.provider_base_url.strip())
            model_configuration_id = ""
            model_configuration_name = ""
            access_method = ACCESS_WORKFLOW_PLATFORM
            model_name = ""
        metadata = {
            "provider": provider,
            "providerName": str(
                (task_auth or {}).get("providerName") or self.settings.provider_name
            ),
            "providerType": str(
                (task_auth or {}).get("providerType") or self.settings.provider_type
            ),
            "providerBaseUrlConfigured": provider_base_url_configured,
            "authSource": auth_source,
            "taskAuthSource": auth_source,
            "taskApiKeyRef": resolved_api_key_ref,
            "accessMethod": access_method,
        }
        if profile_id or profile:
            metadata["workflowProfileId"] = profile_id or str(profile.get("id", ""))
            metadata["workflowProfileName"] = profile_name or str(profile.get("name", ""))
        if model_configuration_id:
            metadata["modelConfigurationId"] = model_configuration_id
            metadata["modelConfigurationName"] = model_configuration_name
        if model_name:
            metadata["modelName"] = model_name
        return metadata

    def build_provider_source(
        self, task_type: str, task_auth: Optional[Dict] = None
    ) -> str:
        resolved = task_auth or self.resolve_task_auth(task_type)
        configuration_name = str(resolved.get("modelConfigurationName", "")).strip()
        access_method = str(resolved.get("accessMethod", ACCESS_WORKFLOW_PLATFORM))
        if access_method == ACCESS_DIRECT_MODEL:
            model_name = str(resolved.get("modelName", "")).strip()
            parts = [configuration_name, "模型直连", model_name]
        else:
            profile_name = str(resolved.get("workflowProfileName", "")).strip()
            parts = [configuration_name or profile_name, "工作流平台"]
        return " · ".join(part for part in parts if part)

    def upload_task_file(
        self,
        task_type: str,
        trace_id: str,
        staged_document,
        task_auth: Optional[Dict] = None,
        timeout_seconds: Optional[int] = None,
    ) -> str:
        resolved_task_auth = task_auth if task_auth is not None else self.resolve_task_auth(task_type)
        provider_base_url = str(
            resolved_task_auth.get("providerBaseUrl") or self.settings.provider_base_url.rstrip("/")
        ).rstrip("/")
        url = "{0}/files/upload".format(provider_base_url)
        extension = str(getattr(staged_document, "extension", "") or "").lower().lstrip(".")
        mime_type = str(getattr(staged_document, "mime_type", "") or "")
        try:
            content = Path(getattr(staged_document, "path")).read_bytes()
            payload, content_type = encode_dify_file_upload(content, extension, mime_type)
        except (OSError, TypeError, ValueError) as exc:
            raise ProviderUnavailableError("PPT document could not be prepared for upload.") from exc

        size_bytes = len(content)
        timeout = timeout_seconds or self.settings.timeout_seconds
        debug_metadata = self.build_debug_metadata(task_type, task_auth=resolved_task_auth)
        safe_context = {
            "stage": "file-upload",
            "extension": extension,
            "sizeBytes": size_bytes,
        }
        logger.info(
            "traceId=%s task=%s stage=file-upload url=%s extension=%s sizeBytes=%s",
            trace_id,
            task_type,
            url,
            extension,
            size_bytes,
        )
        req = urllib_request.Request(
            url,
            data=payload,
            method="POST",
            headers={
                "Authorization": "Bearer {0}".format(str(resolved_task_auth.get("apiKey", ""))),
                "Content-Type": content_type,
                "X-Trace-Id": trace_id,
            },
        )
        try:
            with urllib_request.urlopen(req, timeout=timeout) as response:
                raw_body = response.read().decode("utf-8")
                try:
                    body = json.loads(raw_body)
                except json.JSONDecodeError as exc:
                    record_provider_debug(
                        {
                            "traceId": trace_id,
                            "taskType": task_type,
                            "url": url,
                            **debug_metadata,
                            "validation": safe_context,
                            "error": {
                                "type": "JSONDecodeError",
                                "message": "Provider file upload returned non-JSON response.",
                                "bodyPreview": _sanitize_provider_error_body(raw_body, limit=240),
                            },
                        }
                    )
                    raise ProviderUnavailableError(
                        "Enterprise AI file upload returned a non-JSON response."
                    ) from exc
                upload_file_id = _provider_safe_str(body.get("id") if isinstance(body, dict) else "").strip()
                if not upload_file_id:
                    record_provider_debug(
                        {
                            "traceId": trace_id,
                            "taskType": task_type,
                            "url": url,
                            **debug_metadata,
                            "validation": safe_context,
                            "error": {
                                "type": "ProviderResponseError",
                                "message": "Provider file upload response did not contain an id.",
                            },
                        }
                    )
                    raise ProviderUnavailableError(
                        "Enterprise AI file upload response did not contain an id."
                    )
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": url,
                        **debug_metadata,
                        "validation": safe_context,
                        "response": {
                            "status": getattr(response, "status", 200),
                            "body": body,
                        },
                    }
                )
                return upload_file_id
        except error.HTTPError as exc:
            error_info = {
                "type": "HTTPError",
                "status": exc.code,
                "message": str(exc),
                "bodyPreview": _read_http_error_body(
                    exc,
                    api_key=str(resolved_task_auth.get("apiKey", "")),
                ),
            }
            record_provider_debug(
                {
                    "traceId": trace_id,
                    "taskType": task_type,
                    "url": url,
                    **debug_metadata,
                    "validation": safe_context,
                    "error": error_info,
                }
            )
            if exc.code in (401, 403):
                raise ProviderAuthError() from exc
            raise ProviderUnavailableError(
                "Enterprise AI file upload returned HTTP {0}.".format(exc.code)
            ) from exc
        except error.URLError as exc:
            reason = getattr(exc, "reason", "")
            record_provider_debug(
                {
                    "traceId": trace_id,
                    "taskType": task_type,
                    "url": url,
                    **debug_metadata,
                    "validation": safe_context,
                    "error": {"type": "URLError", "message": "provider network error"},
                }
            )
            if isinstance(reason, (TimeoutError, socket.timeout)) or "timed out" in str(reason).lower():
                raise ProviderTimeoutError() from exc
            raise ProviderUnavailableError("Enterprise AI file upload endpoint is unreachable.") from exc
        except (TimeoutError, socket.timeout) as exc:
            record_provider_debug(
                {
                    "traceId": trace_id,
                    "taskType": task_type,
                    "url": url,
                    **debug_metadata,
                    "validation": safe_context,
                    "error": {"type": "TimeoutError", "message": str(exc)},
                }
            )
            raise ProviderTimeoutError() from exc

    @staticmethod
    def _image_data_uri(image: Dict) -> str:
        if not isinstance(image, dict) or str(image.get("mimeType", "image/png")) != "image/png":
            raise AdapterError("IMAGE_ASSET_TYPE_INVALID", "图片语义输入仅允许 PNG。", status_code=409)
        path_value = image.get("path") or image.get("slotPath")
        path = Path(str(path_value or ""))
        if not path.is_absolute() or path.is_symlink() or not path.is_file():
            raise AdapterError("IMAGE_ASSET_PATH_INVALID", "图片语义输入路径不是受控普通文件。", status_code=409)
        try:
            content = path.read_bytes()
        except OSError as exc:
            raise AdapterError("IMAGE_ASSET_FILE_UNREADABLE", "图片语义输入无法读取。", status_code=409) from exc
        if len(content) > 5 * 1024 * 1024:
            raise AdapterError("IMAGE_ASSET_SIZE_LIMIT", "图片语义输入超过 5 MiB 上限。", status_code=413)
        return "data:image/png;base64," + base64.b64encode(content).decode("ascii")

    def _post_direct_task(
        self,
        task_type: str,
        trace_id: str,
        query: str,
        resolved_task_auth: Dict,
        timeout: int,
        prompt_asset: Optional[Dict] = None,
        response_format: Optional[Dict] = None,
        input_token_limit: Optional[int] = None,
        image_files: Optional[List[Dict]] = None,
        allow_response_format_fallback: bool = False,
        progress_callback=None,
        allow_streaming_fallback: bool = True,
    ) -> Dict:
        if prompt_asset is None:
            try:
                prompt_asset = self.system_prompt_store.load(task_type)
            except SystemPromptError as exc:
                raise AdapterError(exc.code, exc.message, status_code=500) from exc
        context_window = int(
            resolved_task_auth.get("contextWindowTokens")
            or DEFAULT_CONTEXT_WINDOW_TOKENS
        )
        max_output_tokens = resolved_task_auth.get("maxOutputTokens")
        if task_type in ("word.material_composer", "ppt.material_outline") and max_output_tokens is None:
            max_output_tokens = DEFAULT_RESERVED_OUTPUT_TOKENS
        reserved_output = int(max_output_tokens or DEFAULT_RESERVED_OUTPUT_TOKENS)
        input_budget, safety_margin = direct_model_input_budget(
            context_window, reserved_output
        )
        if input_token_limit is not None:
            input_budget = min(input_budget, int(input_token_limit))
        estimated_input = _estimate_direct_tokens(prompt_asset["content"], query)
        if input_budget <= 0 or estimated_input > input_budget:
            raise AdapterError(
                "MODEL_INPUT_OVER_BUDGET",
                "输入内容超过当前模型配置的安全上下文容量，请缩小本次处理范围。",
                status_code=413,
            )
        base_url = str(resolved_task_auth.get("providerBaseUrl", "")).rstrip("/")
        url = "{0}/chat/completions".format(base_url)
        user_content = query
        if image_files:
            content_parts = [{"type": "text", "text": query}]
            if task_type in ("word.material_composer", "excel.material_ledger", "ppt.material_outline"):
                validate_composer_multimodal_input(resolved_task_auth, prompt_asset["content"], query, image_files)
            for image in image_files:
                if task_type in ("word.material_composer", "excel.material_ledger", "ppt.material_outline"):
                    content_parts.append({"type": "text", "text": str(image.get("imageId", ""))})
                    image_uri = _composer_image_data_uri(image)
                else:
                    image_uri = self._image_data_uri(image)
                content_parts.append({
                    "type": "image_url",
                    "image_url": {"url": image_uri},
                })
            user_content = content_parts
        streaming_enabled = (
            bool(resolved_task_auth.get("directStreamingEnabled"))
            if "directStreamingEnabled" in resolved_task_auth
            else direct_streaming_enabled()
        )
        should_stream = bool(
            allow_streaming_fallback
            and streaming_enabled
            and (task_type == "ppt.material_outline" or streaming_capability_validated(
                resolved_task_auth.get("streamingCapability")
            ))
            and task_type in ("word.smart_write", "word.smart_imitation", "ppt.material_outline")
            and response_format is None
        )
        payload_body = {
            "model": str(resolved_task_auth.get("modelName", "")),
            "messages": [
                {"role": "system", "content": prompt_asset["content"]},
                {"role": "user", "content": user_content},
            ],
            "stream": bool(should_stream),
        }
        temperature = resolved_task_auth.get("temperature")
        if temperature is not None:
            payload_body["temperature"] = temperature
        if max_output_tokens is not None:
            payload_body["max_tokens"] = int(max_output_tokens)
        if response_format is not None:
            payload_body["response_format"] = response_format
        debug_metadata = self.build_debug_metadata(task_type, task_auth=resolved_task_auth)
        safe_validation = {
            "stage": "model-processing",
            "timeoutSeconds": timeout,
            "transport": "stream" if should_stream else "blocking",
            "promptVersion": prompt_asset["version"],
            "promptHashPrefix": prompt_asset["hashPrefix"],
            "contextWindowTokens": context_window,
            "reservedOutputTokens": reserved_output,
            "safetyMarginTokens": safety_margin,
            "estimatedInputTokens": estimated_input,
            "inputBudgetTokens": input_budget,
        }
        capability = resolved_task_auth.get("formatModelCapability")
        if isinstance(capability, dict):
            safe_validation["modelCapability"] = {
                key: capability[key]
                for key in (
                    "modelName",
                    "maxOutputTokens",
                    "sourceDate",
                    "sourceUrl",
                    "tableVersion",
                    "tableSha256",
                )
                if key in capability
            }
        record_provider_debug(
            {
                "traceId": trace_id,
                "taskType": task_type,
                "url": url,
                **debug_metadata,
                "validation": safe_validation,
                "request": {"body": payload_body},
            }
        )
        headers = {
            "Authorization": "Bearer {0}".format(
                str(resolved_task_auth.get("apiKey", ""))
            ),
            "Content-Type": "application/json",
            "X-Trace-Id": trace_id,
        }
        if should_stream:
            headers["Accept"] = "text/event-stream"
        req = urllib_request.Request(
            url,
            data=json.dumps(payload_body, ensure_ascii=False).encode("utf-8"),
            method="POST",
            headers=headers,
        )
        t_start = time.monotonic()
        t_headers = None
        first_visible_ms = None
        first_delta_seen = False
        if should_stream and progress_callback:
            try:
                progress_callback("provider_connecting")
            except Exception:
                pass
        try:
            if should_stream and progress_callback:
                try:
                    progress_callback("provider_waiting")
                except Exception:
                    pass
            with _open_task_response(req, timeout, task_type, progress_callback) as response:
                t_headers = time.monotonic()
                if (should_stream and task_type == "ppt.material_outline"
                        and "text/event-stream" not in str(response.headers.get("Content-Type", "")).lower()):
                    # A gateway may ignore stream=true. Consume this response;
                    # submitting it again could duplicate a costly generation.
                    should_stream = False
                if should_stream:
                    content_type = str(
                        response.headers.get("Content-Type", "")
                    ).lower()
                    if "text/event-stream" not in content_type:
                        perf_metrics = _provider_performance_metrics(
                            t_start,
                            headers_at=t_headers,
                        )
                        record_provider_debug(
                            {
                                "traceId": trace_id,
                                "taskType": task_type,
                                "url": url,
                                **debug_metadata,
                                "validation": safe_validation,
                                "performance": perf_metrics,
                                "error": {
                                    "type": "StreamingUnsupportedError",
                                    "status": getattr(response, "status", 200),
                                    "message": "direct model returned non-SSE response",
                                },
                            }
                        )
                        _publish_provider_performance(
                            progress_callback,
                            perf_metrics,
                        )
                        response.close()
                        if progress_callback and hasattr(
                            progress_callback, "disable_running_cancel"
                        ):
                            progress_callback.disable_running_cancel()
                        return self._post_direct_task(
                            task_type,
                            trace_id,
                            query,
                            resolved_task_auth,
                            timeout,
                            prompt_asset=prompt_asset,
                            response_format=response_format,
                            input_token_limit=input_token_limit,
                            image_files=image_files,
                            allow_response_format_fallback=allow_response_format_fallback,
                            progress_callback=progress_callback,
                            allow_streaming_fallback=False,
                        )

                    def on_delta(delta: str) -> None:
                        nonlocal first_delta_seen
                        if not first_delta_seen:
                            first_delta_seen = True
                            if progress_callback:
                                try:
                                    progress_callback("streaming")
                                except Exception:
                                    pass
                        if task_type != "ppt.material_outline" and progress_callback and hasattr(progress_callback, "publish_text"):
                            progress_callback.publish_text(delta)

                    def record_metric(name: str, value: int) -> None:
                        nonlocal first_visible_ms
                        if name == "providerFirstVisibleMs":
                            first_visible_ms = value
                        if task_type != "ppt.material_outline" and progress_callback and hasattr(progress_callback, "record_metric"):
                            progress_callback.record_metric(name, value)

                    cancel_checker = (
                        progress_callback.cancel_requested
                        if progress_callback and hasattr(progress_callback, "cancel_requested")
                        else None
                    )

                    def interrupt_stream_read() -> None:
                        fp = getattr(response, "fp", None)
                        raw = getattr(fp, "raw", None)
                        response_socket = getattr(raw, "_sock", None)
                        if response_socket is not None:
                            try:
                                response_socket.shutdown(socket.SHUT_RDWR)
                            except OSError:
                                pass
                            try:
                                response_socket.close()
                            except OSError:
                                pass
                        else:
                            response.close()

                    cancel_callback = None
                    if progress_callback and hasattr(
                        progress_callback, "set_cancel_callback"
                    ):
                        cancel_callback = interrupt_stream_read
                        progress_callback.set_cancel_callback(cancel_callback)

                    try:
                        stream_result = read_direct_text_stream(
                            response,
                            publish_callback=on_delta,
                            record_metric_callback=record_metric,
                            start_mono=t_start,
                            timeout=(max(0.0, float(timeout) - (time.monotonic() - t_start))
                                     if task_type == "ppt.material_outline" else float(timeout)),
                            cancel_checker=cancel_checker,
                            activity_callback=(progress_callback if task_type == "ppt.material_outline" else None),
                        )
                    except LongTaskCancelled:
                        if task_type == "ppt.material_outline":
                            raise LongTaskCancelled() from None
                        raise
                    finally:
                        if (
                            cancel_callback is not None
                            and hasattr(progress_callback, "clear_cancel_callback")
                        ):
                            progress_callback.clear_cancel_callback(cancel_callback)
                        if progress_callback and hasattr(progress_callback, "flush"):
                            try:
                                progress_callback.flush()
                            except Exception:
                                pass

                    t_complete = time.monotonic()
                    content = stream_result.get("rewrittenText", "")
                    finish_reason = stream_result.get("finishReason") or "stop"
                    perf_metrics = _provider_performance_metrics(
                        t_start,
                        headers_at=t_headers,
                        completed_at=t_complete,
                        first_visible_ms=first_visible_ms,
                    )
                    _publish_provider_performance(progress_callback, perf_metrics)
                    if not content:
                        record_provider_debug(
                            {
                                "traceId": trace_id,
                                "taskType": task_type,
                                "url": url,
                                **debug_metadata,
                                "validation": safe_validation,
                                "performance": perf_metrics,
                                "response": {
                                    "status": getattr(response, "status", 200),
                                    "body": {
                                        "answer": "",
                                        "finishReason": finish_reason,
                                        "contentType": "string",
                                        "reasoningContentPresent": False,
                                        "usage": stream_result.get("usage", {}),
                                    },
                                },
                            }
                        )
                        raise _missing_final_content_error(finish_reason)
                    normalized = {
                        "answer": content,
                        "finishReason": _safe_finish_reason(finish_reason),
                        "contentType": "string",
                        "reasoningContentPresent": False,
                        "usage": stream_result.get("usage", {}),
                        "id": str(stream_result.get("id", "")),
                        "model": str(stream_result.get("model", resolved_task_auth.get("modelName", ""))),
                        "promptVersion": prompt_asset["version"],
                        "choices": [
                            {
                                "message": {
                                    "role": "assistant",
                                    "content": content,
                                },
                                "finish_reason": finish_reason,
                            }
                        ],
                    }
                    record_provider_debug(
                        {
                            "traceId": trace_id,
                            "taskType": task_type,
                            "url": url,
                            **debug_metadata,
                            "validation": safe_validation,
                            "performance": perf_metrics,
                            "response": {
                                "status": getattr(response, "status", 200),
                                "body": normalized,
                            },
                        }
                    )
                    return normalized

                raw_body = response.read().decode("utf-8")
                t_complete = time.monotonic()
                try:
                    body = json.loads(raw_body)
                except json.JSONDecodeError as exc:
                    t_parse = time.monotonic()
                    perf_metrics = _provider_performance_metrics(
                        t_start,
                        headers_at=t_headers,
                        completed_at=t_complete,
                        parsed_at=t_parse,
                    )
                    _publish_provider_performance(progress_callback, perf_metrics)
                    record_provider_debug(
                        {
                            "traceId": trace_id,
                            "taskType": task_type,
                            "url": url,
                            **debug_metadata,
                            "validation": safe_validation,
                            "performance": perf_metrics,
                            "error": {
                                "type": "JSONDecodeError",
                                "message": "direct model returned non-JSON response",
                            },
                        }
                    )
                    raise AdapterError(
                        "MODEL_RESULT_INVALID",
                        "模型后台返回了无法解析的结果。",
                        status_code=502,
                    ) from exc
                t_parse = time.monotonic()
                perf_metrics = _provider_performance_metrics(
                    t_start,
                    headers_at=t_headers,
                    completed_at=t_complete,
                    parsed_at=t_parse,
                )
                _publish_provider_performance(progress_callback, perf_metrics)
                choices = body.get("choices") if isinstance(body, dict) else None
                choice = (
                    choices[0]
                    if isinstance(choices, list)
                    and choices
                    and isinstance(choices[0], dict)
                    else {}
                )
                message = choice.get("message", {}) if isinstance(choice, dict) else {}
                response_diagnostics = _direct_response_diagnostics(
                    body if isinstance(body, dict) else {}, choice, message
                )
                content = _direct_content_text(
                    message.get("content") if isinstance(message, dict) else None
                )
                if not content:
                    record_provider_debug(
                        {
                            "traceId": trace_id,
                            "taskType": task_type,
                            "url": url,
                            **debug_metadata,
                            "validation": safe_validation,
                            "performance": perf_metrics,
                            "response": {
                                "status": getattr(response, "status", 200),
                                "body": {"answer": "", **response_diagnostics},
                            },
                        }
                    )
                    raise _missing_final_content_error(
                        response_diagnostics["finishReason"]
                    )
                normalized = {
                    "answer": content,
                    **response_diagnostics,
                    "id": str(body.get("id", "")),
                    "model": str(body.get("model", resolved_task_auth.get("modelName", ""))),
                    "promptVersion": prompt_asset["version"],
                }
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": url,
                        **debug_metadata,
                        "validation": safe_validation,
                        "performance": perf_metrics,
                        "response": {
                            "status": getattr(response, "status", 200),
                            "body": normalized,
                        },
                    }
                )
                return normalized
        except error.HTTPError as exc:
            t_headers = time.monotonic()
            status = int(exc.code)
            raw_error_body, error_body_complete = _read_http_error_raw_result(
                exc, progress_callback if task_type in ("word.material_composer", "ppt.material_outline") else None
            )
            t_complete = time.monotonic() if error_body_complete else None
            perf_metrics = _provider_performance_metrics(
                t_start,
                headers_at=t_headers,
                completed_at=t_complete,
            )
            _publish_provider_performance(progress_callback, perf_metrics)
            body_preview = _sanitize_provider_error_body(
                raw_error_body,
                query=query,
                api_key=str(resolved_task_auth.get("apiKey", "")),
            )
            record_provider_debug(
                {
                    "traceId": trace_id,
                    "taskType": task_type,
                    "url": url,
                    **debug_metadata,
                    "validation": safe_validation,
                    "performance": perf_metrics,
                    "error": {
                        "type": "HTTPError",
                        "status": status,
                        "message": "direct model http error",
                        "bodyPreview": body_preview,
                    },
                }
            )
            if (
                should_stream
                and task_type != "ppt.material_outline"
                and allow_streaming_fallback
                and not first_delta_seen
                and status in (400, 404, 415, 422, 501)
            ):
                if progress_callback and hasattr(
                    progress_callback, "disable_running_cancel"
                ):
                    progress_callback.disable_running_cancel()
                return self._post_direct_task(
                    task_type,
                    trace_id,
                    query,
                    resolved_task_auth,
                    timeout,
                    prompt_asset=prompt_asset,
                    response_format=response_format,
                    input_token_limit=input_token_limit,
                    image_files=image_files,
                    allow_response_format_fallback=allow_response_format_fallback,
                    progress_callback=progress_callback,
                    allow_streaming_fallback=False,
                )
            if _should_retry_without_response_format(
                status,
                response_format,
                allow_response_format_fallback,
                raw_error_body,
            ):
                return self._post_direct_task(
                    task_type,
                    trace_id,
                    query,
                    resolved_task_auth,
                    timeout,
                    prompt_asset=prompt_asset,
                    response_format=None,
                    input_token_limit=input_token_limit,
                    image_files=image_files,
                    allow_response_format_fallback=False,
                    progress_callback=progress_callback,
                )
            if status in (401, 403):
                raise ProviderAuthError("模型后台认证失败，请检查当前配置的 API Key。") from exc
            if status == 404:
                raise AdapterError(
                    "MODEL_OR_PATH_UNAVAILABLE",
                    "模型或标准调用路径不可用，请检查服务地址和模型标识。",
                    status_code=502,
                ) from exc
            if status == 429:
                raise AdapterError(
                    "MODEL_RATE_LIMITED", "模型后台请求较多，请稍后重新提交。", status_code=429
                ) from exc
            raise ProviderUnavailableError(
                "模型后台暂时不可用，HTTP 状态码 {0}。".format(status)
            ) from exc
        except error.URLError as exc:
            reason = getattr(exc, "reason", "")
            perf_metrics = _provider_performance_metrics(
                t_start,
                headers_at=t_headers,
            )
            _publish_provider_performance(progress_callback, perf_metrics)
            record_provider_debug(
                {
                    "traceId": trace_id,
                    "taskType": task_type,
                    "url": url,
                    **debug_metadata,
                    "validation": safe_validation,
                    "performance": perf_metrics,
                    "error": {"type": "URLError", "message": "provider network error"},
                }
            )
            if isinstance(reason, (TimeoutError, socket.timeout)) or "timed out" in str(reason).lower():
                raise ProviderTimeoutError("模型处理超过当前任务等待时限。") from exc
            raise ProviderUnavailableError("无法访问模型后台，请检查服务地址和网络。") from exc
        except (
            IncompleteRead,
            RemoteDisconnected,
            ConnectionResetError,
            ConnectionAbortedError,
            BrokenPipeError,
        ) as exc:
            perf_metrics = _provider_performance_metrics(
                t_start,
                headers_at=t_headers,
            )
            _publish_provider_performance(progress_callback, perf_metrics)
            record_provider_debug(
                {
                    "traceId": trace_id,
                    "taskType": task_type,
                    "url": url,
                    **debug_metadata,
                    "validation": safe_validation,
                    "performance": perf_metrics,
                    "error": {
                        "type": type(exc).__name__,
                        "message": "direct model response interrupted",
                    },
                }
            )
            raise ProviderMidStreamDisconnectError("模型后台在返回结果过程中断开连接。") from exc
        except (TimeoutError, socket.timeout) as exc:
            perf_metrics = _provider_performance_metrics(
                t_start,
                headers_at=t_headers,
            )
            _publish_provider_performance(progress_callback, perf_metrics)
            record_provider_debug(
                {
                    "traceId": trace_id,
                    "taskType": task_type,
                    "url": url,
                    **debug_metadata,
                    "validation": safe_validation,
                    "performance": perf_metrics,
                    "error": {"type": "TimeoutError", "message": "provider timeout"},
                }
            )
            raise ProviderTimeoutError("模型处理超过当前任务等待时限。") from exc

    def post_task(
        self,
        task_type: str,
        trace_id: str,
        input_data: Dict,
        query: str,
        timeout_seconds: Optional[int] = None,
        files: Optional[List[Dict]] = None,
        task_auth: Optional[Dict] = None,
        input_token_limit: Optional[int] = None,
        image_files: Optional[List[Dict]] = None,
        response_format: Optional[Dict] = None,
        allow_response_format_fallback: bool = False,
        progress_callback=None,
        prompt_asset: Optional[Dict] = None,
    ) -> Dict:
        resolved_task_auth = task_auth if task_auth is not None else self.resolve_task_auth(task_type)
        timeout = timeout_seconds or self.settings.timeout_seconds
        if task_type in ("word.material_composer", "ppt.material_outline"):
            timeout = max(timeout, INTERACTIVE_WRITING_TIMEOUT_SECONDS)
        if str(resolved_task_auth.get("accessMethod", "")) == ACCESS_DIRECT_MODEL:
            if files:
                raise AdapterError(
                    "MODEL_DIRECT_FILE_UNSUPPORTED",
                    "模型直连不上传原始文件，请先完成本地文档抽取。",
                    status_code=400,
                )
            return self._post_direct_task(
                task_type,
                trace_id,
                query,
                resolved_task_auth,
                timeout,
                prompt_asset=prompt_asset,
                input_token_limit=input_token_limit,
                image_files=image_files,
                response_format=response_format,
                allow_response_format_fallback=allow_response_format_fallback,
                progress_callback=progress_callback,
            )
        if task_type in ("word.material_composer", "excel.material_ledger", "ppt.material_outline") and image_files:
            raise AdapterError("MODEL_IMAGE_INPUT_UNSUPPORTED", "当前接入方式无法完整发送原图，请为按需编写选择支持图片的直连模型。", status_code=400)
        provider_base_url = str(
            resolved_task_auth.get("providerBaseUrl") or self.settings.provider_base_url.rstrip("/")
        ).rstrip("/")
        provider_chat_path = str(
            resolved_task_auth.get("providerChatPath")
            or self.settings.provider_chat_path
            or "/chat-messages"
        )
        url = "{0}{1}".format(
            provider_base_url,
            provider_chat_path,
        )
        workflow_profile = resolved_task_auth.get("workflowProfile")
        api_key_ref = str(resolved_task_auth.get("apiKeyRef", ""))
        task_api_key = str(resolved_task_auth.get("apiKey", ""))
        debug_metadata = self.build_debug_metadata(
            task_type,
            workflow_profile=workflow_profile,
            api_key_ref=api_key_ref,
            task_auth=resolved_task_auth,
        )
        cache_key = _provider_input_mode_cache_key(
            self.settings,
            task_type,
            api_key_ref,
            provider_base_url=provider_base_url,
            provider_chat_path=provider_chat_path,
        )
        preferred_mode = str(
            resolved_task_auth.get("providerInputMode")
            or _PROVIDER_INPUT_MODE_CACHE.get(cache_key, DIFY_INPUT_MODE_LEGACY)
        )
        alternate_mode = (
            DIFY_INPUT_MODE_USER_INPUT
            if preferred_mode == DIFY_INPUT_MODE_LEGACY
            else DIFY_INPUT_MODE_LEGACY
        )
        attempt_modes = (preferred_mode, alternate_mode)
        if task_type == "excel.smart_fill":
            logger.info(
                "traceId=%s task=%s payloadStyle=chat queryLength=%s itemCount=%s",
                trace_id,
                task_type,
                len(query or ""),
                (input_data or {}).get("itemCount", 0),
            )
        else:
            logger.info(
                "traceId=%s task=%s url=%s authSource=%s payloadStyle=chat queryLength=%s inputKeysIgnored=%s",
                trace_id,
                task_type,
                url,
                str(resolved_task_auth.get("authSource", "none")),
                len(query or ""),
                sorted((input_data or {}).keys()),
            )
        compatibility_error = None
        for attempt_index, input_mode in enumerate(attempt_modes, start=1):
            attempt_metadata = {
                "inputMode": input_mode,
                "compatibilityFallback": attempt_index > 1,
                "attemptCount": attempt_index,
            }
            route_payload = build_provider_request_payload(
                self.settings,
                {},
                query,
                input_mode=input_mode,
                files=files,
                response_mode=str(resolved_task_auth.get("providerMode", "")),
            )
            payload = json.dumps(route_payload).encode("utf-8")
            record_provider_debug(
                {
                    "traceId": trace_id,
                    "taskType": task_type,
                    "url": url,
                    **debug_metadata,
                    **attempt_metadata,
                    **(
                        {"compatibilityError": compatibility_error}
                        if compatibility_error
                        else {}
                    ),
                    "request": {"body": route_payload},
                }
            )
            req = urllib_request.Request(
                url,
                data=payload,
                method="POST",
                headers={
                    "Authorization": "Bearer {0}".format(
                        task_api_key
                    ),
                    "Content-Type": "application/json",
                    "X-Trace-Id": trace_id,
                },
            )
            t_start = time.monotonic()
            t_headers = None
            try:
                with _open_task_response(req, timeout, task_type, progress_callback) as response:
                    t_headers = time.monotonic()
                    raw_body = response.read().decode("utf-8")
                    t_complete = time.monotonic()
                    try:
                        body = json.loads(raw_body)
                    except json.JSONDecodeError as exc:
                        t_parse = time.monotonic()
                        perf_metrics = _provider_performance_metrics(
                            t_start,
                            headers_at=t_headers,
                            completed_at=t_complete,
                            parsed_at=t_parse,
                        )
                        _publish_provider_performance(progress_callback, perf_metrics)
                        record_provider_debug(
                            {
                                "traceId": trace_id,
                                "taskType": task_type,
                                "url": url,
                                **debug_metadata,
                                **attempt_metadata,
                                **(
                                    {"compatibilityError": compatibility_error}
                                    if compatibility_error
                                    else {}
                                ),
                                "performance": perf_metrics,
                                "request": {"body": route_payload},
                                "error": {
                                    "type": "JSONDecodeError",
                                    "message": "Provider returned non-JSON response.",
                                    "bodyPreview": _sanitize_provider_error_body(
                                        raw_body,
                                        query=query,
                                        api_key=task_api_key,
                                        limit=240,
                                    ),
                                },
                            }
                        )
                        raise ProviderUnavailableError(
                            "Enterprise AI returned a non-JSON response."
                        ) from exc
                    t_parse = time.monotonic()
                    perf_metrics = _provider_performance_metrics(
                        t_start,
                        headers_at=t_headers,
                        completed_at=t_complete,
                        parsed_at=t_parse,
                    )
                    _publish_provider_performance(progress_callback, perf_metrics)
                    _PROVIDER_INPUT_MODE_CACHE[cache_key] = input_mode
                    resolved_task_auth["providerInputMode"] = input_mode
                    record_provider_debug(
                        {
                            "traceId": trace_id,
                            "taskType": task_type,
                            "url": url,
                            **debug_metadata,
                            **attempt_metadata,
                            **(
                                {"compatibilityError": compatibility_error}
                                if compatibility_error
                                else {}
                            ),
                            "performance": perf_metrics,
                            "request": {"body": route_payload},
                            "response": {
                                "status": getattr(response, "status", 200),
                                "body": body,
                            },
                        }
                    )
                    return body
            except error.HTTPError as exc:
                t_headers = time.monotonic()
                raw_error_body, error_body_complete = _read_http_error_raw_result(
                    exc, progress_callback if task_type in ("word.material_composer", "ppt.material_outline") else None
                )
                error_body = _sanitize_provider_error_body(
                    raw_error_body,
                    query=query,
                    api_key=task_api_key,
                )
                t_complete = time.monotonic() if error_body_complete else None
                perf_metrics = _provider_performance_metrics(
                    t_start,
                    headers_at=t_headers,
                    completed_at=t_complete,
                )
                _publish_provider_performance(progress_callback, perf_metrics)
                error_info = {
                    "type": "HTTPError",
                    "status": exc.code,
                    "message": str(exc),
                    "bodyPreview": error_body,
                }
                if exc.code == 400 and attempt_index == 1:
                    compatibility_error = error_info
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": url,
                        **debug_metadata,
                        **attempt_metadata,
                        **(
                            {"compatibilityError": compatibility_error}
                            if compatibility_error
                            else {}
                        ),
                        "performance": perf_metrics,
                        "request": {"body": route_payload},
                        "error": error_info,
                    }
                )
                if exc.code == 400 and attempt_index == 1:
                    continue
                if exc.code in (401, 403):
                    raise ProviderAuthError() from exc
                raise ProviderUnavailableError(
                    "Enterprise AI returned HTTP {0}.".format(exc.code)
                ) from exc
            except (
                IncompleteRead,
                RemoteDisconnected,
                ConnectionResetError,
                ConnectionAbortedError,
                BrokenPipeError,
            ) as exc:
                perf_metrics = _provider_performance_metrics(
                    t_start,
                    headers_at=t_headers,
                )
                _publish_provider_performance(progress_callback, perf_metrics)
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": url,
                        **debug_metadata,
                        **attempt_metadata,
                        **(
                            {"compatibilityError": compatibility_error}
                            if compatibility_error
                            else {}
                        ),
                        "performance": perf_metrics,
                        "request": {"body": route_payload},
                        "error": {
                            "type": type(exc).__name__,
                            "message": "provider response interrupted",
                        },
                    }
                )
                raise
            except error.URLError as exc:
                reason = getattr(exc, "reason", "")
                perf_metrics = _provider_performance_metrics(
                    t_start,
                    headers_at=t_headers,
                )
                _publish_provider_performance(progress_callback, perf_metrics)
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": url,
                        **debug_metadata,
                        **attempt_metadata,
                        **(
                            {"compatibilityError": compatibility_error}
                            if compatibility_error
                            else {}
                        ),
                        "performance": perf_metrics,
                        "request": {"body": route_payload},
                        "error": {"type": "URLError", "message": "provider network error"},
                    }
                )
                if "timed out" in str(reason).lower():
                    raise ProviderTimeoutError() from exc
                raise ProviderUnavailableError(
                    "Enterprise AI endpoint is unreachable."
                ) from exc
            except (TimeoutError, socket.timeout) as exc:
                perf_metrics = _provider_performance_metrics(
                    t_start,
                    headers_at=t_headers,
                )
                _publish_provider_performance(progress_callback, perf_metrics)
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": url,
                        **debug_metadata,
                        **attempt_metadata,
                        **(
                            {"compatibilityError": compatibility_error}
                            if compatibility_error
                            else {}
                        ),
                        "performance": perf_metrics,
                        "request": {"body": route_payload},
                        "error": {"type": "TimeoutError", "message": str(exc)},
                    }
                )
                raise ProviderTimeoutError() from exc

    def full_document_review_chunk(
        self,
        source_text: str,
        trace_id: str,
        chunk_id: str,
        document_type: str,
        review_prompt: str,
        task_auth: Dict,
        correction: bool = False,
        blocks: Optional[List[Dict]] = None,
        progress_callback=None,
    ) -> object:
        if str(task_auth.get("accessMethod", "")) != ACCESS_DIRECT_MODEL:
            raise AdapterError(
                "MODEL_DIRECT_REQUIRED",
                "全篇审查只支持模型直连配置。",
                status_code=409,
            )
        try:
            prompt_asset = self.system_prompt_store.load_stage(
                "word.document_review.full.chunk.correction"
                if correction else "word.document_review.full.chunk"
            )
        except SystemPromptError as exc:
            raise AdapterError(exc.code, exc.message, status_code=500) from exc
        source_blocks = blocks or [
            {
                "blockId": "paragraph-1",
                "blockType": "paragraph",
                "paragraphIndex": 1,
                "text": source_text,
            }
        ]
        query_payload = {
            "schemaVersion": "word.document_review.full.request.v1",
            "chunkId": chunk_id,
            "documentType": document_type,
            "reviewPrompt": review_prompt,
            "blocks": source_blocks,
        }
        if correction:
            query_payload["correctionInstruction"] = (
                "上次结果未通过严格 JSON 契约校验。请重新生成完整 JSON，"
                "不得输出 Markdown、解释或非 Schema 字段。"
            )
        body = self._post_direct_task(
            "word.document_review.full",
            trace_id,
            json.dumps(query_payload, ensure_ascii=False, separators=(",", ":")),
            task_auth,
            max(self.settings.timeout_seconds, DOCUMENT_REVIEW_TIMEOUT_SECONDS),
            prompt_asset=prompt_asset,
            response_format=_full_document_review_chunk_response_format(),
            progress_callback=progress_callback,
        )
        return FullDocumentReviewAnswer(
            str(body.get("answer", "")),
            str(body.get("finishReason", "")),
        )

    def full_document_review_aggregate(
        self,
        aggregate_input: Dict,
        trace_id: str,
        task_auth: Dict,
        correction: bool = False,
        progress_callback=None,
    ) -> object:
        if str(task_auth.get("accessMethod", "")) != ACCESS_DIRECT_MODEL:
            raise AdapterError(
                "MODEL_DIRECT_REQUIRED",
                "全篇审查只支持模型直连配置。",
                status_code=409,
            )
        try:
            prompt_asset = self.system_prompt_store.load_stage(
                "word.document_review.full.aggregate.correction"
                if correction else "word.document_review.full.aggregate"
            )
        except SystemPromptError as exc:
            raise AdapterError(exc.code, exc.message, status_code=500) from exc
        payload = dict(aggregate_input)
        if correction:
            payload["correctionInstruction"] = (
                "上次全局汇总未通过严格 JSON 契约校验。请只返回完整 JSON，"
                "所有 issueId、factId 和 anchorId 必须来自输入索引。"
            )
        body = self._post_direct_task(
            "word.document_review.full",
            trace_id,
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            task_auth,
            max(self.settings.timeout_seconds, DOCUMENT_REVIEW_TIMEOUT_SECONDS),
            prompt_asset=prompt_asset,
            response_format=_full_document_review_aggregate_response_format(),
            progress_callback=progress_callback,
        )
        return FullDocumentReviewAnswer(
            str(body.get("answer", "")),
            str(body.get("finishReason", "")),
        )

    def validate_model_configuration(
        self, configuration_id: str, trace_id: str
    ) -> Dict:
        task_auth = self.resolve_configuration_auth(configuration_id)
        configuration = task_auth["modelConfiguration"]
        task_type = str(configuration.get("taskType", ""))
        if task_type == "word.format_review":
            if str(configuration.get("accessMethod", "")) == ACCESS_WORKFLOW_PLATFORM:
                semantic_validation = self._validate_format_semantic_workflow(
                    configuration_id, trace_id, task_auth
                )
            else:
                semantic_validation = self._validate_format_semantic_direct(trace_id, task_auth)
            return {
                "success": True,
                "taskType": task_type,
                "configurationId": str(configuration.get("id", "")),
                "configurationName": str(configuration.get("name", "")),
                **self._validation_configuration_identity(configuration),
                "accessMethod": str(configuration.get("accessMethod", "")),
                "modelName": str(configuration.get("modelName", "")),
                "promptVersion": "format_semantics.v1",
                "formatSemanticValidation": semantic_validation,
            }
        probe = _VALIDATION_PROBES.get(task_type)
        if not probe:
            raise AdapterError(
                "MODEL_CONFIG_TASK_UNSUPPORTED", "不支持的任务类型。", status_code=400
            )
        timeout = max(self.settings.timeout_seconds, INTERACTIVE_WRITING_TIMEOUT_SECONDS)
        body = self.post_task(
            task_type,
            trace_id,
            {"validation": True},
            probe,
            timeout_seconds=timeout,
            task_auth=task_auth,
        )
        answer = extract_answer(body)
        _validate_probe_answer(task_type, answer)
        prompt_version = str(body.get("promptVersion", ""))
        if not prompt_version:
            try:
                prompt_version = str(self.system_prompt_store.metadata(task_type)["version"])
            except SystemPromptError:
                prompt_version = "platform-managed"
        return {
            "success": True,
            "taskType": task_type,
            "configurationId": str(configuration.get("id", "")),
            "configurationName": str(configuration.get("name", "")),
            **self._validation_configuration_identity(configuration),
            "accessMethod": str(configuration.get("accessMethod", "")),
            "modelName": str(configuration.get("modelName", "")),
            "promptVersion": prompt_version,
        }

    def _probe_direct_streaming(
        self,
        task_type: str,
        trace_id: str,
        query: str,
        task_auth: Dict,
        timeout: int,
    ) -> str:
        try:
            prompt_asset = self.system_prompt_store.load(task_type)
        except SystemPromptError as exc:
            raise AdapterError(exc.code, exc.message, status_code=500) from exc

        base_url = str(task_auth.get("providerBaseUrl", "")).rstrip("/")
        url = "{0}/chat/completions".format(base_url)
        payload_body = {
            "model": str(task_auth.get("modelName", "")),
            "messages": [
                {"role": "system", "content": prompt_asset["content"]},
                {"role": "user", "content": query},
            ],
            "stream": True,
        }
        temperature = task_auth.get("temperature")
        if temperature is not None:
            payload_body["temperature"] = temperature
        max_output_tokens = task_auth.get("maxOutputTokens")
        if max_output_tokens is not None:
            payload_body["max_tokens"] = int(max_output_tokens)

        debug_metadata = self.build_debug_metadata(task_type, task_auth=task_auth)
        record_provider_debug(
            {
                "traceId": trace_id,
                "taskType": task_type,
                "url": url,
                **debug_metadata,
                "validation": {
                    "stage": "streaming-probe",
                    "promptVersion": prompt_asset.get("version"),
                },
                "request": {"body": payload_body},
            }
        )

        req = urllib_request.Request(
            url,
            data=json.dumps(payload_body, ensure_ascii=False).encode("utf-8"),
            method="POST",
            headers={
                "Authorization": "Bearer {0}".format(
                    str(task_auth.get("apiKey", ""))
                ),
                "Content-Type": "application/json",
                "Accept": "text/event-stream",
                "X-Trace-Id": trace_id,
            },
        )

        started_at = time.monotonic()
        try:
            with urllib_request.urlopen(req, timeout=timeout) as response:
                accumulated = []
                terminated = False
                received_bytes = 0
                content_type = str(response.headers.get("Content-Type", "")).lower()
                if "text/event-stream" not in content_type:
                    raise StreamingUnsupportedError(
                        "直连模型未返回 text/event-stream。"
                    )
                for raw_line in response:
                    if time.monotonic() - started_at > timeout:
                        raise ProviderTimeoutError("模型流式能力验证超过等待时限。")
                    if isinstance(raw_line, bytes):
                        received_bytes += len(raw_line)
                        line = raw_line.decode("utf-8", errors="replace")
                    else:
                        line = str(raw_line)
                        received_bytes += len(line.encode("utf-8"))
                    if received_bytes > MAX_STREAMING_PROBE_RESPONSE_BYTES:
                        raise AdapterError(
                            "MODEL_RESPONSE_SIZE_LIMIT",
                            "模型流式能力验证响应超过 5 MiB 上限。",
                            status_code=502,
                        )
                    line = line.strip()
                    if not line:
                        continue
                    if line.startswith("data:"):
                        data_content = line[5:].strip()
                        if data_content == "[DONE]":
                            terminated = True
                            break
                        try:
                            chunk = json.loads(data_content)
                        except json.JSONDecodeError:
                            continue
                        if isinstance(chunk, dict) and isinstance(
                            chunk.get("error"), dict
                        ):
                            raise ProviderUnavailableError(
                                "模型后台在流式能力验证期间返回错误。"
                            )
                        choices = chunk.get("choices") or []
                        if choices and isinstance(choices, list):
                            choice = choices[0] if isinstance(choices[0], dict) else {}
                            delta = choice.get("delta") or {}
                            content = delta.get("content") or delta.get("text") or ""
                            if content:
                                accumulated.append(content)
                            if choice.get("finish_reason"):
                                terminated = True
                                break

                if not terminated:
                    raise ProviderMidStreamDisconnectError(
                        "模型后台在流式能力验证完成前断开连接。"
                    )

                return strip_think_tag_content("".join(accumulated))
        except error.HTTPError as exc:
            status = exc.code
            if status in (401, 403):
                raise ProviderAuthError("模型后台认证失败，请检查当前配置的 API Key。") from exc
            if status in (400, 404, 415, 422, 501):
                raise StreamingUnsupportedError("Streaming HTTP {0}".format(status)) from exc
            if status == 429:
                raise AdapterError(
                    "MODEL_RATE_LIMITED", "模型后台请求较多，请稍后重新提交。", status_code=429
                ) from exc
            raise ProviderUnavailableError(
                "模型后台暂时不可用，HTTP 状态码 {0}。".format(status)
            ) from exc
        except error.URLError as exc:
            reason = getattr(exc, "reason", "")
            if isinstance(reason, (TimeoutError, socket.timeout)) or "timed out" in str(reason).lower():
                raise ProviderTimeoutError() from exc
            raise ProviderUnavailableError("直连模型服务地址无法连接。") from exc
        except (
            IncompleteRead,
            RemoteDisconnected,
            ConnectionResetError,
            ConnectionAbortedError,
            BrokenPipeError,
        ) as exc:
            raise ProviderMidStreamDisconnectError(
                "模型后台在流式能力验证完成前断开连接。"
            ) from exc
        except (TimeoutError, socket.timeout) as exc:
            raise ProviderTimeoutError() from exc

    def validate_task_model_selection(
        self, task_type: str, selection_data: Dict, trace_id: str
    ) -> Dict:
        if self.direct_service_store is None:
            raise AdapterError(
                "DIRECT_SERVICE_UNAVAILABLE", "直连服务存储未初始化。", status_code=500
            )
        service_id = str(selection_data.get("serviceId", "")).strip()
        if not service_id:
            current_sel = self.direct_service_store.get_task_model_selection(task_type)
            selection_data = {**current_sel, **selection_data}
            service_id = str(current_sel.get("serviceId", "")).strip()
        if not service_id:
            raise AdapterError(
                "DIRECT_SERVICE_REQUIRED", "请先选择直连服务。", status_code=400
            )

        service = self.direct_service_store.get_service(service_id, include_secret=True)
        if not service.get("serviceBaseUrl"):
            raise AdapterError(
                "DIRECT_SERVICE_URL_REQUIRED", "直连服务缺少服务地址，无法验证。", status_code=400
            )
        if not service.get("keyConfigured") or not service.get("apiKey"):
            raise AdapterError(
                "DIRECT_SERVICE_KEY_REQUIRED", "直连服务未配置 API Key，无法验证。", status_code=400
            )

        is_custom = bool(selection_data.get("customModel", False))
        explicit_model_name = str(selection_data.get("modelName") or "").strip()
        if is_custom and not explicit_model_name:
            raise AdapterError(
                "DIRECT_SERVICE_MODEL_REQUIRED",
                "高级手填模型名称不能为空。",
                status_code=400,
            )
        model_name = str(
            explicit_model_name or service.get("defaultModel") or ""
        ).strip()
        if not model_name:
            raise AdapterError(
                "DIRECT_SERVICE_MODEL_REQUIRED", "请选择或填写模型名称。", status_code=400
            )

        catalog = service.get("modelCatalog") or {}
        if is_custom and not catalog.get("manualModelAllowed"):
            raise AdapterError(
                "DIRECT_SERVICE_CUSTOM_MODEL_NOT_ALLOWED",
                "模型目录当前可用时不能使用高级手填模型。",
                status_code=400,
            )
        if not is_custom and catalog.get("status") == "expired":
            raise AdapterError(
                "DIRECT_SERVICE_MODEL_CATALOG_EXPIRED",
                "模型目录缓存已过期，请先刷新目录后再验证任务。",
                status_code=400,
            )
        if not is_custom and not catalog.get("usableForSelection"):
            raise AdapterError(
                "DIRECT_SERVICE_MODEL_CATALOG_UNAVAILABLE",
                "模型目录当前不可用，请使用高级手填模型并先验证真实任务调用。",
                status_code=400,
            )
        if (
            not is_custom
            and catalog.get("usableForSelection")
            and model_name not in (catalog.get("models") or [])
        ):
            raise AdapterError(
                "DIRECT_SERVICE_MODEL_DISAPPEARED",
                f"所选模型 {model_name} 已从服务目录中移除，请重新选择模型。",
                status_code=400,
            )

        model_configuration = {
            "id": service["id"],
            "name": service.get("name", ""),
            "taskType": task_type,
            "providerType": ACCESS_DIRECT_MODEL,
            "accessMethod": ACCESS_DIRECT_MODEL,
            "modelName": model_name,
            "temperature": selection_data.get("temperature"),
            "maxOutputTokens": selection_data.get("maxOutputTokens"),
            "contextWindowTokens": int(
                selection_data.get("contextWindowTokens") or DEFAULT_CONTEXT_WINDOW_TOKENS
            ),
            "imageInputMode": selection_data.get(
                "imageInputMode",
                "openai_image_url" if task_type == "word.format_review" else "disabled",
            ),
        }
        task_auth = {
            "providerBaseUrl": service["serviceBaseUrl"].rstrip("/"),
            "providerChatPath": "/chat/completions",
            "providerMode": "blocking",
            "providerName": service.get("name", "模型直连"),
            "providerType": ACCESS_DIRECT_MODEL,
            "providerInputMode": DIFY_INPUT_MODE_LEGACY,
            "accessMethod": ACCESS_DIRECT_MODEL,
            "modelConfiguration": model_configuration,
            "modelConfigurationId": service["id"],
            "modelConfigurationName": service.get("name", ""),
            "modelName": model_name,
            "temperature": selection_data.get("temperature"),
            "maxOutputTokens": selection_data.get("maxOutputTokens"),
            "contextWindowTokens": int(
                selection_data.get("contextWindowTokens") or DEFAULT_CONTEXT_WINDOW_TOKENS
            ),
            "contextWindowTokensExplicit": selection_data.get("contextWindowTokens") is not None,
            "formatSemanticValidation": None,
            "formatSemanticReadiness": None,
            "imageSemantics": self.image_semantic_settings(),
            "imageInputMode": selection_data.get(
                "imageInputMode",
                "openai_image_url" if task_type == "word.format_review" else "disabled",
            ),
            "imageExternalAuthorization": None,
            "imageSemanticValidation": None,
            "apiKeyRef": service["id"],
            "apiKey": service.get("apiKey", ""),
            "authSource": "task-file",
            "directService": service,
            "taskModelSelection": selection_data,
        }

        if task_type == "word.format_review":
            selection_data = {**selection_data, "serviceId": service_id}
            binding = self.direct_service_store.format_validation_binding(service, selection_data)
            try:
                format_semantic_validation = self._validate_format_semantic_direct(trace_id, task_auth)
            except AdapterError as exc:
                self.direct_service_store.record_format_semantic_validation(
                    task_type, {"success": False, "errorCode": exc.code},
                    selection=selection_data, expected_binding=binding,
                )
                raise
            self.direct_service_store.record_format_semantic_validation(
                task_type, format_semantic_validation,
                selection=selection_data, expected_binding=binding,
            )
            if is_custom:
                self.direct_service_store.mark_custom_model_validated(
                    task_type,
                    service["id"],
                    model_name,
                    expected_service_base_url=service.get("serviceBaseUrl", ""),
                    expected_api_key_fingerprint=DirectServiceStore.api_key_fingerprint(
                        service.get("apiKey", "")
                    ),
                )
            return {
                "success": True,
                "validationScope": "task",
                "taskType": task_type,
                "serviceId": service["id"],
                "serviceName": service.get("name", ""),
                "modelName": model_name,
                "customModel": is_custom,
                "customModelValidated": True,
                "taskCallPerformed": True,
                "taskContractValidated": True,
                "promptVersion": "format_semantics.v1",
                "formatSemanticValidation": format_semantic_validation,
                "mayIncurModelCost": True,
                "costWarning": "验证调用会真实请求模型，可能产生费用并等待服务返回。",
            }

        probe = _VALIDATION_PROBES.get(task_type)
        if not probe:
            raise AdapterError(
                "MODEL_CONFIG_TASK_UNSUPPORTED", "不支持的任务类型。", status_code=400
            )

        timeout = max(self.settings.timeout_seconds, INTERACTIVE_WRITING_TIMEOUT_SECONDS)
        streaming_status = "not_checked"

        try:
            answer = self._probe_direct_streaming(
                task_type, trace_id, probe, task_auth, timeout
            )
            _validate_probe_answer(task_type, answer)
            streaming_status = "validated"
        except StreamingUnsupportedError:
            body = self.post_task(
                task_type,
                trace_id,
                {"validation": True},
                probe,
                timeout_seconds=timeout,
                task_auth=task_auth,
            )
            answer = extract_answer(body)
            _validate_probe_answer(task_type, answer)
            streaming_status = "unsupported"

        binding = {
            "serviceRevision": int(service.get("revision", 1)),
            "serviceBaseUrl": normalize_service_base_url(
                service.get("serviceBaseUrl", "")
            ),
            "apiKeyFingerprint": DirectServiceStore.api_key_fingerprint(
                service.get("apiKey", "")
            ),
        }
        self.direct_service_store.record_streaming_capability(
            service["id"],
            model_name,
            streaming_status,
            expected_binding=binding,
        )

        if is_custom:
            self.direct_service_store.mark_custom_model_validated(
                task_type,
                service["id"],
                model_name,
                expected_service_base_url=service.get("serviceBaseUrl", ""),
                expected_api_key_fingerprint=DirectServiceStore.api_key_fingerprint(
                    service.get("apiKey", "")
                ),
            )

        return {
            "success": True,
            "validationScope": "task",
            "taskType": task_type,
            "serviceId": service["id"],
            "serviceName": service.get("name", ""),
            "modelName": model_name,
            "customModel": is_custom,
            "customModelValidated": True,
            "taskCallPerformed": True,
            "taskContractValidated": True,
            "streamingCapability": streaming_status,
            "mayIncurModelCost": True,
            "costWarning": "验证调用会真实请求模型，可能产生费用并等待服务返回。",
        }

    def _validation_configuration_identity(self, configuration: Dict) -> Dict:
        task_type = str(configuration.get("taskType", ""))
        configuration_id = str(configuration.get("id", ""))
        active_id = ""
        active_name = ""
        if self.model_configuration_store is not None:
            task_data = self.model_configuration_store.list_for_task(task_type)
            active_id = str(task_data.get("activeConfigurationId", ""))
            active_configuration = next(
                (
                    item
                    for item in task_data.get("configurations", [])
                    if str(item.get("id", "")) == active_id
                ),
                None,
            )
            active_name = str((active_configuration or {}).get("name", ""))
        return {
            "configurationRevision": int(configuration.get("configVersion") or 1),
            "isCurrent": bool(configuration_id and configuration_id == active_id),
            "currentConfigurationId": active_id,
            "currentConfigurationName": active_name,
        }

    @staticmethod
    def _format_semantic_validation_fixtures() -> Tuple[Dict[str, str], Dict[str, Dict]]:
        binding = {
            "contentSha256": "synthetic-content",
            "structureSha256": "synthetic-structure",
            "formatSha256": "synthetic-format",
        }
        candidates = {
            "classify_role": {
                "synthetic-1": {
                    "allowedTargets": [
                        {"role": "heading", "attributes": {"level": 1}}
                    ]
                }
            },
            "associate_caption": {
                "synthetic-2": {"allowedTargetBlockIds": ["figure-1"]}
            },
            "suggest_table_caption": {
                "synthetic-3": {
                    "tableType": "data",
                    "captionStatus": "missing",
                    "associationStatus": "missing",
                    "evidence": {
                        "evidenceStatus": "complete",
                        "headers": [["合成字段"]],
                        "rows": [["合成值"]],
                    },
                }
            },
            "suggest_figure_caption": {"synthetic-4": {"allowedTargets": []}},
        }
        return binding, candidates

    def validate_task_image_selection(self, task_type: str, trace_id: str) -> Dict:
        import secrets
        import struct
        import tempfile
        import zlib

        store = self.direct_service_store
        service, selection, binding, authorization = store.image_validation_snapshot(task_type)
        auth = {
            "providerBaseUrl": service["serviceBaseUrl"],
            "apiKey": service["apiKey"],
            "modelName": selection.get("effectiveModel"),
            "temperature": selection.get("temperature"),
            "maxOutputTokens": selection.get("maxOutputTokens"),
            "contextWindowTokens": selection.get("contextWindowTokens"),
            "accessMethod": ACCESS_DIRECT_MODEL,
        }
        palette = [
            ("red", (255, 0, 0)), ("green", (0, 255, 0)), ("blue", (0, 0, 255)),
            ("yellow", (255, 255, 0)), ("cyan", (0, 255, 255)), ("magenta", (255, 0, 255)),
        ]
        panels = []
        for _ in range(8):
            choices = [item for item in palette if not panels or item != panels[-1]]
            panels.append(secrets.choice(choices))
        def chunk(kind, content):
            return struct.pack("!I", len(content)) + kind + content + struct.pack("!I", zlib.crc32(kind + content) & 0xffffffff)
        png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack("!2I5B", 512, 64, 8, 2, 0, 0, 0)) +
               chunk(b"IDAT", zlib.compress((b"\0" + b"".join(bytes(rgb) * 64 for _, rgb in panels)) * 64)) + chunk(b"IEND", b""))
        try:
            with tempfile.TemporaryDirectory(prefix="ai-wps-image-probe-") as directory:
                image_path = Path(directory) / "probe.png"
                image_path.write_bytes(png)
                result = self._post_direct_task(
                    task_type, trace_id,
                    "Identify the eight vertical color panels in the attached image, from left to right. Reply only with eight English color names separated by spaces. Use red, green, blue, yellow, cyan, or magenta.",
                    auth, max(self.settings.timeout_seconds, INTERACTIVE_WRITING_TIMEOUT_SECONDS),
                    prompt_asset={"content": "Inspect the supplied synthetic test image.", "version": "image-probe.v1", "hashPrefix": ""},
                    image_files=[{"path": str(image_path), "mimeType": "image/png"}],
                )
            if re.findall(r"[a-z]+", str(result.get("answer", "")).lower()) != [color for color, _ in panels]:
                raise AdapterError("IMAGE_CAPABILITY_VALIDATION_FAILED", "模型未能识别合成测试图片，图片语义保持关闭。", status_code=502)
        except AdapterError as exc:
            store.record_image_semantic_validation(task_type, {"validated": False, "errorCode": exc.code},
                                                   expected_binding=binding, expected_authorization=authorization)
            raise
        saved = store.record_image_semantic_validation(task_type, {"validated": True},
                                                       expected_binding=binding, expected_authorization=authorization)
        return {"success": True, "taskModelSelection": saved, "visualCapability": {"validated": True},
                "mayIncurModelCost": True}

    def _validate_format_semantic_direct(self, trace_id: str, task_auth: Dict) -> Dict:
        from app.services.word.format_semantics import (
            FORMAT_SEMANTIC_SCHEMA_VERSION,
            FormatSemanticExecutor,
        )

        binding, fixtures = self._format_semantic_validation_fixtures()
        candidates = fixtures["classify_role"]
        request_payload = {
            "schemaVersion": FORMAT_SEMANTIC_SCHEMA_VERSION,
            "operation": "classify_role",
            "snapshotBinding": binding,
            "candidates": candidates,
        }
        candidate_json = json.dumps(request_payload, ensure_ascii=False, sort_keys=True)
        prompt = "\n".join(
            [
                "你是 Word 格式语义协议验证助手。",
                "只处理下列合成 classify_role 候选，不得接收或引用用户文档。",
                "只返回符合 format_semantics.v1 的 JSON 对象，不要返回旧式 JSON 数组、Markdown 或解释。",
                json.dumps(request_payload, ensure_ascii=False),
            ]
        )
        def call(query: str, output_budget: int) -> Dict:
            return self.format_semantics(
                "classify_role",
                trace_id,
                {
                    "operation": "classify_role",
                    "snapshotBinding": binding,
                    "candidate_json": candidate_json,
                },
                query,
                task_auth=task_auth,
                output_token_budget=output_budget,
            )

        validation = FormatSemanticExecutor(call, task_auth=task_auth).execute(
            "classify_role",
            prompt,
            candidates,
            binding,
        )
        if validation.get("error") is not None:
            raise validation["error"]
        return {
            "success": True,
            "protocolVersion": FORMAT_SEMANTIC_SCHEMA_VERSION,
            "operations": {"classify_role": True},
            "correctionCount": int(validation.get("correctionCount") or 0),
            "visualCapability": {
                "validated": False,
                "mode": "contract_only",
                "reason": "synthetic_image_files_omitted",
            },
        }

    def _validate_format_semantic_workflow(
        self, configuration_id: str, trace_id: str, task_auth: Dict
    ) -> Dict:
        """Validate all format_semantics.v1 operations with synthetic facts only."""
        from app.services.word.format_semantics import (
            FORMAT_SEMANTIC_OPERATIONS,
            FORMAT_SEMANTIC_SCHEMA_VERSION,
            FormatSemanticContract,
        )

        del configuration_id
        binding, cases = self._format_semantic_validation_fixtures()
        operations = {}
        for operation in FORMAT_SEMANTIC_OPERATIONS:
            candidates = cases[operation]
            candidate_json = json.dumps(
                {
                    "schemaVersion": FORMAT_SEMANTIC_SCHEMA_VERSION,
                    "operation": operation,
                    "snapshotBinding": binding,
                    "candidates": candidates,
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            input_data = {"candidate_json": candidate_json}
            if operation == "suggest_figure_caption":
                input_data["image_files"] = []
            response = self.format_semantics(
                operation,
                trace_id,
                input_data,
                "format_semantics.v1 synthetic validation",
                task_auth=task_auth,
            )
            payload = response.get("result_json") if isinstance(response, dict) else None
            if not isinstance(payload, dict):
                raise AdapterError(
                    "FORMAT_SEMANTIC_RESULT_JSON_INVALID",
                    "格式语义验证未返回有效 result_json。",
                    status_code=502,
                )
            FormatSemanticContract.validate_response(
                operation,
                payload,
                candidates,
                binding,
                require_complete=True,
            )
            operations[operation] = True
        return {
            "success": True,
            "protocolVersion": FORMAT_SEMANTIC_SCHEMA_VERSION,
            "operations": operations,
            "visualCapability": {
                "validated": False,
                "mode": "contract_only",
                "reason": "synthetic_image_files_omitted",
            },
        }

    def record_skipped_debug(
        self,
        task_type: str,
        trace_id: str,
        query: str,
        skip_reason: str,
        provider: str = "local",
    ) -> None:
        self.refresh_settings()
        record_provider_debug(
            {
                "traceId": trace_id,
                "taskType": task_type,
                **self.build_debug_metadata(task_type, provider=provider),
                "skipReason": skip_reason,
                "request": {"body": build_provider_request_payload(self.settings, {}, query)},
            }
        )

    def record_unconfigured_debug(self, task_type: str, trace_id: str, query: str) -> None:
        self.record_skipped_debug(
            task_type=task_type,
            trace_id=trace_id,
            query=query,
            skip_reason="provider_not_configured",
            provider="mock",
        )

    def excel_analysis(
        self,
        request: ExcelAnalysisRequest,
        trace_id: str,
        task_auth: Optional[Dict] = None,
        progress_callback=None,
    ) -> Dict:
        prompt = build_excel_analysis_prompt(request)
        task_type = "excel.analysis"
        has_auth_snapshot = task_auth is not None
        resolved_task_auth = task_auth or {}
        configured = (
            bool(
                str(resolved_task_auth.get("providerBaseUrl", "")).strip()
                and str(resolved_task_auth.get("apiKey", "")).strip()
            )
            if has_auth_snapshot
            else self.is_task_configured(task_type)
        )
        if not configured:
            if not _mock_provider_enabled():
                raise AdapterError(
                    "MODEL_CONFIG_INCOMPLETE",
                    "智能分析尚未配置可用的模型配置，请先前往设置完成配置。",
                    status_code=400,
                )
            logger.info("traceId=%s provider=mock task=excel.analysis", trace_id)
            if has_auth_snapshot:
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": "",
                        **self.build_debug_metadata(
                            task_type,
                            provider="mock",
                            task_auth=resolved_task_auth,
                        ),
                        "skipReason": "provider_not_configured",
                        "request": {
                            "body": build_provider_request_payload(
                                self.settings,
                                {},
                                prompt,
                                input_mode=str(
                                    resolved_task_auth.get("providerInputMode")
                                    or DIFY_INPUT_MODE_LEGACY
                                ),
                                response_mode=str(
                                    resolved_task_auth.get("providerMode", "")
                                ),
                            )
                        },
                    }
                )
            else:
                self.record_unconfigured_debug(task_type, trace_id, prompt)
            if progress_callback:
                progress_callback("parsing")
            return {
                "structuredReport": {
                    "overview": "已读取 {0} 行、{1} 列表格数据。".format(
                        request.table.row_count,
                        request.table.column_count,
                    ),
                    "findings": ["请配置智能分析模型后台后获取完整分析。"],
                    "risks": [],
                    "actions": ["在设置页保存 excel.analysis 的任务级 API Key。"],
                },
                "plainText": "已读取表格数据。请配置智能分析模型后台后生成正式分析报告。",
                "provider": "mock",
                "prompt": prompt,
            }

        post_kwargs = {
            "timeout_seconds": max(
                self.settings.timeout_seconds,
                EXCEL_ANALYSIS_TIMEOUT_SECONDS,
            )
        }
        if has_auth_snapshot:
            post_kwargs["task_auth"] = resolved_task_auth
        if progress_callback is not None:
            post_kwargs["progress_callback"] = progress_callback
        if progress_callback:
            progress_callback("provider_processing")
        body = self.post_task(
            task_type,
            trace_id,
            {
                "scene": "excel",
                "rowCount": request.table.row_count,
                "columnCount": request.table.column_count,
                "truncated": request.table.truncated,
            },
            prompt,
            **post_kwargs
        )
        if progress_callback:
            progress_callback("parsing")
        parsed = parse_excel_analysis_answer(extract_answer(body))
        logger.info("traceId=%s provider=enterprise-dify-chat task=excel.analysis", trace_id)
        return {
            **parsed,
            "provider": self.build_provider_source(
                task_type, resolved_task_auth if has_auth_snapshot else None
            ),
            "prompt": prompt,
            "conversationId": body.get("conversation_id", ""),
            "messageId": body.get("message_id", ""),
        }

    def excel_formula_assistant(
        self,
        request: ExcelFormulaAssistantRequest,
        trace_id: str,
        task_auth: Optional[Dict] = None,
        progress_callback=None,
    ) -> Dict:
        prompt = build_excel_formula_prompt(request)
        task_type = "excel.formula_assistant"
        has_auth_snapshot = task_auth is not None
        resolved_task_auth = task_auth or {}
        configured = (
            bool(
                str(resolved_task_auth.get("providerBaseUrl", "")).strip()
                and str(resolved_task_auth.get("apiKey", "")).strip()
            )
            if has_auth_snapshot
            else self.is_task_configured(task_type)
        )
        if not configured:
            if not _mock_provider_enabled():
                raise AdapterError(
                    "MODEL_CONFIG_INCOMPLETE",
                    "公式助手尚未配置可用的模型配置，请先前往设置完成配置。",
                    status_code=400,
                )
            logger.info(
                "traceId=%s provider=mock task=excel.formula_assistant",
                trace_id,
            )
            if has_auth_snapshot:
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": "",
                        **self.build_debug_metadata(
                            task_type,
                            provider="mock",
                            task_auth=resolved_task_auth,
                        ),
                        "skipReason": "provider_not_configured",
                        "request": {
                            "body": build_provider_request_payload(
                                self.settings,
                                {},
                                prompt,
                                input_mode=str(
                                    resolved_task_auth.get("providerInputMode")
                                    or DIFY_INPUT_MODE_LEGACY
                                ),
                                response_mode=str(
                                    resolved_task_auth.get("providerMode", "")
                                ),
                            )
                        },
                    }
                )
            else:
                self.record_unconfigured_debug(task_type, trace_id, prompt)
            if progress_callback:
                progress_callback("parsing")
            return {
                "mode": request.options.mode,
                "originalFormula": "",
                "primaryFormula": "",
                "alternativeFormula": "",
                "suggestedTarget": "",
                "explanation": (
                    "已读取选区已有公式，请配置公式助手模型后台后执行解释排错。"
                    if request.options.mode == "explain"
                    else "已读取明确选区，请配置公式助手模型后台后生成推荐公式。"
                ),
                "components": [],
                "referenceRanges": [],
                "issues": [],
                "assumptions": (
                    ["选区上下文已截断，只读取 30 行 × 20 列以内的数据。"]
                    if request.selection.truncated
                    else []
                ),
                "compatibilityNotes": [
                    "请在设置页保存 excel.formula_assistant 的任务级 API Key。"
                ],
                "rawFinalResult": "",
                "parseDiagnostic": "",
                "copyText": "",
                "provider": "mock",
                "prompt": prompt,
            }

        post_kwargs = {
            "timeout_seconds": max(
                self.settings.timeout_seconds,
                EXCEL_FORMULA_ASSISTANT_TIMEOUT_SECONDS,
            )
        }
        if has_auth_snapshot:
            post_kwargs["task_auth"] = resolved_task_auth
        if progress_callback is not None:
            post_kwargs["progress_callback"] = progress_callback
        body = self.post_task(
            task_type,
            trace_id,
            {
                "scene": "excel",
                "mode": request.options.mode,
                "rowCount": request.selection.row_count,
                "columnCount": request.selection.column_count,
                "truncated": request.selection.truncated,
            },
            prompt,
            **post_kwargs
        )
        if progress_callback:
            progress_callback("parsing")
        parsed = parse_excel_formula_answer(extract_answer(body))
        logger.info(
            "traceId=%s provider=enterprise-dify-chat task=excel.formula_assistant",
            trace_id,
        )
        return {
            **parsed,
            "provider": self.build_provider_source(
                task_type, resolved_task_auth if has_auth_snapshot else None
            ),
            "prompt": prompt,
            "conversationId": body.get("conversation_id", ""),
            "messageId": body.get("message_id", ""),
        }

    def excel_smart_fill(
        self,
        request: ExcelSmartFillRequest,
        trace_id: str,
        task_auth: Optional[Dict] = None,
        progress_callback=None,
        timeout_seconds: Optional[float] = None,
        deadline_monotonic: Optional[float] = None,
        clock=time.monotonic,
    ) -> Dict:
        from app.services.excel.smart_fill import validate_smart_fill_request_limits

        validate_smart_fill_request_limits(request)
        prompt = build_excel_smart_fill_prompt(request)
        task_type = "excel.smart_fill"
        expected_item_ids = [item.item_id for item in request.items]
        has_auth_snapshot = task_auth is not None
        resolved_task_auth = task_auth or {}
        configured = (
            bool(
                str(resolved_task_auth.get("providerBaseUrl", "")).strip()
                and str(resolved_task_auth.get("apiKey", "")).strip()
            )
            if has_auth_snapshot
            else self.is_task_configured(task_type)
        )
        if not configured:
            if not _mock_provider_enabled():
                raise AdapterError(
                    "MODEL_CONFIG_INCOMPLETE",
                    "智能填写尚未配置可用的模型配置，请先前往设置完成配置。",
                    status_code=400,
                )
            if progress_callback:
                progress_callback("parsing")
            return {
                "schemaVersion": "excel.smart_fill.v2",
                "items": [
                    {
                        "itemId": item_id,
                        "status": "insufficient_information",
                        "valueType": "text",
                        "value": "",
                    }
                    for item_id in expected_item_ids
                ],
                "provider": "mock",
            }

        now_mono = clock()
        if deadline_monotonic is not None and now_mono >= deadline_monotonic:
            raise AdapterError(
                "PROVIDER_TIMEOUT",
                "智能填写模型请求超时，请稍后重试。",
                status_code=504,
            )

        effective_timeout = EXCEL_SMART_FILL_TIMEOUT_SECONDS
        if timeout_seconds is not None:
            effective_timeout = min(effective_timeout, max(0.0, float(timeout_seconds)))
        elif self.settings.timeout_seconds:
            effective_timeout = min(effective_timeout, max(0.0, float(self.settings.timeout_seconds)))

        if deadline_monotonic is not None:
            remaining_total = max(0.0, deadline_monotonic - now_mono)
            effective_timeout = min(effective_timeout, remaining_total)

        if effective_timeout <= 0:
            raise AdapterError(
                "PROVIDER_TIMEOUT",
                "智能填写模型请求超时，请稍后重试。",
                status_code=504,
            )

        if progress_callback:
            progress_callback("provider_processing")
        post_kwargs = {
            "timeout_seconds": effective_timeout,
            "response_format": excel_smart_fill_response_format(),
            "allow_response_format_fallback": True,
        }
        if has_auth_snapshot:
            post_kwargs["task_auth"] = resolved_task_auth
        if progress_callback is not None:
            post_kwargs["progress_callback"] = progress_callback
        input_data = {
            "scene": "excel",
            "itemCount": len(expected_item_ids),
            "batchLimit": 50,
            "sourceRowCount": request.source.row_count,
            "sourceColumnCount": request.source.column_count,
            "sourceTruncated": request.source.truncated,
        }

        def post_smart_fill(query, metadata, call_timeout=None):
            kwargs = dict(post_kwargs)
            if call_timeout is not None:
                kwargs["timeout_seconds"] = call_timeout
            return self.post_task(
                task_type,
                trace_id,
                metadata,
                query,
                **kwargs
            )

        body = post_smart_fill(
            prompt,
            input_data,
        )
        result_body = body
        if progress_callback:
            progress_callback("parsing")
        try:
            parsed = parse_excel_smart_fill_answer(
                extract_answer(body), expected_item_ids=expected_item_ids
            )
        except AdapterError as first_error:
            if first_error.code != "MODEL_RESULT_INVALID":
                raise
            now_mono = clock()
            if deadline_monotonic is not None and now_mono >= deadline_monotonic:
                raise AdapterError(
                    "PROVIDER_TIMEOUT",
                    "智能填写模型请求超时，请稍后重试。",
                    status_code=504,
                )
            if deadline_monotonic is not None:
                remaining_total = max(0.0, deadline_monotonic - now_mono)
                retry_timeout = min(effective_timeout, remaining_total)
            else:
                retry_timeout = effective_timeout
            if retry_timeout <= 0:
                raise AdapterError(
                    "PROVIDER_TIMEOUT",
                    "智能填写模型请求超时，请稍后重试。",
                    status_code=504,
                )
            if progress_callback:
                progress_callback("retrying")
            correction_query = prompt + "\n结构纠正：上一次输出未通过严格契约校验。请重新输出完整 JSON；不得输出 Markdown、解释文字或任何额外字段。"
            corrected_body = post_smart_fill(
                correction_query,
                {**input_data, "correctionAttempt": 1},
                call_timeout=retry_timeout,
            )
            parsed = parse_excel_smart_fill_answer(
                extract_answer(corrected_body), expected_item_ids=expected_item_ids
            )
            result_body = corrected_body
        validate_smart_fill_result_limits(parsed)
        logger.info(
            "traceId=%s provider=enterprise-dify-chat task=excel.smart_fill items=%s",
            trace_id,
            len(expected_item_ids),
        )
        return {
            **parsed,
            "provider": self.build_provider_source(
                task_type, resolved_task_auth if has_auth_snapshot else None
            ),
            "conversationId": result_body.get("conversation_id", ""),
            "messageId": result_body.get("message_id", ""),
        }

    def ppt_slide_assistant(
        self,
        context: Dict,
        user_instruction: str,
        mode: str,
        trace_id: str,
        task_auth: Optional[Dict] = None,
        progress_callback=None,
    ) -> Dict:
        prompt = build_ppt_slide_prompt(context, user_instruction, mode)
        task_type = "ppt.slide_assistant"
        has_auth_snapshot = task_auth is not None
        resolved_task_auth = task_auth or {}
        configured = (
            bool(
                str(resolved_task_auth.get("providerBaseUrl", "")).strip()
                and str(resolved_task_auth.get("apiKey", "")).strip()
            )
            if has_auth_snapshot
            else self.is_task_configured(task_type)
        )
        if not configured:
            if not _mock_provider_enabled():
                raise AdapterError(
                    "MODEL_CONFIG_INCOMPLETE",
                    "智能总结尚未配置可用的模型配置，请先前往设置完成配置。",
                    status_code=400,
                )
            logger.info("traceId=%s provider=mock task=ppt.slide_assistant", trace_id)
            if has_auth_snapshot:
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": "",
                        **self.build_debug_metadata(
                            task_type,
                            provider="mock",
                            task_auth=resolved_task_auth,
                        ),
                        "skipReason": "provider_not_configured",
                        "request": {
                            "body": build_provider_request_payload(
                                self.settings,
                                {},
                                prompt,
                                input_mode=str(
                                    resolved_task_auth.get("providerInputMode")
                                    or DIFY_INPUT_MODE_LEGACY
                                ),
                                response_mode=str(
                                    resolved_task_auth.get("providerMode", "")
                                ),
                            )
                        },
                    }
                )
            else:
                self.record_unconfigured_debug(task_type, trace_id, prompt)
            if progress_callback:
                progress_callback("parsing")
            return build_ppt_unconfigured_result(context, mode, prompt)

        post_kwargs = {
            "timeout_seconds": max(
                self.settings.timeout_seconds,
                PPT_SLIDE_ASSISTANT_TIMEOUT_SECONDS,
            )
        }
        if has_auth_snapshot:
            post_kwargs["task_auth"] = resolved_task_auth
        if progress_callback is not None:
            post_kwargs["progress_callback"] = progress_callback
        body = self.post_task(
            task_type,
            trace_id,
            {
                "scene": "ppt",
                "slideIndex": context["index"],
                "mode": mode,
                "truncated": context["truncated"],
            },
            prompt,
            **post_kwargs,
        )
        if progress_callback:
            progress_callback("parsing")
        parsed = parse_ppt_slide_answer(extract_answer(body))
        logger.info("traceId=%s provider=enterprise-dify-chat task=ppt.slide_assistant", trace_id)
        return {
            **parsed,
            "modeUsed": mode,
            "provider": self.build_provider_source(
                task_type, resolved_task_auth if has_auth_snapshot else None
            ),
            "prompt": prompt,
            "conversationId": body.get("conversation_id", ""),
            "messageId": body.get("message_id", ""),
        }

    def ppt_structure_review(
        self,
        request: PptStructureReviewRequest,
        trace_id: str,
        task_auth: Optional[Dict] = None,
        progress_callback=None,
    ) -> Dict:
        prompt = build_ppt_structure_review_prompt(request)
        task_type = "ppt.structure_review"
        has_auth_snapshot = task_auth is not None
        resolved_task_auth = task_auth or {}
        configured = (
            bool(
                str(resolved_task_auth.get("providerBaseUrl", "")).strip()
                and str(resolved_task_auth.get("apiKey", "")).strip()
            )
            if has_auth_snapshot
            else self.is_task_configured(task_type)
        )
        if not configured:
            if not _mock_provider_enabled():
                raise AdapterError(
                    "MODEL_CONFIG_INCOMPLETE",
                    "结构审查尚未配置可用的模型配置，请先前往设置完成配置。",
                    status_code=400,
                )
            logger.info("traceId=%s provider=mock task=ppt.structure_review", trace_id)
            if has_auth_snapshot:
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": "",
                        **self.build_debug_metadata(
                            task_type,
                            provider="mock",
                            task_auth=resolved_task_auth,
                        ),
                        "skipReason": "provider_not_configured",
                        "request": {
                            "body": build_provider_request_payload(
                                self.settings,
                                {},
                                prompt,
                                input_mode=str(
                                    resolved_task_auth.get("providerInputMode")
                                    or DIFY_INPUT_MODE_LEGACY
                                ),
                                response_mode=str(
                                    resolved_task_auth.get("providerMode", "")
                                ),
                            )
                        },
                    }
                )
            else:
                self.record_unconfigured_debug(task_type, trace_id, prompt)
            if progress_callback:
                progress_callback("parsing")
            return {
                "overallStoryline": "已读取指定页段，请配置结构审查模型后台后获取语义审查。",
                "inferredChapters": [],
                "highPriorityIssues": [],
                "generalSuggestions": [
                    {
                        "code": "workflow_unconfigured",
                        "message": "请在设置页保存 ppt.structure_review 的工作流配置。",
                        "slideNumbers": [],
                    }
                ],
                "slideRecommendations": [],
                "recommendedOutline": [],
                "rawAnswer": None,
                "parseFallbackReason": None,
                "provider": "mock",
                "prompt": prompt,
            }

        post_kwargs = {
            "timeout_seconds": max(
                self.settings.timeout_seconds,
                PPT_STRUCTURE_REVIEW_TIMEOUT_SECONDS,
            )
        }
        if has_auth_snapshot:
            post_kwargs["task_auth"] = resolved_task_auth
        if progress_callback is not None:
            post_kwargs["progress_callback"] = progress_callback
        body = self.post_task(
            task_type,
            trace_id,
            {
                "scene": "ppt",
                "startSlide": request.scope.start_slide,
                "endSlide": request.scope.end_slide,
                "totalSlides": request.scope.total_slides,
            },
            prompt,
            **post_kwargs,
        )
        if progress_callback:
            progress_callback("parsing")
        parsed = parse_ppt_structure_review_answer(extract_answer(body))
        logger.info(
            "traceId=%s provider=enterprise-dify-chat task=ppt.structure_review",
            trace_id,
        )
        return {
            **parsed,
            "provider": self.build_provider_source(
                task_type, resolved_task_auth if has_auth_snapshot else None
            ),
            "prompt": prompt,
            "conversationId": body.get("conversation_id", ""),
            "messageId": body.get("message_id", ""),
        }

    def ppt_document_summary(
        self,
        staged_document,
        requested_slide_count: int,
        user_instruction: str,
        trace_id: str,
        progress_callback=None,
        task_auth: Optional[Dict] = None,
    ) -> Dict:
        task_type = "ppt.slide_assistant"
        slide_count = _normalize_ppt_document_slide_count(requested_slide_count)
        prompt = build_ppt_document_prompt(slide_count, user_instruction)
        resolved_task_auth = (
            task_auth if task_auth is not None else self.resolve_task_auth(task_type)
        )
        if not str(resolved_task_auth.get("providerBaseUrl", "")).strip() or not str(
            resolved_task_auth.get("apiKey", "")
        ).strip():
            if not _mock_provider_enabled():
                raise AdapterError(
                    "MODEL_CONFIG_INCOMPLETE",
                    "智能总结尚未配置可用的模型配置，请先前往设置完成配置。",
                    status_code=400,
                )
            logger.info("traceId=%s provider=mock task=ppt.slide_assistant sourceMode=document", trace_id)
            record_provider_debug(
                {
                    "traceId": trace_id,
                    "taskType": task_type,
                    "url": "",
                    **self.build_debug_metadata(
                        task_type,
                        provider="mock",
                        task_auth=resolved_task_auth,
                    ),
                    "skipReason": "provider_not_configured",
                    "request": {
                        "body": build_provider_request_payload(self.settings, {}, prompt)
                    },
                }
            )
            return {
                "resultType": "document",
                "deckTitle": "",
                "documentSummary": "当前尚未配置 PPT 智能总结工作流。",
                "recommendedSlideCount": slide_count,
                "slides": [],
                "globalStyleAdvice": "",
                "plainText": "请先在设置页完成 ppt.slide_assistant 工作流配置。",
                "rawAnswer": None,
                "parseFallbackReason": None,
                "provider": "mock",
                "prompt": prompt,
            }

        timeout = max(self.settings.timeout_seconds, PPT_SLIDE_ASSISTANT_TIMEOUT_SECONDS)
        if str(resolved_task_auth.get("accessMethod", "")) == ACCESS_DIRECT_MODEL:
            if progress_callback:
                progress_callback("preparing")
            extracted_text = extract_staged_document_text(staged_document)
            direct_prompt = "\n\n".join(
                [
                    prompt,
                    "sourceMode=document",
                    "以下为 Adapter 在本地只读抽取的文档内容：",
                    extracted_text,
                ]
            )
            if progress_callback:
                progress_callback("provider_processing")
            body = self.post_task(
                task_type,
                trace_id,
                {
                    "scene": "ppt",
                    "sourceMode": "document",
                    "requestedSlideCount": slide_count,
                },
                direct_prompt,
                timeout_seconds=timeout,
                task_auth=resolved_task_auth,
                progress_callback=progress_callback,
            )
            if progress_callback:
                progress_callback("parsing")
            parsed = parse_ppt_document_answer(extract_answer(body), slide_count)
            return {
                **parsed,
                "provider": self.build_provider_source(task_type, resolved_task_auth),
                "prompt": prompt,
                "conversationId": "",
                "messageId": body.get("id", ""),
            }
        upload_file_id = self.upload_task_file(
            task_type,
            trace_id,
            staged_document,
            task_auth=resolved_task_auth,
            timeout_seconds=timeout,
        )
        if progress_callback:
            progress_callback("provider_processing")
        files = [
            {
                "type": "document",
                "transfer_method": "local_file",
                "upload_file_id": upload_file_id,
            }
        ]
        body = self.post_task(
            task_type,
            trace_id,
            {
                "scene": "ppt",
                "sourceMode": "document",
                "requestedSlideCount": slide_count,
            },
            prompt,
            timeout_seconds=timeout,
            files=files,
            task_auth=resolved_task_auth,
            progress_callback=progress_callback,
        )
        if progress_callback:
            progress_callback("parsing")
        parsed = parse_ppt_document_answer(extract_answer(body), slide_count)
        logger.info(
            "traceId=%s provider=enterprise-dify-chat task=ppt.slide_assistant sourceMode=document",
            trace_id,
        )
        return {
            **parsed,
            "provider": self.build_provider_source(task_type, resolved_task_auth),
            "prompt": prompt,
            "conversationId": body.get("conversation_id", ""),
            "messageId": body.get("message_id", ""),
        }

    def smart_write(
        self,
        text: str,
        action: str,
        trace_id: str,
        user_prompt: str = "",
        style: str = "default",
        focus: str = "default",
        length: str = "default",
        selection_mode: str = "selection",
        writing_policy_block: str = "",
        task_auth: Optional[Dict] = None,
        progress_callback=None,
    ) -> Dict:
        prompt = build_smart_write_prompt(
            text=text,
            action=action,
            user_prompt=user_prompt,
            style=style,
            focus=focus,
            length=length,
            writing_policy_block=writing_policy_block,
        )
        task_type = "word.smart_write"
        resolved_task_auth = task_auth if task_auth is not None else self.resolve_task_auth(task_type)
        configured = bool(
            str(resolved_task_auth.get("providerBaseUrl", "")).strip()
            and str(resolved_task_auth.get("apiKey", "")).strip()
        )
        if task_auth is None and not configured:
            configured = self.is_task_configured(task_type)
        if not configured:
            if not _mock_provider_enabled():
                raise AdapterError(
                    "MODEL_CONFIG_INCOMPLETE",
                    "智能编写尚未配置可用的模型配置，请先前往设置完成配置。",
                    status_code=400,
                )
            logger.info("traceId=%s provider=mock task=word.smart_write", trace_id)
            self.record_unconfigured_debug(task_type, trace_id, prompt)
            return {
                "rewrittenText": self._mock_rewrite(text, action, user_prompt),
                "provider": "mock",
                "prompt": prompt,
            }

        if progress_callback:
            progress_callback("provider_processing")
        body = self.post_task(
            task_type,
            trace_id,
            {},
            prompt,
            timeout_seconds=max(
                self.settings.timeout_seconds, INTERACTIVE_WRITING_TIMEOUT_SECONDS
            ),
            task_auth=resolved_task_auth,
            progress_callback=progress_callback,
        )

        if progress_callback:
            progress_callback("parsing")

        rewritten_text = extract_answer(body)
        logger.info("traceId=%s provider=enterprise-dify-chat task=word.smart_write", trace_id)
        return {
            "rewrittenText": rewritten_text,
            "provider": self.build_provider_source(task_type, resolved_task_auth),
            "prompt": prompt,
            "conversationId": body.get("conversation_id", ""),
            "messageId": body.get("message_id", ""),
        }

    def smart_imitation(
        self,
        template_text: str,
        requirement: str,
        reference_material: str,
        trace_id: str,
        writing_policy_block: str = "",
        task_auth: Optional[Dict] = None,
        progress_callback=None,
    ) -> Dict:
        prompt = build_smart_imitation_prompt(
            template_text,
            requirement,
            reference_material,
            writing_policy_block=writing_policy_block,
        )
        task_type = "word.smart_imitation"
        resolved_task_auth = task_auth if task_auth is not None else self.resolve_task_auth(task_type)
        configured = bool(
            str(resolved_task_auth.get("providerBaseUrl", "")).strip()
            and str(resolved_task_auth.get("apiKey", "")).strip()
        )
        if task_auth is None and not configured:
            configured = self.is_task_configured(task_type)
        if not configured:
            if not _mock_provider_enabled():
                raise AdapterError(
                    "MODEL_CONFIG_INCOMPLETE",
                    "智能仿写尚未配置可用的模型配置，请先前往设置完成配置。",
                    status_code=400,
                )
            logger.info("traceId=%s provider=mock task=word.smart_imitation", trace_id)
            self.record_unconfigured_debug(task_type, trace_id, prompt)
            return {
                "rewrittenText": self._mock_rewrite(template_text, "imitate", requirement),
                "provider": "mock",
                "prompt": prompt,
            }

        if progress_callback:
            progress_callback("provider_processing")
        body = self.post_task(
            task_type,
            trace_id,
            {},
            prompt,
            timeout_seconds=max(
                self.settings.timeout_seconds, INTERACTIVE_WRITING_TIMEOUT_SECONDS
            ),
            task_auth=resolved_task_auth,
            progress_callback=progress_callback,
        )
        if progress_callback:
            progress_callback("parsing")
        rewritten_text = extract_answer(body)
        logger.info("traceId=%s provider=enterprise-dify-chat task=word.smart_imitation", trace_id)
        return {
            "rewrittenText": rewritten_text,
            "provider": self.build_provider_source(task_type, resolved_task_auth),
            "prompt": prompt,
            "conversationId": body.get("conversation_id", ""),
            "messageId": body.get("message_id", ""),
        }

    def rewrite(
        self,
        text: str,
        mode: str,
        trace_id: str,
        user_instruction: str = "",
        style: str = "default",
        focus: str = "default",
        length: str = "default",
    ) -> Dict:
        prompt = build_rewrite_prompt(
            text=text,
            mode=mode,
            user_instruction=user_instruction,
            style=style,
            focus=focus,
            length=length,
        )
        task_type = "word.continue" if mode == "continue" else "word.rewrite"
        if not self.is_task_configured(task_type):
            logger.info("traceId=%s provider=mock task=word.rewrite", trace_id)
            self.record_unconfigured_debug(task_type, trace_id, prompt)
            return {
                "rewrittenText": self._mock_rewrite(text, mode, user_instruction),
                "provider": "mock",
                "prompt": prompt,
            }

        body = self.post_task(
            task_type,
            trace_id,
            {},
            prompt,
        )

        rewritten_text = extract_answer(body)
        logger.info("traceId=%s provider=enterprise-dify-chat task=word.rewrite", trace_id)
        return {
            "rewrittenText": rewritten_text,
            "provider": "enterprise-dify-chat/{0}".format(self.get_auth_source()),
            "prompt": prompt,
            "conversationId": body.get("conversation_id", ""),
            "messageId": body.get("message_id", ""),
        }

    def document_review(
        self,
        text: str,
        trace_id: str,
        document_type: str = "technical_solution",
        review_prompt: str = "",
        writing_policy_block: str = "",
        task_auth: Optional[Dict] = None,
        progress_callback=None,
    ) -> Dict:
        source_text = text.strip()
        prompt = build_document_review_prompt(
            text=source_text,
            document_type=document_type,
            review_prompt=review_prompt,
            writing_policy_block=writing_policy_block,
        )
        if not source_text:
            return {
                "summary": "未检测到可审查的文档内容。",
                "issues": [],
                "provider": "mock",
                "prompt": prompt,
            }

        task_type = "word.document_review"
        has_auth_snapshot = task_auth is not None
        resolved_task_auth = task_auth or {}
        configured = (
            bool(
                str(resolved_task_auth.get("providerBaseUrl", "")).strip()
                and str(resolved_task_auth.get("apiKey", "")).strip()
            )
            if has_auth_snapshot
            else self.is_task_configured(task_type)
        )
        if not configured:
            if not _mock_provider_enabled():
                raise AdapterError(
                    "MODEL_CONFIG_INCOMPLETE",
                    "文档审查尚未配置可用的模型配置，请先前往设置完成配置。",
                    status_code=400,
                )
            logger.info("traceId=%s provider=mock task=word.document_review", trace_id)
            if has_auth_snapshot:
                record_provider_debug(
                    {
                        "traceId": trace_id,
                        "taskType": task_type,
                        "url": "",
                        **self.build_debug_metadata(
                            task_type, provider="mock", task_auth=resolved_task_auth
                        ),
                        "skipReason": "provider_not_configured",
                        "request": {
                            "body": build_provider_request_payload(
                                self.settings,
                                {},
                                prompt,
                                input_mode=str(
                                    resolved_task_auth.get("providerInputMode")
                                    or DIFY_INPUT_MODE_LEGACY
                                ),
                                response_mode=str(
                                    resolved_task_auth.get("providerMode", "")
                                ),
                            )
                        },
                    }
                )
            else:
                self.record_unconfigured_debug(task_type, trace_id, prompt)
            result = self._mock_document_review(source_text, document_type)
            result["prompt"] = prompt
            return result

        post_kwargs = {
            "timeout_seconds": max(
                self.settings.timeout_seconds, DOCUMENT_REVIEW_TIMEOUT_SECONDS
            )
        }
        if has_auth_snapshot:
            post_kwargs["task_auth"] = resolved_task_auth
        if progress_callback is not None:
            post_kwargs["progress_callback"] = progress_callback
        body = self.post_task(task_type, trace_id, {}, prompt, **post_kwargs)

        parsed = parse_document_review_answer(extract_answer(body))
        logger.info("traceId=%s provider=enterprise-dify-chat task=word.document_review", trace_id)
        return {
            "summary": parsed["summary"],
            "issues": parsed["issues"],
            "rawAnswer": parsed.get("rawAnswer", ""),
            "parseFallbackReason": parsed.get("parseFallbackReason", ""),
            "provider": self.build_provider_source(
                task_type, resolved_task_auth if has_auth_snapshot else None
            ),
            "prompt": prompt,
            "conversationId": body.get("conversation_id", ""),
            "messageId": body.get("message_id", ""),
        }

    def _prepare_format_image_files(
        self, image_files: object, auth: Dict, trace_id: str
    ) -> List[Dict]:
        if not isinstance(image_files, list):
            return []
        prepared = []
        for item in image_files:
            if not isinstance(item, dict):
                raise AdapterError("IMAGE_ASSET_INPUT_INVALID", "图片语义输入格式无效。", status_code=409)
            path = item.get("path") or item.get("slotPath")
            if not isinstance(path, str) or not path:
                raise AdapterError("IMAGE_ASSET_PATH_INVALID", "图片语义输入缺少受控槽位路径。", status_code=409)
            if str(auth.get("accessMethod", "")) == ACCESS_WORKFLOW_PLATFORM:
                upload_id = self.upload_task_file(
                    "word.format_review",
                    trace_id,
                    SimpleNamespace(path=path, extension="png", mime_type="image/png"),
                    task_auth=auth,
                    timeout_seconds=60,
                )
                prepared.append({
                    "type": "image",
                    "transfer_method": "local_file",
                    "upload_file_id": upload_id,
                })
            else:
                prepared.append({
                    "path": path,
                    "mimeType": "image/png",
                    "imageId": str(item.get("imageId") or ""),
                })
        return prepared

    def format_semantics(
        self,
        operation: str,
        trace_id: str,
        input_data: Dict,
        prompt: str,
        task_auth: Optional[Dict] = None,
        output_token_budget: Optional[int] = None,
        progress_callback=None,
    ) -> Dict:
        """Call the versioned format-semantics contract with hard budgets."""
        from copy import deepcopy
        from app.services.word.format_semantics import (
            FormatSemanticContract,
            MAX_FORMAT_SEMANTIC_INPUT_TOKENS,
            MAX_FORMAT_SEMANTIC_OUTPUT_TOKENS,
            WORKFLOW_FORMAT_SEMANTIC_OUTPUT_TOKENS,
            resolve_format_model_capability,
        )

        if not FormatSemanticContract.is_allowed_operation(operation):
            raise AdapterError(
                "FORMAT_SEMANTIC_OPERATION_NOT_ALLOWED",
                "格式语义操作不在白名单内。",
                status_code=409,
            )
        FormatSemanticContract.require_input_budget(prompt)
        auth = deepcopy(task_auth) if task_auth is not None else self.resolve_task_auth(
            "word.format_review"
        )
        if output_token_budget is None:
            budget = FormatSemanticContract.output_budget(auth)
        else:
            try:
                budget = int(output_token_budget)
            except (TypeError, ValueError):
                budget = 0
            budget = max(budget, 0)
        if str(auth.get("accessMethod", "")) == "workflow_platform":
            budget = min(budget or MAX_FORMAT_SEMANTIC_OUTPUT_TOKENS, WORKFLOW_FORMAT_SEMANTIC_OUTPUT_TOKENS)
        else:
            budget = min(budget or MAX_FORMAT_SEMANTIC_OUTPUT_TOKENS, MAX_FORMAT_SEMANTIC_OUTPUT_TOKENS)
        if str(auth.get("accessMethod", "")) == ACCESS_DIRECT_MODEL:
            if auth.get("maxOutputTokens") is None:
                capability = resolve_format_model_capability(
                    str(auth.get("modelName", ""))
                )
                if capability is None:
                    raise AdapterError(
                        "FORMAT_SEMANTIC_OUTPUT_CAPABILITY_UNKNOWN",
                        "直连模型未声明可用的最大输出 Token，且离线能力表无法精确匹配该模型，无法执行格式语义操作。",
                        status_code=409,
                    )
                auth["formatModelCapability"] = capability
                auth["maxOutputTokens"] = int(capability["maxOutputTokens"])
            auth["maxOutputTokens"] = min(
                max(int(auth["maxOutputTokens"]), 0), int(budget), 4096
            )
        input_data = dict(input_data or {})
        input_data["image_files"] = self._prepare_format_image_files(
            input_data.get("image_files"), auth, trace_id
        )
        candidate_json = input_data.get("candidate_json")
        if not isinstance(candidate_json, str) or not candidate_json.strip():
            candidate_source = deepcopy(input_data)
            candidate_source["image_files"] = [
                {
                    key: value
                    for key, value in item.items()
                    if key not in {"path", "slotPath"}
                }
                for item in input_data.get("image_files", [])
                if isinstance(item, dict)
            ]
            candidate_json = json.dumps(candidate_source, ensure_ascii=False, sort_keys=True)
        input_data.update({
            "schemaVersion": "format_semantics.v1",
            "contract_version": "format_semantics.v1",
            "operation": operation,
            "inputTokenBudget": MAX_FORMAT_SEMANTIC_INPUT_TOKENS,
            "outputTokenBudget": int(budget),
            "candidate_json": candidate_json,
        })
        if str(auth.get("accessMethod", "")) == ACCESS_WORKFLOW_PLATFORM:
            return self._post_workflow_format_semantics(
                operation,
                trace_id,
                input_data,
                auth,
                timeout_seconds=60,
                progress_callback=progress_callback,
            )
        prompt = _format_semantic_prompt_with_schema(prompt, operation)
        FormatSemanticContract.require_input_budget(prompt)
        return self.post_task(
            "word.format_review",
            trace_id,
            input_data,
            prompt,
            timeout_seconds=60,
            task_auth=auth,
            input_token_limit=MAX_FORMAT_SEMANTIC_INPUT_TOKENS,
            image_files=input_data.get("image_files"),
            response_format=_format_semantic_response_format(operation),
            allow_response_format_fallback=True,
            progress_callback=progress_callback,
        )

    def _post_workflow_format_semantics(
        self,
        operation: str,
        trace_id: str,
        input_data: Dict,
        task_auth: Dict,
        timeout_seconds: int,
        progress_callback=None,
    ) -> Dict:
        """Call Dify with only the fixed semantic inputs and read result_json."""
        provider_base_url = str(task_auth.get("providerBaseUrl", "")).rstrip("/")
        provider_chat_path = str(task_auth.get("providerChatPath") or "/chat-messages")
        url = "{0}{1}".format(provider_base_url, provider_chat_path)
        api_key = str(task_auth.get("apiKey", ""))
        fixed_inputs = {
            "contract_version": "format_semantics.v1",
            "operation": operation,
            "candidate_json": str(input_data.get("candidate_json", "")),
        }
        image_files = input_data.get("image_files")
        if operation == "suggest_figure_caption":
            fixed_inputs["image_files"] = image_files if isinstance(image_files, list) else []
        payload = {
            "inputs": fixed_inputs,
            "query": "format_semantics.v1",
            "conversation_id": "",
            "response_mode": str(task_auth.get("providerMode") or "blocking"),
            "user": "wps-ai-assistant",
            "files": image_files if isinstance(image_files, list) else [],
        }
        debug_metadata = self.build_debug_metadata(
            "word.format_review",
            api_key_ref=str(task_auth.get("apiKeyRef", "")),
            task_auth=task_auth,
        )
        record_provider_debug(
            {
                "traceId": trace_id,
                "taskType": "word.format_review",
                "url": url,
                **debug_metadata,
                "request": {"body": payload},
            }
        )
        req = urllib_request.Request(
            url,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            method="POST",
            headers={
                "Authorization": "Bearer {0}".format(api_key),
                "Content-Type": "application/json",
                "X-Trace-Id": trace_id,
            },
        )
        t_start = time.monotonic()
        t_headers = None
        t_complete = None

        def publish_performance(parsed_at=None):
            metrics = _provider_performance_metrics(
                t_start,
                headers_at=t_headers,
                completed_at=t_complete,
                parsed_at=parsed_at,
            )
            _publish_provider_performance(progress_callback, metrics)
            merge_provider_debug(trace_id, {"performance": metrics})
            return metrics

        try:
            with urllib_request.urlopen(req, timeout=timeout_seconds) as response:
                t_headers = time.monotonic()
                raw_bytes = response.read()
                t_complete = time.monotonic()
                raw_body = raw_bytes.decode("utf-8")
                body = json.loads(raw_body)
        except error.HTTPError as exc:
            t_headers = time.monotonic()
            publish_performance()
            if exc.code in (401, 403):
                raise ProviderAuthError("模型后台认证失败，请检查当前配置的 API Key。") from exc
            if exc.code == 429:
                raise AdapterError("MODEL_RATE_LIMITED", "模型后台请求较多，请稍后重新提交。", status_code=429) from exc
            raise ProviderUnavailableError("模型后台返回 HTTP {0}。".format(exc.code)) from exc
        except error.URLError as exc:
            publish_performance()
            reason = getattr(exc, "reason", "")
            if isinstance(reason, (TimeoutError, socket.timeout)) or "timed out" in str(reason).lower():
                raise ProviderTimeoutError("模型处理超过当前任务等待时限。") from exc
            raise ProviderUnavailableError("无法访问模型后台，请检查服务地址和网络。") from exc
        except (TimeoutError, socket.timeout) as exc:
            publish_performance()
            raise ProviderTimeoutError("模型处理超过当前任务等待时限。") from exc
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            publish_performance(time.monotonic())
            raise ProviderUnavailableError("模型后台返回了非 JSON 响应。") from exc
        except (IncompleteRead, RemoteDisconnected, ConnectionResetError, ConnectionAbortedError, BrokenPipeError) as exc:
            publish_performance()
            raise ProviderMidStreamDisconnectError("模型后台在返回结果过程中断开连接。") from exc
        result_json = body.get("data", {}).get("outputs", {}).get("result_json") if isinstance(body, dict) else None
        if result_json is None:
            publish_performance(time.monotonic())
            raise AdapterError(
                "FORMAT_SEMANTIC_RESULT_JSON_MISSING",
                "格式语义工作流未返回固定 result_json 输出。",
                status_code=502,
            )
        if isinstance(result_json, str):
            try:
                result_json = json.loads(result_json)
            except json.JSONDecodeError as exc:
                publish_performance(time.monotonic())
                raise AdapterError(
                    "FORMAT_SEMANTIC_RESULT_JSON_INVALID",
                    "格式语义工作流的 result_json 不是有效 JSON。",
                    status_code=502,
                ) from exc
        if not isinstance(result_json, dict):
            publish_performance(time.monotonic())
            raise AdapterError(
                "FORMAT_SEMANTIC_RESULT_JSON_INVALID",
                "格式语义工作流的 result_json 必须是 JSON 对象。",
                status_code=502,
            )
        perf_metrics = publish_performance(time.monotonic())
        record_provider_debug(
            {
                "traceId": trace_id,
                "taskType": "word.format_review",
                "url": url,
                **debug_metadata,
                "performance": perf_metrics,
                "response": {"status": 200, "resultKeys": sorted(result_json.keys())},
            }
        )
        return {"result_json": result_json}

    def _mock_rewrite(self, text: str, mode: str, user_instruction: str) -> str:
        prefix_map = {
            "rewrite": "改写结果：",
            "continue": "续写结果：",
            "polish": "润色结果：",
            "formalize": "正式化结果：",
        }
        suffix = ""
        if user_instruction.strip():
            suffix = "\n附加要求已考虑：{0}".format(user_instruction.strip())
        return "{0}\n{1}{2}".format(prefix_map.get(mode, "改写结果："), text.strip(), suffix)

    def _mock_document_review(self, text: str, document_type: str) -> Dict:
        issues: List[Dict] = []
        vague_terms = ["相关", "等", "尽快", "友好", "高效", "优化", "合理", "多种", "必要时"]
        for term in vague_terms:
            if term in text:
                issues.append(
                    {
                        "category": "expression",
                        "severity": "medium",
                        "location": "未定位",
                        "originalText": term,
                        "problem": "存在不易验收或边界不清的表述。",
                        "suggestion": "补充明确范围、量化指标、完成条件或验收方法。",
                        "suggestedRewrite": "",
                    }
                )
                break

        if ("接口" in text or "API" in text) and not any(
            keyword in text for keyword in ["入参", "出参", "返回", "异常", "状态码", "权限"]
        ):
            issues.append(
                {
                    "category": "professional",
                    "severity": "high",
                    "location": "接口描述",
                    "originalText": "",
                    "problem": "接口相关描述可能缺少入参、出参、异常处理、状态码或权限边界。",
                    "suggestion": "补充接口调用条件、请求参数、返回字段、失败场景和权限要求。",
                    "suggestedRewrite": "",
                }
            )

        if document_type == "technical_solution" and not any(
            keyword in text for keyword in ["架构", "模块", "数据流", "容错", "部署", "安全"]
        ):
            issues.append(
                {
                    "category": "professional",
                    "severity": "medium",
                    "location": "方案设计",
                    "originalText": "",
                    "problem": "技术方案可能缺少架构边界、模块职责、数据流、容错或部署约束。",
                    "suggestion": "补充整体架构、关键模块职责、数据流转、异常兜底和部署约束。",
                    "suggestedRewrite": "",
                }
            )

        if document_type == "contract_acceptance" and not any(
            keyword in text for keyword in ["验收标准", "验收方法", "通过条件", "不通过", "交付物"]
        ):
            issues.append(
                {
                    "category": "professional",
                    "severity": "high",
                    "location": "验收要求",
                    "originalText": "",
                    "problem": "合同验收文档可能缺少可执行的验收标准、验收方法或通过条件。",
                    "suggestion": "明确交付物、验收步骤、通过/不通过判定条件和问题整改机制。",
                    "suggestedRewrite": "",
                }
            )

        if document_type == "test_outline" and not any(
            keyword in text for keyword in ["测试范围", "前置条件", "测试步骤", "预期结果", "通过准则"]
        ):
            issues.append(
                {
                    "category": "professional",
                    "severity": "medium",
                    "location": "测试说明",
                    "originalText": "",
                    "problem": "测试大纲和细则可能缺少测试范围、前置条件、测试步骤或预期结果。",
                    "suggestion": "补充测试范围、测试数据、前置条件、执行步骤、预期结果和通过准则。",
                    "suggestedRewrite": "",
                }
            )

        summary = (
            "当前使用 mock 文档审查，发现 {0} 项可能影响理解、交付或验收的问题。".format(len(issues))
            if issues else
            "当前使用 mock 文档审查，未发现明显问题。"
        )
        return {
            "summary": summary,
            "issues": issues,
            "provider": "mock",
        }
