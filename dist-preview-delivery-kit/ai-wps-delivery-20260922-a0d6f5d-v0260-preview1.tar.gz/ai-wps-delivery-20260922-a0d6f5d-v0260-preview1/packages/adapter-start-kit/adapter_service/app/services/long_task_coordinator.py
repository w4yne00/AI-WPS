import hashlib
import os
import threading
import time
from collections import deque
from copy import deepcopy
from typing import Any, Callable, Deque, Dict, Optional, Set, Tuple

from app.core.errors import AdapterError


DEFAULT_MAX_RUNNING = 2
DEFAULT_MAX_QUEUED = 8
DEFAULT_TERMINAL_TTL_SECONDS = 2 * 60 * 60
DEFAULT_MAX_TERMINAL_JOBS = 50
DEFAULT_MAX_EVENTS = 256
MAX_EVENT_WAIT_MS = 25000
MAX_TEXT_PREVIEW_BYTES = 512 * 1024
MAX_TEXT_BATCH_BYTES = 4096
MAX_TEXT_BATCH_INTERVAL_SECONDS = 0.050
PUBLIC_PHASES = {
    "queued",
    "preparing",
    "extracting",
    "confirming",
    "chunking",
    "uploading",
    "provider_processing",
    "provider_connecting",
    "provider_waiting",
    "streaming",
    "stopping",
    "retrying",
    "splitting",
    "parsing",
    "aggregating",
    "completed",
    "failed",
    "cancelled",
}
TERMINAL_STATUSES = {"completed", "failed", "cancelled"}
PRIORITY_REGULAR = "regular"
PRIORITY_INTERACTIVE = "interactive"
INTERACTIVE_BURST_LIMIT = 3
JobKey = Tuple[str, str]


class LongTaskCancelled(Exception):
    """Signals cooperative cancellation after an in-flight call returns."""

    def __init__(self, partial_result: Optional[Dict] = None) -> None:
        super().__init__()
        self.partial_result = deepcopy(partial_result) if partial_result is not None else None


class LongTaskContinuation:
    """Requests that a running task yield its slot and resume with new state."""

    def __init__(self, snapshot: Dict, phase: str = "queued") -> None:
        self.snapshot = deepcopy(snapshot)
        self.phase = phase if phase in PUBLIC_PHASES else "queued"


def _positive_int_from_env(name: str, default: int) -> int:
    try:
        value = int(os.environ.get(name, ""))
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


def _phase_durations_ms(
    durations: Dict[str, float],
    elapsed_ms: int,
    remainder_phase: Optional[str] = None,
) -> Dict[str, int]:
    converted = {
        phase: int(max(duration, 0.0) * 1000)
        for phase, duration in durations.items()
    }
    remainder_ms = elapsed_ms - sum(converted.values())
    if remainder_ms > 0 and converted:
        target_phase = (
            remainder_phase
            if remainder_phase in converted
            else next(reversed(converted))
        )
        converted[target_phase] += remainder_ms
    return converted


class LongTaskCoordinator:
    """Bounded in-memory coordinator for blocking long-running task runners."""

    def __init__(
        self,
        max_running: int = DEFAULT_MAX_RUNNING,
        max_queued: int = DEFAULT_MAX_QUEUED,
        terminal_ttl_seconds: int = DEFAULT_TERMINAL_TTL_SECONDS,
        max_terminal_jobs: int = DEFAULT_MAX_TERMINAL_JOBS,
        monotonic_clock: Callable[[], float] = time.monotonic,
        wall_clock: Callable[[], float] = time.time,
    ) -> None:
        self.max_running = max(int(max_running), 1)
        self.max_queued = max(int(max_queued), 1)
        self.terminal_ttl_seconds = max(int(terminal_ttl_seconds), 1)
        self.max_terminal_jobs = max(int(max_terminal_jobs), 1)
        self._monotonic = monotonic_clock
        self._wall_clock = wall_clock
        self._jobs: Dict[JobKey, Dict] = {}
        self._queue: Deque[JobKey] = deque()
        self._deferred: Deque[JobKey] = deque()
        self._running_count = 0
        self._cancelled_count = 0
        self._rejected_count = 0
        self._timed_out_count = 0
        self._interactive_dispatch_streak = 0
        self._invalidated_auth_errors: Dict[Tuple[str, str, Optional[int]], Dict] = {}
        self._lock = threading.Lock()
        self._condition = threading.Condition(self._lock)

    def submit(
        self,
        job_id: str,
        trace_id: str,
        task_type: str,
        runner: Callable[[Dict, Callable[[str], None]], Dict],
        snapshot: Dict,
        failure_code: str,
        failure_message: str,
        public_metadata: Optional[Dict] = None,
        safe_failure_codes: Optional[Set[str]] = None,
        priority_class: str = PRIORITY_REGULAR,
        allow_running_cancel: bool = False,
        request_fingerprint: Optional[str] = None,
        request_conflict_code: str = "LONG_TASK_JOB_ID_CONFLICT",
        request_conflict_message: str = "相同任务编号已绑定其他请求，请使用新的任务编号。",
        task_auth: Optional[Dict] = None,
        success_committer: Optional[Callable[[Dict, Dict], None]] = None,
        auth_invalidation_committer: Optional[Callable[[Dict, Dict], None]] = None,
    ) -> Dict:
        worker_job_key: Optional[JobKey] = None
        now_mono = self._monotonic()
        now_wall = self._wall_clock()
        job_key = (task_type, job_id)
        normalized_priority = (
            PRIORITY_INTERACTIVE
            if priority_class == PRIORITY_INTERACTIVE
            else PRIORITY_REGULAR
        )

        auth_service_id = None
        auth_key_fp = None
        auth_service_revision = None
        task_auth_source = (
            task_auth
            if task_auth is not None
            else (snapshot.get("taskAuth") if isinstance(snapshot, dict) else None)
        )
        if isinstance(task_auth_source, dict):
            auth_service_id = str(
                task_auth_source.get("directServiceId")
                or (
                    task_auth_source.get("directService", {}).get("id")
                    if isinstance(task_auth_source.get("directService"), dict)
                    else ""
                )
                or task_auth_source.get("apiKeyRef")
                or task_auth_source.get("serviceId")
                or ""
            ).strip() or None

            raw_fp = task_auth_source.get("apiKeyFingerprint") or task_auth_source.get(
                "keyFingerprint"
            )
            if raw_fp:
                auth_key_fp = str(raw_fp).strip() or None
            elif task_auth_source.get("apiKey"):
                auth_key_fp = hashlib.sha256(
                    str(task_auth_source["apiKey"]).encode("utf-8")
                ).hexdigest()
            direct_service = task_auth_source.get("directService")
            raw_revision = (
                direct_service.get("revision")
                if isinstance(direct_service, dict)
                else task_auth_source.get("directServiceRevision")
            )
            try:
                auth_service_revision = int(raw_revision)
            except (TypeError, ValueError):
                auth_service_revision = None

        with self._lock:
            self._cleanup_locked(now_mono)
            existing = self._jobs.get(job_key)
            if existing is not None:
                stored_fingerprint = existing.get("_requestFingerprint")
                if (
                    request_fingerprint
                    and stored_fingerprint
                    and stored_fingerprint != request_fingerprint
                ):
                    raise AdapterError(
                        request_conflict_code,
                        request_conflict_message,
                        status_code=409,
                    )
                return self._public_job_locked(existing, now_mono)
            invalidated_error = self._invalidated_auth_error_locked(
                auth_service_id,
                auth_key_fp,
                auth_service_revision,
            )
            if (
                invalidated_error is None
                and self._running_count >= self.max_running
                and len(self._queue) >= self.max_queued
            ):
                self._rejected_count += 1
                raise AdapterError(
                    "LONG_TASK_QUEUE_FULL",
                    "当前后台任务较多，排队已满，请等待已有任务完成后重试。",
                    status_code=429,
                )

            status = (
                "failed"
                if invalidated_error is not None
                else ("running" if self._running_count < self.max_running else "queued")
            )
            phase = "failed" if status == "failed" else (
                "preparing" if status == "running" else "queued"
            )
            job = {
                "jobId": job_id,
                "traceId": trace_id,
                "taskType": task_type,
                "status": status,
                "phase": phase,
                "createdAt": now_wall,
                "updatedAt": now_wall,
                "_createdMonotonic": now_mono,
                "_updatedMonotonic": now_mono,
                "_phaseStartedMonotonic": now_mono,
                "_phaseDurations": {},
                "_lastTimedPhase": phase,
                "_terminalAtMonotonic": None,
                "_runner": runner,
                "_snapshot": deepcopy(snapshot),
                "_failureCode": failure_code,
                "_failureMessage": failure_message,
                "_safeFailureCodes": set(safe_failure_codes or set()),
                "_publicMetadata": deepcopy(public_metadata or {}),
                "_priorityClass": normalized_priority,
                "_requestFingerprint": request_fingerprint or "",
                "_allowRunningCancel": bool(allow_running_cancel),
                "_cancelRequested": False,
                "_cancelCallback": None,
                "_occupiesSlot": status == "running",
                "_authServiceId": auth_service_id,
                "_authKeyFingerprint": auth_key_fp,
                "_authServiceRevision": auth_service_revision,
                "_authInvalidated": invalidated_error is not None,
                "_authInvalidatedError": deepcopy(invalidated_error),
                "_successCommitter": success_committer,
                "_authInvalidationCommitter": auth_invalidation_committer,
                "_metrics": {},
                "_events": deque(maxlen=DEFAULT_MAX_EVENTS),
                "_latest_sequence": 0,
                "_oldest_sequence": 0,
                "_text_preview": "",
                "_text_preview_truncated": False,
                "result": None,
                "error": deepcopy(invalidated_error),
            }
            job["_snapshot"].setdefault("traceId", trace_id)
            initial_event_type = "terminal" if status in TERMINAL_STATUSES else "phase"
            self._append_event_locked(
                job,
                initial_event_type,
                phase,
                status,
                error=invalidated_error,
            )
            self._jobs[job_key] = job
            if status == "failed":
                self._commit_auth_invalidation_locked(job, invalidated_error or {})
                self._finish_locked(job, "failed", now_mono)
                self._trim_terminal_locked()
            elif status == "running":
                self._running_count += 1
                worker_job_key = job_key
            else:
                self._queue.append(job_key)
            public_job = self._public_job_locked(job, now_mono)

        if worker_job_key is not None:
            self._start_worker(worker_job_key)
        return public_job

    def get(self, job_id: str, task_type: Optional[str] = None) -> Optional[Dict]:
        now_mono = self._monotonic()
        with self._lock:
            self._cleanup_locked(now_mono)
            job_key = self._find_job_key_locked(job_id, task_type)
            job = self._jobs.get(job_key) if job_key is not None else None
            return self._public_job_locked(job, now_mono) if job else None

    def get_request_fingerprint(
        self, job_id: str, task_type: Optional[str] = None
    ) -> Optional[str]:
        """Return an internal idempotency fingerprint without exposing job data."""
        now_mono = self._monotonic()
        with self._lock:
            self._cleanup_locked(now_mono)
            job_key = self._find_job_key_locked(job_id, task_type)
            job = self._jobs.get(job_key) if job_key is not None else None
            if job is None:
                return None
            return str(job.get("_requestFingerprint") or "") or None

    def wait(self, job_id: str, task_type: Optional[str] = None) -> Optional[Dict]:
        """Wait for one accepted job without bypassing the shared capacity boundary."""
        with self._condition:
            while True:
                now_mono = self._monotonic()
                self._cleanup_locked(now_mono)
                job_key = self._find_job_key_locked(job_id, task_type)
                job = self._jobs.get(job_key) if job_key is not None else None
                if job is None:
                    return None
                if job["status"] in TERMINAL_STATUSES or job.get("_authInvalidated"):
                    return self._public_job_locked(job, now_mono)
                self._condition.wait()

    def wait_result(
        self,
        job_id: str,
        task_type: str,
        not_found_code: str,
        not_found_message: str,
        cancelled_message: str,
        failure_code: str,
        failure_message: str,
        safe_error_statuses: Optional[Dict[str, int]] = None,
    ) -> Dict:
        """Wait for a terminal job and translate its public terminal state once."""
        terminal = self.wait(job_id, task_type=task_type)
        if terminal is None:
            raise AdapterError(not_found_code, not_found_message, status_code=404)
        if terminal["status"] == "completed":
            return terminal.get("result") or {}
        if terminal["status"] == "cancelled":
            raise AdapterError(
                "LONG_TASK_CANCELLED", cancelled_message, status_code=409
            )
        error = terminal.get("error") or {}
        code = str(error.get("code") or failure_code)
        message = str(error.get("message") or failure_message)
        status_code = (safe_error_statuses or {}).get(code, 502)
        raise AdapterError(code, message, status_code=status_code)

    def _append_event_locked(
        self,
        job: Dict,
        event_type: str,
        phase: str,
        status: str,
        error: Optional[Dict] = None,
        data: Optional[Dict] = None,
    ) -> Dict:
        seq = job.get("_latest_sequence", 0) + 1
        job["_latest_sequence"] = seq
        now_wall = self._wall_clock()
        event = {
            "sequence": seq,
            "type": event_type,
            "phase": phase,
            "status": status,
            "createdAt": now_wall,
        }
        if error is not None:
            event["error"] = deepcopy(error)
        if data is not None:
            event.update(deepcopy(data))
        job["_events"].append(event)
        job["_oldest_sequence"] = job["_events"][0]["sequence"]
        return event

    def _build_preview_snapshot_locked(self, job: Dict) -> Dict:
        return {
            "jobId": job["jobId"],
            "taskType": job["taskType"],
            "status": "failed" if job.get("_authInvalidated") else job["status"],
            "phase": "failed" if job.get("_authInvalidated") else job["phase"],
            "text": str(job.get("_text_preview") or ""),
            "previewTruncated": bool(job.get("_text_preview_truncated")),
            "latestSequence": job.get("_latest_sequence", 0),
        }

    def wait_events(
        self,
        job_id: str,
        task_type: Optional[str] = None,
        after_sequence: int = 0,
        wait_ms: int = 0,
    ) -> Optional[Dict]:
        """Query or long-poll incremental task events for a job."""
        try:
            after_seq = int(after_sequence)
        except (TypeError, ValueError):
            after_seq = 0
        try:
            bounded_wait_ms = max(0, min(int(wait_ms), MAX_EVENT_WAIT_MS))
        except (TypeError, ValueError):
            bounded_wait_ms = 0

        now_mono = self._monotonic()
        deadline_mono = now_mono + (bounded_wait_ms / 1000.0)

        with self._condition:
            while True:
                now_mono = self._monotonic()
                self._cleanup_locked(now_mono)
                job_key = self._find_job_key_locked(job_id, task_type)
                job = self._jobs.get(job_key) if job_key is not None else None
                if job is None:
                    return None

                latest_seq = job.get("_latest_sequence", 0)
                events_ring = list(job.get("_events", []))
                oldest_seq = events_ring[0]["sequence"] if events_ring else 1
                is_terminal = job["status"] in TERMINAL_STATUSES or bool(
                    job.get("_authInvalidated")
                )
                effective_status = (
                    "failed" if job.get("_authInvalidated") else job["status"]
                )
                effective_phase = (
                    "failed" if job.get("_authInvalidated") else job["phase"]
                )
                error = deepcopy(
                    job.get("_authInvalidatedError") or job.get("error")
                )
                preview_truncated = bool(job.get("_text_preview_truncated"))

                reset_required = False
                if after_seq < 0:
                    after_seq = 0
                elif after_seq > latest_seq:
                    reset_required = True
                elif after_seq > 0 and after_seq < oldest_seq - 1:
                    reset_required = True

                if reset_required:
                    return {
                        "jobId": job["jobId"],
                        "traceId": job["traceId"],
                        "taskType": job["taskType"],
                        "status": effective_status,
                        "phase": effective_phase,
                        "latestSequence": latest_seq,
                        "previewTruncated": preview_truncated,
                        "events": [deepcopy(e) for e in events_ring],
                        "previewSnapshot": self._build_preview_snapshot_locked(job),
                        "resetRequired": True,
                        "terminal": is_terminal,
                        "error": error,
                    }

                if after_seq == 0:
                    return {
                        "jobId": job["jobId"],
                        "traceId": job["traceId"],
                        "taskType": job["taskType"],
                        "status": effective_status,
                        "phase": effective_phase,
                        "latestSequence": latest_seq,
                        "previewTruncated": preview_truncated,
                        "events": [deepcopy(e) for e in events_ring],
                        "previewSnapshot": self._build_preview_snapshot_locked(job),
                        "resetRequired": False,
                        "terminal": is_terminal,
                        "error": error,
                    }

                if after_seq < latest_seq:
                    new_events = [
                        deepcopy(e) for e in events_ring if e["sequence"] > after_seq
                    ]
                    return {
                        "jobId": job["jobId"],
                        "traceId": job["traceId"],
                        "taskType": job["taskType"],
                        "status": effective_status,
                        "phase": effective_phase,
                        "latestSequence": latest_seq,
                        "previewTruncated": preview_truncated,
                        "events": new_events,
                        "previewSnapshot": None,
                        "resetRequired": False,
                        "terminal": is_terminal,
                        "error": error,
                    }

                if is_terminal:
                    return {
                        "jobId": job["jobId"],
                        "traceId": job["traceId"],
                        "taskType": job["taskType"],
                        "status": effective_status,
                        "phase": effective_phase,
                        "latestSequence": latest_seq,
                        "previewTruncated": preview_truncated,
                        "events": [],
                        "previewSnapshot": None,
                        "resetRequired": False,
                        "terminal": True,
                        "error": error,
                    }

                remaining = deadline_mono - self._monotonic()
                if remaining <= 0 or bounded_wait_ms <= 0:
                    return {
                        "jobId": job["jobId"],
                        "traceId": job["traceId"],
                        "taskType": job["taskType"],
                        "status": effective_status,
                        "phase": effective_phase,
                        "latestSequence": latest_seq,
                        "previewTruncated": preview_truncated,
                        "events": [],
                        "previewSnapshot": None,
                        "resetRequired": False,
                        "terminal": False,
                        "error": error,
                    }

                self._condition.wait(timeout=remaining)

    def cancel(self, job_id: str, task_type: Optional[str] = None) -> Optional[Dict]:
        now_mono = self._monotonic()
        with self._lock:
            self._cleanup_locked(now_mono)
            job_key = self._find_job_key_locked(job_id, task_type)
            job = self._jobs.get(job_key) if job_key is not None else None
            if job is None:
                return None
            if job["status"] != "queued":
                raise AdapterError(
                    "LONG_TASK_NOT_CANCELLABLE",
                    "只有仍在排队的任务可以取消；任务一旦开始运行，模型后台无法可靠取消。",
                    status_code=409,
                )
            try:
                self._queue.remove(job_key)
            except ValueError:
                raise AdapterError(
                    "LONG_TASK_NOT_CANCELLABLE",
                    "任务已离开排队队列，无法取消。",
                    status_code=409,
                )
            self._finish_locked(job, "cancelled", now_mono)
            self._cancelled_count += 1
            self._trim_terminal_locked()
            self._condition.notify_all()
            return self._public_job_locked(job, now_mono)

    def request_cancel(
        self, job_id: str, task_type: Optional[str] = None
    ) -> Optional[Dict]:
        """Atomically cancel a queued job or request cooperative running cancellation."""
        now_mono = self._monotonic()
        next_job_key: Optional[JobKey] = None
        public_job: Optional[Dict] = None
        cancel_callback = None
        with self._lock:
            self._cleanup_locked(now_mono)
            job_key = self._find_job_key_locked(job_id, task_type)
            job = self._jobs.get(job_key) if job_key is not None else None
            if job is None:
                return None
            if job["status"] == "queued":
                try:
                    self._queue.remove(job_key)
                except ValueError:
                    raise AdapterError(
                        "LONG_TASK_NOT_CANCELLABLE",
                        "任务已离开排队队列，无法取消。",
                        status_code=409,
                    )
                self._finish_locked(job, "cancelled", now_mono)
                self._cancelled_count += 1
                self._trim_terminal_locked()
                self._condition.notify_all()
                return self._public_job_locked(job, now_mono)
            if job["status"] == "running" and job.get("_allowRunningCancel"):
                if not job.get("_occupiesSlot"):
                    try:
                        self._deferred.remove(job_key)
                    except ValueError:
                        pass
                    self._finish_locked(job, "cancelled", now_mono)
                    self._cancelled_count += 1
                    next_job_key = self._promote_next_locked(now_mono)
                else:
                    job["_cancelRequested"] = True
                    job["_updatedMonotonic"] = now_mono
                    job["updatedAt"] = self._wall_clock()
                    self._transition_phase_locked(job, "stopping", now_mono)
                    cancel_callback = job.get("_cancelCallback")
                public_job = self._public_job_locked(job, now_mono)
            elif job["status"] in TERMINAL_STATUSES:
                return self._public_job_locked(job, now_mono)
            else:
                raise AdapterError(
                    "LONG_TASK_NOT_CANCELLABLE",
                    "当前任务状态不允许取消。",
                    status_code=409,
                )
            self._trim_terminal_locked()
            self._condition.notify_all()
        if callable(cancel_callback):
            cancel_callback()
        if next_job_key is not None:
            self._start_worker(next_job_key)
        return public_job

    def is_cancel_requested(
        self, job_id: str, task_type: Optional[str] = None
    ) -> bool:
        with self._lock:
            job_key = self._find_job_key_locked(job_id, task_type)
            job = self._jobs.get(job_key) if job_key is not None else None
            return bool(
                job
                and job.get("status") == "running"
                and job.get("_cancelRequested")
            )

    def invalidate_by_auth(
        self,
        service_id: str,
        api_key_fingerprint: str,
        failure_code: str = "DIRECT_SERVICE_KEY_ROTATED",
        failure_message: str = "服务 API Key 已更换或清除，原任务已失效，请重新提交任务。",
        service_revision: Optional[int] = None,
    ) -> int:
        if not service_id or not api_key_fingerprint:
            return 0
        now_mono = self._monotonic()
        invalidated_count = 0
        next_job_key = None
        with self._lock:
            self._cleanup_locked(now_mono)
            invalidation_key = (
                str(service_id),
                str(api_key_fingerprint),
                int(service_revision) if service_revision is not None else None,
            )
            self._invalidated_auth_errors[invalidation_key] = {
                "code": failure_code,
                "message": failure_message,
            }
            for job_key, job in self._jobs.items():
                if job.get("status") in TERMINAL_STATUSES:
                    continue
                if (
                    job.get("_authServiceId") == service_id
                    and job.get("_authKeyFingerprint") == api_key_fingerprint
                    and self._auth_revision_is_invalidated(
                        job.get("_authServiceRevision"), service_revision
                    )
                ):
                    invalidated_count += 1
                    err = {
                        "code": failure_code,
                        "message": failure_message,
                    }
                    job["_authInvalidated"] = True
                    job["_authInvalidatedError"] = deepcopy(err)
                    job["_cancelRequested"] = True
                    job["error"] = deepcopy(err)
                    self._commit_auth_invalidation_locked(job, err)

                    if job["status"] == "queued":
                        try:
                            self._queue.remove(job_key)
                        except ValueError:
                            try:
                                self._deferred.remove(job_key)
                            except ValueError:
                                pass
                        self._finish_locked(job, "failed", now_mono)
                    elif job["status"] == "running":
                        if not job.get("_occupiesSlot"):
                            try:
                                self._deferred.remove(job_key)
                            except ValueError:
                                pass
                            self._finish_locked(job, "failed", now_mono)
                            if next_job_key is None:
                                next_job_key = self._promote_next_locked(now_mono)
            self._trim_terminal_locked()
            self._condition.notify_all()
        if next_job_key is not None:
            self._start_worker(next_job_key)
        return invalidated_count

    def _invalidated_auth_error_locked(
        self,
        service_id: Optional[str],
        api_key_fingerprint: Optional[str],
        service_revision: Optional[int],
    ) -> Optional[Dict]:
        if not service_id or not api_key_fingerprint:
            return None
        wildcard = self._invalidated_auth_errors.get(
            (service_id, api_key_fingerprint, None)
        )
        if wildcard:
            return deepcopy(wildcard)
        matching = [
            (revision, error)
            for (stored_service_id, stored_fingerprint, revision), error
            in self._invalidated_auth_errors.items()
            if stored_service_id == service_id
            and stored_fingerprint == api_key_fingerprint
            and revision is not None
            and self._auth_revision_is_invalidated(service_revision, revision)
        ]
        if not matching:
            return None
        return deepcopy(max(matching, key=lambda item: item[0])[1])

    @staticmethod
    def _auth_revision_is_invalidated(
        task_revision: Optional[int], rotation_revision: Optional[int]
    ) -> bool:
        if rotation_revision is None:
            return True
        if task_revision is None:
            return False
        return int(task_revision) <= int(rotation_revision)

    @staticmethod
    def _commit_auth_invalidation_locked(job: Dict, error: Dict) -> None:
        committer = job.get("_authInvalidationCommitter")
        if committer is None:
            return
        try:
            committer(job.get("_snapshot") or {}, deepcopy(error))
        except Exception:
            # Authentication invalidation remains authoritative even when a
            # best-effort durable marker cannot be written.
            pass

    def diagnostics(self) -> Dict:
        now_mono = self._monotonic()
        with self._lock:
            self._cleanup_locked(now_mono)
            terminal_jobs = sorted(
                (
                    job
                    for job in self._jobs.values()
                    if job["status"] in TERMINAL_STATUSES
                ),
                key=lambda item: item.get("_terminalAtMonotonic") or 0,
                reverse=True,
            )
            return {
                "maxRunning": self.max_running,
                "maxQueued": self.max_queued,
                "runningCount": self._running_count,
                "queuedCount": len(self._queue),
                "deferredCount": sum(
                    1
                    for job_key in self._deferred
                    if self._jobs.get(job_key, {}).get("status") == "running"
                ),
                "interactiveQueuedCount": sum(
                    1
                    for job_key in self._queue
                    if self._jobs.get(job_key, {}).get("_priorityClass")
                    == PRIORITY_INTERACTIVE
                ),
                "regularQueuedCount": sum(
                    1
                    for job_key in self._queue
                    if self._jobs.get(job_key, {}).get("_priorityClass")
                    != PRIORITY_INTERACTIVE
                ),
                "terminalCount": len(terminal_jobs),
                "terminalTtlSeconds": self.terminal_ttl_seconds,
                "maxTerminalJobs": self.max_terminal_jobs,
                "cancelledCount": self._cancelled_count,
                "rejectedCount": self._rejected_count,
                "timedOutCount": self._timed_out_count,
                "recentTerminalJobs": [
                    self._terminal_diagnostic(job) for job in terminal_jobs[:10]
                ],
            }

    def _start_worker(self, job_key: JobKey) -> None:
        worker = threading.Thread(target=self._run, args=(job_key,), daemon=True)
        worker.start()

    def _run(self, job_key: JobKey) -> None:
        next_job_key: Optional[JobKey] = None
        with self._lock:
            job = self._jobs.get(job_key)
            if job is None or job["status"] != "running":
                return
            runner = job["_runner"]
            snapshot = job["_snapshot"]

        class ExecutionControl:
            def __init__(ctrl_self) -> None:
                ctrl_self._pending_chunks = []
                ctrl_self._pending_bytes = 0
                ctrl_self._last_flush_mono = self._monotonic()
                ctrl_self._flush_lock = threading.Lock()
                ctrl_self._flush_timer = None

            def __call__(ctrl_self, phase: str) -> None:
                if phase not in PUBLIC_PHASES or phase in {"queued", "completed", "failed", "cancelled"}:
                    return
                now = self._monotonic()
                with self._lock:
                    current = self._jobs.get(job_key)
                    if current is not None and current["status"] == "running":
                        self._transition_phase_locked(current, phase, now)

            def record_metric(ctrl_self, name: str, value: Any) -> None:
                with self._lock:
                    current = self._jobs.get(job_key)
                    if current is not None:
                        if "_metrics" not in current:
                            current["_metrics"] = {}
                        current["_metrics"][name] = value

            def set_diagnostic_error_code(ctrl_self, code: str) -> None:
                with self._lock:
                    current = self._jobs.get(job_key)
                    if current is not None:
                        current["_diagnosticErrorCode"] = str(code or "").strip()

            def record_provider_attempt(ctrl_self, attempt_metrics: Dict) -> None:
                with self._lock:
                    current = self._jobs.get(job_key)
                    if current is None:
                        return
                    metrics = current.setdefault("_metrics", {})
                    metrics["providerAttempts"] = int(
                        metrics.get("providerAttempts", 0)
                    ) + 1
                    for name in (
                        "providerHeadersMs",
                        "providerFirstVisibleMs",
                        "providerCompleteMs",
                        "parseMs",
                    ):
                        value = attempt_metrics.get(name)
                        if isinstance(value, int) and not isinstance(value, bool):
                            previous = metrics.get(name)
                            metrics[name] = (
                                previous + value
                                if isinstance(previous, int)
                                and not isinstance(previous, bool)
                                else value
                            )
                        elif name not in metrics:
                            metrics[name] = None

            def cancel_requested(ctrl_self) -> bool:
                with self._lock:
                    current = self._jobs.get(job_key)
                    return bool(current and current.get("_cancelRequested"))

            def disable_running_cancel(ctrl_self) -> None:
                with self._lock:
                    current = self._jobs.get(job_key)
                    if (
                        current is None
                        or current["status"] != "running"
                        or current.get("_cancelRequested")
                    ):
                        raise LongTaskCancelled()
                    current["_allowRunningCancel"] = False
                    self._condition.notify_all()

            def set_cancel_callback(ctrl_self, callback) -> None:
                should_cancel = False
                with self._lock:
                    current = self._jobs.get(job_key)
                    if current is None or current["status"] != "running":
                        should_cancel = True
                    elif current.get("_cancelRequested"):
                        should_cancel = True
                    else:
                        current["_cancelCallback"] = callback
                if should_cancel:
                    callback()

            def clear_cancel_callback(ctrl_self, callback) -> None:
                with self._lock:
                    current = self._jobs.get(job_key)
                    if current is not None and current.get("_cancelCallback") is callback:
                        current["_cancelCallback"] = None

            def publish_text(ctrl_self, text: str) -> None:
                if not text or not isinstance(text, str):
                    return
                if ctrl_self.cancel_requested():
                    return
                chunk_bytes = len(text.encode("utf-8"))
                with ctrl_self._flush_lock:
                    ctrl_self._pending_chunks.append(text)
                    ctrl_self._pending_bytes += chunk_bytes
                    now_mono = self._monotonic()
                    if (
                        ctrl_self._pending_bytes >= MAX_TEXT_BATCH_BYTES
                        or (now_mono - ctrl_self._last_flush_mono) >= MAX_TEXT_BATCH_INTERVAL_SECONDS
                    ):
                        ctrl_self._cancel_flush_timer_locked()
                        ctrl_self._flush_locked(now_mono, force=False)
                    if ctrl_self._pending_chunks:
                        ctrl_self._schedule_flush_locked(now_mono)

            def flush(ctrl_self) -> None:
                with ctrl_self._flush_lock:
                    ctrl_self._cancel_flush_timer_locked()
                    ctrl_self._flush_locked(self._monotonic(), force=True)

            def _cancel_flush_timer_locked(ctrl_self) -> None:
                timer = ctrl_self._flush_timer
                ctrl_self._flush_timer = None
                if timer is not None:
                    timer.cancel()

            def _schedule_flush_locked(ctrl_self, now_mono: float) -> None:
                if ctrl_self._flush_timer is not None or not ctrl_self._pending_chunks:
                    return
                delay = max(
                    0.0,
                    MAX_TEXT_BATCH_INTERVAL_SECONDS
                    - (now_mono - ctrl_self._last_flush_mono),
                )

                def flush_pending() -> None:
                    with ctrl_self._flush_lock:
                        ctrl_self._flush_timer = None
                        ctrl_self._flush_locked(self._monotonic(), force=True)

                timer = threading.Timer(delay, flush_pending)
                timer.daemon = True
                ctrl_self._flush_timer = timer
                timer.start()

            def _flush_locked(ctrl_self, now_mono: float, force: bool = False) -> None:
                while ctrl_self._pending_chunks:
                    all_pending = "".join(ctrl_self._pending_chunks)
                    all_bytes = all_pending.encode("utf-8")
                    if len(all_bytes) >= MAX_TEXT_BATCH_BYTES:
                        slice_bytes = all_bytes[:MAX_TEXT_BATCH_BYTES]
                        slice_text = slice_bytes.decode("utf-8", errors="ignore")
                        actual_slice_len = len(slice_text.encode("utf-8"))
                        rem_text = all_bytes[actual_slice_len:].decode("utf-8", errors="ignore")
                        ctrl_self._pending_chunks = [rem_text] if rem_text else []
                        ctrl_self._pending_bytes = len(rem_text.encode("utf-8"))
                        ctrl_self._last_flush_mono = now_mono
                        ctrl_self._emit_delta_locked(slice_text)
                    elif force or (now_mono - ctrl_self._last_flush_mono) >= MAX_TEXT_BATCH_INTERVAL_SECONDS:
                        ctrl_self._pending_chunks = []
                        ctrl_self._pending_bytes = 0
                        ctrl_self._last_flush_mono = now_mono
                        ctrl_self._emit_delta_locked(all_pending)
                        break
                    else:
                        break

            def _emit_delta_locked(ctrl_self, delta_to_emit: str) -> None:
                if not delta_to_emit:
                    return
                with self._lock:
                    current = self._jobs.get(job_key)
                    if (
                        current is None
                        or current["status"] != "running"
                        or current.get("_cancelRequested")
                    ):
                        return
                    if current.get("_text_preview_truncated"):
                        return
                    current_preview = str(current.get("_text_preview") or "")
                    current_len = len(current_preview.encode("utf-8"))
                    if current_len >= MAX_TEXT_PREVIEW_BYTES:
                        current["_text_preview_truncated"] = True
                        return
                    remaining_cap = MAX_TEXT_PREVIEW_BYTES - current_len
                    text_bytes = delta_to_emit.encode("utf-8")
                    if len(text_bytes) > remaining_cap:
                        delta_to_emit = text_bytes[:remaining_cap].decode("utf-8", errors="ignore")
                        current["_text_preview_truncated"] = True
                    if not delta_to_emit:
                        return

                    current["_text_preview"] = current_preview + delta_to_emit
                    self._append_event_locked(
                        current,
                        event_type="delta",
                        phase=current["phase"],
                        status=current["status"],
                        data={"delta": delta_to_emit},
                    )
                    self._condition.notify_all()

        control = ExecutionControl()

        result = None
        error = None
        cancelled = False
        cancelled_result = None
        continuation = None
        try:
            result = runner(snapshot, control)
            if isinstance(result, LongTaskContinuation):
                continuation = result
        except LongTaskCancelled as exc:
            cancelled = True
            cancelled_result = exc.partial_result
        except Exception as exc:
            diagnostic_error_code = (
                exc.code if isinstance(exc, AdapterError) else ""
            )
            partial_result = getattr(exc, "partial_result", None)
            if (
                isinstance(exc, AdapterError)
                and exc.code in job.get("_safeFailureCodes", set())
            ):
                error = {"code": exc.code, "message": exc.message}
            else:
                error = {
                    "code": str(job.get("_failureCode") or "LONG_TASK_FAILED"),
                    "message": str(job.get("_failureMessage") or "后台任务执行失败。"),
                }
            if partial_result is not None:
                error["_partialResult"] = deepcopy(partial_result)
            if diagnostic_error_code:
                error["_diagnosticCode"] = diagnostic_error_code
        finally:
            control.flush()
            snapshot = None
            runner = None

        now_mono = self._monotonic()
        with self._lock:
            job = self._jobs.get(job_key)
            if job is None or job["status"] != "running":
                return
            if job.get("_authInvalidated"):
                job["result"] = None
                job["error"] = deepcopy(
                    job.get("_authInvalidatedError")
                    or {
                        "code": "DIRECT_SERVICE_KEY_ROTATED",
                        "message": "服务 API Key 已更换或清除，原任务已失效，请重新提交任务。",
                    }
                )
                self._finish_locked(job, "failed", now_mono)
                self._running_count = max(self._running_count - 1, 0)
                next_job_key = self._promote_next_locked(now_mono)
                self._trim_terminal_locked()
                self._condition.notify_all()
                if next_job_key is not None:
                    self._start_worker(next_job_key)
                return
            cancel_requested = bool(job.get("_cancelRequested"))
            if cancelled or cancel_requested:
                final_result = cancelled_result
                if final_result is None:
                    if continuation is not None and isinstance(continuation.snapshot, dict):
                        raw_results = continuation.snapshot.get("results")
                        if raw_results is not None:
                            final_result = {
                                "schemaVersion": "excel.smart_fill.v2",
                                "items": raw_results,
                                "provider": str(continuation.snapshot.get("provider", "")),
                                "processedItemCount": len(raw_results),
                                "batchCount": int(continuation.snapshot.get("batchCount", 0)),
                                "partial": True,
                                "stopReason": "cancelled",
                            }
                    elif job.get("_text_preview"):
                        preview_text = str(job["_text_preview"])
                        final_result = {
                            "plainText": preview_text,
                            "rewrittenText": preview_text,
                            "partial": True,
                            "stopReason": "cancelled",
                        }
                    elif job.get("result") is not None:
                        final_result = job.get("result")
                job["result"] = final_result
                self._finish_locked(job, "cancelled", now_mono)
                self._cancelled_count += 1
                self._running_count = max(self._running_count - 1, 0)
            elif continuation is not None:
                job["_snapshot"] = continuation.snapshot
                job["_occupiesSlot"] = False
                if isinstance(continuation.snapshot, dict):
                    pub = job.get("_publicMetadata")
                    if isinstance(pub, dict):
                        if "currentBatch" in continuation.snapshot:
                            pub["currentBatch"] = continuation.snapshot["currentBatch"]
                        if "totalBatches" in continuation.snapshot:
                            pub["totalBatches"] = continuation.snapshot["totalBatches"]
                        if "batchCount" in continuation.snapshot:
                            pub["completedBatchCount"] = continuation.snapshot["batchCount"]
                self._transition_phase_locked(job, continuation.phase, now_mono)
                self._running_count = max(self._running_count - 1, 0)
                self._deferred.append(job_key)
                next_job_key = self._promote_next_locked(now_mono)
            elif error is None:
                self._complete_success_locked(job, result, now_mono)
                self._running_count = max(self._running_count - 1, 0)
            else:
                diagnostic_error_code = str(error.pop("_diagnosticCode", ""))
                partial_result = error.pop("_partialResult", None)
                if partial_result is not None:
                    job["result"] = partial_result
                job["error"] = error
                job["_diagnosticErrorCode"] = diagnostic_error_code
                if "TIMEOUT" in diagnostic_error_code.upper():
                    self._timed_out_count += 1
                self._finish_locked(job, "failed", now_mono)
                self._running_count = max(self._running_count - 1, 0)
            if continuation is None:
                next_job_key = self._promote_next_locked(now_mono)
            self._trim_terminal_locked()
            self._condition.notify_all()

        if next_job_key is not None:
            self._start_worker(next_job_key)

    def _complete_success_locked(
        self, job: Dict, result: Dict, now_mono: float
    ) -> None:
        success_committer = job.get("_successCommitter")
        try:
            if success_committer is not None:
                success_committer(job.get("_snapshot") or {}, result)
        except Exception as exc:
            if (
                isinstance(exc, AdapterError)
                and exc.code in job.get("_safeFailureCodes", set())
            ):
                job["error"] = {"code": exc.code, "message": exc.message}
            else:
                job["error"] = {
                    "code": str(job.get("_failureCode") or "LONG_TASK_FAILED"),
                    "message": str(
                        job.get("_failureMessage") or "后台任务执行失败。"
                    ),
                }
            self._finish_locked(job, "failed", now_mono)
        else:
            job["result"] = result
            self._finish_locked(job, "completed", now_mono)

    def _promote_next_locked(self, now_mono: float) -> Optional[JobKey]:
        while (self._queue or self._deferred) and self._running_count < self.max_running:
            ordered = self._ordered_queue_locked()
            if not ordered:
                return None
            job_key = ordered[0]
            removed = False
            try:
                self._queue.remove(job_key)
                removed = True
            except ValueError:
                try:
                    self._deferred.remove(job_key)
                    removed = True
                except ValueError:
                    pass
            if not removed:
                continue
            job = self._jobs.get(job_key)
            if job is None or job["status"] not in {"queued", "running"}:
                continue
            if job["status"] == "running" and job.get("_occupiesSlot"):
                continue
            if job.get("_priorityClass") == PRIORITY_INTERACTIVE:
                self._interactive_dispatch_streak += 1
            else:
                self._interactive_dispatch_streak = 0
            job["status"] = "running"
            job["_occupiesSlot"] = True
            self._transition_phase_locked(job, "preparing", now_mono)
            self._running_count += 1
            return job_key
        return None

    def _ordered_queue_locked(self):
        pending = [
            job_key
            for job_key in list(self._queue) + list(self._deferred)
            if (
                self._jobs.get(job_key, {}).get("status") == "queued"
                or (
                    self._jobs.get(job_key, {}).get("status") == "running"
                    and not self._jobs.get(job_key, {}).get("_occupiesSlot")
                )
            )
        ]
        ordered = []
        streak = self._interactive_dispatch_streak
        while pending:
            interactive = [
                key
                for key in pending
                if self._jobs.get(key, {}).get("_priorityClass")
                == PRIORITY_INTERACTIVE
            ]
            regular = [key for key in pending if key not in interactive]
            if interactive and regular:
                if streak >= INTERACTIVE_BURST_LIMIT:
                    selected = regular[0]
                    streak = 0
                else:
                    selected = interactive[0]
                    streak += 1
            elif interactive:
                selected = interactive[0]
                streak += 1
            else:
                selected = regular[0]
                streak = 0
            ordered.append(selected)
            pending.remove(selected)
        return ordered

    def _transition_phase_locked(self, job: Dict, phase: str, now_mono: float) -> None:
        current_phase = job.get("phase", "")
        if current_phase == phase:
            return
        phase_started = job.get("_phaseStartedMonotonic", now_mono)
        if current_phase:
            durations = job["_phaseDurations"]
            durations[current_phase] = durations.get(current_phase, 0.0) + max(
                now_mono - phase_started,
                0.0,
            )
            job["_lastTimedPhase"] = current_phase
        job["phase"] = phase
        job["_phaseStartedMonotonic"] = now_mono
        job["_updatedMonotonic"] = now_mono
        job["updatedAt"] = self._wall_clock()
        event_type = "terminal" if phase in TERMINAL_STATUSES else "phase"
        self._append_event_locked(
            job,
            event_type,
            phase,
            job.get("status", phase),
            error=job.get("error"),
        )
        self._condition.notify_all()

    def _finish_locked(self, job: Dict, status: str, now_mono: float) -> None:
        job["status"] = status
        job["_occupiesSlot"] = False
        self._transition_phase_locked(job, status, now_mono)
        job["_terminalAtMonotonic"] = now_mono
        job["_runner"] = None
        job["_cancelCallback"] = None
        job["_successCommitter"] = None
        job["_authInvalidationCommitter"] = None
        job["_snapshot"] = None

    def _cleanup_locked(self, now_mono: float) -> None:
        expired = [
            job_key
            for job_key, job in self._jobs.items()
            if job["status"] in TERMINAL_STATUSES
            and job.get("_terminalAtMonotonic") is not None
            and now_mono - job["_terminalAtMonotonic"] > self.terminal_ttl_seconds
        ]
        for job_key in expired:
            self._jobs.pop(job_key, None)
        self._trim_terminal_locked()

    def _trim_terminal_locked(self) -> None:
        terminal = sorted(
            (
                job
                for job in self._jobs.values()
                if job["status"] in TERMINAL_STATUSES
            ),
            key=lambda item: item.get("_terminalAtMonotonic") or 0,
        )
        while len(terminal) > self.max_terminal_jobs:
            job = terminal.pop(0)
            self._jobs.pop((job["taskType"], job["jobId"]), None)

    def _find_job_key_locked(
        self, job_id: str, task_type: Optional[str]
    ) -> Optional[JobKey]:
        if task_type is not None:
            return (task_type, job_id)
        matches = [
            job_key for job_key in self._jobs if job_key[1] == job_id
        ]
        return matches[0] if len(matches) == 1 else None

    def _public_job_locked(self, job: Dict, now_mono: float) -> Dict:
        terminal_at = job.get("_terminalAtMonotonic")
        elapsed_until = terminal_at if terminal_at is not None else now_mono
        phase_elapsed = 0.0
        if terminal_at is None:
            phase_elapsed = max(now_mono - job.get("_phaseStartedMonotonic", now_mono), 0.0)
        durations = dict(job.get("_phaseDurations", {}))
        if phase_elapsed:
            phase = job.get("phase", "")
            durations[phase] = durations.get(phase, 0.0) + phase_elapsed
        queue_position = None
        if job["status"] == "queued":
            try:
                job_key = (job["taskType"], job["jobId"])
                queued_order = [
                    key
                    for key in self._ordered_queue_locked()
                    if self._jobs.get(key, {}).get("status") == "queued"
                ]
                queue_position = queued_order.index(job_key) + 1
            except ValueError:
                queue_position = None
        is_invalidated = bool(job.get("_authInvalidated"))
        effective_status = "failed" if is_invalidated else job["status"]
        effective_phase = "failed" if is_invalidated else job["phase"]
        elapsed_ms = int(max(elapsed_until - job["_createdMonotonic"], 0.0) * 1000)
        terminal_age_ms = (
            int(max(now_mono - terminal_at, 0.0) * 1000)
            if terminal_at is not None
            else None
        )
        phase_elapsed_ms = int(max(phase_elapsed, 0.0) * 1000)
        remainder_phase = (
            job.get("phase")
            if terminal_at is None
            else job.get("_lastTimedPhase")
        )
        phase_durations_ms = _phase_durations_ms(
            durations,
            elapsed_ms,
            remainder_phase=remainder_phase,
        )
        queue_wait_ms = phase_durations_ms.get("queued", 0)
        metrics = deepcopy(job.get("_metrics", {}))
        public_job = {
            "jobId": job["jobId"],
            "traceId": job["traceId"],
            "status": effective_status,
            "phase": effective_phase,
            "createdAt": job["createdAt"],
            "updatedAt": job["updatedAt"],
            "elapsedSeconds": int(max(elapsed_until - job["_createdMonotonic"], 0.0)),
            "phaseElapsedSeconds": int(phase_elapsed),
            "phaseDurations": {
                phase: int(max(duration, 0.0))
                for phase, duration in durations.items()
            },
            "elapsedMs": elapsed_ms,
            "terminalAgeMs": terminal_age_ms,
            "phaseElapsedMs": phase_elapsed_ms,
            "phaseDurationsMs": phase_durations_ms,
            "queueWaitMs": queue_wait_ms,
            "metrics": metrics,
            "heartbeatAgeSeconds": int(
                max(now_mono - job.get("_updatedMonotonic", now_mono), 0.0)
            ),
            "queuePosition": queue_position if not is_invalidated else None,
            "canCancel": False if is_invalidated else (job["status"] == "queued" or bool(
                job["status"] == "running"
                and job.get("_allowRunningCancel")
                and not job.get("_cancelRequested")
            )),
        }
        if job.get("_allowRunningCancel") and not is_invalidated:
            public_job["cancelRequested"] = bool(job.get("_cancelRequested"))
        public_job.update(job.get("_publicMetadata", {}))
        if "providerOutcome" in metrics:
            public_job["providerOutcome"] = metrics["providerOutcome"]
        if effective_status in TERMINAL_STATUSES:
            public_job.pop("runningMessage", None)
        if is_invalidated:
            public_job["result"] = None
            public_job["error"] = deepcopy(
                job.get("_authInvalidatedError")
                or {
                    "code": "DIRECT_SERVICE_KEY_ROTATED",
                    "message": "服务 API Key 已更换或清除，原任务已失效，请重新提交任务。",
                }
            )
        else:
            if job.get("result") is not None:
                public_job["result"] = job["result"]
            if job.get("error") is not None:
                public_job["error"] = job["error"]
        return public_job

    def _terminal_diagnostic(self, job: Dict) -> Dict:
        terminal_at = job.get("_terminalAtMonotonic")
        elapsed_until = (
            terminal_at
            if terminal_at is not None
            else job.get("_updatedMonotonic", job["_createdMonotonic"])
        )
        error = job.get("error") if isinstance(job.get("error"), dict) else {}
        durations_sec = {
            phase: int(max(duration, 0.0))
            for phase, duration in job.get("_phaseDurations", {}).items()
        }
        elapsed_ms = int(max(elapsed_until - job["_createdMonotonic"], 0.0) * 1000)
        durations_ms = _phase_durations_ms(
            job.get("_phaseDurations", {}),
            elapsed_ms,
            remainder_phase=job.get("_lastTimedPhase"),
        )
        queue_wait_ms = durations_ms.get("queued", 0)
        diagnostic = {
            "jobId": job["jobId"],
            "traceId": job["traceId"],
            "taskType": job["taskType"],
            "status": job["status"],
            "phase": job["phase"],
            "elapsedSeconds": int(
                max(elapsed_until - job["_createdMonotonic"], 0.0)
            ),
            "phaseDurations": durations_sec,
            "elapsedMs": elapsed_ms,
            "phaseDurationsMs": durations_ms,
            "queueWaitMs": queue_wait_ms,
            "metrics": deepcopy(job.get("_metrics", {})),
            "errorCode": str(
                job.get("_diagnosticErrorCode") or error.get("code", "")
            ),
        }
        provider_outcome = job.get("_metrics", {}).get("providerOutcome")
        if provider_outcome is not None:
            diagnostic["providerOutcome"] = provider_outcome
        return diagnostic


_SHARED_COORDINATOR = LongTaskCoordinator(
    max_running=_positive_int_from_env(
        "AI_WPS_LONG_TASK_MAX_RUNNING", DEFAULT_MAX_RUNNING
    ),
    max_queued=_positive_int_from_env(
        "AI_WPS_LONG_TASK_MAX_QUEUED", DEFAULT_MAX_QUEUED
    ),
    terminal_ttl_seconds=_positive_int_from_env(
        "AI_WPS_LONG_TASK_TERMINAL_TTL_SECONDS", DEFAULT_TERMINAL_TTL_SECONDS
    ),
    max_terminal_jobs=_positive_int_from_env(
        "AI_WPS_LONG_TASK_MAX_TERMINAL_JOBS", DEFAULT_MAX_TERMINAL_JOBS
    ),
)


def get_long_task_coordinator() -> LongTaskCoordinator:
    return _SHARED_COORDINATOR
