(function () {
  var ADAPTER_BASE_URL = "http://127.0.0.1:18100";
  var FRONTEND_BUILD_VERSION = "0.26.0-preview.1-a0d6f5d1e772";
  var TASKPANE_ROOT_ID = "result-output";
  var helpers = window.WpsAiAssistantHelpers || {};
  var DOCUMENT_REVIEW_POLL_INTERVAL_MS = 3000;
  var DOCUMENT_REVIEW_POLL_ERROR_RETRY_DELAY_MS = 15000;
  var DOCUMENT_REVIEW_POLL_SLOW_RETRY_DELAY_MS = 30000;
  var DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS = 10000;
  var WRITING_POLICY_MANAGEMENT_REQUEST_TIMEOUT_MS = 15000;
  var WRITING_POLICY_LIST_PAGE_SIZE = 50;
  var SETTINGS_REFRESH_REQUEST_TIMEOUT_MS = 8000;
  var DOCUMENT_REVIEW_POLL_MAX_ERRORS = 240;
  var DOCUMENT_REVIEW_POLL_MAX_WAIT_MS = 60 * 60 * 1000;
  var DOCUMENT_REVIEW_ACTIVE_JOB_STORAGE_KEY = "ai-wps-document-review-active-job-v1";
  var FULL_DOCUMENT_REVIEW_ACTIVE_JOB_STORAGE_KEY = "ai-wps-full-document-review-active-job-v1";
  var DETERMINISTIC_FORMAT_REVIEW_POLL_INTERVAL_MS = 1000;
  var DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS = 10000;
  var DETERMINISTIC_FORMAT_REVIEW_POLL_RETRY_DELAY_MS = 15000;
  var DETERMINISTIC_FORMAT_REVIEW_POLL_MAX_ERRORS = 240;
  var DETERMINISTIC_FORMAT_REVIEW_POLL_MAX_WAIT_MS = 60 * 60 * 1000;
  var DETERMINISTIC_FORMAT_REVIEW_ACTIVE_JOB_STORAGE_KEY = "ai-wps-word-format-review-active-job-v2";
  var WRITING_ACTIVE_JOB_STORAGE_KEY = "ai-wps-writing-active-job-v1";
  var WRITING_POLL_INTERVAL_MS = 3000;
  var WRITING_POLL_RETRY_DELAY_MS = 15000;
  var WRITING_POLL_REQUEST_TIMEOUT_MS = 10000;
  var WRITING_EVENTS_WAIT_MS = 25000;
  var WRITING_EVENTS_REQUEST_TIMEOUT_MS = 35000;
  var DOCUMENT_REVIEW_PHASE_TEXT = {
    queued: "排队等待",
    preparing: "准备审查内容",
    extracting: "抽取审查内容",
    confirming: "等待大型文档确认",
    chunking: "处理审查分片",
    provider_connecting: "正在连接模型服务",
    provider_waiting: "等待模型服务响应",
    provider_processing: "模型后台处理",
    streaming: "正在生成内容",
    stopping: "正在停止任务",
    retrying: "受控重试中",
    splitting: "拆分饱和分片",
    parsing: "解析并整理审查结果",
    aggregating: "汇总分片结果",
    completed: "已完成",
    failed: "已失败",
    cancelled: "已取消"
  };
  var FORMAT_REVIEW_EXTRACTION_OPTIONS = {
    maxParagraphs: 80,
    maxParagraphTextLength: 800,
    maxPlainTextLength: 12000,
    preferSelectionTextParagraphs: true,
    avoidFullTextRead: true,
    avoidFallbackTextRead: true
  };
  var DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS = {
    maxPlainTextLength: 130000,
    preferSelectionTextParagraphs: false,
    preferSelectionRangeParagraphs: true,
    avoidFullTextRead: true,
    avoidFallbackTextRead: true,
    includeCharacterFormatSegments: true,
    maxFormatSegments: 2048
  };
  var DOCUMENT_REVIEW_EXTRACTION_OPTIONS = {
    maxParagraphs: 80,
    maxParagraphTextLength: 800,
    maxPlainTextLength: 12000,
    preferSelectionTextParagraphs: true,
    avoidFullTextRead: true,
    avoidFallbackTextRead: true
  };
  var SMART_WRITE_EXTRACTION_OPTIONS = {
    maxParagraphs: 20,
    maxParagraphTextLength: 2000,
    maxPlainTextLength: 12000,
    preferSelectionTextParagraphs: true,
    avoidFullTextRead: true,
    avoidFallbackTextRead: true
  };
  var DOCUMENT_REVIEW_PROMPTS = {
    technical_solution: [
      "请从以下维度审查技术方案内容：",
      "1. 功能描述准确性：检查功能边界、输入输出、前置条件、异常流程、权限和依赖是否描述清楚，避免夸大或遗漏关键约束。",
      "2. 术语专业性：检查技术术语、产品名称、接口名称、模块名称是否准确、一致，避免口语化和同一概念多种叫法。",
      "3. 设计合理性：检查方案是否说明架构边界、模块职责、数据流、容错机制、安全性、可扩展性和部署约束。",
      "4. 要求明确性：检查需求、验收标准和测试要求是否可执行、可验证、无歧义，避免“尽快、友好、高效、支持多种”等不可验收表述。",
      "请优先指出影响理解、实现、验收或交付风险的问题，并给出可直接落地的修改建议。"
    ].join("\n"),
    contract_acceptance: [
      "请从以下维度审查合同验收文档内容：",
      "1. 验收范围：检查验收对象、交付边界、版本范围、排除项和依赖条件是否明确。",
      "2. 验收证据：检查是否明确交付物清单、测试记录、签署材料、问题闭环记录和可追溯证明。",
      "3. 判定标准：检查通过/不通过标准、缺陷等级、整改时限、复验方式和例外处理是否可执行。",
      "4. 合同一致性：检查文档表述是否与合同条款、技术协议、变更单和项目范围保持一致。",
      "5. 风险闭环：检查遗留问题、限制条件、责任归属和后续计划是否清楚，避免留下验收争议。",
      "请优先指出可能影响验收签署、责任划分或后续交付的风险，并给出可落地修改建议。"
    ].join("\n"),
    test_outline: [
      "请从以下维度审查测试大纲和细则内容：",
      "1. 测试范围：检查测试对象、版本、环境、接口、模块边界和不测范围是否明确。",
      "2. 测试目标：检查测试目标是否与需求、设计、验收标准对应，是否覆盖关键业务路径和异常场景。",
      "3. 用例完整性：检查前置条件、输入数据、操作步骤、预期结果、判定准则和清理步骤是否可复现。",
      "4. 覆盖充分性：检查功能、性能、安全、兼容、异常、边界值和回归测试是否按风险分层覆盖。",
      "5. 缺陷闭环：检查缺陷记录、等级划分、复测策略、通过条件和测试报告输出是否明确。",
      "请优先指出会导致测试不可执行、不可复现、不可验收或覆盖不足的问题，并给出可落地修改建议。"
    ].join("\n")
  };
  var DEFAULT_DOCUMENT_REVIEW_PROMPT = DOCUMENT_REVIEW_PROMPTS.technical_solution;
  var REWRITE_STYLE_PROMPTS = {
    standard: "采用国企技术方案常用的正式、准确、克制表达，术语统一，避免口语化和夸张表述。",
    default: "采用国企技术方案常用的正式、准确、克制表达，术语统一，避免口语化和夸张表述。",
    formal: "采用国企技术方案常用的正式、准确、克制表达，术语统一，避免口语化和夸张表述。",
    structured: "按“背景、问题、措施、结论”组织内容，强化层级、逻辑连接和可执行表述。",
    reporting: "采用汇报材料表达，先给结论，再说明进展、问题、风险和下一步安排，语言稳健。"
  };
  var REWRITE_FOCUS_PROMPTS = {
    complete: "保留原文关键信息、事实、条件和约束，不遗漏责任、时间、对象和结论。",
    default: "保留原文关键信息、事实、条件和约束，不遗漏责任、时间、对象和结论。",
    conclusion: "优先突出核心结论、关键判断、主要风险、影响范围和需要关注的问题。",
    risk: "优先突出核心结论、关键判断、主要风险、影响范围和需要关注的问题。",
    conclusion_risk: "优先突出核心结论、关键判断、主要风险、影响范围和需要关注的问题。",
    next_step: "优先突出解决措施、实施路径、责任分工、时间节点和下一步安排。",
    implementation: "优先突出解决措施、实施路径、责任分工、时间节点和下一步安排。",
    plan_next: "优先突出解决措施、实施路径、责任分工、时间节点和下一步安排。",
    acceptance: "优先突出交付物、验收标准、问题闭环、证据材料和后续跟踪要求。"
  };
  var REWRITE_LENGTH_PROMPTS = {
    same: "保持与原文相近的篇幅，只优化措辞、结构和信息组织。",
    default: "保持与原文相近的篇幅，只优化措辞、结构和信息组织。",
    concise: "压缩冗余表达，保留关键信息和必要限定，输出更短更直接的版本。",
    expanded: "在不编造事实的前提下补足必要背景、逻辑衔接、措施说明和结论表达。"
  };
  var REWRITE_OUTPUT_PROMPT = "不要原样返回待处理内容；只输出最终正文。";
  var fallbackTemplates = [
    { id: "technical-document-template-rules", name: "技术文档模板规则" }
  ];
  var TASK_API_KEY_DEFS = [
    { taskType: "word.smart_write", label: "智能编写" },
    { taskType: "word.smart_imitation", label: "智能仿写" },
    { taskType: "word.document_review", label: "文档审查" },
    { taskType: "word.format_review", label: "格式审查" }
  ];
  var MODE_WORKFLOW_TASK_TYPES = {
    smartWrite: "word.smart_write",
    smartImitation: "word.smart_imitation",
    documentReview: "word.document_review",
    formatReview: "word.format_review"
  };
  var WRITING_POLICY_SCOPE_DEFS = [
    { scope: "global", label: "组织规范", caption: "管理组织术语、文体规则和去模板化规则" },
    { scope: "word.smart_write", label: "智能编写补充", caption: "仅在智能编写中使用的文体规则" },
    { scope: "word.smart_imitation", label: "智能仿写补充", caption: "仅在智能仿写中使用的文体规则" },
    { scope: "word.document_review", label: "文档审查补充", caption: "仅在文档审查中检查的文体规则" }
  ];
  var WRITING_POLICY_RULE_TASK_TYPES = [
    "word.smart_write",
    "word.smart_imitation",
    "word.document_review"
  ];
  var WRITING_POLICY_ITEM_TYPES = ["term", "style", "anti_template"];
  var WRITING_POLICY_RULE_SCENE_IDS = [
    "yangqi",
    "cybersecurity",
    "official"
  ];
  var modeConfig = {
    smartWrite: {
      title: "智能编写",
      styleLabel: "表达风格",
      primaryText: "生成内容",
      runningText: "正在执行智能编写...",
      doneText: "智能编写结果已生成。",
      showRewriteOptions: true,
      showInstruction: true,
      showPromptFragments: false,
      showTemplate: false
    },
    smartImitation: {
      title: "智能仿写",
      primaryText: "生成仿写内容",
      runningText: "正在执行智能仿写...",
      doneText: "智能仿写结果已生成。",
      showRewriteOptions: false,
      showInstruction: false,
      showTemplate: false,
      showDocumentReviewOptions: false,
      showFixedTemplate: false,
      showSmartImitationOptions: true
    },
    documentReview: {
      title: "文档审查",
      primaryText: "开始文档审查",
      showRewriteOptions: false,
      showInstruction: false,
      showTemplate: false,
      showDocumentReviewOptions: true,
      showFixedTemplate: false
    },
    formatReview: {
      title: "格式审查",
      primaryText: "开始格式审查",
      showRewriteOptions: false,
      showInstruction: false,
      showTemplate: false,
      showDocumentReviewOptions: false,
      showFixedTemplate: true
    },
    settings: {
      title: "设置"
    }
  };
  var state = {
    templates: [],
    selectedTemplateId: "technical-document-template-rules",
    writeAction: "rewrite",
    rewriteStyle: "standard",
    focusPoint: "complete",
    lengthMode: "same",
    userInstruction: "",
    technicalDocumentType: "technical_solution",
    technicalReviewPrompt: DEFAULT_DOCUMENT_REVIEW_PROMPT,
    imitationTemplateText: "",
    imitationRequirement: "",
    imitationReferenceMaterial: "",
    traceId: "",
    taskPerformanceByJobId: {},
    taskPerformanceByTraceId: {},
    taskPerformanceOrder: [],
    lastTaskPerformance: null,
    pendingApplyAction: "",
    rewriteResult: null,
    smartWritePreviewModel: null,
    resultViewMode: "preview",
    documentReviewData: null,
    documentReviewIssueStatus: {},
    documentReviewRecordPreviewVisible: false,
    documentReviewJobId: "",
    documentReviewPollStartedAt: 0,
    documentReviewPollErrorCount: 0,
    documentReviewStopWaiting: null,
    fullDocumentReviewEnabled: false,
    deterministicFormatReviewEnabled: false,
    directStreamingEnabled: false,
    deterministicFormatReviewJobId: "",
    deterministicFormatReviewPollStartedAt: 0,
    deterministicFormatReviewPollErrorCount: 0,
    deterministicFormatReviewSnapshot: null,
    deterministicFormatReviewReport: null,
    deterministicFormatReviewIssueJobId: "",
    deterministicFormatReviewIssueCursorHistory: [],
    deterministicFormatReviewIssueFilters: {
      rule: "",
      dataStatus: "",
      status: "",
      sort: "source"
    },
    deterministicFormatReviewDocumentIdentity: null,
    deterministicFormatReviewImageObjects: {},
    deterministicFormatReviewPreparing: false,
    deterministicFormatReviewCancelRequested: false,
    fullDocumentReviewJobId: "",
    fullDocumentReviewPollErrorCount: 0,
    fullDocumentReviewPreparing: false,
    fullDocumentReviewCancelRequested: false,
    fullDocumentReviewIssueJobId: "",
    fullDocumentReviewIssueReport: null,
    fullDocumentReviewIssueCursorHistory: [],
    fullDocumentReviewIssueFilters: {
      severity: "",
      category: "",
      location: "",
      status: "",
      sort: "source"
    },
    writingJobId: "",
    writingJobTaskType: "",
    writingJobMode: "",
    writingJobStartedAt: 0,
    writingJobPollErrorCount: 0,
    latestDocumentPayload: null,
    latestSelectionMode: "document",
    providerName: "未检测",
    providerBaseUrl: "",
    providerAuthSource: "none",
    adapterHealthStatus: "unknown",
    configurationMutationsAllowed: true,
    modelTasksAllowed: true,
    writingPolicyMutationsAllowed: true,
    taskApiKeys: {},
    workflowProfiles: {},
    workflowProfileSelections: {},
    directServices: [],
    directServiceEditor: {
      open: false,
      mode: "create",
      serviceId: "",
      revision: 1,
      dirty: false
    },
    directServiceOperationId: 0,
    directServiceDeleteCandidate: null,
    taskModelSelections: {},
    lastValidatedCustomModel: null,
    taskModelConfigStatusByTask: {},
    taskModelConfigMenu: { open: false, highlightedIndex: -1, itemCount: 0, items: [] },
    workflowProfileRequestSequence: {},
    workflowProfileMutationBusy: false,
    workflowProfileActivationTimer: null,
    settingsWorkflowTaskType: "word.smart_write",
    workflowProfileEditor: null,
    configRefreshRequestId: 0,
    configRefreshPromise: null,
    configRefreshActiveRequestId: 0,
    configRefreshActiveSilent: false,
    configRefreshQueued: false,
    configRefreshQueuedSilent: true,
    modelInterfaceDetectable: false,
    settingsRefreshController: null,
    workflowHelpPinned: false,
    providerUrlEditorOpen: false,
    writingPolicyView: "home",
    writingPolicyScope: "global",
    writingPolicyType: "term",
    writingPolicyItems: [],
    writingPolicyItemTotal: 0,
    writingPolicyItemOffset: 0,
    writingPolicyPresetPacks: [],
    writingPolicyPresetPack: null,
    writingPolicyPresetItems: [],
    writingPolicyPresetItemTotal: 0,
    writingPolicyPresetItemOffset: 0,
    writingPolicyPresetError: "",
    writingPolicyPresetLoadSequence: 0,
    writingPolicySummary: null,
    writingPolicyLoadSequence: 0,
    writingPolicyMutationBusy: false,
    writingPolicyEditor: null,
    writingPolicyEditorDirty: false,
    writingPolicySummaryState: "idle",
    writingPolicyListError: "",
    writingPolicySearch: "",
    writingPolicySearchTimer: null,
    writingPolicyImportStep: "select",
    writingPolicyImportPreview: null,
    writingPolicyImportBusy: false,
    writingPolicyImportSequence: 0,
    writingPolicyImportReader: null,
    writingPolicyScene: "auto",
    writingPolicyAudit: null,
    currentMode: "smartWrite",
    lastTaskMode: "smartWrite",
    modelTaskBusy: false,
    copyText: "",
    diagnosticsCopyText: "",
    scopeWatcher: null,
    activeTaskSlots: {},
    activeResultsByTask: {},
    activeWritingJobsByTask: {},
    activeResults: {},
    activeWritingJobs: {},
    activeReviewJobs: {},
    viewingHistoryReport: null,
    historyOpen: false,
    historyItems: [],
    historyUnreadCount: 0,
    historyTaskType: "word.smart_write",
    historyLoadSequence: 0,
    documentSessionId: ""
  };

  function byId(id) {
    return document.getElementById(id);
  }

  function setNodeTextIfChanged(node, value) {
    var nextValue = value || "";
    if (node && node.textContent !== nextValue) {
      node.textContent = nextValue;
      return true;
    }
    return false;
  }

  function setNodeClassNameIfChanged(node, value) {
    var nextValue = value || "";
    if (node && node.className !== nextValue) {
      node.className = nextValue;
      return true;
    }
    return false;
  }

  function setNodeAttributeIfChanged(node, name, value) {
    var nextValue = value || "";
    if (node && node.getAttribute && node.getAttribute(name) === nextValue) {
      return false;
    }
    if (node && node.setAttribute) {
      node.setAttribute(name, nextValue);
      return true;
    }
    return false;
  }

  function getSettingsStatusTarget() {
    var statusLine = byId("settings-status-line");
    return statusLine && (statusLine.querySelector("strong") || statusLine);
  }

  function setStatus(message) {
    var statusLine = byId("status-line");
    var settingsStatusLine = getSettingsStatusTarget();
    if (statusLine) {
      setNodeTextIfChanged(statusLine, message);
    }
    if (settingsStatusLine) {
      setNodeTextIfChanged(settingsStatusLine.querySelector("strong") || settingsStatusLine, message);
    }
  }

  function setSettingsStatus(message) {
    var settingsStatusLine = getSettingsStatusTarget();
    if (settingsStatusLine) {
      setNodeTextIfChanged(settingsStatusLine.querySelector("strong") || settingsStatusLine, message);
    }
  }

  function confirmWorkflowEditorDiscard() {
    if (!state.workflowProfileEditor || !state.workflowProfileEditor.dirty) {
      return true;
    }
    return !window.confirm || window.confirm("当前模型配置尚未保存，确认放弃修改？");
  }

  function confirmWritingPolicyEditorDiscard() {
    if (!state.writingPolicyEditor || !state.writingPolicyEditorDirty) {
      return true;
    }
    return !window.confirm || window.confirm("当前规范条目尚未保存，确认放弃修改？");
  }

  function isTaskpanePage() {
    return Boolean(byId(TASKPANE_ROOT_ID));
  }

  function getInitialMode() {
    var match = /[?&]mode=([^&]+)/.exec(window.location.search || "");
    var mode = match ? decodeURIComponent(match[1]) : "smartWrite";
    if (mode === "rewrite" || mode === "continue") {
      return "smartWrite";
    }
    return modeConfig[mode] ? mode : "smartWrite";
  }

  function getTaskPerformance(jobId, traceId) {
    var byJobId = state.taskPerformanceByJobId || {};
    var byTraceId = state.taskPerformanceByTraceId || {};
    if (jobId && byJobId[jobId]) {
      return byJobId[jobId];
    }
    if (traceId && byTraceId[traceId]) {
      return byTraceId[traceId];
    }
    return null;
  }

  function beginTaskPerformance(jobId, taskType, clickTimestamp, clickToFeedbackMs) {
    state.taskPerformanceByJobId = state.taskPerformanceByJobId || {};
    state.taskPerformanceByTraceId = state.taskPerformanceByTraceId || {};
    state.taskPerformanceOrder = state.taskPerformanceOrder || [];
    var record = {
      jobId: jobId,
      traceId: "",
      taskType: taskType,
      clickTimestamp: clickTimestamp,
      clickToFeedbackMs: clickToFeedbackMs,
      localExtractionMs: null,
      clickToAdapterAcceptedMs: null,
      completionToFirstRenderMs: null
    };
    state.taskPerformanceByJobId[jobId] = record;
    state.taskPerformanceOrder.push(jobId);
    while (state.taskPerformanceOrder.length > 50) {
      var expiredJobId = state.taskPerformanceOrder.shift();
      var expired = state.taskPerformanceByJobId[expiredJobId];
      if (expired && expired.traceId) {
        delete state.taskPerformanceByTraceId[expired.traceId];
      }
      delete state.taskPerformanceByJobId[expiredJobId];
    }
    state.lastTaskPerformance = record;
    return record;
  }

  function bindTaskPerformanceTrace(jobId, traceId, resolvedJobId) {
    var record = getTaskPerformance(jobId, traceId);
    if (!record) {
      return null;
    }
    if (resolvedJobId) {
      state.taskPerformanceByJobId[resolvedJobId] = record;
      if (jobId && resolvedJobId !== jobId) {
        delete state.taskPerformanceByJobId[jobId];
        for (var index = 0; index < state.taskPerformanceOrder.length; index += 1) {
          if (state.taskPerformanceOrder[index] === jobId) {
            state.taskPerformanceOrder[index] = resolvedJobId;
            break;
          }
        }
      }
      record.jobId = resolvedJobId;
    }
    if (traceId) {
      record.traceId = traceId;
      state.taskPerformanceByTraceId[traceId] = record;
    }
    return record;
  }

  function selectTaskPerformance(jobId, traceId) {
    var record = getTaskPerformance(jobId, traceId);
    state.lastTaskPerformance = record;
    return record;
  }

  function recordTaskFirstRender(jobId, traceId, taskType, completionTimestamp) {
    var record = getTaskPerformance(jobId, traceId);
    if (!record) {
      record = beginTaskPerformance(jobId || traceId, taskType, null, null);
    }
    bindTaskPerformanceTrace(jobId || record.jobId, traceId, jobId || record.jobId);
    var commitMetric = function () {
      var firstRenderTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
      record.completionToFirstRenderMs = Math.max(0, Math.round(firstRenderTimestamp - completionTimestamp));
      record.taskType = taskType;
      if (state.traceId === record.traceId || (!state.traceId && state.lastTaskPerformance === record)) {
        state.lastTaskPerformance = record;
      }
    };
    if (typeof requestAnimationFrame === "function") {
      requestAnimationFrame(commitMetric);
    } else {
      setTimeout(commitMetric, 0);
    }
  }

  function setTrace(traceId) {
    state.traceId = traceId || "";
    selectTaskPerformance("", state.traceId);
    byId("trace-line").textContent = traceId || "未检测";
  }

  function buildDocumentReviewClientJobId() {
    return [
      "client-doc-review",
      Date.now().toString(36),
      Math.random().toString(36).slice(2, 10)
    ].join("-");
  }

  function buildWritingClientJobId(taskType) {
    return [
      taskType === "word.smart_imitation" ? "client-imitation" : "client-smart-write",
      Date.now().toString(36),
      Math.random().toString(36).slice(2, 10)
    ].join("-");
  }

  function getWritingActiveJobStorageKey(taskType, docSessionId) {
    return [
      "ai-wps:writing-active-job",
      taskType || "word.smart_write",
      docSessionId || "default"
    ].join(":");
  }

  function getWritingDocTaskKey(taskType, docSessionId) {
    var tt = taskType || "word.smart_write";
    var ds = docSessionId || (state.documentSessionId || "default");
    return "wps::" + tt + "::" + ds;
  }

  function getActiveWritingJobRecord(taskType, docSessionId) {
    var key = getWritingDocTaskKey(taskType, docSessionId);
    if (state.activeWritingJobs && Object.prototype.hasOwnProperty.call(state.activeWritingJobs, key)) {
      return state.activeWritingJobs[key];
    }
    if (state.activeWritingJobs && state.activeWritingJobs[key]) {
      return state.activeWritingJobs[key];
    }
    if (!state.activeWritingJobs && state.activeWritingJobsByTask && state.activeWritingJobsByTask[taskType]) {
      var fallback = state.activeWritingJobsByTask[taskType];
      if (fallback && (!docSessionId || !fallback.documentSessionId || fallback.documentSessionId === docSessionId)) {
        return fallback;
      }
    }
    return null;
  }

  function setActiveWritingJobRecord(taskType, docSessionId, record) {
    var key = getWritingDocTaskKey(taskType, docSessionId);
    state.activeWritingJobs = state.activeWritingJobs || {};
    state.activeWritingJobsByTask = state.activeWritingJobsByTask || {};
    if (record) {
      state.activeWritingJobs[key] = record;
      state.activeWritingJobsByTask[taskType] = record;
    } else {
      delete state.activeWritingJobs[key];
      if (state.activeWritingJobsByTask[taskType]) {
        var existingJob = state.activeWritingJobsByTask[taskType];
        if (!docSessionId || !existingJob || !existingJob.documentSessionId || existingJob.documentSessionId === docSessionId) {
          delete state.activeWritingJobsByTask[taskType];
        }
      }
    }
  }

  function getActiveReviewJobRecord(taskType, docSessionId) {
    var key = getWritingDocTaskKey(taskType, docSessionId);
    if (state.activeReviewJobs && Object.prototype.hasOwnProperty.call(state.activeReviewJobs, key)) {
      return state.activeReviewJobs[key];
    }
    if (state.activeReviewJobs && state.activeReviewJobs[key]) {
      return state.activeReviewJobs[key];
    }
    return null;
  }

  function setActiveReviewJobRecord(taskType, docSessionId, record) {
    var key = getWritingDocTaskKey(taskType, docSessionId);
    state.activeReviewJobs = state.activeReviewJobs || {};
    if (record) {
      state.activeReviewJobs[key] = record;
    } else {
      delete state.activeReviewJobs[key];
    }
  }

  function getActiveResultRecord(taskType, docSessionId) {
    var key = getWritingDocTaskKey(taskType, docSessionId);
    if (state.activeResults && Object.prototype.hasOwnProperty.call(state.activeResults, key)) {
      return state.activeResults[key];
    }
    if (state.activeResults && state.activeResults[key]) {
      return state.activeResults[key];
    }
    if (!state.activeResults && state.activeResultsByTask && state.activeResultsByTask[taskType]) {
      var fallback = state.activeResultsByTask[taskType];
      if (fallback && (!docSessionId || !fallback.documentSessionId || fallback.documentSessionId === docSessionId)) {
        return fallback;
      }
    }
    return null;
  }

  function setActiveResultRecord(taskType, docSessionId, record) {
    var key = getWritingDocTaskKey(taskType, docSessionId);
    state.activeResults = state.activeResults || {};
    state.activeResultsByTask = state.activeResultsByTask || {};
    if (record) {
      state.activeResults[key] = record;
      var activeRes = record.result || record;
      if (activeRes && typeof activeRes === "object" && docSessionId && !activeRes.documentSessionId) {
        activeRes.documentSessionId = docSessionId;
      }
      state.activeResultsByTask[taskType] = activeRes;
    } else {
      delete state.activeResults[key];
      if (state.activeResultsByTask[taskType]) {
        var existingRes = state.activeResultsByTask[taskType];
        if (!docSessionId || !existingRes || !existingRes.documentSessionId || existingRes.documentSessionId === docSessionId) {
          delete state.activeResultsByTask[taskType];
        }
      }
    }
  }

  function releaseTaskSlotsForJob(jobId) {
    if (!state.activeTaskSlots) {
      return;
    }
    for (var k in state.activeTaskSlots) {
      if (Object.prototype.hasOwnProperty.call(state.activeTaskSlots, k)) {
        if (!jobId || (state.activeTaskSlots[k] && state.activeTaskSlots[k].jobId === jobId)) {
          delete state.activeTaskSlots[k];
        }
      }
    }
  }

  function loadWritingActiveJob(taskType, docSessionId) {
    var raw;
    try {
      if (!window.localStorage) {
        return null;
      }
      if (taskType && docSessionId) {
        raw = window.localStorage.getItem(getWritingActiveJobStorageKey(taskType, docSessionId));
        if (raw) {
          return JSON.parse(raw);
        }
      }
      if (taskType) {
        for (var i = 0; i < window.localStorage.length; i += 1) {
          var k = window.localStorage.key(i);
          if (k && k.indexOf("ai-wps:writing-active-job:" + taskType + ":") === 0) {
            raw = window.localStorage.getItem(k);
            if (raw) {
              return JSON.parse(raw);
            }
          }
        }
      }
      raw = window.localStorage.getItem(WRITING_ACTIVE_JOB_STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (error) {
      return null;
    }
  }

  function saveWritingActiveJob(job) {
    if (!job || !job.jobId) {
      return;
    }
    var key = getWritingActiveJobStorageKey(job.taskType, job.documentSessionId);
    try {
      if (window.localStorage) {
        var record = JSON.stringify({
          jobId: job.jobId,
          taskType: job.taskType,
          mode: job.mode,
          documentSessionId: job.documentSessionId || "",
          traceId: job.traceId || "",
          startedAt: job.startedAt || Date.now(),
          streamingEnabled: typeof job.streamingEnabled === "boolean" ? job.streamingEnabled : false,
          frontendVersion: FRONTEND_BUILD_VERSION
        });
        window.localStorage.setItem(key, record);
        window.localStorage.setItem(WRITING_ACTIVE_JOB_STORAGE_KEY, record);
      }
    } catch (error) {
      // Storage may be unavailable in some WPS WebView modes.
    }
  }

  function clearWritingActiveJob(jobId, taskType, docSessionId) {
    try {
      if (!window.localStorage) {
        return;
      }
      if (taskType && docSessionId) {
        window.localStorage.removeItem(getWritingActiveJobStorageKey(taskType, docSessionId));
      }
      for (var i = window.localStorage.length - 1; i >= 0; i -= 1) {
        var k = window.localStorage.key(i);
        if (k && k.indexOf("ai-wps:writing-active-job:") === 0) {
          var val = window.localStorage.getItem(k);
          if (val) {
            try {
              var parsed = JSON.parse(val);
              if (!jobId || (parsed && parsed.jobId === jobId)) {
                window.localStorage.removeItem(k);
              }
            } catch (e) {}
          }
        }
      }
      var legacyRaw = window.localStorage.getItem(WRITING_ACTIVE_JOB_STORAGE_KEY);
      if (legacyRaw) {
        var legacy = JSON.parse(legacyRaw);
        if (!jobId || !legacy || !legacy.jobId || legacy.jobId === jobId) {
          window.localStorage.removeItem(WRITING_ACTIVE_JOB_STORAGE_KEY);
        }
      }
    } catch (error) {
      // Storage cleanup must not block result rendering.
    }
  }

  function getReviewActiveJobStorageKey(taskType, docSessionId) {
    return [
      "ai-wps:review-active-job",
      taskType || "word.document_review",
      docSessionId || "default"
    ].join(":");
  }

  function loadDocumentReviewActiveJob(docSessionId) {
    var raw;
    try {
      if (!window.localStorage) {
        return null;
      }
      var currentDoc = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
      if (currentDoc) {
        raw = window.localStorage.getItem(getReviewActiveJobStorageKey("word.document_review", currentDoc));
        if (raw) {
          return JSON.parse(raw);
        }
      }
      raw = window.localStorage.getItem(DOCUMENT_REVIEW_ACTIVE_JOB_STORAGE_KEY);
      if (raw) {
        var legacy = JSON.parse(raw);
        if (!currentDoc || !legacy.documentSessionId || legacy.documentSessionId === currentDoc) {
          return legacy;
        }
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  function saveDocumentReviewActiveJob(job) {
    if (!job || !job.jobId) {
      return;
    }
    var currentDoc = job.documentSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
    try {
      if (window.localStorage) {
        var record = JSON.stringify({
          jobId: job.jobId,
          host: "wps",
          taskType: "word.document_review",
          documentSessionId: currentDoc || "",
          traceId: job.traceId || "",
          startedAt: job.startedAt || Date.now(),
          frontendVersion: FRONTEND_BUILD_VERSION
        });
        window.localStorage.setItem(getReviewActiveJobStorageKey("word.document_review", currentDoc), record);
        window.localStorage.setItem(DOCUMENT_REVIEW_ACTIVE_JOB_STORAGE_KEY, record);
      }
    } catch (error) {
      // localStorage may be unavailable in some WPS WebView modes; polling still works in memory.
    }
  }

  function clearDocumentReviewActiveJob(jobId, docSessionId) {
    var active;
    try {
      if (!window.localStorage) {
        return;
      }
      var currentDoc = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
      if (currentDoc) {
        window.localStorage.removeItem(getReviewActiveJobStorageKey("word.document_review", currentDoc));
      }
      for (var i = window.localStorage.length - 1; i >= 0; i -= 1) {
        var k = window.localStorage.key(i);
        if (k && k.indexOf("ai-wps:review-active-job:word.document_review:") === 0) {
          var val = window.localStorage.getItem(k);
          if (val) {
            try {
              var parsed = JSON.parse(val);
              if (!jobId || (parsed && parsed.jobId === jobId)) {
                window.localStorage.removeItem(k);
              }
            } catch (e) {}
          }
        }
      }
      active = loadDocumentReviewActiveJob(currentDoc);
      if (!jobId || (active && active.jobId === jobId)) {
        window.localStorage.removeItem(DOCUMENT_REVIEW_ACTIVE_JOB_STORAGE_KEY);
      }
    } catch (error) {
      // Ignore storage cleanup failures; they should not block task-pane rendering.
    }
  }

  function loadFullDocumentReviewActiveJob(docSessionId) {
    var raw;
    try {
      if (!window.localStorage) {
        return null;
      }
      var currentDoc = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
      if (currentDoc) {
        raw = window.localStorage.getItem(getReviewActiveJobStorageKey("word.document_review.full", currentDoc));
        if (raw) {
          return JSON.parse(raw);
        }
      }
      raw = window.localStorage.getItem(FULL_DOCUMENT_REVIEW_ACTIVE_JOB_STORAGE_KEY);
      if (raw) {
        var legacy = JSON.parse(raw);
        if (!currentDoc || !legacy.documentSessionId || legacy.documentSessionId === currentDoc) {
          return legacy;
        }
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  function saveFullDocumentReviewActiveJob(jobId, docSessionId) {
    if (!jobId) {
      return;
    }
    var currentDoc = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
    try {
      if (window.localStorage) {
        var record = JSON.stringify({
          jobId: jobId,
          host: "wps",
          taskType: "word.document_review.full",
          documentSessionId: currentDoc || "",
          startedAt: Date.now(),
          frontendVersion: FRONTEND_BUILD_VERSION
        });
        window.localStorage.setItem(getReviewActiveJobStorageKey("word.document_review.full", currentDoc), record);
        window.localStorage.setItem(FULL_DOCUMENT_REVIEW_ACTIVE_JOB_STORAGE_KEY, record);
      }
    } catch (error) {
      // Storage may be unavailable; in-memory polling remains active.
    }
  }

  function clearFullDocumentReviewActiveJob(jobId, docSessionId) {
    var active;
    try {
      if (!window.localStorage) {
        return;
      }
      var currentDoc = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
      if (currentDoc) {
        window.localStorage.removeItem(getReviewActiveJobStorageKey("word.document_review.full", currentDoc));
      }
      for (var i = window.localStorage.length - 1; i >= 0; i -= 1) {
        var k = window.localStorage.key(i);
        if (k && k.indexOf("ai-wps:review-active-job:word.document_review.full:") === 0) {
          var val = window.localStorage.getItem(k);
          if (val) {
            try {
              var parsed = JSON.parse(val);
              if (!jobId || (parsed && parsed.jobId === jobId)) {
                window.localStorage.removeItem(k);
              }
            } catch (e) {}
          }
        }
      }
      active = loadFullDocumentReviewActiveJob(currentDoc);
      if (!jobId || (active && active.jobId === jobId)) {
        window.localStorage.removeItem(FULL_DOCUMENT_REVIEW_ACTIVE_JOB_STORAGE_KEY);
      }
    } catch (error) {
      // Storage cleanup must not block report rendering.
    }
  }

  function cleanupDocumentReviewTerminal(submittedDocSession, jobId) {
    var targetDocSession = submittedDocSession || state.documentSessionId || "default";
    releaseTaskSlotsForJob(jobId);
    if (helpers.releaseTaskSlot) {
      helpers.releaseTaskSlot(state.activeTaskSlots, "wps", "word.document_review", targetDocSession, jobId);
    }
    clearDocumentReviewActiveJob(jobId, targetDocSession);
    setActiveReviewJobRecord("word.document_review", targetDocSession, null);
    if (!jobId || jobId === state.documentReviewJobId) {
      setDocumentReviewJobId("");
      state.documentReviewPollStartedAt = 0;
      state.documentReviewPollErrorCount = 0;
      stopDocumentReviewWaitFeedback();
      setModelTaskBusy(false);
      setDocumentReviewCancelVisible(false, false);
    }
  }

  function cleanupFullDocumentReviewTerminal(submittedDocSession, jobId) {
    var targetDocSession = submittedDocSession || state.documentSessionId || "default";
    releaseTaskSlotsForJob(jobId);
    if (helpers.releaseTaskSlot) {
      helpers.releaseTaskSlot(state.activeTaskSlots, "wps", "word.document_review.full", targetDocSession, jobId);
    }
    clearFullDocumentReviewActiveJob(jobId, targetDocSession);
    setActiveReviewJobRecord("word.document_review.full", targetDocSession, null);
    if (!jobId || state.fullDocumentReviewJobId === jobId) {
      state.fullDocumentReviewJobId = "";
      state.fullDocumentReviewPollErrorCount = 0;
      state.fullDocumentReviewPreparing = false;
      state.fullDocumentReviewCancelRequested = false;
      setModelTaskBusy(false);
      setDocumentReviewCancelVisible(false, false);
    }
  }

  function cleanupDeterministicFormatReviewTerminal(submittedDocSession, jobId) {
    var targetDocSession = submittedDocSession || state.documentSessionId || "default";
    releaseTaskSlotsForJob(jobId);
    if (helpers.releaseTaskSlot) {
      helpers.releaseTaskSlot(state.activeTaskSlots, "wps", "word.format_review", targetDocSession, jobId);
    }
    clearDeterministicFormatReviewActiveJob(jobId, targetDocSession);
    setActiveReviewJobRecord("word.format_review", targetDocSession, null);
    if (!jobId || state.deterministicFormatReviewJobId === jobId) {
      state.deterministicFormatReviewJobId = "";
      state.deterministicFormatReviewPollStartedAt = 0;
      state.deterministicFormatReviewPollErrorCount = 0;
      state.deterministicFormatReviewSnapshot = null;
      setModelTaskBusy(false);
      setDocumentReviewCancelVisible(false, false);
    }
  }

  function restoreActiveReviewResult() {
    state.viewingHistoryReport = null;
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    if (state.currentMode === "formatReview") {
      var activeFmtRec = getActiveResultRecord("word.format_review", currentDoc);
      if (activeFmtRec && activeFmtRec.result) {
        var fmtRes = activeFmtRec.result;
        var fmtReport = fmtRes.report || fmtRes;
        var fmtJobId = fmtRes.reportId || fmtRes.jobId || activeFmtRec.jobId || activeFmtRec.traceId;
        state.deterministicFormatReviewReport = fmtReport;
        state.deterministicFormatReviewIssueJobId = fmtJobId;
        renderDeterministicFormatReviewReport(fmtReport, fmtJobId);
        setStatus("已恢复当前格式审查结果。");
      } else {
        clearDeterministicFormatReviewPresentation();
        setPlainResult("等待运行。");
        setStatus("等待操作。");
      }
      return;
    }
    var controls = byId("full-document-review-issue-controls");
    if (controls) {
      controls.hidden = true;
    }
    var activeRec = getActiveResultRecord("word.document_review", currentDoc);
    if (activeRec && activeRec.result) {
      var res = activeRec.result;
      if (res.reportType === "full_document_review" || res.report) {
        renderFullDocumentReviewReport(res.report || res, res.reportId || activeRec.traceId);
      } else {
        renderDocumentReviewResult(res);
      }
      setStatus("已恢复当前文档审查结果。");
    } else {
      renderFullDocumentReviewEntry();
      setPlainResult("等待运行。");
      setStatus("等待操作。");
    }
  }

  function setProviderLine(providerName) {
    var providerText = {
      "enterprise-chat-api": "企业接口",
      "enterprise-dify-chat": "模型接口",
      "enterprise-dify-workflow": "工作流平台",
      mock: "模拟接口"
    };
    var detail = providerText[providerName] || providerName || "未检测";
    state.providerName = detail;
    setNodeTextIfChanged(byId("provider-line"), "接口：" + detail);
    setNodeTextIfChanged(byId("settings-provider-line"), "接口：" + detail);
    setNodeTextIfChanged(byId("provider-summary-type"), detail);
  }

  function setProviderName(name) {
    state.providerName = name || "未检测";
  }

  function setProviderBaseUrl(baseUrl) {
    var summary = byId("provider-summary-url");
    state.providerBaseUrl = baseUrl || "";
    setNodeTextIfChanged(summary, state.providerBaseUrl || "未配置接口地址");
    setNodeAttributeIfChanged(summary, "title", state.providerBaseUrl || "未配置接口地址");
    if (!state.providerUrlEditorOpen && byId("provider-base-url").value !== state.providerBaseUrl) {
      byId("provider-base-url").value = state.providerBaseUrl;
    }
  }

  function setProviderAuthLine(authSource) {
    state.providerAuthSource = authSource || "none";
  }

  function applyProviderConfig(configData) {
    setProviderName(configData.providerName || "企业大模型接口");
    setProviderBaseUrl(configData.providerBaseUrl || "");
    setProviderAuthLine(configData.providerAuthSource || "none");
    state.taskApiKeys = configData.taskApiKeys || {};
    state.fullDocumentReviewEnabled = Boolean(
      configData.features && configData.features.fullDocumentReviewEnabled
    );
    state.deterministicFormatReviewEnabled = Boolean(
      configData.features && configData.features.deterministicFormatReviewEnabled
    );
    state.directStreamingEnabled = Boolean(
      configData.features && configData.features.directStreamingEnabled
    );
    renderWorkflowProfileManager();
    renderWorkflowProfileStrip();
    renderFullDocumentReviewEntry();
    if (
      state.fullDocumentReviewEnabled &&
      state.currentMode === "documentReview" &&
      !state.fullDocumentReviewJobId
    ) {
      resumeFullDocumentReviewActiveJob();
    }
    if (
      state.deterministicFormatReviewEnabled &&
      state.currentMode === "formatReview" &&
      !state.deterministicFormatReviewJobId
    ) {
      resumeDeterministicFormatReviewActiveJob();
    }
  }

  function getFullDocumentReviewReadiness() {
    var data = getWorkflowProfileData("word.document_review");
    if (data && data.activeProfileId && String(data.activeProfileId).startsWith("direct_svc_")) {
      var selection = data.taskModelSelection || (state.taskModelSelections && state.taskModelSelections["word.document_review"]);
      if (!selection || !selection.serviceId) {
        return { fullDocumentReviewReady: false, label: "请先配置并保存文档审查直连服务。" };
      }
      var readiness = selection.fullDocumentReviewReadiness;
      var ready = Boolean(selection.fullDocumentReviewReady);
      return {
        fullDocumentReviewReady: ready,
        label: (readiness && readiness.label) || (ready ? "限量审查与全篇审查均可用。" : "当前配置尚未满足全篇审查要求。")
      };
    }
    var active = (data && data.profiles ? data.profiles : []).filter(function (profile) {
      return profile.id === (data && data.activeProfileId);
    })[0];
    if (!active) {
      return { fullDocumentReviewReady: false, label: "请先启用文档审查模型配置。" };
    }
    return {
      fullDocumentReviewReady: Boolean(active.fullDocumentReviewReady),
      label: active.fullDocumentReviewReadiness && active.fullDocumentReviewReadiness.label ||
        "当前配置尚未满足全篇审查要求。"
    };
  }

  function renderFullDocumentReviewEntry() {
    var entry = byId("full-document-review-entry");
    var button = byId("btn-run-full-document-review");
    var readinessNode = byId("full-document-review-readiness");
    var readiness;
    if (!entry || !button || !readinessNode) {
      return;
    }
    entry.hidden = !state.fullDocumentReviewEnabled;
    if (!state.fullDocumentReviewEnabled) {
      return;
    }
    readiness = getFullDocumentReviewReadiness();
    readinessNode.textContent = readiness.label;
    button.disabled = !readiness.fullDocumentReviewReady ||
      Boolean(state.fullDocumentReviewJobId || state.documentReviewJobId);
  }

  function renderModelInterfaceState(detectable) {
    var taskTypes = TASK_API_KEY_DEFS.map(function (item) {
      return item.taskType;
    });
    var profilesByTask = {};
    var modelState;
    var badge = byId("provider-readiness-badge");
    var summary = byId("provider-summary-url");
    taskTypes.forEach(function (taskType) {
      profilesByTask[taskType] = getWorkflowProfileData(taskType);
    });
    modelState = helpers.deriveModelInterfaceState({
      detectable: detectable,
      providerBaseUrl: state.providerBaseUrl,
      taskTypes: taskTypes,
      profilesByTask: profilesByTask
    });
    setNodeClassNameIfChanged(badge, "readiness-badge is-" + modelState.code);
    setNodeTextIfChanged(badge, modelState.label);
    setNodeTextIfChanged(summary, state.providerBaseUrl || "未配置接口地址");
    setNodeAttributeIfChanged(summary, "title", state.providerBaseUrl || "未配置接口地址");
    setNodeTextIfChanged(byId("diagnostics-summary"), modelState.label);
  }

  function setAdapterUnavailableState(error) {
    var message = error && error.message ? error.message : "端口未监听";
    setHealthBadge("badge-warn", "待启动");
    setTrace("");
    setProviderLine("mock");
    setProviderName("本地 mock");
    setStatus("本地适配服务暂不可用。");
    setResult([
      "本地适配服务暂不可用，插件无法访问 http://127.0.0.1:18100。",
      "请确认已执行 adapter 一键启动脚本，并用健康检查确认 /health 可访问。",
      "这不是大模型接口故障；adapter 启动后，未配置企业密钥时会继续使用 mock 模型。",
      "后台返回：" + message
    ].join("\n"));
  }

  function setScopeLine(label) {
    var text = label || "识别范围：未检测";
    text = text.replace(/^当前范围：/, "").replace(/^识别范围：/, "");
    setNodeTextIfChanged(byId("scope-line"), text);
    setNodeTextIfChanged(byId("settings-scope-line"), text);
  }

  function setHealthBadge(mode, text) {
    var node = byId("health-indicator");
    setNodeClassNameIfChanged(node, "badge " + mode);
    setNodeTextIfChanged(node, text);
  }

  function applyAdapterHealthState(data, connected) {
    var healthState = helpers.normalizeAdapterHealth(data, connected);
    state.adapterHealthStatus = healthState.status;
    state.configurationMutationsAllowed = healthState.configurationMutationsAllowed;
    state.modelTasksAllowed = healthState.modelTasksAllowed;
    state.writingPolicyMutationsAllowed = healthState.writingPolicyMutationsAllowed;
    setHealthBadge(healthState.badgeClass, healthState.badgeLabel);
    if (typeof renderRecoveryActions === "function") {
      renderRecoveryActions(data || {}, healthState.status === "recovery");
    }
    if (healthState.status === "recovery") {
      state.modelInterfaceDetectable = false;
      renderModelInterfaceState(false);
      setSettingsStatus(healthState.summary);
    }
    return healthState;
  }

  function renderRecoveryActions(data, visible) {
    var card = byId("recovery-actions-card");
    var subsystemLine = byId("recovery-subsystem-status");
    var backupLine = byId("recovery-backup-status");
    var subsystems = data && data.subsystems || {};
    var labels = {
      modelConfigurations: "模型配置",
      taskRoutes: "任务路由",
      writingPolicies: "写作规范"
    };
    var failures = Object.keys(labels).filter(function (name) {
      return subsystems[name] && subsystems[name].status !== "ready";
    }).map(function (name) {
      var item = subsystems[name];
      return labels[name] + "（" + (item.stage || item.errorCode || "状态异常") + "）";
    });
    var backup = data && data.backupStatus || {};
    if (!card) {
      return;
    }
    card.hidden = !visible;
    if (!visible) {
      return;
    }
    setNodeTextIfChanged(
      subsystemLine,
      failures.length ? "故障子系统：" + failures.join("、") : "核心运行数据需要恢复。"
    );
    setNodeTextIfChanged(
      backupLine,
      backup.latestValid && backup.latestValid.snapshotId
        ? "最近有效备份：" + backup.latestValid.snapshotId
        : (backup.latestVerified && backup.latestVerified.snapshotId
          ? "无有效备份；最近只读备份不可恢复：" + backup.latestVerified.snapshotId
          : "尚无有效备份")
    );
  }

  function createRecoveryBackup() {
    var button = byId("btn-recovery-backup");
    button.disabled = true;
    setSettingsStatus("正在创建只读整体备份...");
    return request("/recovery/backups", {}).then(function (response) {
      var data = response.data || {};
      renderRecoveryActions({
        status: "recovery",
        subsystems: {},
        backupStatus: data.backupStatus || {}
      }, true);
      setSettingsStatus("只读备份已创建：" + (data.snapshotId || "已完成"));
    }).catch(function (error) {
      setSettingsStatus(error && error.message || "只读备份创建失败，请重试。");
    }).then(function () {
      button.removeAttribute("disabled");
    });
  }

  function exportRecoveryDiagnostics() {
    setSettingsStatus("正在生成脱敏诊断...");
    return request("/recovery/diagnostics", null).then(function (response) {
      var text = JSON.stringify(response.data || {}, null, 2);
      var blob = new Blob([text], { type: "application/json;charset=utf-8" });
      var objectUrl = URL.createObjectURL(blob);
      var link = document.createElement("a");
      link.href = objectUrl;
      link.download = "ai-wps-recovery-diagnostics.json";
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(objectUrl);
      setSettingsStatus("脱敏诊断已导出。");
    }).catch(function (error) {
      setSettingsStatus(error && error.message || "脱敏诊断导出失败，请重试。");
    });
  }

  function setResult(text, copyText) {
    var output = byId("result-output");
    output.hidden = false;
    output.classList.remove("plain-output");
    output.classList.remove("streaming-preview-wait");
    if (helpers.renderMarkdown) {
      output.innerHTML = helpers.renderMarkdown(text);
    } else {
      output.textContent = text;
    }
    state.copyText = typeof copyText === "string" ? copyText : (text || "");
  }

  function setPlainResult(text, copyText) {
    var output = byId("result-output");
    output.hidden = false;
    output.classList.add("plain-output");
    output.classList.remove("streaming-preview-wait");
    output.textContent = text || "";
    state.copyText = typeof copyText === "string" ? copyText : (text || "");
  }

  function setRewriteResult(result) {
    setPlainResult(result.rewrittenText || "");
  }

  function clearWritingPolicyUsage() {
    var strip = byId("writing-policy-usage-strip");
    var summary = byId("writing-policy-usage-summary");
    var details = byId("writing-policy-usage-details");
    var list = byId("writing-policy-usage-list");
    if (summary) {
      summary.textContent = "";
    }
    if (list) {
      list.textContent = "";
    }
    if (details) {
      details.hidden = true;
      details.open = false;
    }
    if (strip) {
      strip.hidden = true;
    }
    clearWritingPolicyAudit();
  }

  function clearWritingPolicyAudit() {
    var summary = byId("writing-policy-audit-summary");
    var details = byId("writing-policy-audit-details");
    var needsReview = byId("writing-policy-needs-review");
    var suggestions = byId("writing-policy-expression-suggestions");
    var needsReviewList = byId("writing-policy-needs-review-list");
    var suggestionList = byId("writing-policy-expression-suggestions-list");
    if (summary) {
      summary.textContent = "";
    }
    if (needsReviewList) {
      needsReviewList.textContent = "";
    }
    if (suggestionList) {
      suggestionList.textContent = "";
    }
    if (needsReview) {
      needsReview.hidden = true;
    }
    if (suggestions) {
      suggestions.hidden = true;
    }
    if (details) {
      details.hidden = true;
      details.open = false;
    }
  }

  function appendWritingPolicyAuditFindings(list, findings) {
    findings.forEach(function (finding) {
      var row = document.createElement("li");
      row.textContent = helpers.writingPolicyAuditFindingText
        ? helpers.writingPolicyAuditFindingText(finding)
        : String(finding && finding.message || "");
      list.appendChild(row);
    });
  }

  function renderWritingPolicyAudit(value) {
    var strip = byId("writing-policy-usage-strip");
    var summary = byId("writing-policy-audit-summary");
    var details = byId("writing-policy-audit-details");
    var needsReview = byId("writing-policy-needs-review");
    var suggestions = byId("writing-policy-expression-suggestions");
    var needsReviewList = byId("writing-policy-needs-review-list");
    var suggestionList = byId("writing-policy-expression-suggestions-list");
    var audit = helpers.normalizeWritingPolicyAudit
      ? helpers.normalizeWritingPolicyAudit(value)
      : null;

    clearWritingPolicyAudit();
    if (!audit || !summary || !details || !needsReview || !suggestions ||
        !needsReviewList || !suggestionList) {
      return;
    }
    summary.textContent = audit.summary || (
      audit.passed ? "已完成写作规范检查" : "写作规范检查已完成"
    );
    appendWritingPolicyAuditFindings(needsReviewList, audit.needsReview);
    appendWritingPolicyAuditFindings(suggestionList, audit.expressionSuggestions);
    needsReview.hidden = audit.needsReview.length === 0;
    suggestions.hidden = audit.expressionSuggestions.length === 0;
    details.hidden = audit.needsReview.length === 0 &&
      audit.expressionSuggestions.length === 0;
    if (!needsReview.hidden) {
      needsReview.setAttribute("aria-label", "需要核对");
    }
    if (!suggestions.hidden) {
      suggestions.setAttribute("aria-label", "表达建议");
    }
    if (strip) {
      strip.hidden = false;
    }
  }

  function renderWritingPolicyUsage(value, taskType) {
    var strip = byId("writing-policy-usage-strip");
    var summary = byId("writing-policy-usage-summary");
    var details = byId("writing-policy-usage-details");
    var list = byId("writing-policy-usage-list");
    var usage = helpers.normalizeWritingPolicyUsage
      ? helpers.normalizeWritingPolicyUsage(value)
      : null;
    var summaryText;
    var detailItems;

    clearWritingPolicyUsage();
    if (!usage || !strip || !summary || !details || !list) {
      return;
    }
    summaryText = helpers.writingPolicyUsageSummary
      ? helpers.writingPolicyUsageSummary(usage, taskType)
      : "";
    detailItems = helpers.writingPolicyUsageDetails
      ? helpers.writingPolicyUsageDetails(usage)
      : [];
    summary.textContent = summaryText;
    detailItems.forEach(function (item) {
      var row = document.createElement("li");
      row.textContent = item;
      list.appendChild(row);
    });
    details.hidden = detailItems.length === 0;
    strip.hidden = false;
  }

  function setResultViewSwitchVisible(visible) {
    var node = byId("result-view-switch");
    if (node) {
      node.hidden = !visible;
    }
  }

  function updateResultViewButtons() {
    [
      { id: "btn-result-preview", mode: "preview" },
      { id: "btn-result-compare", mode: "compare" },
      { id: "btn-result-plain", mode: "plain" }
    ].forEach(function (item) {
      var button = byId(item.id);
      var active = state.resultViewMode === item.mode;
      if (button) {
        button.classList.toggle("active", active);
        button.setAttribute("aria-pressed", active ? "true" : "false");
      }
    });
  }

  function resetSmartWritePreviewState() {
    state.smartWritePreviewModel = null;
    state.resultViewMode = "preview";
    clearWritingPolicyUsage();
    setResultViewSwitchVisible(false);
    updateResultViewButtons();
  }

  function hideCompareForSmartImitation() {
    var compareButton = byId("btn-result-compare");
    if (!compareButton) {
      return;
    }
    if (state.currentMode !== "smartImitation") {
      compareButton.hidden = false;
      return;
    }
    compareButton.hidden = true;
    if (state.resultViewMode === "compare") {
      setResultViewMode("preview");
    }
  }

  function setReviewRecordActionsVisible(visible) {
    var node = byId("review-record-actions");
    var previewButton = byId("btn-preview-review-record");
    if (node) {
      node.hidden = !visible;
    }
    if (previewButton) {
      previewButton.textContent = state.documentReviewRecordPreviewVisible ? "返回审查结果" : "预览审查记录";
    }
  }

  function setDocumentReviewJobId(jobId) {
    state.documentReviewJobId = jobId || "";
    setModelTaskBusy(Boolean(state.documentReviewJobId));
    if (!state.documentReviewJobId) {
      setDocumentReviewCancelVisible(false);
    }
    renderWorkflowProfileStrip();
  }

  function setDocumentReviewCancelVisible(visible, disabled, text) {
    var button = byId("btn-cancel-document-review-job");
    if (!button) {
      return;
    }
    button.hidden = !visible;
    button.disabled = Boolean(disabled);
    if (typeof text === "string" && text.length > 0) {
      button.textContent = text;
    }
  }

  function setInterruptedRetryVisible(visible) {
    var button = byId("btn-resubmit-interrupted-job");
    if (button) {
      button.hidden = !visible;
    }
  }

  function resetDocumentReviewState() {
    stopDocumentReviewWaitFeedback();
    state.documentReviewData = null;
    state.documentReviewIssueStatus = {};
    state.documentReviewRecordPreviewVisible = false;
    clearWritingPolicyUsage();
    setDocumentReviewJobId("");
    state.documentReviewPollStartedAt = 0;
    state.documentReviewPollErrorCount = 0;
    setReviewRecordActionsVisible(false);
  }

  function stopDocumentReviewWaitFeedback(fallback) {
    var stopWaiting = state.documentReviewStopWaiting || fallback;
    state.documentReviewStopWaiting = null;
    if (typeof stopWaiting === "function") {
      stopWaiting();
    }
  }

  function renderSmartWritePreviewMode() {
    var model = state.smartWritePreviewModel || {};
    var copyText = state.rewriteResult && state.rewriteResult.rewrittenText
      ? state.rewriteResult.rewrittenText
      : (model.plainText || "");
    var presented;

    updateResultViewButtons();
    if (helpers.presentWordResultView) {
      presented = helpers.presentWordResultView({
        originalText: model.originalText || getLatestOriginalText(),
        rewrittenText: copyText,
        view: state.resultViewMode,
        rewriteMode: state.currentMode === "smartImitation" ? "imitate" : "rewrite"
      });
      if (presented.presentation === "source") {
        setPlainResult(presented.sourceText || "", presented.copyText);
      } else {
        setResult(presented.displayMarkdown || "", presented.copyText);
      }
      return;
    }
    if (state.resultViewMode === "plain") {
      setPlainResult(model.plainText || "", copyText);
      return;
    }
    if (state.resultViewMode === "compare") {
      setResult(model.comparisonMarkdown || model.previewMarkdown || "", copyText);
      return;
    }
    setResult(model.previewMarkdown || "", copyText);
  }

  function setResultViewMode(mode) {
    if (!state.smartWritePreviewModel) {
      return;
    }
    state.resultViewMode = state.currentMode === "smartImitation" && mode === "compare" ? "preview" : mode;
    renderSmartWritePreviewMode();
  }

  function getLatestOriginalText() {
    return state.latestDocumentPayload &&
      state.latestDocumentPayload.content &&
      state.latestDocumentPayload.content.plainText
      ? state.latestDocumentPayload.content.plainText
      : "";
  }

  function shouldUseStructuredSmartWriteResult(text) {
    if (helpers.shouldUseStructuredSmartWriteResult) {
      return helpers.shouldUseStructuredSmartWriteResult(getLatestOriginalText(), text);
    }
    if (helpers.hasStructuredSmartWriteContent) {
      return helpers.hasStructuredSmartWriteContent(getLatestOriginalText()) ||
        helpers.hasStructuredSmartWriteContent(text);
    }
    return false;
  }

  function normalizeSmartWriteResult(result) {
    var source = result || {};
    var normalized = {};
    var key;
    var text = source && source.rewrittenText ? source.rewrittenText : "";
    var formattedText = helpers.formatSmartWriteResult
      ? helpers.formatSmartWriteResult(getLatestOriginalText(), text)
      : text;

    for (key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        normalized[key] = source[key];
      }
    }
    normalized.rewrittenText = formattedText;
    return normalized;
  }

  function setSmartWriteResult(result, taskType) {
    var normalized = normalizeSmartWriteResult(result);
    var text = normalized.rewrittenText || "";
    var previewSource = {};
    var key;
    for (key in normalized) {
      if (Object.prototype.hasOwnProperty.call(normalized, key)) {
        previewSource[key] = normalized[key];
      }
    }
    previewSource.originalText = previewSource.originalText || getLatestOriginalText();
    state.smartWritePreviewModel = helpers.buildSmartWritePreviewModel
      ? helpers.buildSmartWritePreviewModel(previewSource)
      : {
        previewMarkdown: text,
        plainText: text,
        comparisonMarkdown: text,
        hasOriginal: Boolean(previewSource.originalText),
        hasStructuredResult: shouldUseStructuredSmartWriteResult(text)
      };
    state.resultViewMode = "preview";
    setResultViewSwitchVisible(Boolean(text));
    renderSmartWritePreviewMode();
    state.writingPolicyAudit = normalized.writingPolicyAudit || null;
    renderWritingPolicyUsage(normalized.writingPolicyUsage, taskType);
    renderWritingPolicyAudit(state.writingPolicyAudit);
    return normalized;
  }

  function setApplyEnabled(enabled) {
    byId("btn-apply").disabled = !enabled;
  }

  function getRewritePromptFragments() {
    return {
      style: REWRITE_STYLE_PROMPTS[state.rewriteStyle] || REWRITE_STYLE_PROMPTS.standard,
      focus: REWRITE_FOCUS_PROMPTS[state.focusPoint] || REWRITE_FOCUS_PROMPTS.complete,
      length: REWRITE_LENGTH_PROMPTS[state.lengthMode] || REWRITE_LENGTH_PROMPTS.same
    };
  }

  function getSelectedOptionText(selectId) {
    var select = byId(selectId);
    if (!select || !select.options || select.selectedIndex < 0) {
      return "";
    }
    return select.options[select.selectedIndex].text || "";
  }

  function updateRewritePromptPreview() {
    var fragments = getRewritePromptFragments();
    var config = modeConfig[state.currentMode] || modeConfig.smartWrite;
    var shouldShowPromptFragments = state.currentMode === "smartWrite" && config.showPromptFragments;
    byId("rewrite-prompt-label").textContent = "编写要求";
    byId("prompt-fragment-card").hidden = !shouldShowPromptFragments;
    byId("rewrite-summary-text").textContent = [
      getSelectedOptionText("rewrite-style") || "技术方案正式",
      getSelectedOptionText("focus-point") || "保持信息完整",
      getSelectedOptionText("length-mode") || "保持篇幅"
    ].join(" / ");
    byId("rewrite-style-detail").textContent = fragments.style;
    byId("rewrite-focus-detail").textContent = fragments.focus;
    byId("rewrite-length-detail").textContent = fragments.length;
    byId("rewrite-output-detail").textContent = REWRITE_OUTPUT_PROMPT;
    byId("selected-style-prompt").textContent = fragments.style;
    byId("selected-focus-prompt").textContent = fragments.focus;
    byId("selected-length-prompt").textContent = fragments.length;
    byId("selected-output-prompt").textContent = REWRITE_OUTPUT_PROMPT;
  }

  function switchView(viewName) {
    byId("home-view").classList.toggle("active", viewName === "home");
    byId("settings-view").classList.toggle("active", viewName === "settings");
    syncSettingsRefreshController();
    syncScopeWatcher();
  }

  function syncSettingsRefreshController() {
    var settingsView = byId("settings-view");
    var shouldRun;
    if (!state.settingsRefreshController) {
      return;
    }
    shouldRun = Boolean(
      settingsView &&
      byId("settings-view").classList.contains("active") &&
      document.visibilityState !== "hidden" &&
      state.writingPolicyView === "home" &&
      !state.workflowProfileEditor &&
      !state.providerUrlEditorOpen &&
      !state.workflowProfileMutationBusy
    );
    if (shouldRun) {
      state.settingsRefreshController.start();
    } else if (state.settingsRefreshController.isRunning()) {
      state.settingsRefreshController.stop();
      invalidateConfigRefresh();
    }
  }

  function isSettingsRefreshEligible() {
    var settingsView = byId("settings-view");
    return Boolean(
      settingsView &&
      settingsView.classList.contains("active") &&
      document.visibilityState !== "hidden" &&
      state.writingPolicyView === "home" &&
      !state.workflowProfileEditor &&
      !state.providerUrlEditorOpen &&
      !state.workflowProfileMutationBusy
    );
  }

  function invalidateConfigRefresh() {
    state.configRefreshRequestId += 1;
    state.configRefreshQueued = false;
    state.configRefreshQueuedSilent = true;
  }

  function toggleSettingsShortcut() {
    var settingsOpen = byId("settings-view").classList.contains("active");
    var returnMode = state.lastTaskMode || "smartWrite";
    var returnConfig;

    if (!settingsOpen) {
      if (state.currentMode !== "settings") {
        state.lastTaskMode = state.currentMode;
        returnMode = state.currentMode;
      }
      if (!state.workflowProfileEditor && MODE_WORKFLOW_TASK_TYPES[returnMode]) {
        state.settingsWorkflowTaskType = MODE_WORKFLOW_TASK_TYPES[returnMode];
        renderWorkflowProfileManager();
      }
      returnConfig = modeConfig[returnMode] || modeConfig.smartWrite;
      switchView("settings");
      document.body.setAttribute("data-task-mode", "settings");
      byId("task-title").textContent = "设置";
      byId("btn-open-settings").classList.add("is-back");
      byId("btn-open-settings").setAttribute("title", "返回" + returnConfig.title);
      byId("btn-open-settings").setAttribute("aria-label", "返回" + returnConfig.title);
      setWritingPolicyView("home");
      loadWritingPolicySummary();
      return;
    }

    if (state.writingPolicyMutationBusy) {
      setStatus("写作规范条目正在保存，请稍候。");
      return;
    }
    if (!confirmWorkflowEditorDiscard() || !confirmWritingPolicyEditorDiscard()) {
      return;
    }
    state.workflowProfileEditor = null;
    clearWritingPolicyEditorState();
    setWritingPolicyView("home", true);

    if (state.currentMode === "settings") {
      switchMode(returnMode);
      return;
    }

    returnConfig = modeConfig[state.currentMode] || modeConfig.smartWrite;
    switchView("home");
    document.body.setAttribute("data-task-mode", state.currentMode);
    byId("task-title").textContent = returnConfig.title;
    byId("btn-open-settings").classList.remove("is-back");
    byId("btn-open-settings").setAttribute("title", "打开设置");
    byId("btn-open-settings").setAttribute("aria-label", "打开设置");
  }

  function switchMode(mode) {
    var requestedMode = modeConfig[mode] ? mode : "smartWrite";
    var config = modeConfig[requestedMode] || modeConfig.smartWrite;
    var settingsMode = requestedMode === "settings";
    var writingMode = requestedMode === "smartWrite" || requestedMode === "smartImitation";
    var writingPolicyMode;
    var returnTitle;

    setInterruptedRetryVisible(false);
    state.currentMode = requestedMode;
    if (!settingsMode) {
      state.lastTaskMode = requestedMode;
    }
    returnTitle = (modeConfig[state.lastTaskMode] || modeConfig.smartWrite).title;
    document.body.setAttribute("data-task-mode", state.currentMode);
    byId("task-title").textContent = config.title;
    byId("btn-open-settings").classList.toggle("is-back", settingsMode);
    byId("btn-open-settings").setAttribute("title", settingsMode ? "返回" + returnTitle : "打开设置");
    byId("btn-open-settings").setAttribute("aria-label", settingsMode ? "返回" + returnTitle : "打开设置");
    closeTaskModelConfigMenu(false);

    var btnViewHistory = byId("btn-view-history");
    var historySupported = writingMode || requestedMode === "documentReview" || requestedMode === "formatReview";
    if (btnViewHistory) {
      btnViewHistory.hidden = !historySupported;
    }
    if (!historySupported && state.historyOpen) {
      switchWordHistoryView(false);
    } else if (historySupported && state.historyOpen) {
      var currentWritingTask = getCurrentWorkflowTaskType();
      state.historyTaskType = currentWritingTask;
      loadAndRenderWritingHistory(currentWritingTask);
    }

    if (settingsMode) {
      switchView("settings");
      renderWorkflowProfileManager();
      renderDirectServicesList();
      renderTaskModelSelectionSection();
      setWritingPolicyView("home");
      loadWritingPolicySummary();
      return;
    }

    switchView("home");
    renderWorkflowProfileStrip();
    loadWorkflowProfiles(getCurrentWorkflowTaskType());
    byId("rewrite-options").hidden = !config.showRewriteOptions;
    byId("instruction-block").hidden = !config.showInstruction;
    byId("template-options").hidden = !config.showTemplate;
    byId("document-review-options").hidden = !config.showDocumentReviewOptions;
    byId("fixed-template-options").hidden = !config.showFixedTemplate;
    byId("smart-imitation-options").hidden = !config.showSmartImitationOptions;
    renderFullDocumentReviewEntry();
    writingPolicyMode = ["smartWrite", "smartImitation", "documentReview"].indexOf(state.currentMode) >= 0;
    byId("writing-policy-scene-block").hidden = !writingPolicyMode;
    if (writingPolicyMode) {
      restoreWritingPolicyScene();
    }
    byId("style-field-label").textContent = config.styleLabel || "表达风格";
    byId("btn-run-primary").textContent = config.primaryText;
    byId("btn-apply").hidden = state.currentMode !== "smartWrite";
    hideCompareForSmartImitation();
    updateRewritePromptPreview();

    if (writingMode) {
      var currentTaskType = getCurrentWorkflowTaskType();
      var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
      var activeJob = getActiveWritingJobRecord(currentTaskType, currentDoc);
      if (activeJob) {
        state.writingJobId = activeJob.jobId;
        state.writingJobTaskType = currentTaskType;
        state.writingJobMode = requestedMode;
        setModelTaskBusy(true);
        var previewKey = [currentTaskType, currentDoc, activeJob.jobId].join("::");
        var preview = state && state.writingJobPreviews && state.writingJobPreviews[previewKey];
        if (preview && preview.text) {
          renderWritingJobPreview(previewKey);
          setStatus(writingTaskLabel(currentTaskType) + "正在生成内容...");
        }
      } else {
        state.writingJobId = "";
        state.writingJobTaskType = "";
        state.writingJobMode = "";
        setModelTaskBusy(false);
        var activeRecord = getActiveResultRecord(currentTaskType, currentDoc);
        if (activeRecord) {
          var activeRes = activeRecord.result || activeRecord;
          if (activeRecord.documentPayload) {
            state.latestDocumentPayload = activeRecord.documentPayload;
            state.latestSelectionMode = activeRecord.documentPayload.selectionMode || state.latestSelectionMode;
          }
          state.rewriteResult = setSmartWriteResult(activeRes, currentTaskType);
          var canApply = state.currentMode === "smartWrite" &&
            !activeRecord.resumed &&
            activeRecord.pendingApplyAction === "rewrite" &&
            Boolean(activeRecord.documentPayload);
          state.pendingApplyAction = canApply ? "rewrite" : "";
          setApplyEnabled(canApply);
          setTrace(activeRecord.traceId || "");
        } else {
          resetSmartWritePreviewState();
          state.pendingApplyAction = "";
          setApplyEnabled(false);
          setPlainResult("等待运行。");
        }
      }
    } else if (state.currentMode === "documentReview") {
      var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
      var activeReviewJob = getActiveReviewJobRecord("word.document_review", currentDoc) || getActiveReviewJobRecord("word.document_review.full", currentDoc);
      if (activeReviewJob) {
        setDocumentReviewJobId(activeReviewJob.taskType === "word.document_review" ? activeReviewJob.jobId : "");
        state.fullDocumentReviewJobId = activeReviewJob.taskType === "word.document_review.full" ? activeReviewJob.jobId : "";
        setModelTaskBusy(true);
      } else {
        setDocumentReviewJobId("");
        state.fullDocumentReviewJobId = "";
        setModelTaskBusy(false);
        var activeRecord = getActiveResultRecord("word.document_review", currentDoc);
        if (activeRecord && activeRecord.result) {
          var res = activeRecord.result;
          setTrace(activeRecord.traceId || "");
          if (res.reportType === "full_document_review" || res.report) {
            renderFullDocumentReviewReport(res.report || res, res.reportId || activeRecord.traceId);
          } else {
            renderDocumentReviewResult(res);
          }
        } else {
          resetSmartWritePreviewState();
          resetDocumentReviewState();
          setPlainResult("等待运行。");
        }
      }
      state.pendingApplyAction = "";
      setApplyEnabled(false);
    } else if (state.currentMode === "formatReview") {
      var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
      var activeReviewJob = getActiveReviewJobRecord("word.format_review", currentDoc);
      if (activeReviewJob) {
        state.deterministicFormatReviewJobId = activeReviewJob.jobId;
        setModelTaskBusy(true);
      } else {
        var activeRecord = getActiveResultRecord("word.format_review", currentDoc);
        if (activeRecord && activeRecord.result) {
          var res = activeRecord.result;
          setTrace(activeRecord.traceId || activeRecord.jobId || "");
          var fmtReport = res.report || res;
          var fmtJobId = res.reportId || res.jobId || activeRecord.jobId || activeRecord.traceId;
          state.deterministicFormatReviewReport = fmtReport;
          state.deterministicFormatReviewIssueJobId = fmtJobId;
          renderDeterministicFormatReviewReport(fmtReport, fmtJobId);
        } else {
          clearDeterministicFormatReviewPresentation();
          setPlainResult("等待运行。");
        }
      }
      state.pendingApplyAction = "";
      setApplyEnabled(false);
    } else {
      resetSmartWritePreviewState();
      resetDocumentReviewState();
      state.pendingApplyAction = "";
      setApplyEnabled(false);
    }

    setStatus("等待操作。");
    if (state.currentMode === "smartImitation") {
      fillSmartImitationTemplateFromSelection();
    }
    if (state.currentMode === "documentReview") {
      if (!resumeFullDocumentReviewActiveJob()) {
        resumeDocumentReviewActiveJob();
      }
    } else if (state.currentMode === "formatReview") {
      resumeDeterministicFormatReviewActiveJob();
    } else if (writingMode) {
      resumeWritingActiveJob();
    }
  }

  function getHostApplication() {
    return window.Application || window.wps || {};
  }

  function callNoArgs(fn, thisArg) {
    if (typeof fn !== "function") {
      return null;
    }
    try {
      return fn.call(thisArg);
    } catch (error) {
      return null;
    }
  }

  function getActiveDocument() {
    var app = getHostApplication();
    var document = app.ActiveDocument || app.activeDocument || null;
    if (typeof document === "function") {
      document = callNoArgs(document, app);
    }
    return document || null;
  }

  function getDocumentName(document) {
    if (helpers.toSafeString) {
      return helpers.toSafeString(document && (document.Name || document.name), "unnamed.docx") || "unnamed.docx";
    }
    return (document && (document.Name || document.name)) || "unnamed.docx";
  }

  function getSelectionSources(document) {
    var app = getHostApplication();
    return [
      document && document.Selection,
      app && app.Selection,
      app && app.ActiveWindow && app.ActiveWindow.Selection,
      app && app.ActiveDocument && app.ActiveDocument.Selection
    ];
  }

  function getParagraphs(document) {
    if (helpers.getParagraphCollection) {
      return helpers.getParagraphCollection(document);
    }
    return (document && (document.Paragraphs || document.paragraphs)) || [];
  }

  function getSelectionText(document) {
    return helpers.getEffectiveSelectionText
      ? helpers.getEffectiveSelectionText(getSelectionSources(document))
      : "";
  }

  function fillSmartImitationTemplateFromSelection() {
    var document = getActiveDocument();
    var selectedText = "";
    if (!document || state.imitationTemplateText) {
      return;
    }
    try {
      selectedText = getSelectionText(document);
    } catch (error) {
      selectedText = "";
    }
    selectedText = String(selectedText || "").trim();
    if (selectedText) {
      state.imitationTemplateText = selectedText;
      byId("imitation-template-text").value = selectedText;
    }
  }

  function truncateText(text, maxLength) {
    var value = String(text || "");
    if (maxLength && value.length > maxLength) {
      return value.slice(0, maxLength);
    }
    return value;
  }

  function getWritableSelection(document) {
    return helpers.getWritableSelection
      ? helpers.getWritableSelection(getSelectionSources(document))
      : (document && document.Selection) || null;
  }

  function collectParagraphs(document, options) {
    if (helpers.collectParagraphs) {
      return helpers.collectParagraphs(document, options);
    }
    var paragraphs = getParagraphs(document);
    var items = [];
    var maxParagraphs = options && options.maxParagraphs ? Math.min(paragraphs.length, options.maxParagraphs) : paragraphs.length;
    for (var i = 0; i < maxParagraphs; i += 1) {
      var paragraph = paragraphs[i];
      var font = paragraph.Font || {};
      var paragraphFormat = paragraph.ParagraphFormat || {};
      items.push({
        index: i + 1,
        text: truncateText(paragraph.Text || paragraph.text || "", options && options.maxParagraphTextLength),
        styleName: paragraph.StyleNameLocal || paragraph.styleName || "Body",
        fontName: font.NameFarEast || font.Name || "",
        fontSize: font.Size || null,
        bold: Boolean(font.Bold),
        italic: Boolean(font.Italic),
        underline: font.Underline || null,
        alignment: String(paragraphFormat.Alignment || ""),
        outlineLevel: helpers.normalizeWpsOutlineLevel
          ? helpers.normalizeWpsOutlineLevel(paragraphFormat.OutlineLevel)
          : paragraphFormat.OutlineLevel,
        lineSpacing: paragraphFormat.LineSpacing || paragraphFormat.lineSpacing || null,
        lineSpacingMode: paragraphFormat.LineSpacingRule || paragraphFormat.lineSpacingRule || null,
        firstLineIndent: paragraphFormat.FirstLineIndent || paragraphFormat.firstLineIndent || null,
        spaceBefore: paragraphFormat.SpaceBefore || paragraphFormat.spaceBefore || null,
        spaceAfter: paragraphFormat.SpaceAfter || paragraphFormat.spaceAfter || null,
        leftIndent: paragraphFormat.LeftIndent || paragraphFormat.leftIndent || null,
        rightIndent: paragraphFormat.RightIndent || paragraphFormat.rightIndent || null
      });
    }
    return items;
  }

  function collectHeadings(paragraphs) {
    if (helpers.collectHeadingsFromParagraphs) {
      return helpers.collectHeadingsFromParagraphs(paragraphs);
    }
    return paragraphs.filter(function (item) {
      return item.outlineLevel >= 1 && item.outlineLevel <= 9;
    }).map(function (item) {
      return {
        level: item.outlineLevel,
        text: item.text || "",
        paragraphIndex: item.index
      };
    });
  }

  function collectPageSetup(document) {
    var setup = document && (document.PageSetup || document.pageSetup);
    if (!setup) {
      return {};
    }
    return {
      paperSize: setup.PaperSize || setup.paperSize || "",
      marginTop: setup.TopMargin || setup.marginTop || null,
      marginBottom: setup.BottomMargin || setup.marginBottom || null,
      marginLeft: setup.LeftMargin || setup.marginLeft || null,
      marginRight: setup.RightMargin || setup.marginRight || null
    };
  }

  function extractDocument(selectionMode, rewriteAction, extractionOptions) {
    var options = extractionOptions || {};
    var document = getActiveDocument();
    var selectionSources = [];
    if (!document) {
      throw new Error("未检测到活动文档。");
    }

    var selectedText = selectionMode === "selection" ? getSelectionText(document) : "";
    var paragraphs = [];
    var plainText = "";
    if (selectionMode === "selection") {
      selectionSources = getSelectionSources(document);
    }
    if (options.preferSelectionTextParagraphs && selectedText && helpers.collectParagraphsFromText) {
      plainText = selectedText;
      paragraphs = helpers.collectParagraphsFromSelectionSources
        ? helpers.collectParagraphsFromSelectionSources(selectionSources, selectedText, options)
        : helpers.collectParagraphsFromText(selectedText, options);
    } else if (selectionMode === "selection" && options.preferSelectionRangeParagraphs &&
        helpers.collectParagraphsFromSelectionSources) {
      paragraphs = helpers.collectParagraphsFromSelectionSources(selectionSources, selectedText, options);
      plainText = selectedText || paragraphs.map(function (item) { return item.text; }).join("\n");
    } else {
      paragraphs = collectParagraphs(document, options);
      if (!options.avoidFullTextRead && helpers.readDocumentText) {
        plainText = helpers.readDocumentText(document);
      }
      if (!plainText) {
        plainText = paragraphs.map(function (item) { return item.text; }).join("\n");
      }
    }
    if (selectionMode === "selection") {
      plainText = selectedText || plainText;
    }
    plainText = truncateText(plainText, options.maxPlainTextLength);

    var documentName = getDocumentName(document);
    var headings = collectHeadings(paragraphs);
    var documentStructure = helpers.buildDocumentStructure
      ? helpers.buildDocumentStructure({
        documentId: documentName,
        templateId: state.selectedTemplateId,
        selectionMode: selectionMode,
        plainText: plainText,
        pageSetup: collectPageSetup(document),
        paragraphs: paragraphs,
        headings: headings
      })
      : {};

    return {
      documentId: documentName,
      scene: "word",
      selectionMode: selectionMode,
      content: {
        plainText: plainText,
        paragraphs: paragraphs,
        headings: headings,
        documentStructure: documentStructure
      },
      options: {
        templateId: state.selectedTemplateId,
        trackChanges: true,
        userInstruction: state.userInstruction,
        rewriteStyle: state.rewriteStyle,
        focusPoint: state.focusPoint,
        lengthMode: state.lengthMode,
        rewriteAction: rewriteAction || "rewrite",
        technicalDocumentType: state.technicalDocumentType,
        technicalReviewPrompt: state.technicalReviewPrompt
      }
    };
  }

  function extractDocumentYielding(selectionMode, rewriteAction, extractionOptions, loopOptions) {
    var options = extractionOptions || {};
    var document = getActiveDocument();
    var selectionSources = [];
    if (!document) {
      return Promise.reject(new Error("未检测到活动文档。"));
    }
    var selectedText = selectionMode === "selection" ? getSelectionText(document) : "";
    var plainText = "";
    if (selectionMode === "selection") {
      selectionSources = getSelectionSources(document);
    }
    var collectPromise;
    if (options.preferSelectionTextParagraphs && selectedText && helpers.collectParagraphsFromText) {
      plainText = selectedText;
      collectPromise = helpers.collectParagraphsFromSelectionSourcesYielding
        ? helpers.collectParagraphsFromSelectionSourcesYielding(
          selectionSources, selectedText, options, loopOptions
        )
        : Promise.resolve(helpers.collectParagraphsFromSelectionSources
          ? helpers.collectParagraphsFromSelectionSources(selectionSources, selectedText, options)
          : helpers.collectParagraphsFromText(selectedText, options));
    } else if (selectionMode === "selection" && options.preferSelectionRangeParagraphs &&
        helpers.collectParagraphsFromSelectionSources) {
      collectPromise = (helpers.collectParagraphsFromSelectionSourcesYielding
        ? helpers.collectParagraphsFromSelectionSourcesYielding(
          selectionSources, selectedText, options, loopOptions
        )
        : Promise.resolve(helpers.collectParagraphsFromSelectionSources(
          selectionSources, selectedText, options
        ))).then(function (paras) {
        plainText = selectedText || paras.map(function (item) { return item.text; }).join("\n");
        return paras;
      });
    } else {
      collectPromise = (helpers.collectParagraphsYielding
        ? helpers.collectParagraphsYielding(document, options, loopOptions)
        : Promise.resolve(collectParagraphs(document, options))
      ).then(function (paras) {
        if (!options.avoidFullTextRead && helpers.readDocumentText) {
          plainText = helpers.readDocumentText(document);
        }
        if (!plainText) {
          plainText = paras.map(function (item) { return item.text; }).join("\n");
        }
        return paras;
      });
    }

    return collectPromise.then(function (paragraphs) {
      if (selectionMode === "selection") {
        plainText = selectedText || plainText;
      }
      plainText = truncateText(plainText, options.maxPlainTextLength);

      var documentName = getDocumentName(document);
      var headings = collectHeadings(paragraphs);
      var documentStructure = helpers.buildDocumentStructure
        ? helpers.buildDocumentStructure({
          documentId: documentName,
          templateId: state.selectedTemplateId,
          selectionMode: selectionMode,
          plainText: plainText,
          pageSetup: collectPageSetup(document),
          paragraphs: paragraphs,
          headings: headings
        })
        : {};

      return {
        documentId: documentName,
        scene: "word",
        selectionMode: selectionMode,
        content: {
          plainText: plainText,
          paragraphs: paragraphs,
          headings: headings,
          documentStructure: documentStructure
        },
        options: {
          templateId: state.selectedTemplateId,
          trackChanges: true,
          userInstruction: state.userInstruction,
          rewriteStyle: state.rewriteStyle,
          focusPoint: state.focusPoint,
          lengthMode: state.lengthMode,
          rewriteAction: rewriteAction || "rewrite",
          technicalDocumentType: state.technicalDocumentType,
          technicalReviewPrompt: state.technicalReviewPrompt
        }
      };
    });
  }

  function resolveSelectionScope(requireSelection) {
    var document = getActiveDocument();
    var selectionText = getSelectionText(document);
    var resolved = helpers.resolveRewriteScope
      ? helpers.resolveRewriteScope({
        selectionText: selectionText,
        requireSelection: requireSelection
      })
      : {
        ok: !!selectionText || !requireSelection,
        selectionMode: selectionText ? "selection" : "document",
        scopeLabel: selectionText ? "识别范围：选中文本" : "识别范围：全文",
        selectedText: selectionText,
        message: "请先用鼠标选中一段文字，再执行改写或续写。"
      };

    setScopeLine(resolved.scopeLabel);
    return resolved;
  }

  function updateScopeIndicator() {
    var document = getActiveDocument();
    if (!document) {
      setScopeLine("识别范围：未检测");
      return;
    }
    resolveSelectionScope(false);
  }

  function getWordSelectionEventSource() {
    var sources = [
      window.wps && window.wps.ApiEvent,
      window.Application && window.Application.ApiEvent
    ];
    var index;
    for (index = 0; index < sources.length; index += 1) {
      if (sources[index] && typeof sources[index].AddApiEventListener === "function") {
        return sources[index];
      }
    }
    return null;
  }

  function isScopeWatcherEligible() {
    var homeView = byId("home-view");
    return Boolean(
      homeView &&
      homeView.classList.contains("active") &&
      document.visibilityState !== "hidden" &&
      !state.modelTaskBusy
    );
  }

  function syncScopeWatcher() {
    if (!state.scopeWatcher) {
      return;
    }
    if (isScopeWatcherEligible()) {
      state.scopeWatcher.start();
    } else if (state.scopeWatcher.isRunning()) {
      state.scopeWatcher.stop();
    }
  }

  function setModelTaskBusy(busy) {
    var button = byId("btn-run-primary");
    state.modelTaskBusy = Boolean(busy);
    if (button) {
      button.disabled = state.modelTaskBusy;
      button.setAttribute("aria-busy", state.modelTaskBusy ? "true" : "false");
    }
    syncScopeWatcher();
  }

  function request(path, payload, requestOptions) {
    var timeoutMs = requestOptions && requestOptions.timeoutMs;
    var requestMethod = requestOptions && requestOptions.method;
    var controller = null;
    var timeoutId = null;
    var options = {
      method: requestMethod || (payload ? "POST" : "GET")
    };
    var normalizedMethod = String(options.method || "GET").toUpperCase();
    var mutating = ["POST", "PUT", "PATCH", "DELETE"].indexOf(normalizedMethod) >= 0;
    var blockedCode = "";

    if (mutating && path.indexOf("/provider/") === 0 && !state.configurationMutationsAllowed) {
      blockedCode = "ADAPTER_RECOVERY_MODE";
    } else if (
      mutating &&
      path.indexOf("/writing-policies/") === 0 &&
      !state.writingPolicyMutationsAllowed
    ) {
      blockedCode = state.adapterHealthStatus === "recovery"
        ? "ADAPTER_RECOVERY_MODE"
        : "WRITING_POLICY_READ_ONLY";
    } else if (
      normalizedMethod === "POST" &&
      ["/word/", "/excel/", "/ppt/"].some(function (prefix) {
        return path.indexOf(prefix) === 0;
      }) &&
      !state.modelTasksAllowed
    ) {
      blockedCode = "ADAPTER_RECOVERY_MODE";
    }
    if (blockedCode) {
      var blockedError = new Error(
        blockedCode === "WRITING_POLICY_READ_ONLY"
          ? "写作规范增强能力当前处于降级状态，仅允许只读查看。"
          : "Adapter 当前处于恢复模式，配置变更和模型任务已被安全阻止。"
      );
      blockedError.adapterCode = blockedCode;
      return Promise.reject(blockedError);
    }

    if (payload) {
      options.headers = {
        "Content-Type": "application/json"
      };
      options.body = JSON.stringify(payload);
    }

    if (timeoutMs && typeof AbortController !== "undefined") {
      controller = new AbortController();
      options.signal = controller.signal;
      timeoutId = setTimeout(function () {
        controller.abort();
      }, timeoutMs);
    }

    return fetch(ADAPTER_BASE_URL + path, {
      method: options.method,
      headers: options.headers,
      body: options.body,
      signal: options.signal
    }).then(function (response) {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      return response.json().then(function (body) {
        if (!response.ok) {
          var validation = body.data && body.data.validation;
          var adapterError = (body.errors && body.errors[0]) || {};
          var requestError;
          if (validation && validation.errors && validation.errors.length) {
            var details = validation.errors.map(function (item) {
              return [item.loc, item.type, item.message].filter(Boolean).join(" | ");
            }).join("\n");
            requestError = new Error("HTTP " + response.status + " 请求数据校验失败：\n" + details);
            requestError.adapterCode = "REQUEST_VALIDATION_FAILED";
            requestError.httpStatus = response.status;
            throw requestError;
          }
          requestError = new Error(adapterError.message || body.message || ("HTTP " + response.status));
          requestError.adapterCode = adapterError.code || "";
          requestError.httpStatus = response.status;
          throw requestError;
        }
        return body;
      });
    }, function (error) {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      throw error;
    });
  }

  function describeFetchError(error) {
    var message = error && error.message ? error.message : String(error || "");
    if (error && error.adapterCode === "WORD_DOCUMENT_REVIEW_TASK_BUSY") {
      return "当前文档已存在进行中的文档审查任务，请等待其完成。";
    }
    if (error && error.adapterCode === "WORD_DOCUMENT_REVIEW_TASK_CONFLICT") {
      return "文档审查任务标识冲突，请重试。";
    }
    if (error && error.adapterCode === "FULL_DOCUMENT_REVIEW_TASK_BUSY") {
      return "当前文档已存在进行中的全篇审查任务，请等待其完成。";
    }
    if (message === "Failed to fetch" || message.indexOf("NetworkError") >= 0) {
      return "插件无法访问 http://127.0.0.1:18100。请确认 adapter 正在运行、端口为 18100，并重新打开任务窗格。";
    }
    return message;
  }

  function isFullDocumentReviewPermanentPollError(error) {
    var status = Number(error && error.httpStatus);
    return Boolean(error) && (
      (status >= 400 && status < 500) ||
      error.adapterCode === "FULL_DOCUMENT_REVIEW_JOB_NOT_FOUND"
    );
  }

  function describeDocumentReviewError(error) {
    var message = describeFetchError(error);
    if (error && error.adapterCode === "WORD_DOCUMENT_REVIEW_TASK_BUSY") {
      return "当前文档已存在进行中的文档审查任务，请等待其完成。";
    }
    if (error && error.adapterCode === "WORD_DOCUMENT_REVIEW_TASK_CONFLICT") {
      return "文档审查任务标识冲突，请重试。";
    }
    if (error && error.adapterCode === "FULL_DOCUMENT_REVIEW_TASK_BUSY") {
      return "当前文档已存在进行中的全篇审查任务，请等待其完成。";
    }
    if (error && error.name === "AbortError") {
      return "文档审查任务提交请求超过 10 秒未返回，任务窗格将尝试按本地任务编号恢复查询。";
    }
    if (error && error.adapterCode === "PROVIDER_TIMEOUT") {
      return "模型后台文档审查未按时返回，adapter 已停止等待。请缩小审查范围后重试，或到“设置-最近一次任务诊断”查看 trace 和 provider 状态。";
    }
    if (message.indexOf("插件无法访问 http://127.0.0.1:18100") === 0) {
      return message + "\n\n如果模型后台已经收到文档审查请求，通常说明 adapter 正在等待模型后台返回或模型后台返回过慢；请稍后在“设置-最近一次任务诊断”查看 trace 和 provider 状态。";
    }
    return message;
  }

  function describeDocumentReviewPollError(error) {
    var message = describeFetchError(error);
    if (error && error.name === "AbortError") {
      return "状态查询请求超过 10 秒未返回，将继续自动刷新。";
    }
    if (error && error.adapterCode === "PROVIDER_TIMEOUT") {
      return "模型后台文档审查仍未按时返回，adapter 可能仍在等待或已返回超时诊断。";
    }
    if (message.indexOf("插件无法访问 http://127.0.0.1:18100") === 0) {
      return "状态查询暂时未连上本地 adapter；这不代表模型后台任务失败，将继续自动刷新。";
    }
    return message;
  }

  function readAdapterJson(path, requestOptions) {
    return request(path, null, requestOptions).catch(function (error) {
      return {
        success: false,
        data: {},
        errors: [{ message: describeFetchError(error) }]
      };
    });
  }

  function yesNo(value) {
    return value ? "是" : "否";
  }

  function describeAuthSource(value) {
    return {
      env: "环境变量",
      file: "统一密钥文件",
      "task-file": "任务级密钥文件",
      "route-file": "任务级密钥文件",
      none: "未配置"
    }[value] || value || "未检测";
  }

  function firstErrorMessage(result) {
    if (!result || result.success !== false) {
      return "";
    }
    return result.errors && result.errors[0] && result.errors[0].message
      ? result.errors[0].message
      : "请求失败";
  }

  function renderProviderDiagnostics(debugResult, statusResult, routesResult, taskKeysResult) {
    var debug = (debugResult && debugResult.data) || {};
    var status = (statusResult && statusResult.data) || {};
    var routes = (routesResult && routesResult.data) || {};
    var longTasks = routes.longTaskCoordinator || {};
    var taskKeys = (taskKeysResult && taskKeysResult.data) || {};
    var lines = ["最近一次任务诊断", ""];

    if (firstErrorMessage(debugResult)) {
      lines.push("- debug-last：" + firstErrorMessage(debugResult));
    }
    if (firstErrorMessage(statusResult)) {
      lines.push("- provider/status：" + firstErrorMessage(statusResult));
    }
    if (firstErrorMessage(routesResult)) {
      lines.push("- route-diagnostics：" + firstErrorMessage(routesResult));
    }
    if (firstErrorMessage(taskKeysResult)) {
      lines.push("- task-api-keys：" + firstErrorMessage(taskKeysResult));
    }

    lines.push("- 任务类型：" + (debug.taskType || "未记录"));
    lines.push("- traceId：" + (debug.traceId || "未记录"));
    lines.push("- adapter 状态：" + (status.configured ? "provider 已配置" : "provider 未配置"));
    lines.push("- provider 类型：" + (status.providerType || routes.providerType || "未检测"));
    lines.push("- provider 名称：" + (status.providerName || "未检测"));
    lines.push("- 统一 API URL 已配置：" + yesNo(routes.providerBaseUrlConfigured || debug.providerBaseUrlConfigured));
    lines.push("- 认证来源：" + describeAuthSource(debug.taskAuthSource || debug.authSource || status.authSource || routes.authSource));
    lines.push("- 请求路径：" + (debug.url || routes.url || "未进入模型后台请求"));
    lines.push("- fallback 原因：" + (debug.skipReason || "无"));

    if (typeof longTasks.maxRunning === "number") {
      lines.push("");
      lines.push("## 共享长任务协调器");
      lines.push("- 运行中：" + (longTasks.runningCount || 0) + "/" + longTasks.maxRunning);
      lines.push("- 排队中：" + (longTasks.queuedCount || 0) + "/" + longTasks.maxQueued);
      lines.push("- 终态保留：" + (longTasks.terminalCount || 0) + "/" + longTasks.maxTerminalJobs);
      lines.push("- 终态保留时长：" + (longTasks.terminalTtlSeconds || 0) + " 秒");
      lines.push("- 取消数：" + (longTasks.cancelledCount || 0));
      lines.push("- 拒绝数：" + (longTasks.rejectedCount || 0));
      lines.push("- 超时数：" + (longTasks.timedOutCount || 0));
      (longTasks.recentTerminalJobs || []).forEach(function (job) {
        var elapsedDesc = (typeof job.elapsedMs === "number")
          ? (job.elapsedMs + " ms（" + (job.elapsedSeconds || 0) + " 秒）")
          : ((job.elapsedSeconds || 0) + " 秒");
        var queueDesc = (typeof job.queueWaitMs === "number")
          ? ("，排队 " + job.queueWaitMs + " ms")
          : "";
        var phaseDesc = Object.keys(job.phaseDurationsMs || {}).map(function (phase) {
          return phase + " " + job.phaseDurationsMs[phase] + " ms";
        }).join("、");
        lines.push(
          "- 最近任务 " + (job.jobId || "未记录") +
          (job.taskType ? "（" + job.taskType + "）" : "") +
          "：" + (job.status || "未记录") +
          "，耗时 " + elapsedDesc +
          queueDesc +
          (phaseDesc ? "，阶段 " + phaseDesc : "") +
          (job.errorCode ? "，错误码 " + job.errorCode : "") +
          (job.providerOutcome ? "，模型结果 " + job.providerOutcome : "")
        );
      });
    }

    if (debug.performance) {
      lines.push("");
      lines.push("## 模型服务耗时");
      if (debug.performance.providerOutcome) {
        lines.push("- 模型调用结果：" + debug.performance.providerOutcome);
      }
      if (typeof debug.performance.providerAttempts === "number") {
        lines.push("- 模型调用次数：" + debug.performance.providerAttempts);
      }
      if (typeof debug.performance.providerHeadersMs === "number") {
        lines.push("- 响应头耗时：" + debug.performance.providerHeadersMs + " ms");
      }
      if (debug.performance.providerFirstVisibleMs !== null && typeof debug.performance.providerFirstVisibleMs === "number") {
        lines.push("- 首内容耗时：" + debug.performance.providerFirstVisibleMs + " ms");
      } else {
        lines.push("- 首内容耗时：阻塞调用无流式首包（null）");
      }
      if (typeof debug.performance.providerCompleteMs === "number") {
        lines.push("- 完整响应耗时：" + debug.performance.providerCompleteMs + " ms");
      }
      if (typeof debug.performance.parseMs === "number") {
        lines.push("- 解析耗时：" + debug.performance.parseMs + " ms");
      }
    }

    if (typeof state !== "undefined" && state.lastTaskPerformance) {
      lines.push("");
      lines.push("## 任务窗格本地耗时");
      if (typeof state.lastTaskPerformance.clickToFeedbackMs === "number") {
        lines.push("- 点击到反馈耗时：" + state.lastTaskPerformance.clickToFeedbackMs + " ms");
      }
      if (typeof state.lastTaskPerformance.localExtractionMs === "number") {
        lines.push("- 本地抽取耗时：" + state.lastTaskPerformance.localExtractionMs + " ms");
      }
      if (typeof state.lastTaskPerformance.clickToAdapterAcceptedMs === "number") {
        lines.push("- 点击到后台接收耗时：" + state.lastTaskPerformance.clickToAdapterAcceptedMs + " ms");
      }
      if (typeof state.lastTaskPerformance.completionToFirstRenderMs === "number") {
        lines.push("- 完成到首渲染耗时：" + state.lastTaskPerformance.completionToFirstRenderMs + " ms");
      }
    }

    if (debug.request) {
      lines.push("");
      lines.push("## 请求摘要");
      lines.push("- body 字段：" + (debug.request.bodyKeys || []).join(", "));
      lines.push("- inputs 字段：" + (debug.request.inputsKeys || []).join(", "));
      lines.push("- query 长度：" + (debug.request.queryLength || 0));
      lines.push("- response_mode：" + (debug.request.responseMode || "未记录"));
    }

    if (debug.response) {
      lines.push("");
      lines.push("## 响应摘要");
      lines.push("- HTTP 状态：" + (debug.response.status || "未记录"));
      lines.push("- body 字段：" + (debug.response.bodyKeys || []).join(", "));
      lines.push("- answer 长度：" + (debug.response.answerLength || 0));
      if (debug.response.answerFormat) {
        lines.push("- Markdown 特征：" + yesNo(debug.response.answerFormat.containsMarkdown));
      }
    }

    if (debug.error) {
      lines.push("");
      lines.push("## 错误摘要");
      lines.push("- 类型：" + (debug.error.type || "未记录"));
      lines.push("- 状态：" + (debug.error.status || "未记录"));
    }

    lines.push("");
    lines.push("## 任务密钥状态");
    Object.keys(taskKeys).forEach(function (taskType) {
      var item = taskKeys[taskType] || {};
      lines.push("- " + taskType + "：" + describeAuthSource(item.authSource) + "，已配置：" + yesNo(item.configured));
    });

    return lines.join("\n");
  }

  function mergeTemplates(serverTemplates) {
    var merged = [];
    var seen = {};

    function add(template) {
      if (!template || template.id !== "technical-document-template-rules" || seen[template.id]) {
        return;
      }
      seen[template.id] = true;
      merged.push(template);
    }

    fallbackTemplates.forEach(add);
    (serverTemplates || []).forEach(add);
    return merged;
  }

  function refreshConfig(options) {
    var requestId;
    var refreshOperation;
    var refreshPromise;
    var healthConnected = false;
    var silent = Boolean(options && options.silent);

    function releaseRefresh(result) {
      var shouldRestart = false;
      var restartSilent = true;
      if (state.configRefreshPromise === refreshPromise) {
        state.configRefreshPromise = null;
        state.configRefreshActiveRequestId = 0;
        state.configRefreshActiveSilent = false;
        shouldRestart = state.configRefreshQueued;
        restartSilent = state.configRefreshQueuedSilent;
        state.configRefreshQueued = false;
        state.configRefreshQueuedSilent = true;
      }
      if (shouldRestart && isSettingsRefreshEligible()) {
        return refreshConfig({ silent: restartSilent });
      }
      return result;
    }

    if (state.configRefreshPromise) {
      if (state.configRefreshActiveRequestId !== state.configRefreshRequestId) {
        if (!state.configRefreshQueued) {
          state.configRefreshQueuedSilent = silent;
        } else {
          state.configRefreshQueuedSilent = state.configRefreshQueuedSilent && silent;
        }
        state.configRefreshQueued = true;
      } else if (!silent && state.configRefreshActiveSilent) {
        state.configRefreshActiveSilent = false;
        setSettingsStatus("正在刷新配置...");
      }
      return state.configRefreshPromise;
    }

    requestId = state.configRefreshRequestId + 1;
    state.configRefreshRequestId = requestId;
    state.configRefreshActiveRequestId = requestId;
    state.configRefreshActiveSilent = silent;
    if (!silent) {
      setSettingsStatus("正在刷新配置...");
    }
    refreshOperation = request("/health", null, {
      timeoutMs: SETTINGS_REFRESH_REQUEST_TIMEOUT_MS
    }).then(function (health) {
      var healthData;
      var healthState;
      if (state.configRefreshRequestId !== requestId) {
        return null;
      }
      healthData = health.data || {};
      healthConnected = true;
      healthState = applyAdapterHealthState(healthData, true);
      setProviderLine(healthData.providerType || "未检测");
      if (healthState.status === "recovery") {
        return null;
      }
      return Promise.all([
        Promise.resolve(health),
        readAdapterJson("/templates", { timeoutMs: SETTINGS_REFRESH_REQUEST_TIMEOUT_MS }),
        readAdapterJson("/config", { timeoutMs: SETTINGS_REFRESH_REQUEST_TIMEOUT_MS })
      ]);
    }).then(function (results) {
      if (!results) {
        return null;
      }
      var templates = results[1];
      var config = results[2];
      if (state.configRefreshRequestId !== requestId) {
        return null;
      }
      if (config.success === false) {
        throw new Error(config.errors && config.errors[0] && config.errors[0].message || "配置读取失败");
      }
      applyProviderConfig(config.data || {});
      if (templates.success === false) {
        renderFallbackTemplateOptions();
      } else {
        state.templates = mergeTemplates(templates.data.templates || []);
        renderTemplateOptions();
      }
      var directServicesPromise = typeof loadDirectServices === "function"
        ? loadDirectServices(requestId, { timeoutMs: SETTINGS_REFRESH_REQUEST_TIMEOUT_MS })
        : Promise.resolve();
      return Promise.all([
        refreshAllWorkflowProfiles(requestId, { timeoutMs: SETTINGS_REFRESH_REQUEST_TIMEOUT_MS }),
        directServicesPromise
      ]).then(function (allResults) {
        var profileResults = allResults[0];
        var profileIndex;
        if (state.configRefreshRequestId !== requestId) {
          return null;
        }
        if (!profileResults || profileResults.length !== TASK_API_KEY_DEFS.length) {
          throw new Error("模型配置读取不完整");
        }
        for (profileIndex = 0; profileIndex < profileResults.length; profileIndex += 1) {
          if (!profileResults[profileIndex]) {
            throw new Error("模型配置读取失败");
          }
        }
        state.modelInterfaceDetectable = true;
        renderModelInterfaceState(state.modelInterfaceDetectable);
        if (!state.configRefreshActiveSilent) {
          setSettingsStatus(state.adapterHealthStatus === "degraded"
            ? "增强能力降级，核心功能可用。"
            : "就绪");
        }
        return results;
      });
    }).catch(function (error) {
      if (state.configRefreshRequestId !== requestId) {
        return null;
      }
      if (!healthConnected) {
        applyAdapterHealthState(null, false);
      }
      state.modelInterfaceDetectable = false;
      renderModelInterfaceState(state.modelInterfaceDetectable);
      setSettingsStatus("配置刷新失败：" + describeFetchError(error));
      return null;
    });

    refreshPromise = refreshOperation.then(releaseRefresh, function (error) {
      if (state.configRefreshRequestId === requestId) {
        if (!healthConnected) {
          applyAdapterHealthState(null, false);
        }
        state.modelInterfaceDetectable = false;
        renderModelInterfaceState(state.modelInterfaceDetectable);
        setSettingsStatus("配置刷新失败：" + describeFetchError(error));
      }
      return releaseRefresh(null);
    });
    state.configRefreshPromise = refreshPromise;
    return refreshPromise;
  }

  function renderFallbackTemplateOptions() {
    state.templates = mergeTemplates([]);
    renderTemplateOptions();
  }

  function closeProviderUrlEditor(suppressRefreshSync) {
    var details = byId("provider-url-details");
    var input = byId("provider-base-url");
    state.providerUrlEditorOpen = false;
    if (details) {
      details.removeAttribute("open");
    }
    if (input) {
      input.value = state.providerBaseUrl || "";
    }
    if (suppressRefreshSync !== true) {
      syncSettingsRefreshController();
    }
  }

  function saveProviderBaseUrl() {
    var input = byId("provider-base-url");
    var baseUrl = (input.value || "").trim();
    var refreshPromise;
    setSettingsStatus("正在保存大模型 API URL...");
    request("/provider/base-url", { baseUrl: baseUrl })
      .then(function (body) {
        var savedUrl = typeof body.data.providerBaseUrl === "string" ? body.data.providerBaseUrl : baseUrl;
        setProviderBaseUrl(savedUrl);
        closeProviderUrlEditor(true);
        setSettingsStatus("大模型 API URL 已保存。");
        invalidateConfigRefresh();
        refreshPromise = refreshConfig({ silent: false });
        syncSettingsRefreshController();
        return refreshPromise;
      })
      .catch(function (error) {
        setSettingsStatus("保存大模型 API URL 失败：" + describeFetchError(error));
      });
  }

  function getCurrentWorkflowTaskType() {
    return MODE_WORKFLOW_TASK_TYPES[state.currentMode] || "";
  }

  function getSettingsWorkflowTaskType() {
    var taskType = state.settingsWorkflowTaskType;
    var exists = TASK_API_KEY_DEFS.some(function (item) {
      return item.taskType === taskType;
    });
    return exists ? taskType : TASK_API_KEY_DEFS[0].taskType;
  }

  function isWorkflowInteractionBlocked() {
    return Boolean(state.documentReviewJobId || state.fullDocumentReviewJobId || state.workflowProfileMutationBusy);
  }

  function nextWorkflowProfileRequestId(taskType) {
    var requestId = (state.workflowProfileRequestSequence[taskType] || 0) + 1;
    state.workflowProfileRequestSequence[taskType] = requestId;
    return requestId;
  }

  function invalidateWorkflowProfileRequests(taskType) {
    return nextWorkflowProfileRequestId(taskType);
  }

  function isWorkflowProfileRequestCurrent(taskType, requestId) {
    return state.workflowProfileRequestSequence[taskType] === requestId;
  }

  function getWorkflowProfileOptionState(profile, activeProfileId, busy) {
    if (helpers.workflowProfileOptionState) {
      var sharedState = helpers.workflowProfileOptionState(profile, activeProfileId);
      return {
        id: sharedState.id,
        label: sharedState.label,
        active: Boolean(sharedState.active),
        disabled: Boolean(busy || sharedState.disabled)
      };
    }
    return {
      active: Boolean(profile && profile.id === activeProfileId),
      id: String(profile && profile.id || ""),
      label: String(profile && profile.name || "未命名配置") + " · " +
        (profile && profile.accessMethod === "direct_model" ? "模型直连" : "工作流平台"),
      disabled: Boolean(busy || !profile || !profile.keyConfigured)
    };
  }

  function getWorkflowProfileDraftValidation(draft, requireApiKey) {
    if (helpers.validateWorkflowProfileDraft) {
      var sharedValidation = helpers.validateWorkflowProfileDraft(
        draft,
        requireApiKey ? "create" : "edit"
      );
      return {
        valid: Boolean(sharedValidation && sharedValidation.ok),
        message: sharedValidation && sharedValidation.message || ""
      };
    }
    if (!draft || !String(draft.name || "").trim()) {
      return { valid: false, message: "请填写模型配置名称。" };
    }
    if (requireApiKey && !String(draft.apiKey || "").trim()) {
      return { valid: false, message: "请填写模型配置 API Key。" };
    }
    return { valid: true, message: "" };
  }

  function getShouldActivateNewWorkflowProfile(data, requestedActivate) {
    if (helpers.shouldActivateNewWorkflowProfile) {
      var profileCount = data && Array.isArray(data.profiles) ?
        data.profiles.length : Number(data && data.profileCount || 0);
      return helpers.shouldActivateNewWorkflowProfile(profileCount, requestedActivate);
    }
    return Boolean(requestedActivate || !(data && data.activeProfileId));
  }

  function getWorkflowProfileData(taskType) {
    var sharedDirectServiceEnabled = taskType === "word.smart_write" || taskType === "word.smart_imitation" || taskType === "word.format_review" || taskType === "word.document_review";
    var base = state.workflowProfiles[taskType] || {
      taskType: taskType,
      activeProfileId: "",
      profileCount: 0,
      profiles: []
    };
    var activeId = base.activeProfileId;
    var taskKeyStatus = state.taskApiKeys && state.taskApiKeys[taskType];
    if (sharedDirectServiceEnabled && taskKeyStatus && taskKeyStatus.accessMethod === "direct_model" && taskKeyStatus.activeProfileId) {
      activeId = taskKeyStatus.activeProfileId;
    } else if (!activeId && taskKeyStatus && taskKeyStatus.accessMethod !== "direct_model" && taskKeyStatus.activeProfileId) {
      activeId = taskKeyStatus.activeProfileId;
    }
    if (sharedDirectServiceEnabled && !activeId && state.workflowProfileSelections[taskType] && String(state.workflowProfileSelections[taskType]).startsWith("direct_svc_")) {
      activeId = state.workflowProfileSelections[taskType];
    }
    return {
      taskType: base.taskType,
      activeProfileId: activeId,
      profileCount: base.profileCount,
      profiles: base.profiles,
      loadError: base.loadError,
      directServices: sharedDirectServiceEnabled ? (state.directServices || []) : [],
      taskModelSelection: sharedDirectServiceEnabled
        ? ((state.taskModelSelections && state.taskModelSelections[taskType]) || null)
        : null
    };
  }

  function normalizeWorkflowProfileData(data, taskType) {
    if (helpers.normalizeWorkflowProfileData) {
      return helpers.normalizeWorkflowProfileData(data, taskType);
    }
    return {
      taskType: taskType,
      activeProfileId: data && data.activeProfileId || "",
      profileCount: data && data.profileCount || 0,
      profiles: data && Array.isArray(data.profiles) ? data.profiles : []
    };
  }

  function loadWorkflowProfiles(taskType, configRefreshRequestId, requestOptions) {
    var requestId;
    var previousProfileData;
    if (!taskType) {
      return Promise.resolve(null);
    }
    previousProfileData = state.workflowProfiles[taskType] || null;
    requestId = nextWorkflowProfileRequestId(taskType);
    return request(
      "/provider/model-configurations?taskType=" + encodeURIComponent(taskType),
      null,
      requestOptions
    )
      .then(function (body) {
        if (!isWorkflowProfileRequestCurrent(taskType, requestId) ||
            (configRefreshRequestId && state.configRefreshRequestId !== configRefreshRequestId)) {
          return null;
        }
        state.workflowProfiles[taskType] = normalizeWorkflowProfileData(body.data || {}, taskType);
        state.workflowProfileSelections[taskType] = state.workflowProfiles[taskType].activeProfileId || "";
        renderWorkflowProfileStrip();
        renderWorkflowProfileManager();
        renderModelInterfaceState(state.modelInterfaceDetectable);
        renderFullDocumentReviewEntry();
        return state.workflowProfiles[taskType];
      })
      .catch(function (error) {
        var loadError;
        var preservedProfileData;
        if (!isWorkflowProfileRequestCurrent(taskType, requestId) ||
            (configRefreshRequestId && state.configRefreshRequestId !== configRefreshRequestId)) {
          return null;
        }
        loadError = describeFetchError(error);
        if (previousProfileData) {
          preservedProfileData = {};
          Object.keys(previousProfileData).forEach(function (key) {
            preservedProfileData[key] = previousProfileData[key];
          });
          preservedProfileData.loadError = loadError;
          state.workflowProfiles[taskType] = preservedProfileData;
        } else {
          state.workflowProfiles[taskType] = {
            taskType: taskType,
            activeProfileId: "",
            profileCount: 0,
            profiles: [],
            loadError: loadError
          };
        }
        state.modelInterfaceDetectable = false;
        renderWorkflowProfileStrip();
        renderWorkflowProfileManager();
        renderModelInterfaceState(state.modelInterfaceDetectable);
        return null;
      });
  }

  function refreshAllWorkflowProfiles(configRefreshRequestId, requestOptions) {
    return Promise.all(TASK_API_KEY_DEFS.map(function (item) {
      return loadWorkflowProfiles(item.taskType, configRefreshRequestId, requestOptions);
    }));
  }

  function syncWorkflowProfileSelectOptions() {}

  function currentTaskModelConfigProfile(data) {
    if (!data) {
      return null;
    }
    var taskType = data.taskType || getCurrentWorkflowTaskType();
    var selectedId = state.workflowProfileSelections[taskType] || data.activeProfileId || "";
    if (helpers.resolveCurrentTaskModelConfigProfile) {
      return helpers.resolveCurrentTaskModelConfigProfile(data, selectedId, {
        directServices: state.directServices,
        taskModelSelection: state.taskModelSelections && state.taskModelSelections[taskType]
      });
    }
    return getWorkflowProfileById(taskType, selectedId);
  }

  function resolveTaskModelConfigStatus(taskType, data, profile) {
    if (helpers.resolveTaskModelConfigViewStatus) {
      return helpers.resolveTaskModelConfigViewStatus({
        taskType: taskType,
        mutationBusy: state.workflowProfileMutationBusy,
        statusByTask: state.taskModelConfigStatusByTask,
        hasLoaded: Object.prototype.hasOwnProperty.call(state.workflowProfiles, taskType),
        loadError: Boolean(data && data.loadError),
        hasProfile: Boolean(profile)
      });
    }
    if (state.workflowProfileMutationBusy) {
      return "busy";
    }
    if (state.taskModelConfigStatusByTask[taskType] === "error") {
      return "error";
    }
    if (data && data.loadError) {
      return "loadError";
    }
    if (!profile) {
      return "empty";
    }
    return "ready";
  }

  function taskModelConfigOptionId(index) {
    return "task-model-config-option-" + index;
  }

  function updateTaskModelConfigMenuHighlight(highlightedIndex) {
    var menu = byId("task-model-config-menu");
    var trigger = byId("task-model-config-trigger");
    var options;
    var index;
    var isHighlighted;
    if (!menu) {
      return;
    }
    options = menu.querySelectorAll("[data-config-action]");
    for (index = 0; index < options.length; index += 1) {
      isHighlighted = index === highlightedIndex;
      if (isHighlighted) {
        options[index].classList.add("is-active");
      } else {
        options[index].classList.remove("is-active");
      }
    }
    if (highlightedIndex >= 0 && options[highlightedIndex]) {
      scrollWorkflowTaskTabIntoView(options[highlightedIndex]);
    }
    if (trigger) {
      if (highlightedIndex >= 0) {
        trigger.setAttribute("aria-activedescendant", taskModelConfigOptionId(highlightedIndex));
      } else {
        trigger.removeAttribute("aria-activedescendant");
      }
    }
  }

  function positionTaskModelConfigMenu() {
    var menu = byId("task-model-config-menu");
    var trigger = byId("task-model-config-trigger");
    var menuRect;
    var triggerRect;
    var viewportHeight;
    if (!menu || !trigger || typeof menu.getBoundingClientRect !== "function") {
      return;
    }
    menu.classList.remove("is-above");
    menuRect = menu.getBoundingClientRect();
    triggerRect = trigger.getBoundingClientRect();
    viewportHeight = window.innerHeight || 700;
    if (menuRect.bottom > viewportHeight - 8 && triggerRect.top > menuRect.height + 8) {
      menu.classList.add("is-above");
    }
  }

  function renderTaskModelConfigMenu(items, highlightedIndex) {
    var menu = byId("task-model-config-menu");
    var rows = [];
    var esc = typeof escapeWorkflowText === "function" ? escapeWorkflowText : function (v) {
      return helpers.escapeHtml ? helpers.escapeHtml(String(v || "")) : String(v || "");
    };
    if (!menu) {
      return;
    }
    items.forEach(function (item, index) {
      var isHighlighted = index === highlightedIndex;
      var isManage = item.action === "manage";
      var role = isManage ? "menuitem" : "menuitemradio";
      var checkedAttr = isManage ? "" : ' aria-checked="' + (item.selected ? "true" : "false") + '"';
      rows.push('<button type="button" class="task-model-config-option' +
        (item.selected ? " is-current" : "") +
        (isHighlighted ? " is-active" : "") +
        '" role="' + role + '" id="' + taskModelConfigOptionId(index) +
        '" tabindex="-1" data-config-action="' + esc(item.action) +
        '" data-profile-id="' + esc(item.id || "") + '"' +
        checkedAttr +
        (item.disabled ? " disabled" : "") + ">" + esc(item.label) + "</button>");
    });
    menu.innerHTML = rows.join("");
    menu.hidden = false;
    updateTaskModelConfigMenuHighlight(highlightedIndex);
    positionTaskModelConfigMenu();
  }

  function openTaskModelConfigMenu() {
    var taskType = getCurrentWorkflowTaskType();
    var data = getWorkflowProfileData(taskType);
    var items = helpers.buildTaskModelConfigMenuItems
      ? helpers.buildTaskModelConfigMenuItems(data.profiles || [], {
        activeProfileId: data.activeProfileId,
        taskType: taskType,
        directServices: data.directServices,
        taskModelSelection: data.taskModelSelection
      })
      : [];
    var selectedIndex = 0;
    items.forEach(function (item, index) {
      if (item.selected && item.action === "select") {
        selectedIndex = index;
      }
    });
    var reduced = helpers.reduceTaskModelConfigMenuKey
      ? helpers.reduceTaskModelConfigMenuKey({
        open: false,
        itemCount: items.length,
        highlightedIndex: selectedIndex,
        items: items
      }, "Open")
      : { open: true, highlightedIndex: selectedIndex, itemCount: items.length };
    state.taskModelConfigMenu = {
      open: true,
      highlightedIndex: reduced.highlightedIndex,
      itemCount: items.length,
      items: items
    };
    byId("task-model-config-trigger").setAttribute("aria-expanded", "true");
    renderTaskModelConfigMenu(items, reduced.highlightedIndex);
  }

  function closeTaskModelConfigMenu(restoreFocus) {
    var menu = byId("task-model-config-menu");
    var trigger = byId("task-model-config-trigger");
    state.taskModelConfigMenu.open = false;
    state.taskModelConfigMenu.highlightedIndex = -1;
    if (menu) {
      menu.hidden = true;
      menu.innerHTML = "";
    }
    if (trigger) {
      trigger.setAttribute("aria-expanded", "false");
      trigger.removeAttribute("aria-activedescendant");
      if (restoreFocus) {
        focusTaskModelConfigTrigger();
      }
    }
  }

  function applyTaskModelConfigMenuItem(item, restoreFocus) {
    var taskType = getCurrentWorkflowTaskType();
    closeTaskModelConfigMenu(restoreFocus);
    if (!item) {
      return;
    }
    if (item.action === "manage") {
      state.settingsWorkflowTaskType = taskType;
      switchMode("settings");
      var targetTab = document.querySelector('[data-workflow-task-tab="' + taskType + '"]');
      if (targetTab && typeof targetTab.focus === "function") {
        targetTab.focus();
      } else {
        var backBtn = byId("btn-open-settings");
        if (backBtn && typeof backBtn.focus === "function") {
          backBtn.focus();
        }
      }
      return;
    }
    if (item.action === "select" && item.id) {
      scheduleWorkflowProfileActivation(item.id, taskType, getWorkflowProfileData(taskType).activeProfileId);
    }
  }

  function handleTaskModelConfigTriggerClick() {
    if (state.modelTaskBusy || state.workflowProfileMutationBusy || isWorkflowInteractionBlocked()) {
      return;
    }
    if (state.taskModelConfigMenu.open) {
      closeTaskModelConfigMenu(true);
      return;
    }
    openTaskModelConfigMenu();
  }

  function handleTaskModelConfigMenuClick(event) {
    var node = event.target;
    var button = null;
    var action;
    var profileId;
    while (node && node.getAttribute) {
      if (node.getAttribute("data-config-action")) {
        button = node;
        break;
      }
      node = node.parentNode;
    }
    if (!button || !state.taskModelConfigMenu.open) {
      return;
    }
    action = button.getAttribute("data-config-action");
    profileId = button.getAttribute("data-profile-id");
    applyTaskModelConfigMenuItem({ action: action, id: profileId }, action !== "manage");
  }

  function handleTaskModelConfigKeydown(event) {
    var next;
    if (!state.taskModelConfigMenu.open) {
      return;
    }
    next = helpers.reduceTaskModelConfigMenuKey({
      open: true,
      itemCount: state.taskModelConfigMenu.itemCount,
      highlightedIndex: state.taskModelConfigMenu.highlightedIndex,
      items: state.taskModelConfigMenu.items
    }, event.key);
    if (event.key === "ArrowDown" || event.key === "ArrowUp" || event.key === "Enter" || event.key === "Escape") {
      event.preventDefault();
    }
    state.taskModelConfigMenu.highlightedIndex = next.highlightedIndex;
    if (next.action === "close") {
      closeTaskModelConfigMenu(next.restoreFocus);
      return;
    }
    if (next.action === "select" || next.action === "manage") {
      applyTaskModelConfigMenuItem(
        state.taskModelConfigMenu.items[next.action === "select" ? next.selectedIndex : next.highlightedIndex],
        next.restoreFocus
      );
      return;
    }
    updateTaskModelConfigMenuHighlight(next.highlightedIndex);
  }

  function bindTaskModelConfigPress(element) {
    if (!element) {
      return;
    }
    element.addEventListener("pointerdown", function () {
      element.classList.add("is-pressed");
    });
    ["pointerup", "pointerleave", "pointercancel"].forEach(function (type) {
      element.addEventListener(type, function () {
        element.classList.remove("is-pressed");
      });
    });
  }

  function focusTaskModelConfigTrigger() {
    var trigger = byId("task-model-config-trigger");
    if (trigger && typeof trigger.focus === "function") {
      trigger.focus();
    }
  }

  function renderWorkflowProfileStrip() {
    var strip = byId("workflow-profile-strip");
    var trigger = byId("task-model-config-trigger");
    var label = byId("task-model-config-label");
    var statusNode = byId("task-model-config-status");
    var feedback = byId("workflow-switch-feedback");
    var taskType = getCurrentWorkflowTaskType();
    var data = getWorkflowProfileData(taskType);
    var profile = currentTaskModelConfigProfile(data);
    var status = resolveTaskModelConfigStatus(taskType, data, profile);
    var entry = helpers.formatTaskModelConfigEntry
      ? helpers.formatTaskModelConfigEntry(profile, { status: status })
      : { visibleText: "未配置", statusText: "未配置", ariaLabel: "未配置" };
    var taskLabels = {
      "word.smart_write": "选择智能编写模型配置",
      "word.smart_imitation": "选择智能仿写模型配置",
      "word.document_review": "选择文档审查模型配置",
      "word.format_review": "选择格式审查模型配置"
    };
    var taskLabel = taskLabels[taskType] || "选择模型配置";
    if (!strip || !trigger || !label || !statusNode || !feedback) {
      return;
    }
    strip.hidden = !taskType || state.currentMode === "settings";
    if (state.currentMode === "settings") {
      closeTaskModelConfigMenu(false);
      return;
    }
    if (!taskType) {
      return;
    }
    label.textContent = entry.visibleText;
    trigger.setAttribute("aria-label", taskLabel + "，" + entry.ariaLabel);
    statusNode.className = "task-model-config-status is-" + status;
    var interactionBlocked = typeof isWorkflowInteractionBlocked === "function"
      ? isWorkflowInteractionBlocked()
      : Boolean(state.documentReviewJobId || state.fullDocumentReviewJobId);
    trigger.disabled = state.modelTaskBusy || state.workflowProfileMutationBusy || interactionBlocked || status === "loading";
    setNodeTextIfChanged(feedback, entry.statusText);
    if (state.taskModelConfigMenu.open) {
      state.taskModelConfigMenu.items = helpers.buildTaskModelConfigMenuItems
        ? helpers.buildTaskModelConfigMenuItems(data.profiles || [], {
          activeProfileId: data.activeProfileId,
          taskType: taskType,
          directServices: data.directServices,
          taskModelSelection: data.taskModelSelection
        })
        : [];
      state.taskModelConfigMenu.itemCount = state.taskModelConfigMenu.items.length;
      renderTaskModelConfigMenu(state.taskModelConfigMenu.items, state.taskModelConfigMenu.highlightedIndex);
    }
  }

  function findDirectService(serviceId) {
    var services = state.directServices || [];
    var i;
    for (i = 0; i < services.length; i += 1) {
      if (services[i].id === serviceId) {
        return services[i];
      }
    }
    return null;
  }

  function findWorkflowProfile(profileId, taskType) {
    var data = getWorkflowProfileData(taskType || getCurrentWorkflowTaskType());
    var profiles = data.profiles || [];
    var index;
    for (index = 0; index < profiles.length; index += 1) {
      if (profiles[index].id === profileId) {
        return profiles[index];
      }
    }
    var directServices = data.directServices || [];
    for (index = 0; index < directServices.length; index += 1) {
      if (directServices[index].id === profileId) {
        var svc = directServices[index];
        var selection = (state.taskModelSelections && state.taskModelSelections[taskType || getCurrentWorkflowTaskType()]) || {};
        var effModel = selection.effectiveModel || svc.defaultModel || "";
        return {
          id: svc.id,
          name: svc.name,
          accessMethod: "direct_model",
          effectiveModel: effModel,
          complete: Boolean(svc.serviceBaseUrl && svc.keyConfigured),
          serviceBaseUrl: svc.serviceBaseUrl,
          keyConfigured: svc.keyConfigured
        };
      }
    }
    return null;
  }

  function getWorkflowProfileById(taskType, profileId) {
    return findWorkflowProfile(profileId, taskType);
  }

  function canDeleteWorkflowProfile(profile, activeProfileId) {
    if (helpers.canDeleteWorkflowProfile) {
      return helpers.canDeleteWorkflowProfile(profile, activeProfileId);
    }
    return Boolean(profile && profile.id && profile.id !== activeProfileId);
  }

  function escapeWorkflowText(value) {
    if (helpers.escapeHtml) {
      return helpers.escapeHtml(String(value || ""));
    }
    return String(value || "").replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function renderWorkflowTaskTabs() {
    var tabs = byId("workflow-task-tabs");
    var taskType = getSettingsWorkflowTaskType();
    var buttons;
    var index;
    if (!tabs) {
      return;
    }
    buttons = tabs.querySelectorAll("[data-workflow-task-tab]");
    for (index = 0; index < buttons.length; index += 1) {
      var active = buttons[index].getAttribute("data-workflow-task-tab") === taskType;
      buttons[index].classList.toggle("active", active);
      buttons[index].setAttribute("aria-selected", active ? "true" : "false");
      buttons[index].tabIndex = active ? 0 : -1;
      buttons[index].disabled = state.workflowProfileMutationBusy;
    }
  }

  function scrollWorkflowTaskTabIntoView(button) {
    var reducedMotion = false;
    if (!button || typeof button.scrollIntoView !== "function") {
      return;
    }
    try {
      reducedMotion = Boolean(
        window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches
      );
    } catch (error) {
      reducedMotion = false;
    }
    try {
      button.scrollIntoView({
        behavior: reducedMotion ? "auto" : "smooth",
        block: "nearest",
        inline: "nearest"
      });
    } catch (error) {
      try {
        button.scrollIntoView(true);
      } catch (fallbackError) {
        // Older WPS WebViews may not expose a working scrollIntoView implementation.
      }
    }
  }

  function handleWorkflowTaskTabKeydown(event) {
    var buttons = byId("workflow-task-tabs").querySelectorAll("[data-workflow-task-tab]");
    var currentIndex = Array.prototype.indexOf.call(buttons, event.target);
    var nextIndex = currentIndex;
    var nextButton;
    if (currentIndex < 0 || state.workflowProfileMutationBusy) {
      return;
    }
    if (event.key === "ArrowLeft") {
      nextIndex = (currentIndex - 1 + buttons.length) % buttons.length;
    } else if (event.key === "ArrowRight") {
      nextIndex = (currentIndex + 1) % buttons.length;
    } else if (event.key === "Home") {
      nextIndex = 0;
    } else if (event.key === "End") {
      nextIndex = buttons.length - 1;
    } else {
      return;
    }
    event.preventDefault();
    nextButton = buttons[nextIndex];
    nextButton.click();
    nextButton.focus();
    scrollWorkflowTaskTabIntoView(nextButton);
  }

  function setWorkflowHelpOpen(open, pinned) {
    var button = byId("workflow-help-button");
    var popover = byId("workflow-help-popover");
    if (typeof pinned === "boolean") {
      state.workflowHelpPinned = pinned;
    }
    popover.hidden = !open;
    button.setAttribute("aria-expanded", open ? "true" : "false");
  }

  function syncWorkflowProfileManagerBusyState() {
    var manager = byId("workflow-profile-manager");
    var editorView = byId("workflow-editor-view");
    var directServicesCard = byId("direct-services-card");
    var taskDirectServiceSection = byId("word-task-direct-service-section");
    var controls;
    var index;
    var roots = [manager, editorView, directServicesCard, taskDirectServiceSection];
    var rootIndex;
    if (!manager && !editorView && !directServicesCard && !taskDirectServiceSection) {
      return;
    }
    for (rootIndex = 0; rootIndex < roots.length; rootIndex += 1) {
      if (!roots[rootIndex]) {
        continue;
      }
      controls = roots[rootIndex].querySelectorAll("button, input, textarea, select");
      for (index = 0; index < controls.length; index += 1) {
        controls[index].disabled = state.workflowProfileMutationBusy;
      }
    }
    var btnNewWorkflowProfile = byId("btn-new-workflow-profile");
    if (btnNewWorkflowProfile) {
      btnNewWorkflowProfile.disabled = state.workflowProfileMutationBusy;
    }
  }

  function setWorkflowProfileMutationBusy(busy) {
    state.workflowProfileMutationBusy = Boolean(busy);
    renderWorkflowProfileStrip();
    renderWorkflowTaskTabs();
    syncWorkflowProfileManagerBusyState();
    syncSettingsRefreshController();
  }

  function markWorkflowProfileEditorDirty() {
    if (state.workflowProfileEditor) {
      state.workflowProfileEditor.dirty = true;
      var validateButton = document.querySelector('[data-workflow-action="validate"]');
      if (validateButton) {
        validateButton.disabled = true;
      }
    }
  }

  function handleModelConfigurationEditorChange(event) {
    markWorkflowProfileEditorDirty();
  }

  function renderWorkflowProfileManager() {
    var manager = byId("workflow-profile-manager");
    var settingsHome = byId("workflow-settings-home");
    var editorView = byId("workflow-editor-view");
    var editorContent = byId("workflow-editor-content");
    var managerTitle = byId("workflow-manager-title");
    var newProfileButton = byId("btn-new-workflow-profile");
    var taskType = getSettingsWorkflowTaskType();
    var definition = TASK_API_KEY_DEFS.filter(function (item) {
      return item.taskType === taskType;
    })[0] || TASK_API_KEY_DEFS[0];
    var data = getWorkflowProfileData(taskType);
    var editor = state.workflowProfileEditor;
    var rows = [];
    var disabledAttribute = state.workflowProfileMutationBusy ? " disabled" : "";
    var createDisabledAttribute = state.workflowProfileMutationBusy || data.loadError ? " disabled" : "";
    var activationDisabledAttribute = isWorkflowInteractionBlocked() ? " disabled" : "";
    if (!manager) {
      return;
    }
    renderWorkflowTaskTabs();
    if (editor && editor.taskType === taskType) {
      if (settingsHome) {
        settingsHome.hidden = true;
      }
      if (editorView) {
        editorView.hidden = false;
      }
      var profile = editor.mode === "edit" ? getWorkflowProfileById(taskType, editor.profileId) : null;
      if (editor.mode === "edit" && !profile) {
        state.workflowProfileEditor = null;
        syncSettingsRefreshController();
        renderWorkflowProfileManager();
        return;
      }
      var accessMethod = "workflow_platform";
      var validationSummary = profile
        ? (helpers.formatModelValidationStatus
          ? helpers.formatModelValidationStatus(profile, data.activeProfileId)
          : (profile.lastValidation && profile.lastValidation.message || "尚未验证"))
        : "";
      rows.push('<section class="workflow-settings-subpage" aria-label="' +
        (editor.mode === "create" ? "新建工作流配置" : "编辑工作流配置") + '">');
      rows.push('<div class="workflow-subpage-head"><button type="button" class="ghost-action mini-button" data-workflow-action="editor-cancel"' + disabledAttribute + '>返回</button><div><h5>' +
        (editor.mode === "create" ? "新建" + definition.label + "工作流配置" : "编辑" + escapeWorkflowText(profile.name)) +
        '</h5><span>' + definition.label + '</span></div></div>');
      rows.push('<div class="workflow-editor-fields">');
      rows.push('<label class="field"><span>配置名称</span><input type="text" data-workflow-editor-name maxlength="40" value="' +
        escapeWorkflowText(profile ? profile.name : "") + '"' + disabledAttribute + ' /></label>');
      rows.push('<label class="field"><span>接入方式</span><select data-workflow-editor-method' + disabledAttribute + '>' +
        '<option value="workflow_platform" selected>工作流平台</option></select></label>');
      rows.push('<label class="field"><span>服务地址</span><input type="text" data-workflow-editor-url placeholder="例如：http://1.1.1.1:1111/one-api/v1" value="' +
        escapeWorkflowText(profile ? profile.serviceBaseUrl : "") + '"' + disabledAttribute + ' /></label>');
      rows.push('<label class="field"><span>备注</span><textarea data-workflow-editor-note rows="3" maxlength="200" placeholder="选填"' + disabledAttribute + '>' +
        escapeWorkflowText(profile ? profile.note : "") + '</textarea></label>');
      rows.push('<section class="model-key-editor"><div class="model-key-status">API Key：' +
        (profile && profile.keyConfigured ? "已配置" : "未配置") + '</div>' +
        '<label class="field"><span>' + (profile && profile.keyConfigured ? "新 API Key（选填）" : "API Key（可稍后配置）") +
        '</span><input type="password" data-workflow-editor-key autocomplete="new-password"' + disabledAttribute + ' /></label>' +
        '<label class="field"><span>再次输入 API Key</span><input type="password" data-workflow-editor-key-confirm autocomplete="new-password"' + disabledAttribute + ' /></label></section>');
      rows.push('<details class="model-advanced-settings"><summary>高级配置</summary><div class="workflow-editor-fields">' +
        (profile ? '<button type="button" class="ghost-action" data-workflow-action="validate" data-task-type="' + taskType + '" data-profile-id="' + escapeWorkflowText(profile.id) + '"' +
          (!profile.complete || editor.dirty ? " disabled" : "") + '>验证调用</button><p class="inline-status" data-model-validation-summary>' +
          escapeWorkflowText(validationSummary) + '</p>' : '') +
        '</div></details>');
      if (editor.mode === "create") {
        var shouldCheckActivate = getShouldActivateNewWorkflowProfile(data, false);
        rows.push('<label class="workflow-activate-check"><input type="checkbox" data-workflow-editor-activate' +
          (shouldCheckActivate ? " checked" : "") + disabledAttribute + ' /> 保存后设为当前</label>');
      }
      rows.push('</div><div class="button-row workflow-editor-actions">');
      rows.push('<button type="button" data-workflow-action="' + (editor.mode === "create" ? "create-save" : "edit-save") + '" data-task-type="' +
        taskType + '"' + (profile ? ' data-profile-id="' + escapeWorkflowText(profile.id) + '"' : "") + disabledAttribute + '>保存</button>');
      rows.push('<button type="button" class="ghost-action" data-workflow-action="editor-cancel"' + disabledAttribute + '>取消</button>');
      rows.push('</div></section>');
      editorContent.innerHTML = rows.join("");
      manager.innerHTML = "";
      return;
    }

    if (settingsHome) {
      settingsHome.hidden = false;
    }
    if (editorView) {
      editorView.hidden = true;
    }
    if (editorContent) {
      editorContent.innerHTML = "";
    }
    if (managerTitle) {
      managerTitle.textContent = "工作流配置";
    }
    if (newProfileButton) {
      newProfileButton.disabled = Boolean(createDisabledAttribute.trim());
    }
    if (data.loadError) {
      rows.push('<div class="workflow-profile-error-actions"><p class="workflow-profile-error">无法读取工作流配置：' +
        escapeWorkflowText(data.loadError) + '</p><button type="button" class="ghost-action mini-button" data-workflow-action="reload" data-task-type="' +
        taskType + '"' + disabledAttribute + '>重新读取</button></div>');
    }
    if (!data.profiles.length && !data.loadError) {
      rows.push('<p class="workflow-profile-empty">尚未建立工作流配置。</p>');
    }
    if (data.profiles.length) {
      rows.push('<div class="workflow-profile-list">');
      data.profiles.forEach(function (profile) {
        var isActive = profile.id === data.activeProfileId;
        var canDelete = canDeleteWorkflowProfile(profile, data.activeProfileId);
        var statusText = helpers.workflowProfileStatusText ?
          helpers.workflowProfileStatusText(profile, data.activeProfileId) :
          (isActive ? "当前使用" : (profile.complete ? "配置完整" : "配置不完整"));
        rows.push('<div class="workflow-profile-list-row workflow-profile-row" data-profile-id="' + escapeWorkflowText(profile.id) + '">');
        rows.push('<div class="workflow-profile-summary"><strong>' + escapeWorkflowText(profile.name) + '</strong>');
        rows.push('<span class="workflow-profile-note">' +
          (profile.accessMethod === "direct_model" ? "模型直连" + (profile.modelName ? " · " + escapeWorkflowText(profile.modelName) : "") : "工作流平台") + '</span>');
        if (profile.note) {
          rows.push('<span class="workflow-profile-note">' + escapeWorkflowText(profile.note) + '</span>');
        }
        if (taskType === "word.document_review") {
          rows.push('<span class="workflow-profile-note">限量审查：' +
            (profile.limitedReviewReady ? "可用" : "不可用") + '</span>');
          rows.push('<span class="workflow-profile-note">全篇审查：' +
            escapeWorkflowText(profile.fullDocumentReviewReadiness &&
              profile.fullDocumentReviewReadiness.label || "尚未就绪") + '</span>');
        }
        rows.push('</div>');
        rows.push('<span class="provider-badge">' + escapeWorkflowText(statusText) + '</span>');
        rows.push('<div class="workflow-profile-actions">');
        if (!isActive && profile.complete) {
          rows.push('<button type="button" class="ghost-action mini-button" data-workflow-action="activate" data-task-type="' + taskType +
            '" data-profile-id="' + escapeWorkflowText(profile.id) + '"' + activationDisabledAttribute + '>设为当前</button>');
        }
        rows.push('<button type="button" class="ghost-action mini-button" data-workflow-action="edit-open" data-task-type="' + taskType +
          '" data-profile-id="' + escapeWorkflowText(profile.id) + '"' + disabledAttribute + '>编辑</button>');
        rows.push('<button type="button" class="ghost-action mini-button" data-workflow-action="copy" data-task-type="' + taskType +
          '" data-profile-id="' + escapeWorkflowText(profile.id) + '"' + disabledAttribute + '>复制</button>');
        if (canDelete) {
          rows.push('<button type="button" class="ghost-action mini-button danger-action" data-workflow-action="delete" data-task-type="' + taskType +
            '" data-profile-id="' + escapeWorkflowText(profile.id) + '"' + disabledAttribute + '>删除</button>');
        }
        rows.push('</div></div>');
      });
      rows.push('</div>');
    }
    manager.innerHTML = rows.join("");
  }

  function completeWorkflowMutation(taskType, message) {
    state.workflowProfileMutationBusy = false;
    state.workflowProfileEditor = null;
    renderWorkflowTaskTabs();
    return loadWorkflowProfiles(taskType).then(function () {
      syncSettingsRefreshController();
      setStatus(message);
    });
  }

  function readModelConfigurationDraft() {
    function value(selector) {
      var input = document.querySelector(selector);
      return input ? String(input.value || "").trim() : "";
    }
    return {
      name: value("[data-workflow-editor-name]"),
      note: value("[data-workflow-editor-note]"),
      accessMethod: "workflow_platform",
      serviceBaseUrl: value("[data-workflow-editor-url]"),
      modelName: "",
      temperature: "",
      maxOutputTokens: "",
      contextWindowTokens: "40000",
      apiKey: value("[data-workflow-editor-key]"),
      apiKeyConfirm: value("[data-workflow-editor-key-confirm]")
    };
  }

  function modelConfigurationPayload(taskType, draft) {
    return {
      taskType: taskType,
      name: draft.name,
      note: draft.note,
      accessMethod: "workflow_platform",
      serviceBaseUrl: draft.serviceBaseUrl,
      modelName: "",
      temperature: null,
      maxOutputTokens: null,
      contextWindowTokens: 40000
    };
  }

  function validateModelConfigurationDraft(draft) {
    var base = getWorkflowProfileDraftValidation(draft, false);
    if (!base.valid) {
      return base;
    }
    if (draft.apiKey !== draft.apiKeyConfirm) {
      return { valid: false, message: "两次输入的 API Key 不一致。" };
    }
    return { valid: true, message: "" };
  }

  function saveModelConfigurationKey(configurationId, draft) {
    if (!draft.apiKey) {
      return Promise.resolve();
    }
    return request("/provider/model-configurations/" + encodeURIComponent(configurationId) + "/api-key", {
      apiKey: draft.apiKey
    });
  }

  function validateSavedFormatSemanticConfiguration(taskType, configurationId) {
    if (taskType !== "word.format_review") {
      return Promise.resolve({ validated: false, skipped: true });
    }
    return request("/provider/model-configurations/" + encodeURIComponent(configurationId) + "/validate", {})
      .then(function () {
        return { validated: true, skipped: false };
      })
      .catch(function (error) {
        return { validated: false, skipped: false, error: error };
      });
  }

  function failWorkflowMutation(taskType, prefix, error, preserveEditor) {
    setWorkflowProfileMutationBusy(false);
    state.workflowProfileSelections[taskType] = getWorkflowProfileData(taskType).activeProfileId || "";
    setStatus(prefix + "：" + describeFetchError(error));
    renderWorkflowProfileStrip();
    if (!preserveEditor) {
      renderWorkflowProfileManager();
    }
  }

  function createWorkflowProfile(taskType) {
    var activateInput = document.querySelector("[data-workflow-editor-activate]");
    var draft = readModelConfigurationDraft();
    var validation = validateModelConfigurationDraft(draft);
    var activate = getShouldActivateNewWorkflowProfile(
      getWorkflowProfileData(taskType),
      Boolean(activateInput && activateInput.checked)
    );
    if (!validation.valid) {
      setStatus(validation.message || "请检查工作流配置。");
      return;
    }
    setWorkflowProfileMutationBusy(true);
    request("/provider/model-configurations", modelConfigurationPayload(taskType, draft))
      .then(function (body) {
        var configuration = body && body.data && body.data.configuration || {};
        return saveModelConfigurationKey(configuration.id, draft).then(function () {
          return validateSavedFormatSemanticConfiguration(taskType, configuration.id).then(function (validation) {
          var complete = Boolean(draft.serviceBaseUrl && draft.apiKey &&
            (draft.accessMethod !== "direct_model" || draft.modelName));
          if (activate && complete) {
            return request("/provider/model-configurations/" + encodeURIComponent(configuration.id) + "/activate", {})
              .then(function () { return validation; });
          }
          return validation;
          });
        });
      }).then(function (validation) {
      var message = "工作流配置已保存。";
      if (validation && validation.skipped === false && !validation.validated) {
        message += "格式语义协议验证未通过，当前仅运行确定性规则。" +
          (validation.error ? "原因：" + describeFetchError(validation.error) : "");
      }
      return completeWorkflowMutation(taskType, message);
    }).catch(function (error) {
      failWorkflowMutation(taskType, "保存工作流配置失败", error, true);
    });
  }

  function saveWorkflowProfileEdit(profileId, taskType) {
    var draft = readModelConfigurationDraft();
    var validation = validateModelConfigurationDraft(draft);
    var metadataSaved = false;
    if (!validation.valid) {
      setStatus(validation.message || "请检查工作流配置。");
      return;
    }
    setWorkflowProfileMutationBusy(true);
    request("/provider/model-configurations/" + encodeURIComponent(profileId),
      modelConfigurationPayload(taskType, draft), { method: "PATCH" }).then(function () {
      metadataSaved = true;
      return saveModelConfigurationKey(profileId, draft).then(function () {
        return validateSavedFormatSemanticConfiguration(taskType, profileId).then(function (validation) {
          var message = "工作流配置已保存。";
          if (validation && validation.skipped === false && !validation.validated) {
            message += "格式语义协议验证未通过，当前仅运行确定性规则。" +
              (validation.error ? "原因：" + describeFetchError(validation.error) : "");
          }
          return completeWorkflowMutation(taskType, message);
        });
      });
    }).catch(function (error) {
      if (!metadataSaved) {
        failWorkflowMutation(taskType, "保存工作流配置失败", error, true);
        return;
      }
      state.workflowProfileMutationBusy = false;
      state.workflowProfileEditor = null;
      renderWorkflowTaskTabs();
      return loadWorkflowProfiles(taskType).then(function () {
        syncSettingsRefreshController();
        setStatus("工作流配置已保存，但 API Key 更换失败：" + describeFetchError(error));
      });
    });
  }

  function activateWorkflowProfile(profileId, arg2, arg3) {
    var taskType;
    var previousProfileId;
    if (typeof arg2 === "string" && (arg2.indexOf("word.") === 0 || arg2.indexOf("excel.") === 0 || arg2.indexOf("ppt.") === 0)) {
      taskType = arg2;
      previousProfileId = arg3;
    } else if (typeof arg3 === "string" && (arg3.indexOf("word.") === 0 || arg3.indexOf("excel.") === 0 || arg3.indexOf("ppt.") === 0)) {
      taskType = arg3;
      previousProfileId = arg2;
    } else {
      taskType = arg2 || getCurrentWorkflowTaskType();
      previousProfileId = arg3;
    }
    var data = getWorkflowProfileData(taskType);
    var profile = getWorkflowProfileById(taskType, profileId);
    var decision;
    previousProfileId = typeof previousProfileId === "string" ? previousProfileId : (data.activeProfileId || "");
    decision = helpers.evaluateTaskModelConfigSwitch
      ? helpers.evaluateTaskModelConfigSwitch({
        requestedId: profileId,
        previousId: previousProfileId,
        busy: state.modelTaskBusy || isWorkflowInteractionBlocked(),
        mutationBusy: state.workflowProfileMutationBusy,
        profileComplete: Boolean(profile && profile.complete)
      })
      : {
        allowed: Boolean(profileId && profileId !== previousProfileId && profile && profile.complete && !state.modelTaskBusy && !state.workflowProfileMutationBusy && !isWorkflowInteractionBlocked()),
        reason: "activate",
        nextSelectionId: profileId,
        restoreFocus: false
      };
    if (!decision.allowed) {
      state.workflowProfileSelections[taskType] = decision.nextSelectionId;
      renderWorkflowProfileStrip();
      if (decision.reason === "incomplete") {
        setStatus("该模型配置不完整，无法切换。");
      } else if (decision.reason === "busy") {
        setStatus(state.documentReviewJobId ?
          "文档审查正在运行，暂不能切换模型配置。" :
          "当前正忙，请稍后切换模型配置。");
      }
      if (decision.restoreFocus) {
        focusTaskModelConfigTrigger();
      }
      return Promise.resolve();
    }
    state.taskModelConfigStatusByTask[taskType] = "";
    state.workflowProfileSelections[taskType] = profileId;
    if (typeof invalidateWorkflowProfileRequests === "function") {
      invalidateWorkflowProfileRequests(taskType);
    }
    setWorkflowProfileMutationBusy(true);
    var isDirectService = String(profileId || "").startsWith("direct_svc_");
    var activationPromise = isDirectService
      ? request("/provider/direct-services/" + encodeURIComponent(profileId) + "/activate", {
        taskType: taskType,
        taskModelSelection: {
          serviceId: profileId,
          modelName: "",
          customModel: false,
          temperature: null,
          maxOutputTokens: null,
          contextWindowTokens: null
        }
      })
      : request("/provider/model-configurations/" + encodeURIComponent(profileId) + "/activate", {});
    return activationPromise
      .then(function (body) {
        if (isDirectService) {
          state.workflowProfileSelections[taskType] = profileId;
          state.taskModelConfigStatusByTask[taskType] = "";
          if (body && body.data && body.data.taskModelSelection) {
            state.taskModelSelections[taskType] = body.data.taskModelSelection;
          }
          state.taskApiKeys = state.taskApiKeys || {};
          state.taskApiKeys[taskType] = Object.assign({}, state.taskApiKeys[taskType] || {}, {
            activeProfileId: profileId,
            activeConfigurationId: profileId,
            accessMethod: "direct_model",
            serviceId: profileId,
            configured: true,
            taskKeyConfigured: true
          });
        } else {
          var nextData = normalizeWorkflowProfileData(body && body.data || {}, taskType);
          if (typeof invalidateWorkflowProfileRequests === "function") {
            invalidateWorkflowProfileRequests(taskType);
          }
          state.workflowProfiles[taskType] = nextData;
          state.workflowProfileSelections[taskType] = nextData.activeProfileId || profileId;
          state.taskModelConfigStatusByTask[taskType] = "";
          state.taskApiKeys = state.taskApiKeys || {};
          state.taskApiKeys[taskType] = Object.assign({}, state.taskApiKeys[taskType] || {}, {
            activeProfileId: nextData.activeProfileId || profileId,
            activeConfigurationId: nextData.activeProfileId || profileId,
            accessMethod: String(profile && profile.accessMethod || "workflow_platform"),
            serviceId: "",
            configured: Boolean(profile && profile.complete),
            taskKeyConfigured: Boolean(profile && profile.keyConfigured)
          });
        }
        var dsRefresh = typeof loadDirectServices === "function" ? loadDirectServices() : Promise.resolve();
        return Promise.all([
          loadWorkflowProfiles(taskType),
          dsRefresh
        ]).then(function () {
          state.workflowProfileMutationBusy = false;
          renderWorkflowProfileStrip();
          renderWorkflowTaskTabs();
          if (typeof renderTaskModelSelectionSection === "function") {
            renderTaskModelSelectionSection();
          }
          if (taskType === "word.document_review" && typeof renderFullDocumentReviewEntry === "function") {
            renderFullDocumentReviewEntry();
          }
          renderModelInterfaceState(state.modelInterfaceDetectable);
          setStatus("模型配置已切换，从下一次任务开始生效。");
        }).catch(function (refreshError) {
          state.workflowProfileMutationBusy = false;
          renderWorkflowProfileStrip();
          renderWorkflowTaskTabs();
          renderWorkflowProfileManager();
          if (typeof renderTaskModelSelectionSection === "function") {
            renderTaskModelSelectionSection();
          }
          if (taskType === "word.document_review" && typeof renderFullDocumentReviewEntry === "function") {
            renderFullDocumentReviewEntry();
          }
          renderModelInterfaceState(state.modelInterfaceDetectable);
          setStatus("模型配置已激活，但刷新最新列表失败：" + describeFetchError(refreshError));
        });
      })
      .catch(function (error) {
        var previousProfile = typeof getWorkflowProfileById === "function"
          ? getWorkflowProfileById(taskType, previousProfileId)
          : (typeof findWorkflowProfile === "function" ? findWorkflowProfile(previousProfileId, taskType) : null);
        var previousEntry = helpers.formatTaskModelConfigEntry
          ? helpers.formatTaskModelConfigEntry(previousProfile, { status: "error" })
          : { visibleText: helpers.getActiveWorkflowProfileName ? helpers.getActiveWorkflowProfileName(getWorkflowProfileData(taskType)) : "尚未配置" };
        var rolled = helpers.rollbackTaskModelConfigSwitch
          ? helpers.rollbackTaskModelConfigSwitch({
            previousId: previousProfileId,
            previousLabel: previousEntry.visibleText
          })
          : {
            selectionId: previousProfileId,
            statusText: "切换模型配置失败，已恢复至“" + previousEntry.visibleText + "”",
            restoreFocus: true
          };
        var stillOnOriginatingTask = getCurrentWorkflowTaskType() === taskType;
        state.workflowProfileMutationBusy = false;
        state.workflowProfileSelections[taskType] = rolled.selectionId;
        state.taskModelConfigStatusByTask[taskType] = "error";
        renderWorkflowProfileStrip();
        renderWorkflowTaskTabs();
        renderWorkflowProfileManager();
        if (!stillOnOriginatingTask) {
          return;
        }
        setStatus("切换模型配置失败：" + describeFetchError(error));
        setNodeTextIfChanged(byId("workflow-switch-feedback"), rolled.statusText);
        if (rolled.restoreFocus) {
          focusTaskModelConfigTrigger();
        }
      });
  }

  function deleteWorkflowProfile(profileId, taskType) {
    var data = getWorkflowProfileData(taskType);
    var profile = getWorkflowProfileById(taskType, profileId);
    if (!canDeleteWorkflowProfile(profile, data.activeProfileId)) {
      setStatus("当前工作流配置不可删除，请先切换到其他工作流配置。");
      return;
    }
    if (window.confirm && !window.confirm("确认删除工作流配置“" + profile.name + "”？删除后无法恢复其 API Key。")) {
      return;
    }
    setWorkflowProfileMutationBusy(true);
    request("/provider/model-configurations/" + encodeURIComponent(profileId), null, { method: "DELETE" })
      .then(function () {
        return completeWorkflowMutation(taskType, "工作流配置“" + profile.name + "”已删除。");
      })
      .catch(function (error) {
        failWorkflowMutation(taskType, "删除工作流配置失败", error);
      });
  }

  function copyModelConfiguration(profileId, taskType) {
    setWorkflowProfileMutationBusy(true);
    request("/provider/model-configurations/" + encodeURIComponent(profileId) + "/copy", {
      targetTaskType: taskType
    }).then(function () {
      return completeWorkflowMutation(taskType, "工作流配置副本已创建，请检查后再启用。");
    }).catch(function (error) {
      failWorkflowMutation(taskType, "复制工作流配置失败", error);
    });
  }

  function validateModelConfiguration(profileId, taskType) {
    if (state.workflowProfileEditor && state.workflowProfileEditor.dirty) {
      setStatus("请先保存工作流配置，再执行验证调用。");
      return;
    }
    if (window.confirm && !window.confirm("验证调用会向模型后台发送一条内置测试请求，是否继续？")) {
      return;
    }
    setWorkflowProfileMutationBusy(true);
    setStatus("正在验证工作流配置，模型响应较慢时请耐心等待...");
    request("/provider/model-configurations/" + encodeURIComponent(profileId) + "/validate", {})
      .then(function (body) {
        var duration = body && body.data ? Number(body.data.durationMs || 0) : 0;
        state.workflowProfileMutationBusy = false;
        state.workflowProfileEditor.dirty = false;
        return loadWorkflowProfiles(taskType).then(function () {
          var refreshedProfile = getWorkflowProfileById(taskType, profileId);
          if (!refreshedProfile) {
            state.workflowProfileEditor = null;
            renderWorkflowProfileManager();
            setStatus("工作流配置已验证，但刷新后未找到该配置，请重新进入设置。");
            return;
          }
          state.workflowProfileEditor = {
            mode: "edit",
            taskType: taskType,
            profileId: profileId,
            dirty: false,
            originalAccessMethod: refreshedProfile.accessMethod,
            currentAccessMethod: refreshedProfile.accessMethod
          };
          renderWorkflowProfileManager();
          setStatus("验证成功，用时 " + (duration / 1000).toFixed(1) + " 秒。");
        });
      }).catch(function (error) {
        setWorkflowProfileMutationBusy(false);
        setStatus("验证失败：" + describeFetchError(error));
        renderWorkflowProfileManager();
      });
  }

  function scheduleWorkflowProfileActivation(profileId, taskType, previousProfileId) {
    cancelWorkflowProfileActivation();
    state.workflowProfileActivationTimer = window.setTimeout(function () {
      state.workflowProfileActivationTimer = null;
      activateWorkflowProfile(profileId, taskType, previousProfileId);
    }, 0);
  }

  function cancelWorkflowProfileActivation() {
    if (state.workflowProfileActivationTimer !== null) {
      window.clearTimeout(state.workflowProfileActivationTimer);
      state.workflowProfileActivationTimer = null;
    }
  }

  function handleWorkflowProfileSelectionChange(event) {
    var taskType = getCurrentWorkflowTaskType();
    var data = getWorkflowProfileData(taskType);
    var previousProfileId = data.activeProfileId || state.workflowProfileSelections[taskType] || "";
    var profileId = event.target.value;
    if (!profileId || profileId === previousProfileId) {
      cancelWorkflowProfileActivation();
      state.workflowProfileSelections[taskType] = previousProfileId;
      renderWorkflowProfileStrip();
      return;
    }
    scheduleWorkflowProfileActivation(profileId, taskType, previousProfileId);
  }

  function handleWorkflowTaskTabClick(event) {
    var taskType = event.target.getAttribute("data-workflow-task-tab");
    if (!taskType || state.workflowProfileMutationBusy) {
      return;
    }
    if (taskType === getSettingsWorkflowTaskType()) {
      return;
    }
    if (!confirmWorkflowEditorDiscard()) {
      return;
    }
    state.settingsWorkflowTaskType = taskType;
    state.workflowProfileEditor = null;
    syncSettingsRefreshController();
    renderWorkflowTaskTabs();
    renderWorkflowProfileManager();
    renderTaskModelSelectionSection();
    if (!state.workflowProfiles[taskType]) {
      loadWorkflowProfiles(taskType);
    }
  }

  function handleWorkflowProfileManagerAction(event) {
    var target = event.target;
    var action = target.getAttribute("data-workflow-action");
    var taskType = target.getAttribute("data-task-type") || "";
    var profileId = target.getAttribute("data-profile-id") || "";
    if (!action || state.workflowProfileMutationBusy) {
      return;
    }
    taskType = taskType || getSettingsWorkflowTaskType();
    if (action === "create-open") {
      if (getWorkflowProfileData(taskType).loadError) {
        setStatus("模型配置读取失败，请先重新读取。");
        return;
      }
      state.workflowProfileEditor = {
        mode: "create", taskType: taskType, profileId: "", dirty: false,
        originalAccessMethod: "workflow_platform", currentAccessMethod: "workflow_platform"
      };
      syncSettingsRefreshController();
      renderWorkflowProfileManager();
    } else if (action === "edit-open") {
      var editingProfile = getWorkflowProfileById(taskType, profileId);
      state.workflowProfileEditor = {
        mode: "edit", taskType: taskType, profileId: profileId, dirty: false,
        originalAccessMethod: editingProfile ? editingProfile.accessMethod : "workflow_platform",
        currentAccessMethod: editingProfile ? editingProfile.accessMethod : "workflow_platform"
      };
      syncSettingsRefreshController();
      renderWorkflowProfileManager();
    } else if (action === "editor-cancel") {
      if (!confirmWorkflowEditorDiscard()) {
        return;
      }
      state.workflowProfileEditor = null;
      renderWorkflowProfileManager();
      syncSettingsRefreshController();
    } else if (action === "reload") {
      setStatus("正在重新读取模型配置...");
      loadWorkflowProfiles(taskType);
    } else if (action === "create-save") {
      createWorkflowProfile(taskType);
    } else if (action === "activate") {
      activateWorkflowProfile(profileId, taskType, getWorkflowProfileData(taskType).activeProfileId || "");
    } else if (action === "edit-save") {
      saveWorkflowProfileEdit(profileId, taskType);
    } else if (action === "delete") {
      deleteWorkflowProfile(profileId, taskType);
    } else if (action === "copy") {
      copyModelConfiguration(profileId, taskType);
    } else if (action === "validate") {
      validateModelConfiguration(profileId, taskType);
    }
  }

  var setWorkflowMutationBusy = setWorkflowProfileMutationBusy;

  function formatDirectServiceCatalogStatus(service) {
    var catalog = helpers.getDirectServiceCatalogState
      ? helpers.getDirectServiceCatalogState(service)
      : { status: "unavailable", models: [] };
    var count = catalog.models ? catalog.models.length : 0;
    var errorText = catalog.lastError && (catalog.lastError.message || catalog.lastError.code);
    if (catalog.status === "available" && catalog.cacheStatus === "valid") {
      if (catalog.fetchStatus === "error" && errorText) {
        return "目录刷新失败，继续使用 " + count + " 个缓存模型；" + errorText;
      }
      return "目录有效：" + count + " 个模型" + (catalog.fetchedAt ? "，获取于 " + catalog.fetchedAt : "");
    }
    if (catalog.status === "expired") {
      return "目录已过期，请刷新" + (errorText ? "；最近错误：" + errorText : "");
    }
    if (catalog.status === "empty") {
      return "目录为空，请检查服务能力" + (errorText ? "；最近错误：" + errorText : "");
    }
    return "目录不可用，请刷新" + (errorText ? "；最近错误：" + errorText : "");
  }

  function renderLegacyDirectPendingStatus() {
    var node = byId("legacy-direct-pending-status");
    if (!node) return;
    var pending = state.legacyDirectPending || {};
    var count = Number(pending.pendingConfigurationCount || 0);
    node.hidden = count < 1;
    setNodeTextIfChanged(node, count > 0
      ? "发现 " + count + " 份待处理旧直连配置。请由管理员通过迁移管理接口处理。"
      : "");
  }

  function loadDirectServices(configRefreshRequestId, requestOptions, directServiceOperationId) {
    return Promise.all([
      request("/provider/direct-services", null, requestOptions),
      request("/provider/task-model-selections?host=word", null, requestOptions)
    ]).then(function (results) {
      var dsBody = results[0];
      var tmsBody = results[1];
      if (configRefreshRequestId && state.configRefreshRequestId !== configRefreshRequestId) {
        return { superseded: true };
      }
      if (directServiceOperationId && state.directServiceOperationId !== directServiceOperationId) {
        return { superseded: true };
      }
      state.directServices = (dsBody && dsBody.data && dsBody.data.directServices) || [];
      state.legacyDirectPending = (dsBody && dsBody.data && dsBody.data.legacyDirectPending) || {};
      if (typeof renderLegacyDirectPendingStatus === "function") {
        renderLegacyDirectPendingStatus();
      }
      var selectionsMap = {};
      var rawSelections = (tmsBody && tmsBody.data && (tmsBody.data.taskModelSelections || tmsBody.data.selections)) || [];
      if (Array.isArray(rawSelections)) {
        rawSelections.forEach(function (sel) {
          if (sel && sel.taskType) {
            selectionsMap[sel.taskType] = sel;
          }
        });
      } else if (rawSelections && typeof rawSelections === "object") {
        selectionsMap = rawSelections;
      }
      state.taskModelSelections = selectionsMap;
      TASK_API_KEY_DEFS.forEach(function (definition) {
        var taskType = definition.taskType;
        var taskStatus = state.taskApiKeys && state.taskApiKeys[taskType];
        if (taskStatus && taskStatus.accessMethod === "direct_model" && taskStatus.activeProfileId) {
          state.workflowProfileSelections[taskType] = taskStatus.activeProfileId;
        }
      });
      renderDirectServicesList();
      renderTaskModelSelectionSection();
      renderWorkflowProfileStrip();
      renderWorkflowProfileManager();
      return { success: true };
    }).catch(function (error) {
      if (configRefreshRequestId && state.configRefreshRequestId !== configRefreshRequestId) {
        return { superseded: true };
      }
      if (directServiceOperationId && state.directServiceOperationId !== directServiceOperationId) {
        return { superseded: true };
      }
      renderDirectServicesList();
      renderTaskModelSelectionSection();
      throw error;
    });
  }

  function renderDirectServicesList() {
    var list = byId("direct-services-list");
    var btnNew = byId("btn-new-direct-service");
    var rows = [];
    if (!list) {
      return;
    }
    if (btnNew) {
      btnNew.disabled = (state.directServices || []).length >= 5;
    }
    if (!state.directServices || state.directServices.length === 0) {
      list.innerHTML = '<p class="direct-services-empty-state">尚未建立直连模型配置。</p>';
      return;
    }
    state.directServices.forEach(function (svc) {
      var id = escapeWorkflowText(svc.id);
      var modelText = svc.defaultModel ? (" · 默认模型：" + escapeWorkflowText(svc.defaultModel)) : "";
      var catalogText = typeof formatDirectServiceCatalogStatus === "function"
        ? formatDirectServiceCatalogStatus(svc)
        : (svc.modelList && svc.modelList.length ? ("目录已有 " + svc.modelList.length + " 个模型") : "目录未获取");
      rows.push('<div class="workflow-profile-list-row" data-direct-service-id="' + id + '">');
      rows.push('<div class="workflow-profile-copy">');
      rows.push('<div class="workflow-profile-title"><strong>' + escapeWorkflowText(svc.name) + '</strong>');
      rows.push('<span class="provider-badge">' + (svc.keyConfigured ? "已配Key" : "未配Key") + '</span></div>');
      rows.push('<p class="workflow-profile-note">' + escapeWorkflowText(svc.serviceBaseUrl || "未配置URL") + modelText + '</p>');
      rows.push('<p class="workflow-profile-note">' + escapeWorkflowText(catalogText) + '</p>');
      rows.push('</div>');
      rows.push('<div class="workflow-profile-actions">');
      rows.push('<button type="button" class="ghost-action mini-button" data-direct-action="edit" data-direct-id="' + id + '">编辑</button>');
      rows.push('<button type="button" class="ghost-action mini-button danger-action" data-direct-action="delete" data-direct-id="' + id + '">删除</button>');
      rows.push('</div></div>');
    });
    list.innerHTML = rows.join("");
  }

  function openDirectServiceEditor(mode, serviceId) {
    var isCreate = mode === "create";
    var svc = isCreate ? null : findDirectService(serviceId);
    var title = byId("direct-service-editor-title");
    var nameInput = byId("direct-service-name");
    var urlInput = byId("direct-service-url");
    var keyInput = byId("direct-service-key");
    var keyLabel = byId("direct-service-key-label");
    var keyStatus = byId("direct-service-key-status");
    var defaultModelInput = byId("direct-service-default-model");
    var modelsStatus = byId("direct-service-models-status");
    var btnRefresh = byId("btn-refresh-direct-service-models");
    var btnValidate = byId("btn-validate-direct-service");
    var validationStatus = byId("direct-service-validation-status");
    var errorBox = byId("direct-service-editor-error");

    if (isCreate && (state.directServices || []).length >= 5) {
      setStatus("最多只能保存 5 份直连模型配置。");
      return;
    }
    if (!isCreate && !svc) {
      setStatus("未找到指定的直连服务。");
      return;
    }

    state.directServiceOperationId = Number(state.directServiceOperationId || 0) + 1;
    state.directServiceEditor = {
      open: true,
      mode: mode,
      serviceId: isCreate ? "" : svc.id,
      revision: isCreate ? 1 : svc.revision,
      dirty: false
    };

    if (title) {
      title.textContent = isCreate ? "新建直连模型配置" : "编辑直连模型配置";
    }
    if (nameInput) {
      nameInput.value = isCreate ? "" : svc.name;
    }
    if (urlInput) {
      urlInput.value = isCreate ? "" : svc.serviceBaseUrl;
    }
    if (keyInput) {
      keyInput.value = "";
      keyInput.placeholder = isCreate ? "输入 API Key" : "留空保持原 API Key 不变";
    }
    if (keyLabel) {
      keyLabel.textContent = isCreate ? "API Key（仅需录入一次）" : "更换 API Key";
    }
    if (keyStatus) {
      keyStatus.textContent = isCreate ? "" : (svc.keyConfigured ? "已配置（留空保持不变）" : "未配置");
    }
    renderDirectServiceDefaultModelOptions(isCreate ? null : svc);
    if (modelsStatus) {
      modelsStatus.textContent = !isCreate && typeof formatDirectServiceCatalogStatus === "function"
        ? formatDirectServiceCatalogStatus(svc)
        : (!isCreate && svc.modelList && svc.modelList.length
          ? ("已获取 " + svc.modelList.length + " 个模型")
          : "目录未获取");
    }
    if (btnRefresh) {
      btnRefresh.disabled = isCreate;
    }
    if (btnValidate) {
      btnValidate.disabled = isCreate;
    }
    if (validationStatus) {
      validationStatus.textContent = "";
    }
    if (errorBox) {
      errorBox.textContent = "";
    }
    var urlImpactNode = byId("direct-service-url-impact");
    if (urlImpactNode) {
      urlImpactNode.hidden = true;
      urlImpactNode.textContent = "";
    }
    var btnClearKey = byId("btn-clear-direct-service-key");
    if (btnClearKey) {
      btnClearKey.hidden = isCreate || !svc.keyConfigured;
      btnClearKey.disabled = false;
    }

    byId("direct-service-editor-view").hidden = false;
    byId("direct-services-list").hidden = true;
    byId("btn-new-direct-service").hidden = true;
    if (nameInput && typeof nameInput.focus === "function") {
      nameInput.focus();
    }
  }

  function renderDirectServiceDefaultModelOptions(service) {
    var select = byId("direct-service-default-model");
    var models = service && Array.isArray(service.modelList) ? service.modelList : [];
    var current = service ? String(service.defaultModel || "") : "";
    var options = ['<option value="">不设置默认模型</option>'];
    if (current && models.indexOf(current) < 0) {
      options.push('<option value="' + escapeWorkflowText(current) + '">' + escapeWorkflowText(current) + '（当前目录不可用）</option>');
    }
    models.forEach(function (model) {
      options.push('<option value="' + escapeWorkflowText(model) + '">' + escapeWorkflowText(model) + '</option>');
    });
    if (select) {
      select.innerHTML = options.join("");
      select.value = current;
      select.disabled = !service;
    }
  }

  function closeDirectServiceEditor() {
    state.directServiceOperationId = Number(state.directServiceOperationId || 0) + 1;
    state.directServiceEditor.open = false;
    var keyInput = byId("direct-service-key");
    if (keyInput) {
      keyInput.value = "";
    }
    if (state.workflowProfileMutationBusy) {
      if (typeof setWorkflowMutationBusy === "function") {
        setWorkflowMutationBusy(false);
      } else {
        state.workflowProfileMutationBusy = false;
        if (typeof syncWorkflowProfileManagerBusyState === "function") {
          syncWorkflowProfileManagerBusyState();
        }
      }
    }
    byId("direct-service-editor-view").hidden = true;
    byId("direct-services-list").hidden = false;
    byId("btn-new-direct-service").hidden = false;
    byId("direct-service-editor-error").textContent = "";
    var urlImpactNode = byId("direct-service-url-impact");
    if (urlImpactNode) {
      urlImpactNode.hidden = true;
      urlImpactNode.textContent = "";
    }
  }

  function updateDirectServiceUrlImpact() {
    var editor = state.directServiceEditor || {};
    if (editor.mode !== "edit" || !editor.serviceId) {
      var node = byId("direct-service-url-impact");
      if (node) {
        node.hidden = true;
        node.textContent = "";
      }
      return;
    }
    var svc = findDirectService(editor.serviceId);
    var urlInput = byId("direct-service-url");
    var urlImpactNode = byId("direct-service-url-impact");
    if (!svc || !urlInput || !urlImpactNode) {
      return;
    }
    var res = helpers.evaluateDirectServiceUrlImpact
      ? helpers.evaluateDirectServiceUrlImpact(svc, urlInput.value)
      : { isModified: false, warning: "" };
    if (res.isModified && res.warning) {
      urlImpactNode.textContent = res.warning;
      urlImpactNode.hidden = false;
    } else {
      urlImpactNode.hidden = true;
      urlImpactNode.textContent = "";
    }
  }

  function clearDirectServiceApiKey() {
    var editor = state.directServiceEditor || {};
    var serviceId = editor.serviceId;
    var revision = editor.revision;
    var keyInput = byId("direct-service-key");
    var keyStatus = byId("direct-service-key-status");
    var btnClear = byId("btn-clear-direct-service-key");
    var errorBox = byId("direct-service-editor-error");
    if (!serviceId || state.workflowProfileMutationBusy) {
      return;
    }
    setWorkflowMutationBusy(true);
    request("/provider/direct-services/" + encodeURIComponent(serviceId) + "/api-key?expectedRevision=" + encodeURIComponent(revision), null, {
      method: "DELETE"
    }).then(function (body) {
      setWorkflowMutationBusy(false);
      var svc = (body && body.data && body.data.directService) || {};
      var nextRev = svc.revision || (revision + 1);
      if (state.directServiceEditor && state.directServiceEditor.serviceId === serviceId) {
        state.directServiceEditor.revision = nextRev;
      }
      if (keyInput) {
        keyInput.value = "";
        keyInput.placeholder = "输入新 API Key";
      }
      if (keyStatus) {
        keyStatus.textContent = "未配置";
      }
      if (btnClear) {
        btnClear.hidden = true;
      }
      return loadDirectServices().then(function () {
        setStatus("API Key 已清除。");
      });
    }).catch(function (error) {
      setWorkflowMutationBusy(false);
      if (helpers.isDirectServiceRevisionConflict && helpers.isDirectServiceRevisionConflict(error)) {
        if (errorBox) {
          errorBox.textContent = "服务已被其他操作修改（版本冲突），已停止清除 Key。请刷新后重新编辑，本次修改未自动合并。";
        }
      } else if (errorBox) {
        errorBox.textContent = "清除 API Key 失败：" + describeFetchError(error);
      }
    });
  }

  function saveDirectServiceEditor() {
    if (state.workflowProfileMutationBusy) {
      return;
    }
    var isCreate = state.directServiceEditor.mode === "create";
    var serviceId = state.directServiceEditor.serviceId;
    var revision = state.directServiceEditor.revision;
    var name = (byId("direct-service-name").value || "").trim();
    var url = (byId("direct-service-url").value || "").trim();
    var key = (byId("direct-service-key").value || "").trim();
    var defaultModel = (byId("direct-service-default-model").value || "").trim();
    var errorBox = byId("direct-service-editor-error");

    var draft = {
      name: name,
      serviceBaseUrl: url,
      apiKey: key,
      key: key,
      isNew: isCreate,
      defaultModel: defaultModel
    };

    var checked = helpers.validateDirectServiceDraft
      ? helpers.validateDirectServiceDraft(draft, state.directServiceEditor.mode)
      : { ok: Boolean(draft.name && draft.serviceBaseUrl && (!isCreate || draft.apiKey)) };

    if (!checked.ok) {
      if (errorBox) {
        errorBox.textContent = checked.message || checked.error || "请检查输入项。";
      }
      return;
    }

    state.directServiceOperationId = Number(state.directServiceOperationId || 0) + 1;
    var operationId = state.directServiceOperationId;
    var editorMode = state.directServiceEditor.mode;
    function isCurrentOperation() {
      return state.directServiceOperationId === operationId &&
        state.directServiceEditor && state.directServiceEditor.open &&
        state.directServiceEditor.mode === editorMode &&
        state.directServiceEditor.serviceId === serviceId;
    }
    function completeSave(message) {
      return loadDirectServices(undefined, undefined, operationId).then(function () {
        if (!isCurrentOperation()) {
          return { superseded: true };
        }
        setWorkflowMutationBusy(false);
        closeDirectServiceEditor();
        setStatus(message);
        return { success: true };
      });
    }
    function failSave(error, prefix) {
      if (!isCurrentOperation()) {
        return { superseded: true };
      }
      setWorkflowMutationBusy(false);
      if (helpers.isDirectServiceRevisionConflict && helpers.isDirectServiceRevisionConflict(error)) {
        if (errorBox) {
          errorBox.textContent = "服务已被其他操作修改（版本冲突），已停止保存。请刷新后重新编辑，本次修改未自动合并。";
        }
      } else if (errorBox) {
        errorBox.textContent = prefix + describeFetchError(error);
      }
      return { failed: true, error: error };
    }
    setWorkflowMutationBusy(true);

    if (isCreate) {
      return request("/provider/direct-services", {
        name: draft.name,
        serviceBaseUrl: draft.serviceBaseUrl,
        defaultModel: draft.defaultModel,
        apiKey: draft.apiKey
      }).then(function (body) {
        if (!isCurrentOperation()) {
          return { superseded: true };
        }
        var created = (body.data && body.data.directService) || body.data;
        var createdId = created.id;
        var createdRev = created.revision || 1;
        var keyPromise = created.keyConfigured
          ? Promise.resolve()
          : request("/provider/direct-services/" + encodeURIComponent(createdId) + "/api-key", {
              apiKey: draft.apiKey,
              expectedRevision: createdRev
            }).catch(function (keyErr) {
              return request("/provider/direct-services/" + encodeURIComponent(createdId) + "?expectedRevision=" + encodeURIComponent(createdRev), null, {
                method: "DELETE"
              }).then(function () {
                throw keyErr;
              }, function () {
                throw keyErr;
              });
            });

        return keyPromise.then(function () {
          if (!isCurrentOperation()) {
            return { superseded: true };
          }
          return completeSave("直连模型配置已新建，模型目录已自动刷新。");
        });
      }).catch(function (error) {
        return failSave(error, "新建直连模型配置失败：");
      });
    }

    return request("/provider/direct-services/" + encodeURIComponent(serviceId), {
      name: draft.name,
      serviceBaseUrl: draft.serviceBaseUrl,
      defaultModel: draft.defaultModel,
      expectedRevision: revision
    }, { method: "PATCH" }).then(function (patchBody) {
      if (!isCurrentOperation()) {
        return { superseded: true };
      }
      var updated = (patchBody.data && patchBody.data.directService) || patchBody.data || {};
      var nextRev = updated.revision || (revision + 1);
      if (!draft.key) {
        return completeSave("直连模型配置已保存。");
      }
      return request("/provider/direct-services/" + encodeURIComponent(serviceId) + "/api-key", {
        apiKey: draft.key,
        expectedRevision: nextRev
      }).then(function () {
        if (!isCurrentOperation()) {
          return { superseded: true };
        }
        return completeSave("直连模型配置与 API Key 已保存。");
      });
    }).catch(function (error) {
      return failSave(error, "保存直连服务失败：");
    });
  }

  function refreshDirectServiceModelsInEditor() {
    var serviceId = state.directServiceEditor.serviceId;
    var revision = state.directServiceEditor.revision;
    var statusNode = byId("direct-service-models-status");
    if (!serviceId || state.workflowProfileMutationBusy) {
      return;
    }
    state.directServiceOperationId = Number(state.directServiceOperationId || 0) + 1;
    var operationId = state.directServiceOperationId;
    setWorkflowMutationBusy(true);
    if (statusNode) {
      statusNode.textContent = "正在刷新模型目录...";
    }
    return request("/provider/direct-services/" + encodeURIComponent(serviceId) + "/refresh-models", {
      expectedRevision: revision
    }).then(function (body) {
      if (state.directServiceOperationId !== operationId || !state.directServiceEditor.open || state.directServiceEditor.serviceId !== serviceId) {
        return { superseded: true };
      }
      var svc = (body && body.data && body.data.directService) || {};
      var models = svc.modelList || (body && body.data && body.data.models) || [];
      var nextRev = svc.revision || (body && body.data && body.data.revision) || (revision + 1);
      if (state.directServiceEditor && state.directServiceEditor.serviceId === serviceId) {
        state.directServiceEditor.revision = nextRev;
      }
      if (statusNode) {
        statusNode.textContent = typeof formatDirectServiceCatalogStatus === "function"
          ? formatDirectServiceCatalogStatus(svc)
          : ("已获取 " + models.length + " 个模型");
      }
      return loadDirectServices(undefined, undefined, operationId).then(function () {
        if (state.directServiceOperationId !== operationId || !state.directServiceEditor.open || state.directServiceEditor.serviceId !== serviceId) {
          return { superseded: true };
        }
        if (state.directServiceEditor && state.directServiceEditor.open && state.directServiceEditor.serviceId === serviceId) {
          var updatedSvc = findDirectService(serviceId);
          if (updatedSvc && updatedSvc.revision) {
            state.directServiceEditor.revision = updatedSvc.revision;
          }
          if (statusNode && updatedSvc && typeof formatDirectServiceCatalogStatus === "function") {
            statusNode.textContent = formatDirectServiceCatalogStatus(updatedSvc);
          }
          if (updatedSvc) {
            renderDirectServiceDefaultModelOptions(updatedSvc);
          }
        }
        setWorkflowMutationBusy(false);
        return { success: true };
      });
    }).catch(function (error) {
      if (state.directServiceOperationId !== operationId || !state.directServiceEditor.open || state.directServiceEditor.serviceId !== serviceId) {
        return { superseded: true };
      }
      setWorkflowMutationBusy(false);
      if (statusNode) {
        statusNode.textContent = "刷新失败：" + describeFetchError(error);
      }
      return { failed: true, error: error };
    });
  }

  function validateDirectService() {
    var editor = state.directServiceEditor || {};
    var serviceId = editor.serviceId;
    var revision = editor.revision;
    var statusNode = byId("direct-service-validation-status");
    var modelsStatus = byId("direct-service-models-status");
    if (!serviceId || state.workflowProfileMutationBusy) {
      if (statusNode) {
        statusNode.textContent = "请先保存直连服务。";
      }
      return;
    }
    if (statusNode) {
      statusNode.textContent = "正在验证服务连接、认证和模型目录（不执行任务调用）...";
    }
    state.directServiceOperationId = Number(state.directServiceOperationId || 0) + 1;
    var operationId = state.directServiceOperationId;
    setWorkflowMutationBusy(true);
    return request("/provider/direct-services/" + encodeURIComponent(serviceId) + "/validate", {
      expectedRevision: revision
    }).then(function (body) {
      if (state.directServiceOperationId !== operationId || !state.directServiceEditor.open || state.directServiceEditor.serviceId !== serviceId) {
        return { superseded: true };
      }
      setWorkflowMutationBusy(false);
      var data = (body && body.data) || {};
      var catalogAvailable = data.modelCatalogAvailable;
      if (catalogAvailable === undefined && data.directService) {
        catalogAvailable = helpers.getDirectServiceCatalogState
          ? helpers.getDirectServiceCatalogState(data.directService).usableForSelection
          : Boolean(data.directService.modelList && data.directService.modelList.length);
      }
      if (modelsStatus && data.directService && typeof formatDirectServiceCatalogStatus === "function") {
        modelsStatus.textContent = formatDirectServiceCatalogStatus(data.directService);
      }
      if (data.directService && data.directService.revision && state.directServiceEditor && state.directServiceEditor.serviceId === serviceId) {
        state.directServiceEditor.revision = data.directService.revision;
      }
      if (data.directService) {
        renderDirectServiceDefaultModelOptions(data.directService);
      }
      if (statusNode) {
        if (catalogAvailable) {
          statusNode.textContent = "服务验证成功；模型目录可用。";
        } else if (data.authenticationVerified === false) {
          statusNode.textContent = "服务可达，但认证未验证；未提供可用模型目录，请检查地址、Key 或刷新。";
        } else {
          statusNode.textContent = "服务可达且认证成功，但未提供可用模型目录，请检查服务是否支持模型目录。";
        }
      }
      if (typeof loadDirectServices === "function") {
        loadDirectServices(undefined, undefined, operationId).catch(function () {});
      }
    }).catch(function (error) {
      if (state.directServiceOperationId !== operationId || !state.directServiceEditor.open || state.directServiceEditor.serviceId !== serviceId) {
        return { superseded: true };
      }
      setWorkflowMutationBusy(false);
      if (statusNode) {
        statusNode.textContent = "服务验证失败：" + describeFetchError(error);
      }
      if (typeof loadDirectServices === "function") {
        loadDirectServices(undefined, undefined, operationId).then(function () {
          var currentSvc = findDirectService(serviceId);
          if (modelsStatus && currentSvc && typeof formatDirectServiceCatalogStatus === "function") {
            modelsStatus.textContent = formatDirectServiceCatalogStatus(currentSvc);
          }
        }).catch(function () {});
      }
    });
  }

  function openDirectServiceDeleteDialog(serviceId) {
    var svc = findDirectService(serviceId);
    var nameNode = byId("direct-service-delete-name");
    var warningNode = byId("direct-service-delete-warning");
    var confirmBtn = byId("btn-confirm-direct-service-delete");
    var dialog = byId("direct-service-delete-dialog");
    if (!svc) {
      return;
    }
    state.directServiceDeleteCandidate = { id: svc.id, name: svc.name, revision: svc.revision };
    if (nameNode) {
      nameNode.textContent = svc.name;
    }
    var evalRes = helpers.evaluateDirectServiceDelete ? helpers.evaluateDirectServiceDelete(svc) : { canDelete: true, message: "" };
    if (warningNode) {
      warningNode.textContent = evalRes.message || "";
    }
    if (confirmBtn) {
      confirmBtn.disabled = !evalRes.canDelete;
    }
    if (dialog) {
      dialog.hidden = false;
    }
  }

  function hideDirectServiceDeleteDialog() {
    state.directServiceDeleteCandidate = null;
    var dialog = byId("direct-service-delete-dialog");
    if (dialog) {
      dialog.hidden = true;
    }
    var confirmBtn = byId("btn-confirm-direct-service-delete");
    if (confirmBtn) {
      confirmBtn.disabled = false;
    }
  }

  function confirmDirectServiceDelete() {
    var candidate = state.directServiceDeleteCandidate;
    if (!candidate || state.workflowProfileMutationBusy) {
      return;
    }
    setWorkflowMutationBusy(true);
    request("/provider/direct-services/" + encodeURIComponent(candidate.id) + "?expectedRevision=" + encodeURIComponent(candidate.revision), null, {
      method: "DELETE"
    }).then(function () {
      hideDirectServiceDeleteDialog();
      return loadDirectServices().then(function () {
        setWorkflowMutationBusy(false);
        setStatus("直连服务“" + candidate.name + "”已删除。");
      });
    }).catch(function (error) {
      hideDirectServiceDeleteDialog();
      setWorkflowMutationBusy(false);
      var errObj = error || {};
      var referenced = errObj.referencedTasks || (errObj.data && errObj.data.referencedTasks);
      if ((errObj.adapterCode || errObj.code) === "DIRECT_SERVICE_IN_USE" || (Array.isArray(referenced) && referenced.length)) {
        var tasksStr = helpers.formatReferencedTasks ? helpers.formatReferencedTasks(referenced) : "";
        setStatus("删除直连服务失败：该服务正被任务使用（" + (tasksStr || "已引用") + "），无法删除。");
      } else {
        setStatus("删除直连服务失败：" + describeFetchError(error));
      }
    });
  }

  function handleDirectServiceAction(event) {
    var action = event.target.getAttribute("data-direct-action");
    var serviceId = event.target.getAttribute("data-direct-id") || "";
    if (!action || state.workflowProfileMutationBusy) {
      return;
    }
    if (action === "edit") {
      openDirectServiceEditor("edit", serviceId);
    } else if (action === "delete") {
      openDirectServiceDeleteDialog(serviceId);
    }
  }

  function renderTaskModelSelectionSection() {
    var section = byId("word-task-direct-service-section");
    var title = byId("word-task-direct-service-title");
    var select = byId("word-task-direct-service-select");
    var paramsDiv = byId("word-task-direct-params");
    var modelSelect = byId("word-task-model-select");
    var tempInput = byId("word-task-temperature");
    var maxOutInput = byId("word-task-max-output");
    var contextInput = byId("word-task-context");
    var costWarning = byId("word-task-model-cost-warning");
    var statusNode = byId("word-task-model-validation-status");

    if (!section || !select) {
      return;
    }

    var currentTask = getSettingsWorkflowTaskType();
    var isSupportedTask = (currentTask === "word.smart_write" || currentTask === "word.smart_imitation" || currentTask === "word.format_review" || currentTask === "word.document_review");
    section.hidden = !isSupportedTask;
    if (!isSupportedTask) {
      return;
    }

    if (title) {
      title.textContent = "接入选择";
    }
    var directServices = state.directServices || [];
    var currentSelection = (state.taskModelSelections && state.taskModelSelections[currentTask]) || null;
    var activeProfileId = getWorkflowProfileData(currentTask).activeProfileId;
    var chosenServiceId = (currentSelection && currentSelection.serviceId) || (String(activeProfileId).startsWith("direct_svc_") ? activeProfileId : "");

    var optionsHtml = ['<option value="">-- 使用工作流或模型配置 --</option>'];
    directServices.forEach(function (svc) {
      var selectedAttr = svc.id === chosenServiceId ? " selected" : "";
      optionsHtml.push('<option value="' + escapeWorkflowText(svc.id) + '"' + selectedAttr + '>' + escapeWorkflowText(svc.name) + '</option>');
    });
    select.innerHTML = optionsHtml.join("");

    if (!chosenServiceId) {
      if (paramsDiv) {
        paramsDiv.hidden = true;
      }
      var noServiceImageModeRow = byId("word-task-image-mode-row");
      if (noServiceImageModeRow) {
        noServiceImageModeRow.hidden = true;
      }
      if (costWarning) {
        costWarning.hidden = true;
      }
      if (statusNode) {
        statusNode.textContent = "";
      }
      return;
    }

    if (paramsDiv) {
      paramsDiv.hidden = false;
    }

    var currentSvc = findDirectService(chosenServiceId);
    var catalog = helpers.getDirectServiceCatalogState
      ? helpers.getDirectServiceCatalogState(currentSvc || {})
      : {
        status: currentSvc && currentSvc.modelList && currentSvc.modelList.length ? "available" : "unavailable",
        cacheStatus: currentSvc && currentSvc.modelList && currentSvc.modelList.length ? "valid" : "empty",
        fetchStatus: "not_attempted",
        models: (currentSvc && currentSvc.modelList) || [],
        manualModelAllowed: true,
        usableForSelection: Boolean(currentSvc && currentSvc.modelList && currentSvc.modelList.length)
      };
    var modelList = catalog.usableForSelection ? catalog.models : [];
    var defaultModel = (currentSvc && currentSvc.defaultModel) || "";
    var currentModel = (currentSelection && currentSelection.modelName) || "";

    var modelOptionsHtml = ['<option value="">继承服务默认模型 (' + (escapeWorkflowText(defaultModel) || "未设置") + ')</option>'];
    var isModelInCatalog = false;
    modelList.forEach(function (m) {
      var sel = m === currentModel ? " selected" : "";
      if (sel) {
        isModelInCatalog = true;
      }
      modelOptionsHtml.push('<option value="' + escapeWorkflowText(m) + '"' + sel + '>' + escapeWorkflowText(m) + '</option>');
    });
    var isCustom = currentSelection && currentSelection.customModel !== undefined
      ? Boolean(currentSelection.customModel)
      : Boolean(currentModel && !isModelInCatalog);
    if (currentModel && !isCustom && !isModelInCatalog) {
      modelOptionsHtml.push('<option value="' + escapeWorkflowText(currentModel) + '" selected disabled>当前模型：' + escapeWorkflowText(currentModel) + '（目录不可用）</option>');
    }
    if (modelSelect) {
      modelSelect.innerHTML = modelOptionsHtml.join("");
    }
    if (tempInput) {
      tempInput.value = currentSelection && currentSelection.temperature !== null && currentSelection.temperature !== undefined ? currentSelection.temperature : "";
    }
    if (maxOutInput) {
      maxOutInput.value = currentSelection && currentSelection.maxOutputTokens !== null && currentSelection.maxOutputTokens !== undefined ? currentSelection.maxOutputTokens : "";
    }
    if (contextInput) {
      contextInput.value = currentSelection && currentSelection.contextWindowTokens ? currentSelection.contextWindowTokens : "";
    }
    var imageModeRow = byId("word-task-image-mode-row");
    var imageModeSelect = byId("word-task-image-input-mode");
    if (imageModeRow) {
      imageModeRow.hidden = (currentTask !== "word.format_review");
    }
    if (imageModeSelect && currentTask === "word.format_review") {
      var currentImageMode = (currentSelection && currentSelection.imageInputMode) || "openai_image_url";
      imageModeSelect.value = currentImageMode;
    }
    if (costWarning) {
      costWarning.hidden = false;
      costWarning.textContent = "验证调用会真实请求模型，可能产生费用并等待服务返回。";
    }
    if (statusNode) {
      var unavailableReason = currentSelection && currentSelection.modelUnavailableReason;
      if (currentSelection && currentSelection.modelAvailable === false && unavailableReason === "catalog_usable") {
        statusNode.textContent = "模型目录当前可用，不能使用高级手填模型；请从目录选择。";
      } else if (currentSelection && currentSelection.modelAvailable === false && unavailableReason === "cache_expired") {
        statusNode.textContent = "模型目录已过期，不能发起新任务；请先刷新目录。";
      } else if (currentSelection && currentSelection.modelAvailable === false && (unavailableReason === "catalog_unavailable" || unavailableReason === "catalog_empty")) {
        statusNode.textContent = "模型目录当前不可用；请先刷新目录。";
      } else if (currentSelection && currentSelection.modelAvailable === false) {
        statusNode.textContent = "当前模型已从最新目录移除，不能发起新任务；请重新选择模型。";
      } else if (catalog.fetchStatus === "error" && catalog.cacheStatus === "valid") {
        statusNode.textContent = "目录刷新失败，当前继续使用有效缓存；请留意最近一次错误。";
      } else {
        statusNode.textContent = "";
      }
    }
  }

  function handleTaskDirectServiceSelectChange() {
    var select = byId("word-task-direct-service-select");
    var serviceId = select ? select.value : "";
    var paramsDiv = byId("word-task-direct-params");
    var modelSelect = byId("word-task-model-select");
    var statusNode = byId("word-task-model-validation-status");
    state.lastValidatedCustomModel = null;

    if (!serviceId) {
      if (paramsDiv) {
        paramsDiv.hidden = true;
      }
      return;
    }
    if (paramsDiv) {
      paramsDiv.hidden = false;
    }
    var svc = findDirectService(serviceId);
    var catalog = helpers.getDirectServiceCatalogState
      ? helpers.getDirectServiceCatalogState(svc || {})
      : { usableForSelection: Boolean(svc && svc.modelList && svc.modelList.length), manualModelAllowed: true };
    var modelList = catalog.usableForSelection ? catalog.models : [];
    var defaultModel = (svc && svc.defaultModel) || "";
    var modelOptionsHtml = ['<option value="">继承服务默认模型 (' + (escapeWorkflowText(defaultModel) || "未设置") + ')</option>'];
    modelList.forEach(function (m) {
      modelOptionsHtml.push('<option value="' + escapeWorkflowText(m) + '">' + escapeWorkflowText(m) + '</option>');
    });
    if (modelSelect) {
      modelSelect.innerHTML = modelOptionsHtml.join("");
    }
    var currentTask = getSettingsWorkflowTaskType();
    var imageModeRow = byId("word-task-image-mode-row");
    var imageModeSelect = byId("word-task-image-input-mode");
    if (imageModeRow) {
      imageModeRow.hidden = (currentTask !== "word.format_review");
    }
    if (imageModeSelect && currentTask === "word.format_review") {
      imageModeSelect.value = "openai_image_url";
    }
    if (statusNode) {
      statusNode.textContent = catalog.fetchStatus === "error" && catalog.cacheStatus === "valid"
        ? "目录刷新失败，当前继续使用有效缓存；请留意最近一次错误。"
        : "";
    }
  }

  function getTaskModelSelectionDraft() {
    var serviceId = (byId("word-task-direct-service-select") && byId("word-task-direct-service-select").value) || "";
    var isCustom = false;
    var modelName = byId("word-task-model-select") ? byId("word-task-model-select").value : "";
    var tempVal = byId("word-task-temperature") ? byId("word-task-temperature").value : "";
    var maxOutVal = byId("word-task-max-output") ? byId("word-task-max-output").value : "";
    var contextVal = byId("word-task-context") ? byId("word-task-context").value : "";

    var taskType = typeof getSettingsWorkflowTaskType === "function" ? getSettingsWorkflowTaskType() : "";

    var draft = {
      serviceId: serviceId,
      modelName: modelName,
      customModel: isCustom,
      temperature: tempVal !== "" ? Number(tempVal) : null,
      maxOutputTokens: maxOutVal !== "" && Number(maxOutVal) !== 0 ? Number(maxOutVal) : null,
      contextWindowTokens: contextVal !== "" && Number(contextVal) !== 0 ? Number(contextVal) : null
    };
    if (taskType === "word.format_review") {
      var imageModeVal = (byId("word-task-image-input-mode") && byId("word-task-image-input-mode").value) || "openai_image_url";
      draft.imageInputMode = imageModeVal;
    }
    return draft;
  }

  function performTaskImageAction(action, authorized) {
    var taskType = getSettingsWorkflowTaskType();
    var statusNode = byId("word-task-model-validation-status");
    var saved = (state.taskModelSelections || {})[taskType] || {};
    var draft = getTaskModelSelectionDraft();
    if (taskType !== "word.format_review" || state.workflowProfileMutationBusy) return;
    var fields = ["serviceId", "modelName", "imageInputMode", "temperature", "maxOutputTokens", "contextWindowTokens"];
    var changed = fields.some(function (key) { return (draft[key] == null ? "" : draft[key]) !== (saved[key] == null ? "" : saved[key]); });
    if (!saved.serviceId || changed || saved.imageInputMode !== "openai_image_url") {
      if (statusNode) statusNode.textContent = "请先保存当前模型选择和图片输入模式，再授权或验证图片。";
      return;
    }
    var service = findDirectService(saved.serviceId) || {};
    if (action === "image-authorization" && authorized && !window.confirm(
      "允许格式审查向「" + (service.name || "所选服务") + "」发送本任务图片？\n服务地址：" +
      (service.serviceBaseUrl || "") + "\n模型：" + (saved.effectiveModel || saved.modelName || service.defaultModel || "") +
      "\n授权仅用于当前任务及模型配置，可随时撤销。"
    )) return;
    var operationId = Number(state.directServiceOperationId || 0) + 1;
    state.directServiceOperationId = operationId;
    setWorkflowProfileMutationBusy(true);
    if (statusNode) statusNode.textContent = action === "validate-image"
      ? "正在发送无敏感内容的合成测试图片，验证会产生模型调用费用…" : "正在保存图片授权…";
    return request("/provider/task-model-selections/" + encodeURIComponent(taskType) + "/" + action,
      action === "image-authorization" ? { authorized: Boolean(authorized), expectedSelection: draft, expectedServiceRevision: service.revision } : {})
      .then(function (body) {
        if (state.directServiceOperationId !== operationId || getSettingsWorkflowTaskType() !== taskType) return;
        var selection = body && body.data && body.data.taskModelSelection;
        if (selection) state.taskModelSelections[taskType] = selection;
        if (statusNode) statusNode.textContent = action === "validate-image" ? "视觉能力验证成功。" : (authorized ? "已授权，请继续验证视觉能力。" : "已撤销图片外发授权。");
      }).catch(function (error) {
        if (state.directServiceOperationId !== operationId || getSettingsWorkflowTaskType() !== taskType) return;
        if (statusNode) statusNode.textContent = "操作失败：" + describeFetchError(error);
      }).then(function () {
        if (state.directServiceOperationId === operationId) setWorkflowProfileMutationBusy(false);
      });
  }

  function validateTaskModelSelection() {
    var draft = getTaskModelSelectionDraft();
    var taskType = getSettingsWorkflowTaskType();
    var statusNode = byId("word-task-model-validation-status");
    var costWarning = byId("word-task-model-cost-warning");
    var currentSvc = findDirectService(draft.serviceId);
    if (!draft.serviceId || state.workflowProfileMutationBusy) {
      if (statusNode) {
        statusNode.textContent = "请先选择直连服务。";
      }
      return;
    }
    var checked = helpers.validateTaskModelSelectionDraft
      ? helpers.validateTaskModelSelectionDraft(draft, { service: currentSvc })
      : { ok: Boolean(draft.serviceId) };
    if (!checked.ok) {
      if (statusNode) {
        statusNode.textContent = checked.message || checked.error || "请检查参数设置。";
      }
      return;
    }
    if (statusNode) {
      statusNode.textContent = "正在验证调用（会真实请求模型，可能产生费用）...";
    }
    if (costWarning) {
      costWarning.hidden = false;
      costWarning.textContent = "验证调用会真实请求模型，可能产生费用并等待服务返回。";
    }
    state.directServiceOperationId = Number(state.directServiceOperationId || 0) + 1;
    var operationId = state.directServiceOperationId;
    setWorkflowProfileMutationBusy(true);
    return request("/provider/task-model-selections/" + encodeURIComponent(taskType) + "/validate", draft)
      .then(function (body) {
        if (state.directServiceOperationId !== operationId || getSettingsWorkflowTaskType() !== taskType) {
          return { superseded: true };
        }
        setWorkflowProfileMutationBusy(false);
        if (draft.customModel && draft.modelName) {
          state.lastValidatedCustomModel = {
            serviceId: draft.serviceId,
            modelName: draft.modelName
          };
        } else {
          state.lastValidatedCustomModel = null;
        }
        var result = body && body.data && body.data.validation ? body.data.validation : (body && body.data) || {};
        if (statusNode) {
          statusNode.textContent = (result.costWarning || result.mayIncurModelCost)
            ? "验证成功（真实调用，可能产生费用）。"
            : "验证成功！模型可正常调用。";
        }
        if (costWarning && result.costWarning) {
          costWarning.textContent = result.costWarning;
        }
      }).catch(function (error) {
        if (state.directServiceOperationId !== operationId || getSettingsWorkflowTaskType() !== taskType) {
          return { superseded: true };
        }
        setWorkflowProfileMutationBusy(false);
        if (statusNode) {
          statusNode.textContent = "验证失败：" + describeFetchError(error);
        }
      });
  }

  function saveTaskModelSelection() {
    var draft = getTaskModelSelectionDraft();
    var taskType = getSettingsWorkflowTaskType();
    var statusNode = byId("word-task-model-validation-status");
    var currentSvc = findDirectService(draft.serviceId);
    if (!draft.serviceId || state.workflowProfileMutationBusy) {
      setStatus("请先选择直连服务。");
      return;
    }
    var checked = helpers.validateTaskModelSelectionDraft
      ? helpers.validateTaskModelSelectionDraft(draft, { service: currentSvc })
      : { ok: Boolean(draft.serviceId) };
    if (!checked.ok) {
      if (statusNode) {
        statusNode.textContent = checked.message || checked.error || "请检查参数设置。";
      }
      return;
    }
    if (draft.customModel) {
      var validatedCustom = state.lastValidatedCustomModel;
      var customValidated = typeof validatedCustom === "string"
        ? validatedCustom === draft.modelName
        : Boolean(validatedCustom && validatedCustom.serviceId === draft.serviceId && validatedCustom.modelName === draft.modelName);
      if (!customValidated) {
        if (statusNode) {
          statusNode.textContent = "请先验证调用；验证会真实请求模型并可能产生费用。";
        }
        return;
      }
      draft.customModelValidated = true;
    }
    state.directServiceOperationId = Number(state.directServiceOperationId || 0) + 1;
    var operationId = state.directServiceOperationId;
    var activationSaved = false;
    setWorkflowProfileMutationBusy(true);
    return request("/provider/direct-services/" + encodeURIComponent(draft.serviceId) + "/activate", {
      taskType: taskType,
      taskModelSelection: draft
    }).then(function (body) {
        if (state.directServiceOperationId !== operationId || getSettingsWorkflowTaskType() !== taskType) {
          return { superseded: true };
        }
        activationSaved = true;
        state.workflowProfileSelections[taskType] = draft.serviceId;
        if (body && body.data && body.data.taskModelSelection) {
          state.taskModelSelections[taskType] = body.data.taskModelSelection;
        }
        state.taskApiKeys = state.taskApiKeys || {};
        state.taskApiKeys[taskType] = Object.assign({}, state.taskApiKeys[taskType] || {}, {
          activeProfileId: draft.serviceId,
          activeConfigurationId: draft.serviceId,
          accessMethod: "direct_model",
          serviceId: draft.serviceId,
          configured: true,
          taskKeyConfigured: true
        });
        return Promise.all([
          loadWorkflowProfiles(taskType),
          loadDirectServices(undefined, undefined, operationId)
        ]).then(function () {
          if (state.directServiceOperationId !== operationId || getSettingsWorkflowTaskType() !== taskType) {
            return { superseded: true };
          }
          setWorkflowProfileMutationBusy(false);
          var taskLabel = taskType === "word.format_review" ? "格式审查" : (taskType === "word.document_review" ? "文档审查" : (taskType === "word.smart_imitation" ? "智能仿写" : "智能编写"));
          setStatus(taskLabel + "接入直连服务已保存并设为当前。");
          if (statusNode) {
            statusNode.textContent = "已保存并设为当前。";
          }
          if (taskType === "word.document_review" && typeof renderFullDocumentReviewEntry === "function") {
            renderFullDocumentReviewEntry();
          }
        });
      }).catch(function (error) {
        if (state.directServiceOperationId !== operationId || getSettingsWorkflowTaskType() !== taskType) {
          return { superseded: true };
        }
        setWorkflowProfileMutationBusy(false);
        if (statusNode) {
          statusNode.textContent = activationSaved
            ? "已保存，但刷新列表失败：" + describeFetchError(error)
            : "保存失败：" + describeFetchError(error);
        }
        if (activationSaved) {
          setStatus("任务接入已保存，但刷新最新列表失败：" + describeFetchError(error));
        }
      });
  }

  function validateActiveDirectTaskSelection(taskType) {
    var taskStatus = (state.taskApiKeys && state.taskApiKeys[taskType]) || {};
    var selection = (state.taskModelSelections && state.taskModelSelections[taskType]) || {};
    var activeProfileId = String(taskStatus.activeProfileId || "").trim();
    var serviceId = "";
    var service;

    if (taskStatus.accessMethod === "direct_model" && activeProfileId.indexOf("direct_svc_") === 0) {
      serviceId = activeProfileId;
    } else if (taskStatus.accessMethod === "direct_model" &&
        String(taskStatus.serviceId || "").indexOf("direct_svc_") === 0) {
      serviceId = String(taskStatus.serviceId).trim();
    } else {
      return { valid: true, ok: true, applicable: false, error: "" };
    }

    service = findDirectService(serviceId);
    if (helpers.validateDirectTaskSelectionReadiness) {
      return helpers.validateDirectTaskSelectionReadiness(
        Object.assign({}, selection, { serviceId: serviceId }),
        service,
        Object.assign({}, taskStatus, { accessMethod: "direct_model" })
      );
    }
    return { valid: true, ok: true };
  }

  function getWritingPolicyScopeDefinition(scope) {
    var index;
    for (index = 0; index < WRITING_POLICY_SCOPE_DEFS.length; index += 1) {
      if (WRITING_POLICY_SCOPE_DEFS[index].scope === scope) {
        return WRITING_POLICY_SCOPE_DEFS[index];
      }
    }
    return WRITING_POLICY_SCOPE_DEFS[0];
  }

  function renderWritingPolicyManagerView() {
    var view = state.writingPolicyView || "home";
    var home = view === "home";
    var diagnosticsDisclosure = byId("diagnostics-disclosure");
    byId("connection-settings-section").hidden = !home;
    if (home) {
      diagnosticsDisclosure.hidden = false;
    } else {
      diagnosticsDisclosure.open = false;
      diagnosticsDisclosure.hidden = true;
    }
    byId("writing-policy-preset-view").hidden = view !== "preset";
    byId("writing-policy-scope-view").hidden = view !== "scope";
    byId("writing-policy-list-view").hidden = view !== "list";
    byId("writing-policy-more-view").hidden = view !== "more";
    byId("writing-policy-editor-view").hidden = view !== "editor";
    byId("writing-policy-import-view").hidden = view !== "import";
  }

  function focusWritingPolicyView(view) {
    var targetIds = {
      home: "btn-open-writing-policy-manager",
      preset: "writing-policy-preset-title",
      scope: "writing-policy-scope-title",
      list: "writing-policy-list-title",
      more: "writing-policy-more-title",
      editor: "writing-policy-editor-title",
      import: "writing-policy-import-title"
    };
    var targetId = targetIds[view];
    if (!targetId) {
      return;
    }
    setTimeout(function () {
      var target;
      if (state.writingPolicyView !== view) {
        return;
      }
      target = byId(targetId);
      if (target && target.focus) {
        target.focus();
      }
    }, 0);
  }

  function setWritingPolicyView(view, suppressRefreshSync) {
    var diagnosticsDisclosure = byId("diagnostics-disclosure");
    if (view === "home" && diagnosticsDisclosure) {
      diagnosticsDisclosure.open = false;
    }
    state.writingPolicyView = view;
    renderWritingPolicyManagerView();
    focusWritingPolicyView(view);
    if (!suppressRefreshSync) {
      syncSettingsRefreshController();
    }
  }

  function formatWritingPolicyUpdatedAt(value) {
    var text;
    var date;
    if (helpers.formatWritingPolicyUpdatedAt) {
      return helpers.formatWritingPolicyUpdatedAt(value);
    }
    text = String(value || "").trim();
    if (!text) {
      return "尚无更新时间";
    }
    date = new Date(text);
    if (!isFinite(date.getTime())) {
      return "最近更新：" + text;
    }
    return "最近更新：" + new Intl.DateTimeFormat("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    }).format(date);
  }

  function renderWritingPolicySummary() {
    var summary = state.writingPolicySummary || {};
    var statusNode = byId("writing-policy-summary-status");
    var enterButton = byId("btn-open-writing-policy-manager");
    var retryButton = byId("btn-retry-writing-policy-summary");
    byId("writing-policy-summary-total").textContent = String(Math.max(0, Number(summary.totalCount) || 0));
    byId("writing-policy-summary-enabled").textContent = String(Math.max(0, Number(summary.enabledCount) || 0));
    byId("writing-policy-summary-updated").textContent = formatWritingPolicyUpdatedAt(summary.updatedAt);
    enterButton.disabled = state.writingPolicySummaryState !== "ready";
    retryButton.hidden = state.writingPolicySummaryState !== "error";
    if (state.writingPolicySummaryState === "loading") {
      statusNode.textContent = "正在读取...";
    } else if (state.writingPolicySummaryState === "ready") {
      statusNode.textContent = "可用";
    } else if (state.writingPolicySummaryState === "unsupported") {
      statusNode.textContent = "当前 adapter 版本不支持写作规范库";
    } else if (state.writingPolicySummaryState === "error") {
      statusNode.textContent = "写作规范库暂不可用";
    } else {
      statusNode.textContent = "尚未读取";
    }
  }

  function loadWritingPolicySummary() {
    var requestId = state.writingPolicyLoadSequence + 1;
    state.writingPolicyLoadSequence = requestId;
    state.writingPolicySummaryState = "loading";
    renderWritingPolicySummary();
    return request("/writing-policies/summary").then(function (body) {
      if (state.writingPolicyLoadSequence !== requestId) {
        return null;
      }
      state.writingPolicySummary = body.data || {};
      state.writingPolicySummaryState = "ready";
      renderWritingPolicySummary();
      return state.writingPolicySummary;
    }).catch(function (error) {
      if (state.writingPolicyLoadSequence !== requestId) {
        return null;
      }
      state.writingPolicySummary = null;
      state.writingPolicySummaryState = error && error.httpStatus === 404 ? "unsupported" : "error";
      renderWritingPolicySummary();
      return null;
    });
  }

  function renderWritingPolicyPresetItems() {
    var pack = state.writingPolicyPresetPack || {};
    var source = pack.source || {};
    var meta = byId("writing-policy-preset-pack-meta");
    var list = byId("writing-policy-preset-item-list");
    var index;
    list.textContent = "";
    renderWritingPolicyPagination(
      "preset",
      state.writingPolicyPresetItemOffset,
      state.writingPolicyPresetItemTotal,
      state.writingPolicyPresetItems.length,
      Boolean(state.writingPolicyPresetError)
    );
    if (state.writingPolicyPresetError) {
      meta.textContent = "预置规范暂时无法读取，请稍后重试。";
      return;
    }
    if (!pack.packId) {
      meta.textContent = "正在读取规范包...";
      return;
    }
    byId("writing-policy-preset-title").textContent = String(pack.name || "预置规范");
    meta.textContent = pack.name + " v" + pack.version + " ｜ 来源：" +
      source.name + " " + source.version + " ｜ 提交：" + source.commit +
      " ｜ 许可证：" + source.license;
    for (index = 0; index < state.writingPolicyPresetItems.length; index += 1) {
      var item = state.writingPolicyPresetItems[index];
      var row = document.createElement("div");
      var title = document.createElement("strong");
      var rule = document.createElement("p");
      var trace = document.createElement("small");
      var status = document.createElement("span");
      var actions = document.createElement("div");
      row.className = "writing-policy-item-row writing-policy-preset-item";
      title.textContent = item.name || item.preferredText || "未命名规范";
      rule.textContent = item.ruleText || item.definition || "";
      trace.textContent = "ID：" + String(item.id || "") + " ｜ 来源版本：" +
        String((item.source || {}).version || source.version || "") +
        " ｜ 提交：" + String((item.source || {}).commit || source.commit || "") +
        " ｜ 许可证：" + String((item.source || {}).license || source.license || "");
      status.className = "provider-badge";
      status.textContent = helpers.writingPolicyItemStateLabel
        ? helpers.writingPolicyItemStateLabel(item, "preset")
        : (item.effective === false ? "预置停用 · 未生效" : "预置基线 · 已生效");
      actions.className = "writing-policy-preset-actions";
      if (WRITING_POLICY_ITEM_TYPES.indexOf(item.type) >= 0 && item.organizationState !== "disabled") {
        var editButton = document.createElement("button");
        var disableButton = document.createElement("button");
        editButton.type = "button";
        editButton.className = "ghost-action mini-button";
        editButton.textContent = "编辑覆盖";
        editButton.setAttribute("data-writing-policy-preset-action", "edit");
        editButton.setAttribute("data-writing-policy-preset-id", String(item.id || ""));
        editButton.disabled = state.writingPolicyMutationBusy;
        disableButton.type = "button";
        disableButton.className = "ghost-action mini-button danger-action";
        disableButton.textContent = "停用预置";
        disableButton.setAttribute("data-writing-policy-preset-action", "disable");
        disableButton.setAttribute("data-writing-policy-preset-id", String(item.id || ""));
        disableButton.disabled = state.writingPolicyMutationBusy;
        actions.appendChild(editButton);
        actions.appendChild(disableButton);
      }
      if (WRITING_POLICY_ITEM_TYPES.indexOf(item.type) >= 0 &&
          (item.organizationState === "overridden" || item.organizationState === "disabled")) {
        var restoreButton = document.createElement("button");
        restoreButton.type = "button";
        restoreButton.className = "ghost-action mini-button";
        restoreButton.textContent = "恢复预置";
        restoreButton.setAttribute("data-writing-policy-preset-action", "restore");
        restoreButton.setAttribute("data-writing-policy-preset-id", String(item.id || ""));
        restoreButton.disabled = state.writingPolicyMutationBusy;
        actions.appendChild(restoreButton);
      }
      row.appendChild(title);
      row.appendChild(rule);
      row.appendChild(trace);
      row.appendChild(status);
      row.appendChild(actions);
      list.appendChild(row);
    }
    if (!state.writingPolicyPresetItems.length) {
      list.textContent = "当前规范包暂无可显示条目。";
    }
  }

  function renderWritingPolicyPresetPackSelect() {
    var select = byId("writing-policy-preset-pack-select");
    var selectedId = String(state.writingPolicyPresetPack && state.writingPolicyPresetPack.packId || "");
    select.textContent = "";
    state.writingPolicyPresetPacks.forEach(function (pack) {
      var option = document.createElement("option");
      option.value = String(pack.packId || "");
      option.textContent = String(pack.name || pack.packId || "未命名规范包");
      option.selected = option.value === selectedId;
      select.appendChild(option);
    });
    select.disabled = state.writingPolicyMutationBusy || !state.writingPolicyPresetPacks.length;
  }

  function loadWritingPolicyPresetItems(packId) {
    var requestId = state.writingPolicyPresetLoadSequence + 1;
    var requestOffset = state.writingPolicyPresetItemOffset;
    state.writingPolicyPresetLoadSequence = requestId;
    return request("/writing-policies/items?layer=preset&packId=" +
      encodeURIComponent(packId) + "&limit=" + WRITING_POLICY_LIST_PAGE_SIZE +
      "&offset=" + requestOffset).then(function (body) {
      var data = body.data || {};
      if (state.writingPolicyPresetLoadSequence !== requestId) {
        return null;
      }
      state.writingPolicyPresetItems = Array.isArray(data.items)
        ? data.items.slice(0, WRITING_POLICY_LIST_PAGE_SIZE)
        : [];
      state.writingPolicyPresetItemTotal = Math.max(
        state.writingPolicyPresetItems.length,
        Number(data.count) || 0
      );
      var normalizedOffset = normalizeWritingPolicyPageOffset(
        state.writingPolicyPresetItemOffset,
        state.writingPolicyPresetItemTotal
      );
      if (normalizedOffset !== state.writingPolicyPresetItemOffset) {
        state.writingPolicyPresetItemOffset = normalizedOffset;
        return loadWritingPolicyPresetItems(packId);
      }
      state.writingPolicyPresetError = "";
      renderWritingPolicyPresetItems();
      return state.writingPolicyPresetItems;
    }).catch(function () {
      if (state.writingPolicyPresetLoadSequence !== requestId) {
        return null;
      }
      state.writingPolicyPresetItems = [];
      state.writingPolicyPresetItemTotal = 0;
      state.writingPolicyPresetError = "items_unavailable";
      renderWritingPolicyPresetItems();
      return [];
    });
  }

  function loadWritingPolicyPresetPacks() {
    state.writingPolicyPresetPacks = [];
    state.writingPolicyPresetPack = null;
    state.writingPolicyPresetItems = [];
    state.writingPolicyPresetItemTotal = 0;
    state.writingPolicyPresetItemOffset = 0;
    state.writingPolicyPresetError = "";
    renderWritingPolicyPresetItems();
    return request("/writing-policies/packs").then(function (body) {
      var packs = body.data && Array.isArray(body.data.packs) ? body.data.packs : [];
      var index;
      state.writingPolicyPresetPacks = packs;
      for (index = 0; index < packs.length; index += 1) {
        if (packs[index].packId === "yangqi-tech-writing-base") {
          state.writingPolicyPresetPack = packs[index];
          renderWritingPolicyPresetPackSelect();
          return loadWritingPolicyPresetItems(packs[index].packId);
        }
      }
      state.writingPolicyPresetError = "base_pack_missing";
      renderWritingPolicyPresetPackSelect();
      renderWritingPolicyPresetItems();
      return [];
    }).catch(function () {
      state.writingPolicyPresetError = "packs_unavailable";
      renderWritingPolicyPresetPackSelect();
      renderWritingPolicyPresetItems();
      return [];
    });
  }

  function openWritingPolicyPresetView() {
    if (state.writingPolicySummaryState !== "ready") {
      return;
    }
    setWritingPolicyView("preset");
    loadWritingPolicyPresetPacks();
  }

  function selectWritingPolicyPresetPack(packId) {
    var selected = null;
    state.writingPolicyPresetPacks.forEach(function (pack) {
      if (String(pack.packId || "") === String(packId || "")) {
        selected = pack;
      }
    });
    if (!selected || state.writingPolicyMutationBusy) {
      return;
    }
    state.writingPolicyPresetPack = selected;
    state.writingPolicyPresetItems = [];
    state.writingPolicyPresetItemTotal = 0;
    state.writingPolicyPresetItemOffset = 0;
    state.writingPolicyPresetError = "";
    renderWritingPolicyPresetPackSelect();
    renderWritingPolicyPresetItems();
    loadWritingPolicyPresetItems(selected.packId);
  }

  function openWritingPolicyScopeView() {
    setWritingPolicyView("scope");
  }

  function writingPolicyTypeLabel(type) {
    if (type === "term") {
      return "术语";
    }
    return type === "anti_template" ? "去模板化规则" : "文体规则";
  }

  function normalizeWritingPolicyPageOffset(offset, total) {
    return helpers.writingPolicyPageState(
      offset,
      total,
      0,
      WRITING_POLICY_LIST_PAGE_SIZE
    ).offset;
  }

  function renderWritingPolicyPagination(kind, offset, total, pageCount, error) {
    var preset = kind === "preset";
    var container = byId(preset ? "writing-policy-preset-pagination" : "writing-policy-pagination");
    var previous = byId(preset ? "btn-writing-policy-preset-previous" : "btn-writing-policy-previous");
    var next = byId(preset ? "btn-writing-policy-preset-next" : "btn-writing-policy-next");
    var status = byId(preset ? "writing-policy-preset-page-status" : "writing-policy-page-status");
    var page = helpers.writingPolicyPageState(
      offset,
      total,
      pageCount,
      WRITING_POLICY_LIST_PAGE_SIZE
    );
    var disabled = Boolean(error) || state.writingPolicyMutationBusy;
    container.hidden = Boolean(error) || (!page.hasPrevious && !page.hasNext);
    previous.disabled = disabled || !page.hasPrevious;
    next.disabled = disabled || !page.hasNext;
    status.textContent = page.label;
  }

  function changeWritingPolicyPresetPage(direction) {
    var nextOffset = normalizeWritingPolicyPageOffset(
      state.writingPolicyPresetItemOffset +
        direction * WRITING_POLICY_LIST_PAGE_SIZE,
      state.writingPolicyPresetItemTotal
    );
    if (nextOffset === state.writingPolicyPresetItemOffset ||
        !state.writingPolicyPresetPack ||
        state.writingPolicyMutationBusy) {
      return;
    }
    state.writingPolicyPresetItemOffset = nextOffset;
    loadWritingPolicyPresetItems(state.writingPolicyPresetPack.packId);
  }

  function changeWritingPolicyPage(direction) {
    var nextOffset = normalizeWritingPolicyPageOffset(
      state.writingPolicyItemOffset + direction * WRITING_POLICY_LIST_PAGE_SIZE,
      state.writingPolicyItemTotal
    );
    if (nextOffset === state.writingPolicyItemOffset ||
        state.writingPolicyMutationBusy) {
      return;
    }
    state.writingPolicyItemOffset = nextOffset;
    loadWritingPolicyItems();
  }

  function handleWritingPolicyLayerClick(event) {
    var layer = event.target.getAttribute("data-writing-policy-layer");
    if (layer === "preset") {
      openWritingPolicyPresetView();
    } else if (layer === "organization") {
      openWritingPolicyScopeView();
    }
  }

  function renderWritingPolicyTypeSwitch() {
    var buttons = byId("writing-policy-type-switch").querySelectorAll("[data-writing-policy-type]");
    var index;
    for (index = 0; index < buttons.length; index += 1) {
      var type = buttons[index].getAttribute("data-writing-policy-type");
      var active = type === state.writingPolicyType;
      buttons[index].classList.toggle("active", active);
      buttons[index].setAttribute("aria-selected", active ? "true" : "false");
      buttons[index].disabled = state.writingPolicyMutationBusy;
      buttons[index].tabIndex = active ? 0 : -1;
    }
  }

  function renderWritingPolicyList() {
    var scopeDefinition = getWritingPolicyScopeDefinition(state.writingPolicyScope);
    var list = byId("writing-policy-item-list");
    var statusNode = byId("writing-policy-list-status");
    var retryButton = byId("btn-retry-writing-policy-list");
    var addButton = byId("btn-writing-policy-add");
    list.textContent = "";
    renderWritingPolicyPagination(
      "organization",
      state.writingPolicyItemOffset,
      state.writingPolicyItemTotal,
      state.writingPolicyItems.length,
      Boolean(state.writingPolicyListError)
    );
    byId("writing-policy-list-title").textContent = state.writingPolicyType === "term"
      ? scopeDefinition.label
      : "组织" + writingPolicyTypeLabel(state.writingPolicyType);
    byId("writing-policy-list-caption").textContent = state.writingPolicyType === "term"
      ? scopeDefinition.caption
      : "统一管理规则的任务与场景范围。";
    byId("writing-policy-search-input").value = state.writingPolicySearch;
    renderWritingPolicyTypeSwitch();
    addButton.disabled = state.writingPolicyMutationBusy || Boolean(state.writingPolicyListError);
    retryButton.hidden = !state.writingPolicyListError;
    if (state.writingPolicyListError) {
      statusNode.textContent = "写作规范库暂不可用，未显示空列表。";
      return;
    }
    if (!state.writingPolicyItems.length) {
      statusNode.textContent = "当前范围暂无" + writingPolicyTypeLabel(state.writingPolicyType) + "。";
      return;
    }
    statusNode.textContent = (
      state.writingPolicyItemTotal > state.writingPolicyItems.length
        ? "共 " + state.writingPolicyItemTotal + " 条，当前显示第 " +
          (state.writingPolicyItemOffset + 1) + "–" +
          (state.writingPolicyItemOffset + state.writingPolicyItems.length) + " 条"
        : "共 " + state.writingPolicyItems.length + " 条"
    ) + writingPolicyTypeLabel(state.writingPolicyType);
    state.writingPolicyItems.forEach(function (item) {
      var row = document.createElement("button");
      var text = document.createElement("span");
      var title = document.createElement("strong");
      var note = document.createElement("small");
      var status = document.createElement("span");
      row.type = "button";
      row.className = "writing-policy-item-row";
      row.setAttribute("data-writing-policy-item-id", String(item.id || ""));
      title.textContent = String(item.type === "term" ? item.preferredText || "未命名术语" : item.name || "未命名规则");
      note.textContent = String(item.note || (item.type === "term" ? item.definition || "暂无说明" : item.ruleText || "暂无说明"));
      status.className = "provider-badge";
      status.textContent = helpers.writingPolicyItemStateLabel
        ? helpers.writingPolicyItemStateLabel(item, "organization")
        : (item.enabled === false ? "组织自定义 · 未生效" : "组织自定义 · 已生效");
      text.appendChild(title);
      text.appendChild(note);
      row.appendChild(text);
      row.appendChild(status);
      list.appendChild(row);
    });
  }

  function loadWritingPolicyItems() {
    var requestId = state.writingPolicyLoadSequence + 1;
    var requestType = state.writingPolicyType;
    var requestSearch = state.writingPolicySearch;
    var requestOffset = state.writingPolicyItemOffset;
    var listScope = requestType === "term"
      ? state.writingPolicyScope
      : "organization";
    state.writingPolicyLoadSequence = requestId;
    state.writingPolicyListError = "";
    byId("writing-policy-list-status").textContent = "正在读取...";
    byId("writing-policy-item-list").textContent = "";
    return request("/writing-policies/items?scope=" + encodeURIComponent(listScope) +
      "&type=" + encodeURIComponent(requestType) +
      "&query=" + encodeURIComponent(requestSearch) +
      "&limit=" + WRITING_POLICY_LIST_PAGE_SIZE +
      "&offset=" + requestOffset).then(function (body) {
      var data = body.data || {};
      if (state.writingPolicyLoadSequence !== requestId) {
        return null;
      }
      state.writingPolicyItems = Array.isArray(data.items)
        ? data.items.slice(0, WRITING_POLICY_LIST_PAGE_SIZE)
        : [];
      state.writingPolicyItemTotal = Math.max(
        state.writingPolicyItems.length,
        Number(data.count) || 0
      );
      var normalizedOffset = normalizeWritingPolicyPageOffset(
        state.writingPolicyItemOffset,
        state.writingPolicyItemTotal
      );
      if (normalizedOffset !== state.writingPolicyItemOffset) {
        state.writingPolicyItemOffset = normalizedOffset;
        return loadWritingPolicyItems();
      }
      renderWritingPolicyList();
      return state.writingPolicyItems;
    }).catch(function (error) {
      if (state.writingPolicyLoadSequence !== requestId) {
        return null;
      }
      state.writingPolicyItems = [];
      state.writingPolicyItemTotal = 0;
      state.writingPolicyItemOffset = 0;
      state.writingPolicyListError = describeFetchError(error);
      renderWritingPolicyList();
      return null;
    });
  }

  function openWritingPolicyList(scope, type) {
    state.writingPolicyScope = getWritingPolicyScopeDefinition(scope).scope;
    state.writingPolicyType = type || state.writingPolicyType;
    state.writingPolicySearch = "";
    state.writingPolicyItems = [];
    state.writingPolicyItemTotal = 0;
    state.writingPolicyItemOffset = 0;
    state.writingPolicyListError = "";
    setWritingPolicyView("list");
    renderWritingPolicyList();
    loadWritingPolicyItems();
  }

  function joinWritingPolicyList(values) {
    return Array.isArray(values) ? values.join(" | ") : "";
  }

  function splitWritingPolicyList(value) {
    return String(value || "").split("|").map(function (item) {
      return item.trim();
    }).filter(function (item) {
      return Boolean(item);
    });
  }

  function normalizeWritingPolicyRuleTasks(item) {
    var aliases = {
      smart_write: "word.smart_write",
      smart_imitate: "word.smart_imitation",
      document_review: "word.document_review"
    };
    var values = Array.isArray(item && item.taskTypes) ? item.taskTypes : [];
    values = values.map(function (value) {
      return aliases[value] || value;
    }).filter(function (value) {
      return WRITING_POLICY_RULE_TASK_TYPES.indexOf(value) >= 0;
    });
    if (!values.length && item && item.scope && item.scope !== "global") {
      values = [item.scope];
    }
    return values.length ? values : WRITING_POLICY_RULE_TASK_TYPES.slice();
  }

  function normalizeWritingPolicyRuleScenes(item) {
    var values = Array.isArray(item && item.sceneIds) ? item.sceneIds : [];
    values = values.filter(function (value) {
      return WRITING_POLICY_RULE_SCENE_IDS.indexOf(value) >= 0;
    });
    return values.length ? values : WRITING_POLICY_RULE_SCENE_IDS.slice();
  }

  function setWritingPolicyCheckedValues(containerId, values) {
    var controls = byId(containerId).querySelectorAll('input[type="checkbox"]');
    var index;
    for (index = 0; index < controls.length; index += 1) {
      controls[index].checked = values.indexOf(controls[index].value) >= 0;
    }
  }

  function readWritingPolicyCheckedValues(containerId) {
    var controls = byId(containerId).querySelectorAll('input[type="checkbox"]');
    var values = [];
    var index;
    for (index = 0; index < controls.length; index += 1) {
      if (controls[index].checked) {
        values.push(controls[index].value);
      }
    }
    return values;
  }

  function setWritingPolicyEditorError(message, field) {
    var errorNode = byId("writing-policy-editor-error");
    var fieldIds = {
      preferredText: "writing-policy-preferred-text",
      name: "writing-policy-style-name",
      ruleText: "writing-policy-rule-text",
      taskTypes: "writing-policy-task-types",
      sceneIds: "writing-policy-scene-ids",
      scope: "writing-policy-editor-caption"
    };
    var errorIds = {
      preferredText: "writing-policy-preferred-error",
      name: "writing-policy-style-name-error",
      ruleText: "writing-policy-rule-error"
    };
    Object.keys(fieldIds).forEach(function (fieldName) {
      var input = byId(fieldIds[fieldName]);
      if (input) {
        input.removeAttribute("aria-invalid");
      }
    });
    ["preferredText", "name", "ruleText"].forEach(function (fieldName) {
      var fieldError = byId(errorIds[fieldName]);
      fieldError.textContent = "";
      fieldError.hidden = true;
    });
    errorNode.textContent = String(message || "");
    errorNode.hidden = !message;
    if (message && errorIds[field]) {
      byId(errorIds[field]).textContent = String(message);
      byId(errorIds[field]).hidden = false;
      byId(fieldIds[field]).setAttribute("aria-invalid", "true");
    }
    if (message && fieldIds[field] && byId(fieldIds[field]) && byId(fieldIds[field]).focus) {
      byId(fieldIds[field]).focus();
    }
  }

  function clearWritingPolicyEditorState() {
    var ids = [
      "writing-policy-preferred-text", "writing-policy-aliases", "writing-policy-forbidden-variants",
      "writing-policy-definition", "writing-policy-style-name", "writing-policy-rule-text",
      "writing-policy-positive-example", "writing-policy-negative-example", "writing-policy-note",
      "writing-policy-category", "writing-policy-context-keywords"
    ];
    ids.forEach(function (id) {
      byId(id).value = "";
    });
    setWritingPolicyCheckedValues("writing-policy-task-types", []);
    setWritingPolicyCheckedValues("writing-policy-scene-ids", []);
    state.writingPolicyEditor = null;
    state.writingPolicyEditorDirty = false;
    setWritingPolicyEditorError("", "");
  }

  function setWritingPolicyEditorControlsDisabled(disabled) {
    var controls = byId("writing-policy-editor-view").querySelectorAll("button, input, textarea, select");
    var index;
    for (index = 0; index < controls.length; index += 1) {
      controls[index].disabled = Boolean(disabled);
    }
  }

  function renderWritingPolicyEditor() {
    var editor = state.writingPolicyEditor || {};
    var item = editor.item || {};
    var type = editor.type || state.writingPolicyType;
    var scopeDefinition = getWritingPolicyScopeDefinition(editor.scope || state.writingPolicyScope);
    byId("writing-policy-editor-title").textContent = editor.mode === "preset-override"
      ? "编辑预置规范覆盖"
      : editor.mode === "edit"
        ? "编辑规范条目"
        : "新增规范条目";
    byId("writing-policy-editor-caption").textContent = editor.mode === "preset-override"
      ? "组织覆盖 · 保存后优先于预置基线"
      : scopeDefinition.label + " · " + writingPolicyTypeLabel(type);
    byId("writing-policy-term-fields").hidden = type !== "term";
    byId("writing-policy-style-fields").hidden = type === "term";
    byId("writing-policy-category-field").hidden = type !== "term";
    byId("writing-policy-always-apply-field").hidden = type === "term";
    byId("writing-policy-enabled-field").hidden = editor.mode === "preset-override";
    byId("writing-policy-preferred-text").value = String(item.preferredText || "");
    byId("writing-policy-aliases").value = joinWritingPolicyList(item.aliases);
    byId("writing-policy-forbidden-variants").value = joinWritingPolicyList(item.forbiddenVariants);
    byId("writing-policy-definition").value = String(item.definition || "");
    byId("writing-policy-style-name").value = String(item.name || "");
    byId("writing-policy-rule-text").value = String(item.ruleText || "");
    byId("writing-policy-positive-example").value = String(item.positiveExample || "");
    byId("writing-policy-negative-example").value = String(item.negativeExample || "");
    byId("writing-policy-note").value = String(item.note || "");
    byId("writing-policy-category").value = String(item.category || "");
    byId("writing-policy-context-keywords").value = joinWritingPolicyList(item.contextKeywords);
    byId("writing-policy-priority").value = helpers.normalizeWritingPolicyPriority
      ? helpers.normalizeWritingPolicyPriority(item.priority)
      : String(item.priority || "medium");
    byId("writing-policy-always-apply").checked = editor.mode === "preset-override"
      ? item.alwaysApply !== false
      : Boolean(item.alwaysApply);
    byId("writing-policy-enabled").checked = item.enabled !== false;
    setWritingPolicyCheckedValues(
      "writing-policy-task-types",
      normalizeWritingPolicyRuleTasks(item)
    );
    setWritingPolicyCheckedValues(
      "writing-policy-scene-ids",
      normalizeWritingPolicyRuleScenes(item)
    );
    byId("writing-policy-editor-advanced").open = false;
    byId("btn-writing-policy-delete").hidden = editor.mode !== "edit";
    setWritingPolicyEditorError("", "");
    setWritingPolicyEditorControlsDisabled(state.writingPolicyMutationBusy);
  }

  function openWritingPolicyEditor(item) {
    state.writingPolicyEditor = {
      mode: item ? "edit" : "create",
      item: item || {},
      type: item && item.type ? item.type : state.writingPolicyType,
      scope: item && item.scope ? item.scope : state.writingPolicyScope
    };
    state.writingPolicyEditorDirty = false;
    setWritingPolicyView("editor");
    renderWritingPolicyEditor();
  }

  function openWritingPolicyPresetEditor(item) {
    if (!item || WRITING_POLICY_ITEM_TYPES.indexOf(item.type) < 0 ||
        state.writingPolicyMutationBusy) {
      return;
    }
    state.writingPolicyEditor = {
      mode: "preset-override",
      item: item,
      type: item.type,
      scope: item.scope || "global",
      returnView: "preset"
    };
    state.writingPolicyEditorDirty = false;
    setWritingPolicyView("editor");
    renderWritingPolicyEditor();
  }

  function readWritingPolicyDraft() {
    var editor = state.writingPolicyEditor || {};
    var type = editor.type || state.writingPolicyType;
    var draft = {
      type: type,
      scope: editor.scope || state.writingPolicyScope,
      contextKeywords: splitWritingPolicyList(byId("writing-policy-context-keywords").value),
      priority: byId("writing-policy-priority").value || "medium",
      enabled: Boolean(byId("writing-policy-enabled").checked),
      note: String(byId("writing-policy-note").value || "").trim()
    };
    if (type === "term") {
      draft.category = String(byId("writing-policy-category").value || "").trim();
      draft.preferredText = String(byId("writing-policy-preferred-text").value || "").trim();
      draft.aliases = splitWritingPolicyList(byId("writing-policy-aliases").value);
      draft.forbiddenVariants = splitWritingPolicyList(byId("writing-policy-forbidden-variants").value);
      draft.definition = String(byId("writing-policy-definition").value || "").trim();
    } else {
      draft.name = String(byId("writing-policy-style-name").value || "").trim();
      draft.ruleText = String(byId("writing-policy-rule-text").value || "").trim();
      draft.positiveExample = String(byId("writing-policy-positive-example").value || "").trim();
      draft.negativeExample = String(byId("writing-policy-negative-example").value || "").trim();
      draft.alwaysApply = Boolean(byId("writing-policy-always-apply").checked);
      draft.taskTypes = readWritingPolicyCheckedValues("writing-policy-task-types");
      draft.sceneIds = readWritingPolicyCheckedValues("writing-policy-scene-ids");
      if (type === "anti_template") {
        draft.type = "anti_template";
      }
    }
    return draft;
  }

  function setWritingPolicyMutationBusy(busy) {
    state.writingPolicyMutationBusy = Boolean(busy);
    setWritingPolicyEditorControlsDisabled(state.writingPolicyMutationBusy);
  }

  function saveWritingPolicyItem() {
    var editor = state.writingPolicyEditor;
    var draft;
    var validation;
    var path;
    var options;
    if (!editor || state.writingPolicyMutationBusy) {
      return;
    }
    draft = readWritingPolicyDraft();
    validation = helpers.validateWritingPolicyDraft ? helpers.validateWritingPolicyDraft(draft) : { ok: true, field: "", message: "" };
    if (!validation.ok) {
      setWritingPolicyEditorError(validation.message, validation.field);
      return;
    }
    path = "/writing-policies/items";
    options = { timeoutMs: WRITING_POLICY_MANAGEMENT_REQUEST_TIMEOUT_MS };
    if (editor.mode === "preset-override") {
      path = "/writing-policies/preset-overrides/" +
        encodeURIComponent(String(editor.item.id || ""));
      options.method = "PUT";
      draft.operation = "override";
    } else if (editor.mode === "edit") {
      path += "/" + encodeURIComponent(String(editor.item.id || ""));
      options.method = "PATCH";
    }
    setWritingPolicyEditorError("", "");
    setWritingPolicyMutationBusy(true);
    request(path, draft, options).then(function () {
      setWritingPolicyMutationBusy(false);
      state.writingPolicyEditorDirty = false;
      clearWritingPolicyEditorState();
      if (editor.mode === "preset-override") {
        setWritingPolicyView("preset");
        return loadWritingPolicyPresetItems(state.writingPolicyPresetPack.packId).then(function () {
          loadWritingPolicySummary();
          setStatus("预置规范的组织覆盖已保存。");
        });
      }
      setWritingPolicyView("list");
      return loadWritingPolicyItems().then(function () {
        loadWritingPolicySummary();
        setStatus("写作规范条目已保存。");
      });
    }).catch(function (error) {
      var field = helpers.writingPolicyConflictField ? helpers.writingPolicyConflictField(error) : "";
      setWritingPolicyMutationBusy(false);
      setWritingPolicyEditorError(describeFetchError(error), field);
    });
  }

  function deleteWritingPolicyItem() {
    var editor = state.writingPolicyEditor;
    var item;
    var itemName;
    if (!editor || editor.mode !== "edit" || state.writingPolicyMutationBusy) {
      return;
    }
    item = editor.item || {};
    itemName = String(item.type === "term" ? item.preferredText || "该术语" : item.name || "该规则");
    if (window.confirm && !window.confirm("确认删除“" + itemName + "”？删除后无法恢复。")) {
      return;
    }
    setWritingPolicyMutationBusy(true);
    request("/writing-policies/items/" + encodeURIComponent(String(item.id || "")), null, {
      method: "DELETE",
      timeoutMs: WRITING_POLICY_MANAGEMENT_REQUEST_TIMEOUT_MS
    })
      .then(function () {
        setWritingPolicyMutationBusy(false);
        state.writingPolicyEditorDirty = false;
        clearWritingPolicyEditorState();
        setWritingPolicyView("list");
        return loadWritingPolicyItems().then(function () {
          loadWritingPolicySummary();
          setStatus("写作规范条目已删除。");
        });
      }).catch(function (error) {
        setWritingPolicyMutationBusy(false);
        setWritingPolicyEditorError("删除失败：" + describeFetchError(error), "");
      });
  }

  function closeWritingPolicyEditor() {
    var returnView = state.writingPolicyEditor && state.writingPolicyEditor.returnView;
    if (!confirmWritingPolicyEditorDiscard()) {
      return;
    }
    clearWritingPolicyEditorState();
    if (returnView === "preset") {
      setWritingPolicyView("preset");
      renderWritingPolicyPresetItems();
    } else {
      setWritingPolicyView("list");
      renderWritingPolicyList();
    }
  }

  function findWritingPolicyPresetItem(itemId) {
    var found = null;
    state.writingPolicyPresetItems.forEach(function (item) {
      if (String(item.id || "") === String(itemId || "")) {
        found = item;
      }
    });
    return found;
  }

  function disableWritingPolicyPresetItem(itemId) {
    var item = findWritingPolicyPresetItem(itemId);
    if (!item || WRITING_POLICY_ITEM_TYPES.indexOf(item.type) < 0 ||
        state.writingPolicyMutationBusy) {
      return;
    }
    if (window.confirm && !window.confirm("确认停用预置规范“" + String(item.preferredText || item.name || "") + "”？")) {
      return;
    }
    state.writingPolicyMutationBusy = true;
    renderWritingPolicyPresetPackSelect();
    renderWritingPolicyPresetItems();
    request("/writing-policies/preset-overrides/" + encodeURIComponent(String(item.id || "")), {
      operation: "disabled"
    }, {
      method: "PUT",
      timeoutMs: WRITING_POLICY_MANAGEMENT_REQUEST_TIMEOUT_MS
    }).then(function () {
      state.writingPolicyMutationBusy = false;
      renderWritingPolicyPresetPackSelect();
      return loadWritingPolicyPresetItems(state.writingPolicyPresetPack.packId).then(function () {
        loadWritingPolicySummary();
        setStatus("预置规范已停用。");
      });
    }).catch(function (error) {
      state.writingPolicyMutationBusy = false;
      renderWritingPolicyPresetPackSelect();
      renderWritingPolicyPresetItems();
      setStatus("停用失败：" + describeFetchError(error));
    });
  }

  function restoreWritingPolicyPresetItem(itemId) {
    var item = findWritingPolicyPresetItem(itemId);
    if (!item || WRITING_POLICY_ITEM_TYPES.indexOf(item.type) < 0 ||
        state.writingPolicyMutationBusy) {
      return;
    }
    if (window.confirm && !window.confirm("确认恢复预置规范“" +
        String((item.baseline || {}).preferredText || (item.baseline || {}).name ||
          item.preferredText || item.name || "") + "”？")) {
      return;
    }
    state.writingPolicyMutationBusy = true;
    renderWritingPolicyPresetPackSelect();
    renderWritingPolicyPresetItems();
    request("/writing-policies/preset-overrides/" + encodeURIComponent(String(item.id || "")), null, {
      method: "DELETE",
      timeoutMs: WRITING_POLICY_MANAGEMENT_REQUEST_TIMEOUT_MS
    }).then(function () {
      state.writingPolicyMutationBusy = false;
      renderWritingPolicyPresetPackSelect();
      return loadWritingPolicyPresetItems(state.writingPolicyPresetPack.packId).then(function () {
        loadWritingPolicySummary();
        setStatus("预置规范已恢复。");
      });
    }).catch(function (error) {
      state.writingPolicyMutationBusy = false;
      renderWritingPolicyPresetPackSelect();
      renderWritingPolicyPresetItems();
      setStatus("恢复失败：" + describeFetchError(error));
    });
  }

  function handleWritingPolicyPresetAction(event) {
    var target = event.target;
    var action;
    var itemId;
    while (target && target !== byId("writing-policy-preset-item-list") && !target.getAttribute("data-writing-policy-preset-action")) {
      target = target.parentNode;
    }
    if (!target || target === byId("writing-policy-preset-item-list")) {
      return;
    }
    action = target.getAttribute("data-writing-policy-preset-action");
    itemId = target.getAttribute("data-writing-policy-preset-id");
    if (action === "edit") {
      openWritingPolicyPresetEditor(findWritingPolicyPresetItem(itemId));
    } else if (action === "disable") {
      disableWritingPolicyPresetItem(itemId);
    } else if (action === "restore") {
      restoreWritingPolicyPresetItem(itemId);
    }
  }

  function handleWritingPolicyScopeClick(event) {
    var target = event.target;
    while (target && target !== byId("writing-policy-scope-list") && !target.getAttribute("data-writing-policy-scope")) {
      target = target.parentNode;
    }
    if (target && target.getAttribute("data-writing-policy-scope")) {
      openWritingPolicyList(
        target.getAttribute("data-writing-policy-scope"),
        target.getAttribute("data-writing-policy-entry-type") || ""
      );
    }
  }

  function handleWritingPolicyTypeClick(event) {
    var type = event.target.getAttribute("data-writing-policy-type");
    selectWritingPolicyType(type);
  }

  function selectWritingPolicyType(type) {
    if (WRITING_POLICY_ITEM_TYPES.indexOf(type) < 0 || state.writingPolicyMutationBusy) {
      return;
    }
    state.writingPolicyType = type;
    state.writingPolicyItems = [];
    state.writingPolicyItemTotal = 0;
    state.writingPolicyItemOffset = 0;
    state.writingPolicyListError = "";
    renderWritingPolicyList();
    loadWritingPolicyItems();
  }

  function handleWritingPolicyTypeKeydown(event) {
    var keys = ["ArrowLeft", "ArrowRight", "Home", "End"];
    var buttons;
    var enabledButtons;
    var currentIndex;
    var nextIndex;
    var type;
    if (keys.indexOf(event.key) < 0) {
      return;
    }
    buttons = Array.prototype.slice.call(byId("writing-policy-type-switch").querySelectorAll("[data-writing-policy-type]"));
    enabledButtons = buttons.filter(function (button) {
      return !button.disabled;
    });
    if (!enabledButtons.length) {
      return;
    }
    currentIndex = enabledButtons.indexOf(event.target);
    if (currentIndex < 0) {
      currentIndex = 0;
    }
    nextIndex = helpers.nextWritingPolicyTabIndex ?
      helpers.nextWritingPolicyTabIndex(currentIndex, event.key, enabledButtons.length) : currentIndex;
    if (nextIndex < 0 || !enabledButtons[nextIndex]) {
      return;
    }
    event.preventDefault();
    enabledButtons[nextIndex].focus();
    type = enabledButtons[nextIndex].getAttribute("data-writing-policy-type");
    selectWritingPolicyType(type);
  }

  function handleWritingPolicyListClick(event) {
    var target = event.target;
    var itemId;
    var item;
    while (target && target !== byId("writing-policy-item-list") && !target.getAttribute("data-writing-policy-item-id")) {
      target = target.parentNode;
    }
    itemId = target && target.getAttribute("data-writing-policy-item-id");
    if (!itemId) {
      return;
    }
    item = state.writingPolicyItems.filter(function (candidate) {
      return String(candidate.id || "") === itemId;
    })[0];
    if (item) {
      openWritingPolicyEditor(item);
    }
  }

  function scheduleWritingPolicySearch(value) {
    state.writingPolicySearch = String(value || "");
    state.writingPolicyItemOffset = 0;
    state.writingPolicyLoadSequence += 1;
    state.writingPolicyItems = [];
    state.writingPolicyItemTotal = 0;
    state.writingPolicyListError = "";
    renderWritingPolicyList();
    byId("writing-policy-list-status").textContent = "正在筛选...";
    if (state.writingPolicySearchTimer) {
      clearTimeout(state.writingPolicySearchTimer);
    }
    state.writingPolicySearchTimer = setTimeout(function () {
      state.writingPolicySearchTimer = null;
      loadWritingPolicyItems();
    }, 250);
  }

  function setWritingPolicyImportBusy(busy) {
    var controls = byId("writing-policy-import-view").querySelectorAll("button, input, select");
    var index;
    state.writingPolicyImportBusy = Boolean(busy);
    for (index = 0; index < controls.length; index += 1) {
      controls[index].disabled = state.writingPolicyImportBusy;
    }
  }

  function releaseWritingPolicyImportReader(abortRead, expectedReader) {
    var reader = expectedReader || state.writingPolicyImportReader;
    if (!reader) {
      return;
    }
    if (!expectedReader || state.writingPolicyImportReader === expectedReader) {
      state.writingPolicyImportReader = null;
    }
    reader.onload = null;
    reader.onerror = null;
    if (abortRead && reader.readyState === 1 && reader.abort) {
      reader.abort();
    }
  }

  function renderWritingPolicyImportStep() {
    var steps = byId("writing-policy-import-steps").querySelectorAll("[data-import-step]");
    var order = { select: 0, validate: 1, conflicts: 2, apply: 3 };
    var activeIndex = order[state.writingPolicyImportStep] || 0;
    var index;
    for (index = 0; index < steps.length; index += 1) {
      steps[index].classList.toggle(
        "active",
        order[steps[index].getAttribute("data-import-step")] <= activeIndex
      );
      if (order[steps[index].getAttribute("data-import-step")] === activeIndex) {
        steps[index].setAttribute("aria-current", "step");
      } else {
        steps[index].removeAttribute("aria-current");
      }
    }
  }

  function clearWritingPolicyImportPreview(message, clearFile) {
    state.writingPolicyImportPreview = null;
    state.writingPolicyImportStep = "select";
    if (clearFile) {
      byId("writing-policy-import-file").value = "";
    }
    byId("writing-policy-import-preview-panel").hidden = true;
    byId("writing-policy-import-error-list").textContent = "";
    byId("writing-policy-import-conflict-list").textContent = "";
    byId("writing-policy-import-change-list").textContent = "";
    byId("writing-policy-import-changes-section").hidden = true;
    byId("writing-policy-import-errors-section").hidden = true;
    byId("writing-policy-import-conflicts-section").hidden = true;
    byId("writing-policy-import-errors-title").textContent = "校验错误";
    byId("writing-policy-import-conflicts-title").textContent = "冲突处理";
    byId("writing-policy-import-status").textContent = message || "请选择文件。";
    renderWritingPolicyImportStep();
  }

  function resetWritingPolicyImport(message) {
    state.writingPolicyImportSequence += 1;
    releaseWritingPolicyImportReader(true);
    setWritingPolicyImportBusy(false);
    clearWritingPolicyImportPreview(message, true);
  }

  function openWritingPolicyImport() {
    if (state.writingPolicyImportBusy) {
      return;
    }
    resetWritingPolicyImport("");
    setWritingPolicyView("import");
  }

  function closeWritingPolicyImport() {
    if (state.writingPolicyImportBusy) {
      return;
    }
    resetWritingPolicyImport("");
    setWritingPolicyView("more");
  }

  function openWritingPolicyMore() {
    if (state.writingPolicyMutationBusy || state.writingPolicyImportBusy) {
      return;
    }
    byId("writing-policy-more-status").textContent = "按需执行操作。";
    setWritingPolicyView("more");
  }

  function closeWritingPolicyMore() {
    setWritingPolicyView("preset");
  }

  function handleWritingPolicyImportFileChange(event) {
    var file = event.target.files && event.target.files[0];
    var validation;
    state.writingPolicyImportSequence += 1;
    clearWritingPolicyImportPreview(file ? "已选择文件，可开始校验。" : "请选择文件。", false);
    if (!file) {
      return;
    }
    validation = helpers.validateWritingPolicyImportFile ? helpers.validateWritingPolicyImportFile(file) : { ok: true };
    if (!validation.ok) {
      byId("writing-policy-import-status").textContent = validation.message;
    }
  }

  function arrayBufferToWritingPolicyBase64(arrayBuffer) {
    var bytes = new Uint8Array(arrayBuffer);
    var chunks = [];
    var chunkSize = 32768;
    var offset;
    for (offset = 0; offset < bytes.length; offset += chunkSize) {
      chunks.push(String.fromCharCode.apply(null, bytes.subarray(offset, offset + chunkSize)));
    }
    var encoded = window.btoa(chunks.join(""));
    bytes = null;
    chunks.length = 0;
    return encoded;
  }

  function renderWritingPolicyImportPreview() {
    var preview = state.writingPolicyImportPreview;
    var errorsSection = byId("writing-policy-import-errors-section");
    var conflictsSection = byId("writing-policy-import-conflicts-section");
    var errorList = byId("writing-policy-import-error-list");
    var conflictList = byId("writing-policy-import-conflict-list");
    var changeList = byId("writing-policy-import-change-list");
    var applyButton = byId("btn-apply-writing-policy-import");
    errorList.textContent = "";
    conflictList.textContent = "";
    changeList.textContent = "";
    if (!preview) {
      byId("writing-policy-import-preview-panel").hidden = true;
      return;
    }
    byId("writing-policy-import-preview-panel").hidden = false;
    byId("writing-policy-import-new-count").textContent = String(preview.stats.newCount);
    byId("writing-policy-import-modify-count").textContent = String(preview.stats.modifyCount);
    byId("writing-policy-import-disable-count").textContent = String(preview.stats.disableCount);
    byId("writing-policy-import-restore-count").textContent = String(preview.stats.restoreCount);
    byId("writing-policy-import-delete-count").textContent = String(preview.stats.deleteCount);
    byId("writing-policy-import-conflict-count").textContent = String(preview.stats.conflictCount);
    byId("writing-policy-import-error-count").textContent = String(preview.stats.errorCount);
    byId("writing-policy-import-errors-title").textContent = helpers.writingPolicyImportCountLabel ?
      helpers.writingPolicyImportCountLabel("校验错误", preview.stats.errorCount, preview.errors.length) : "校验错误";
    byId("writing-policy-import-conflicts-title").textContent = helpers.writingPolicyImportCountLabel ?
      helpers.writingPolicyImportCountLabel("冲突处理", preview.stats.conflictCount, preview.conflicts.length) : "冲突处理";
    preview.changes.forEach(function (item) {
      var row = document.createElement("li");
      var labels = {
        "new": "新增",
        "modify": "修改",
        "disable": "停用",
        "restore": "恢复",
        "delete": "删除"
      };
      row.textContent = "第 " + String(item.rowNumber) + " 行 · " +
        (labels[item.action] || item.action || "变更") + " · " + item.name;
      changeList.appendChild(row);
    });
    byId("writing-policy-import-changes-title").textContent = helpers.writingPolicyImportCountLabel ?
      helpers.writingPolicyImportCountLabel("变更预览", preview.changes.length, preview.changes.length) : "变更预览";
    byId("writing-policy-import-changes-section").hidden = preview.changes.length === 0;
    preview.errors.forEach(function (item) {
      var row = document.createElement("li");
      row.textContent = item.message;
      errorList.appendChild(row);
    });
    errorsSection.hidden = preview.errors.length === 0;
    preview.conflicts.forEach(function (item) {
      var row = document.createElement("div");
      var message = document.createElement("span");
      var select = document.createElement("select");
      var keep = document.createElement("option");
      var skip = document.createElement("option");
      row.className = "writing-policy-import-conflict-row";
      message.textContent = item.message;
      select.setAttribute("data-writing-policy-conflict-row", String(item.rowNumber));
      keep.value = "keep_existing";
      keep.textContent = "保留库内标准";
      skip.value = "skip";
      skip.textContent = "跳过该行";
      select.appendChild(keep);
      select.appendChild(skip);
      select.value = helpers.normalizeWritingPolicyConflictDecision ?
        helpers.normalizeWritingPolicyConflictDecision(item.decision) : "keep_existing";
      row.appendChild(message);
      row.appendChild(select);
      conflictList.appendChild(row);
    });
    conflictsSection.hidden = preview.conflicts.length === 0;
    applyButton.disabled = state.writingPolicyImportBusy || !preview.previewToken ||
      preview.stats.errorCount > 0;
    applyButton.textContent = preview.conflicts.length ? "按当前选择应用" : "应用无冲突项";
  }

  function previewWritingPolicyImport() {
    var input = byId("writing-policy-import-file");
    var file = input.files && input.files[0];
    var validation = helpers.validateWritingPolicyImportFile ?
      helpers.validateWritingPolicyImportFile(file) : { ok: Boolean(file), message: "请选择导入文件。" };
    var reader;
    var requestId;
    if (state.writingPolicyImportBusy) {
      return;
    }
    if (!validation.ok) {
      byId("writing-policy-import-status").textContent = validation.message;
      return;
    }
    reader = new FileReader();
    requestId = state.writingPolicyImportSequence + 1;
    state.writingPolicyImportSequence = requestId;
    state.writingPolicyImportReader = reader;
    setWritingPolicyImportBusy(true);
    state.writingPolicyImportStep = "validate";
    renderWritingPolicyImportStep();
    byId("writing-policy-import-status").textContent = "正在读取并校验文件...";
    reader.onerror = function () {
      if (state.writingPolicyImportSequence !== requestId) {
        return;
      }
      releaseWritingPolicyImportReader(false, reader);
      input.value = "";
      setWritingPolicyImportBusy(false);
      state.writingPolicyImportStep = "select";
      renderWritingPolicyImportStep();
      byId("writing-policy-import-status").textContent = "无法读取所选文件，请重新选择。";
    };
    reader.onload = function (event) {
      var arrayBuffer = event && event.target ? event.target.result : reader.result;
      var contentBase64 = "";
      var payload = null;
      var previewRequest;
      function releaseLargeReferences() {
        var isCurrentRequest = state.writingPolicyImportSequence === requestId;
        arrayBuffer = null;
        contentBase64 = "";
        payload = null;
        file = null;
        if (isCurrentRequest) {
          input.value = "";
        }
        releaseWritingPolicyImportReader(false, reader);
        reader = null;
        if (isCurrentRequest) {
          setWritingPolicyImportBusy(false);
          renderWritingPolicyImportPreview();
        }
      }
      try {
        contentBase64 = arrayBufferToWritingPolicyBase64(arrayBuffer);
        payload = helpers.buildWritingPolicyImportRequest ?
          helpers.buildWritingPolicyImportRequest(file, contentBase64) : null;
        previewRequest = request("/writing-policies/imports/preview", payload);
      } catch (error) {
        if (state.writingPolicyImportSequence === requestId) {
          state.writingPolicyImportStep = "select";
          byId("writing-policy-import-status").textContent = "文件编码失败，请重新选择。";
          renderWritingPolicyImportStep();
        }
        releaseLargeReferences();
        return;
      }
      previewRequest.then(function (body) {
        if (state.writingPolicyImportSequence !== requestId) {
          return;
        }
        state.writingPolicyImportPreview = helpers.normalizeWritingPolicyImportPreview ?
          helpers.normalizeWritingPolicyImportPreview(body.data || {}) : body.data;
        if (!state.writingPolicyImportPreview || !state.writingPolicyImportPreview.previewToken) {
          throw new Error("校验结果缺少导入预览编号。");
        }
        state.writingPolicyImportStep = state.writingPolicyImportPreview.conflicts.length ? "conflicts" : "apply";
        if (state.writingPolicyImportPreview.stats.errorCount > 0) {
          state.writingPolicyImportStep = "validate";
          byId("writing-policy-import-status").textContent = "校验发现错误，请修正文件后重新预览。";
        } else {
          byId("writing-policy-import-status").textContent = state.writingPolicyImportPreview.conflicts.length ?
            "校验完成，请处理冲突后应用。" : "校验完成，可应用导入。";
        }
        renderWritingPolicyImportPreview();
      }).catch(function (error) {
        if (state.writingPolicyImportSequence !== requestId) {
          return;
        }
        state.writingPolicyImportPreview = null;
        state.writingPolicyImportStep = "select";
        byId("writing-policy-import-status").textContent = "校验失败：" + describeFetchError(error);
        renderWritingPolicyImportPreview();
        renderWritingPolicyImportStep();
      }).then(function () {
        releaseLargeReferences();
      });
    };
    reader.readAsArrayBuffer(file);
  }

  function handleWritingPolicyConflictDecision(event) {
    var rowNumber = Number(event.target.getAttribute("data-writing-policy-conflict-row"));
    var preview = state.writingPolicyImportPreview;
    if (!rowNumber || !preview) {
      return;
    }
    preview.conflicts.forEach(function (item) {
      if (item.rowNumber === rowNumber) {
        item.decision = helpers.normalizeWritingPolicyConflictDecision ?
          helpers.normalizeWritingPolicyConflictDecision(event.target.value) : "keep_existing";
        event.target.value = item.decision;
      }
    });
  }

  function applyWritingPolicyImport() {
    var preview = state.writingPolicyImportPreview;
    var applyPayload;
    if (!preview || !preview.previewToken || state.writingPolicyImportBusy) {
      return;
    }
    if (preview.stats.errorCount > 0) {
      byId("writing-policy-import-status").textContent = "预览仍有错误，不能应用。";
      return;
    }
    applyPayload = helpers.buildWritingPolicyImportApplyRequest ?
      helpers.buildWritingPolicyImportApplyRequest(preview) : {
        previewToken: preview.previewToken,
        fileDigest: preview.fileDigest,
        acceptedConflictRows: []
      };
    setWritingPolicyImportBusy(true);
    state.writingPolicyImportStep = "apply";
    renderWritingPolicyImportStep();
    byId("writing-policy-import-status").textContent = "正在应用导入结果...";
    request("/writing-policies/imports/apply", applyPayload).then(function (body) {
      var result = body.data || {};
      state.writingPolicyImportPreview = null;
      byId("writing-policy-import-preview-panel").hidden = true;
      byId("writing-policy-import-status").textContent = "导入完成：新增 " +
        String(result.createdCount || 0) + "，修改 " + String(result.modifiedCount || result.updatedCount || 0) +
        "，停用 " + String(result.disabledCount || 0) + "，恢复 " +
        String(result.restoredCount || 0) + "，删除 " + String(result.deletedCount || 0) + "。";
      setWritingPolicyImportBusy(false);
      loadWritingPolicySummary();
    }).catch(function (error) {
      setWritingPolicyImportBusy(false);
      if (helpers.isWritingPolicyPreviewExpired && helpers.isWritingPolicyPreviewExpired(error)) {
        resetWritingPolicyImport("导入预览已过期，请重新选择文件。");
        return;
      }
      byId("writing-policy-import-status").textContent = "应用失败：" + describeFetchError(error);
      renderWritingPolicyImportPreview();
    });
  }

  function downloadWritingPolicyFile(path, fileName) {
    var objectUrl = "";
    var anchor = null;
    function cleanup() {
      if (anchor) {
        anchor.href = "";
      }
      if (anchor && anchor.parentNode) {
        anchor.parentNode.removeChild(anchor);
      }
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
      }
    }
    return fetch(ADAPTER_BASE_URL + path).then(function (response) {
      if (!response.ok) {
        throw new Error("HTTP " + response.status);
      }
      return response.blob();
    }).then(function (blob) {
      objectUrl = URL.createObjectURL(blob);
      anchor = document.createElement("a");
      anchor.href = objectUrl;
      anchor.download = fileName;
      anchor.hidden = true;
      document.body.appendChild(anchor);
      anchor.click();
      return true;
    }).then(function (result) {
      cleanup();
      return result;
    }, function (error) {
      cleanup();
      throw error;
    });
  }

  function runWritingPolicyDownload(path, fileName, successMessage) {
    var statusNode = state.writingPolicyView === "import" ?
      byId("writing-policy-import-status") :
      state.writingPolicyView === "more" ? byId("writing-policy-more-status") : null;
    if (statusNode) {
      statusNode.textContent = "正在准备下载...";
    } else {
      setStatus("正在准备下载...");
    }
    downloadWritingPolicyFile(path, fileName).then(function () {
      if (statusNode) {
        statusNode.textContent = successMessage;
      } else {
        setStatus(successMessage);
      }
    }).catch(function (error) {
      if (statusNode) {
        statusNode.textContent = "下载失败：" + describeFetchError(error);
      } else {
        setStatus("下载失败：" + describeFetchError(error));
      }
    });
  }

  function exportWritingPolicies(format) {
    var scope = byId("writing-policy-export-scope").value === "organization" ?
      "organization" : "effective";
    var suffix = format === "xlsx" ? "xlsx" : "csv";
    runWritingPolicyDownload(
      "/writing-policies/export." + suffix + "?scope=" + encodeURIComponent(scope),
      "writing-policies-" + scope + "." + suffix,
      (scope === "organization" ? "组织规范" : "当前生效规范") +
        "已导出为 " + suffix.toUpperCase() + "。"
    );
  }

  function refreshWritingPolicyDiagnostics() {
    var status = byId("writing-policy-more-status");
    var output = byId("writing-policy-diagnostics-output");
    status.textContent = "正在读取写作规范库诊断...";
    request("/writing-policies/diagnostics", null, {
      method: "GET",
      timeoutMs: WRITING_POLICY_MANAGEMENT_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      output.textContent = JSON.stringify(body.data || {}, null, 2);
      output.hidden = false;
      status.textContent = "写作规范库诊断已刷新。";
    }).catch(function (error) {
      output.hidden = true;
      output.textContent = "";
      status.textContent = "诊断读取失败：" + describeFetchError(error);
    });
  }

  function renderTemplateOptions() {
    var select = byId("template-select");
    select.innerHTML = "";

    if (!state.templates.length) {
      var fallback = document.createElement("option");
      fallback.value = "technical-document-template-rules";
      fallback.textContent = "技术文档模板规则";
      select.appendChild(fallback);
      state.selectedTemplateId = "technical-document-template-rules";
      return;
    }

    state.templates.forEach(function (template) {
      var option = document.createElement("option");
      option.value = template.id;
      option.textContent = template.name;
      if (template.id === state.selectedTemplateId) {
        option.selected = true;
      }
      select.appendChild(option);
    });
  }

  var DOCUMENT_REVIEW_CATEGORY_ORDER = ["typo", "expression", "logic", "fluency", "professional", "other"];
  var DOCUMENT_REVIEW_CATEGORY_TEXT = {
    typo: "错别字",
    expression: "语言表达",
    logic: "逻辑表达",
    fluency: "通畅性",
    professional: "专业性",
    other: "其他问题"
  };
  var REVIEW_SEVERITY_TEXT = {
    high: "高",
    medium: "中",
    low: "低"
  };
  function groupItems(items, getKey) {
    var grouped = {};
    (items || []).forEach(function (item) {
      var key = getKey(item) || "other";
      if (!grouped[key]) {
        grouped[key] = [];
      }
      grouped[key].push(item);
    });
    return grouped;
  }

  function getDocumentReviewCategory(issue) {
    var category = issue && issue.category ? String(issue.category) : "";
    return DOCUMENT_REVIEW_CATEGORY_TEXT[category] ? category : "other";
  }

  function renderGroupedDocumentReview(data) {
    var documentTypeText = {
      technical_solution: "技术方案",
      contract_acceptance: "合同验收文档",
      test_outline: "测试大纲和细则"
    };
    var issues = data.issues || [];
    var rawAnswer = data.rawAnswer || data.raw_answer || "";
    var parseFallbackReason = data.parseFallbackReason || data.parse_fallback_reason || "";
    var lines = [
      "文档审查结果",
      "",
      "文档类型：" + (documentTypeText[data.documentType] || data.documentType || "技术方案"),
      "检查范围：" + (data.scope === "selection" ? "选中内容" : "全文"),
      "总体结论：" + (data.summary || "审查完成。"),
      "问题数量：" + issues.length,
      ""
    ];

    if (parseFallbackReason) {
      lines.push("解析状态：" + formatDocumentReviewFallbackReason(parseFallbackReason));
      lines.push("");
    }

    if (!issues.length) {
      if (rawAnswer) {
        lines.push("未解析到结构化问题列表，以下展示模型后台原始回复。");
        lines.push("");
        lines.push("## 原始模型回复");
        lines.push("");
        lines.push(rawAnswer);
        return lines.join("\n").trim();
      }
      lines.push("未发现明显文档质量问题。");
      return lines.join("\n");
    }

    var grouped = groupItems(issues, getDocumentReviewCategory);
    DOCUMENT_REVIEW_CATEGORY_ORDER.forEach(function (category) {
      var categoryIssues = grouped[category] || [];
      if (!categoryIssues.length) {
        return;
      }
      lines.push("## " + DOCUMENT_REVIEW_CATEGORY_TEXT[category] + "（" + categoryIssues.length + "）");
      lines.push("");
      categoryIssues.forEach(function (issue, index) {
        lines.push("### " + DOCUMENT_REVIEW_CATEGORY_TEXT[category] + " #" + (index + 1));
        lines.push("- 严重程度：" + (REVIEW_SEVERITY_TEXT[issue.severity] || issue.severity || "中"));
        lines.push("- 位置：" + (issue.location || "未定位"));
        if (issue.originalText) {
          lines.push("- 原文片段：" + issue.originalText);
        }
        lines.push("- 问题说明：" + (issue.problem || "未说明"));
        lines.push("- 修改建议：" + (issue.suggestion || "无"));
        if (issue.suggestedRewrite) {
          lines.push("- 建议改写：" + issue.suggestedRewrite);
        }
        lines.push("");
      });
    });

    return lines.join("\n").trim();
  }

  function formatDocumentReviewFallbackReason(reason) {
    var reasonText = {
      provider_timeout: "模型后台未按时返回，adapter 已停止等待。",
      provider_unreachable: "模型后台或企业大模型接口暂不可达。",
      provider_auth_failed: "模型后台或企业大模型接口认证失败。",
      non_json_answer: "模型后台已返回内容，但不是标准 JSON 问题列表。",
      unsupported_json_shape: "模型后台已返回 JSON，但未包含标准 issues 问题列表。"
    };
    return reasonText[reason] || "模型后台已返回内容，但未解析为标准问题列表。";
  }

  function escapeHtmlText(value) {
    return helpers.escapeHtml ? helpers.escapeHtml(value) : String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function getDocumentReviewRecordText() {
    if (helpers.buildDocumentReviewRecord) {
      return helpers.buildDocumentReviewRecord(state.documentReviewData || {}, state.documentReviewIssueStatus || {});
    }
    return renderGroupedDocumentReview(state.documentReviewData || {});
  }

  function getDocumentReviewStatus(index) {
    return state.documentReviewIssueStatus[String(index)] || "pending";
  }

  function getDocumentReviewStatusText(status) {
    return {
      pending: "待处理",
      done: "已处理",
      ignored: "已忽略"
    }[status] || "待处理";
  }

  function renderDocumentReviewInteractive(data) {
    var output = byId("result-output");
    var issues = data.issues || [];
    var documentTypeText = {
      technical_solution: "技术方案",
      contract_acceptance: "合同验收文档",
      test_outline: "测试大纲和细则"
    };
    var grouped = {};
    var html = [];
    var markdown = renderGroupedDocumentReview(data);

    state.copyText = markdown;
    output.hidden = false;
    output.classList.remove("plain-output");
    output.classList.remove("streaming-preview-wait");

    if (!issues.length) {
      setResult(markdown, markdown);
      setReviewRecordActionsVisible(Boolean(state.documentReviewData));
      return;
    }

    issues.forEach(function (issue, index) {
      var category = getDocumentReviewCategory(issue);
      if (!grouped[category]) {
        grouped[category] = [];
      }
      grouped[category].push({ issue: issue, index: index });
    });

    html.push('<div class="document-review-result">');
    html.push('<section class="review-summary-box">');
    html.push("<h3>文档审查结果</h3>");
    html.push("<p>文档类型：" + escapeHtmlText(documentTypeText[data.documentType] || data.documentType || "技术方案") + "</p>");
    html.push("<p>检查范围：" + (data.scope === "selection" ? "选中内容" : "全文") + "</p>");
    html.push("<p>总体结论：" + escapeHtmlText(data.summary || "审查完成。") + "</p>");
    html.push("<p>问题数量：" + issues.length + "</p>");
    html.push("</section>");

    DOCUMENT_REVIEW_CATEGORY_ORDER.forEach(function (category) {
      var items = grouped[category] || [];
      if (!items.length) {
        return;
      }
      html.push('<section class="review-category-section">');
      html.push("<h3>" + DOCUMENT_REVIEW_CATEGORY_TEXT[category] + "（" + items.length + "）</h3>");
      items.forEach(function (entry, localIndex) {
        var issue = entry.issue;
        var index = entry.index;
        var status = getDocumentReviewStatus(index);
        html.push('<article class="review-issue-card" data-review-issue-index="' + index + '">');
        html.push("<h4>" + DOCUMENT_REVIEW_CATEGORY_TEXT[category] + " #" + (localIndex + 1) + "</h4>");
        html.push('<div class="review-issue-meta">');
        html.push("<span>严重程度：" + escapeHtmlText(REVIEW_SEVERITY_TEXT[issue.severity] || issue.severity || "中") + "</span>");
        html.push("<span>位置：" + escapeHtmlText(issue.location || "未定位") + "</span>");
        html.push("</div>");
        if (issue.originalText) {
          html.push("<p><strong>原文片段：</strong>" + escapeHtmlText(issue.originalText) + "</p>");
        }
        html.push("<p><strong>问题说明：</strong>" + escapeHtmlText(issue.problem || "未说明") + "</p>");
        html.push("<p><strong>修改建议：</strong>" + escapeHtmlText(issue.suggestion || "无") + "</p>");
        if (issue.suggestedRewrite) {
          html.push("<p><strong>建议改写：</strong>" + escapeHtmlText(issue.suggestedRewrite) + "</p>");
        }
        html.push('<div class="review-status-row">');
        html.push('<span class="review-status-pill ' + status + '">' + getDocumentReviewStatusText(status) + "</span>");
        html.push("</div>");
        html.push('<div class="review-action-row">');
        html.push('<button type="button" class="ghost-action" data-review-action="mark-done" data-issue-index="' + index + '">标记已处理</button>');
        html.push('<button type="button" class="ghost-action" data-review-action="mark-ignored" data-issue-index="' + index + '">忽略</button>');
        html.push('<button type="button" class="ghost-action" data-review-action="copy-suggestion" data-issue-index="' + index + '">复制建议</button>');
        if (issue.suggestedRewrite) {
          html.push('<button type="button" class="ghost-action" data-review-action="copy-rewrite" data-issue-index="' + index + '">复制改写</button>');
        }
        html.push("</div>");
        html.push("</article>");
      });
      html.push("</section>");
    });

    html.push("</div>");
    output.innerHTML = html.join("");
    setReviewRecordActionsVisible(true);
  }

  function renderDocumentReviewResult(data) {
    var markdown = renderGroupedDocumentReview(data || {});
    state.documentReviewRecordPreviewVisible = false;
    state.writingPolicyAudit = data && data.writingPolicyAudit ? data.writingPolicyAudit : null;
    renderWritingPolicyUsage(data && data.writingPolicyUsage, "word.document_review");
    try {
      renderDocumentReviewInteractive(data || {});
      return true;
    } catch (error) {
      setResult(markdown, markdown);
      setReviewRecordActionsVisible(Boolean(data));
      return false;
    }
  }

  function completeDocumentReview(data, traceId, docSessionId, jobId) {
    var completionTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var targetJobId = jobId || state.documentReviewJobId || traceId || "";
    var targetDocSession = docSessionId || state.documentSessionId || "default";
    state.pendingApplyAction = "";
    setApplyEnabled(false);
    if (traceId) {
      setTrace(traceId);
    }
    state.documentReviewData = data || {};
    state.documentReviewIssueStatus = {};
    setActiveResultRecord("word.document_review", targetDocSession, {
      result: data,
      traceId: traceId || "",
      taskType: "word.document_review",
      documentSessionId: targetDocSession,
      completedAt: Date.now()
    });
    if (renderDocumentReviewResult(state.documentReviewData)) {
      setStatus("文档审查完成。");
    } else {
      setStatus("文档审查完成，已使用简洁结果视图显示。");
    }
    if (typeof recordTaskFirstRender === "function") {
      recordTaskFirstRender(targetJobId, traceId || targetJobId || "", "word.document_review", completionTimestamp);
    }
  }

  function scheduleDocumentReviewPoll(jobId, stopWaiting, delayMs, resumeExpected, docSessionId) {
    setTimeout(function () {
      pollDocumentReviewJob(jobId, stopWaiting, resumeExpected, docSessionId);
    }, delayMs);
  }

  function isFatalDocumentReviewPollError(error) {
    return error && (
      error.adapterCode === "DOCUMENT_REVIEW_JOB_NOT_FOUND" ||
      error.adapterCode === "DOCUMENT_REVIEW_JOB_INTERRUPTED" ||
      error.adapterCode === "LONG_TASK_QUEUE_FULL" ||
      error.adapterCode === "DOCUMENT_REVIEW_AUTH_SNAPSHOT_FAILED" ||
      error.adapterCode === "REQUEST_VALIDATION_FAILED" ||
      error.adapterCode === "WORD_DOCUMENT_REVIEW_TASK_CONFLICT" ||
      error.adapterCode === "WORD_DOCUMENT_REVIEW_TASK_BUSY" ||
      error.httpStatus === 409
    );
  }

  function renderDocumentReviewJobProgress(job, jobId) {
    var phaseText = DOCUMENT_REVIEW_PHASE_TEXT[job.phase] || job.phase || "等待状态更新";
    var elapsedSeconds = Number(job.elapsedSeconds || 0);
    var phaseElapsedSeconds = Number(job.phaseElapsedSeconds || 0);
    var lines = [];
    if (job.status === "queued") {
      setStatus("文档审查正在排队，当前位置：" + (job.queuePosition || 1) + "。");
      lines.push("文档审查已进入共享任务队列。", "排队位置：" + (job.queuePosition || 1));
    } else {
      setStatus("文档审查正在处理，当前阶段：" + phaseText + "。");
      lines.push(job.runningMessage || "adapter 正在执行文档审查。", "当前阶段：" + phaseText);
    }
    lines.push(
      "总耗时：" + elapsedSeconds + " 秒",
      "本阶段耗时：" + phaseElapsedSeconds + " 秒",
      "任务编号：" + jobId
    );
    setDocumentReviewCancelVisible(job.status === "queued" && job.canCancel, false);
    setPlainResult(lines.join("\n"));
  }

  function finishCancelledDocumentReview(jobId, stopWaiting, docSessionId) {
    cleanupDocumentReviewTerminal(docSessionId, jobId);
    setStatus("排队中的文档审查任务已取消。");
    setPlainResult("排队中的文档审查任务已取消，未调用模型后台。\n任务编号：" + jobId);
  }

  function pollDocumentReviewJob(jobId, stopWaiting, resumeExpected, docSessionId) {
    var query = resumeExpected ? "?resume=1" : "";
    var targetDocSession = docSessionId || state.documentSessionId || "default";
    if (!jobId || state.documentReviewJobId !== jobId) {
      return;
    }
    request("/word/document-review/jobs/" + encodeURIComponent(jobId) + query, null, {
      timeoutMs: DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS
    })
      .then(function (body) {
        var job = body.data || {};
        if (state.documentReviewJobId !== jobId) {
          return;
        }
        state.documentReviewPollErrorCount = 0;
        setTrace(body.traceId || job.traceId || jobId);
        saveDocumentReviewActiveJob({
          jobId: jobId,
          host: "wps",
          taskType: "word.document_review",
          documentSessionId: targetDocSession,
          traceId: body.traceId || job.traceId || "",
          startedAt: state.documentReviewPollStartedAt || Date.now()
        });
        if (job.status === "completed") {
          cleanupDocumentReviewTerminal(targetDocSession, jobId);
          completeDocumentReview(job.result || {}, body.traceId || job.traceId || jobId, targetDocSession, jobId);
          return;
        }
        if (job.status === "cancelled") {
          finishCancelledDocumentReview(jobId, stopWaiting, targetDocSession);
          return;
        }
        if (job.status === "failed") {
          cleanupDocumentReviewTerminal(targetDocSession, jobId);
          var errMsg = (job.error && job.error.message) || "后台任务执行失败。";
          setStatus("文档审查失败：" + errMsg);
          setResult(errMsg);
          return;
        }
        renderDocumentReviewJobProgress(job, jobId);
        scheduleDocumentReviewPoll(jobId, stopWaiting, DOCUMENT_REVIEW_POLL_INTERVAL_MS, true, targetDocSession);
      })
      .catch(function (error) {
        var elapsed;
        var message;
        var withinRetryBudget;
        var retryDelay;
        if (state.documentReviewJobId !== jobId) {
          return;
        }
        message = describeDocumentReviewPollError(error);
        state.documentReviewPollErrorCount = (state.documentReviewPollErrorCount || 0) + 1;
        elapsed = Date.now() - (state.documentReviewPollStartedAt || Date.now());
        if (error && error.adapterCode === "DOCUMENT_REVIEW_JOB_INTERRUPTED") {
          cleanupDocumentReviewTerminal(targetDocSession, jobId);
          setStatus("adapter 已重启，原文档审查任务已中断，请重新提交。");
          setResult("adapter 已重启，原文档审查任务无法恢复。阻塞式模型请求不会伪装为可恢复，请重新提交文档审查。\n任务编号：" + jobId);
          setInterruptedRetryVisible(true);
          return;
        }
        if (!isFatalDocumentReviewPollError(error)) {
          withinRetryBudget = (
            state.documentReviewPollErrorCount <= DOCUMENT_REVIEW_POLL_MAX_ERRORS &&
            elapsed <= DOCUMENT_REVIEW_POLL_MAX_WAIT_MS
          );
          retryDelay = withinRetryBudget
            ? DOCUMENT_REVIEW_POLL_ERROR_RETRY_DELAY_MS
            : DOCUMENT_REVIEW_POLL_SLOW_RETRY_DELAY_MS;
          saveDocumentReviewActiveJob({
            jobId: jobId,
            host: "wps",
            taskType: "word.document_review",
            documentSessionId: targetDocSession,
            traceId: state.traceId || "",
            startedAt: state.documentReviewPollStartedAt || Date.now()
          });
          setStatus(withinRetryBudget
            ? "文档审查状态查询暂时失败，正在继续等待模型后台返回..."
            : "文档审查任务连接中断，正在尝试恢复状态查询...");
          setPlainResult([
            withinRetryBudget
              ? "文档审查状态查询暂时失败，adapter 后台任务可能仍在执行，将继续自动刷新。"
              : "文档审查任务连接中断，前台不会丢弃任务编号，将继续低频自动刷新。",
            "这不代表模型后台任务失败；如果模型后台已收到请求，请保持 WPS 和 adapter 打开。",
            "已重试：" + state.documentReviewPollErrorCount + "/" + DOCUMENT_REVIEW_POLL_MAX_ERRORS,
            "任务编号：" + jobId,
            "最近错误：" + message
          ].join("\n"));
          scheduleDocumentReviewPoll(jobId, stopWaiting, retryDelay, resumeExpected, targetDocSession);
          return;
        }
        cleanupDocumentReviewTerminal(targetDocSession, jobId);
        setStatus("文档审查状态查询持续失败，请查看最近一次任务诊断。");
        setResult([
          "文档审查状态查询持续失败，前台已暂停自动刷新。",
          "这不代表模型后台任务失败；如果模型后台已收到请求，adapter 可能仍在等待模型后台返回，或目标机网络/任务窗格连接不稳定。",
          "请到“设置-最近一次任务诊断”查看 trace、provider 状态和模型后台返回情况。",
          "任务编号：" + jobId,
          "最近错误：" + message
        ].join("\n"));
        stopDocumentReviewWaitFeedback(stopWaiting);
      });
  }

  function resumeDocumentReviewActiveJob() {
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    var active = loadDocumentReviewActiveJob(currentDoc);
    if (!active || !active.jobId || state.currentMode !== "documentReview") {
      return false;
    }
    if (active.host && active.host !== "wps") {
      return false;
    }
    if (active.taskType && active.taskType !== "word.document_review") {
      return false;
    }
    if (active.documentSessionId && currentDoc && active.documentSessionId !== currentDoc) {
      return false;
    }
    if (active.jobId === state.documentReviewJobId) {
      return true;
    }
    setDocumentReviewJobId(active.jobId);
    state.documentReviewPollStartedAt = active.startedAt || Date.now();
    state.documentReviewPollErrorCount = 0;
    if (helpers.claimTaskSlot) {
      helpers.claimTaskSlot(state.activeTaskSlots, "wps", "word.document_review", currentDoc, active.jobId);
    }
    setActiveReviewJobRecord("word.document_review", currentDoc, active);
    setApplyEnabled(false);
    setReviewRecordActionsVisible(false);
    setTrace(active.traceId || active.jobId);
    setStatus("已恢复未完成的文档审查任务，正在查询模型后台结果...");
    setPlainResult([
      "检测到未完成的文档审查任务，将继续查询 adapter 后台状态。",
      "如果模型后台仍在处理，请保持 WPS 和 adapter 打开。",
      "任务编号：" + active.jobId
    ].join("\n"));
    pollDocumentReviewJob(active.jobId, function () {}, true, currentDoc);
    return true;
  }

  function cancelQueuedDocumentReviewJob() {
    var jobId = state.documentReviewJobId;
    if (!jobId) {
      return;
    }
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    setDocumentReviewCancelVisible(true, true);
    setStatus("正在取消排队中的文档审查任务...");
    request("/word/document-review/jobs/" + encodeURIComponent(jobId) + "?resume=1", null, {
      method: "DELETE",
      timeoutMs: DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      var job = body.data || {};
      if (state.documentReviewJobId !== jobId) {
        return;
      }
      cleanupDocumentReviewTerminal(currentDoc, jobId);
      setStatus("排队中的文档审查任务已取消。");
      setPlainResult("排队中的文档审查任务已取消，未调用模型后台。\n任务编号：" + jobId);
    }).catch(function (error) {
      if (state.documentReviewJobId !== jobId) {
        return;
      }
      if (error && error.adapterCode === "LONG_TASK_NOT_CANCELLABLE") {
        setDocumentReviewCancelVisible(false);
        setStatus("文档审查已经开始运行，模型后台无法可靠取消。");
        return;
      }
      setDocumentReviewCancelVisible(true, false);
      setStatus("取消排队任务失败：" + describeDocumentReviewPollError(error));
    });
  }

  function writeClipboardText(text, successMessage) {
    if (!String(text || "").trim()) {
      setStatus("暂无可复制的内容。");
      return;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        setStatus(successMessage);
      }).catch(function () {
        setStatus("复制失败，请手动选择文本复制。");
      });
      return;
    }
    setStatus("当前环境不支持自动复制，请手动选择文本复制。");
  }

  function handleDocumentReviewAction(event) {
    var action = event.target.getAttribute("data-review-action");
    var indexText = event.target.getAttribute("data-issue-index");
    var index;
    var issue;
    if (!action) {
      return;
    }
    index = Number(indexText);
    issue = state.documentReviewData &&
      state.documentReviewData.issues &&
      state.documentReviewData.issues[index];
    if (!issue) {
      return;
    }
    if (action === "mark-done") {
      state.documentReviewIssueStatus[String(index)] = "done";
      renderDocumentReviewResult(state.documentReviewData);
      setStatus("已标记为已处理。");
      return;
    }
    if (action === "mark-ignored") {
      state.documentReviewIssueStatus[String(index)] = "ignored";
      renderDocumentReviewResult(state.documentReviewData);
      setStatus("已标记为忽略。");
      return;
    }
    if (action === "copy-suggestion") {
      writeClipboardText(issue.suggestion || "", "修改建议已复制。");
      return;
    }
    if (action === "copy-rewrite") {
      writeClipboardText(issue.suggestedRewrite || "", "建议改写已复制。");
    }
  }

  function copyDocumentReviewRecord() {
    writeClipboardText(getDocumentReviewRecordText(), "审查记录已复制。");
  }

  function toggleDocumentReviewRecordPreview() {
    var record;
    if (!state.documentReviewData) {
      setStatus("暂无可预览的审查记录。");
      return;
    }
    if (state.documentReviewRecordPreviewVisible) {
      renderDocumentReviewResult(state.documentReviewData);
      setStatus("已返回文档审查结果。");
      return;
    }
    record = getDocumentReviewRecordText();
    state.documentReviewRecordPreviewVisible = true;
    setResult(record, record);
    setReviewRecordActionsVisible(true);
    setStatus("正在预览审查记录。");
  }

  function copyResult() {
    var text = state.copyText || byId("result-output").textContent || "";
    if (!text.trim()) {
      setStatus("暂无可复制的结果。");
      return;
    }

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        setStatus("结果已复制。");
      }).catch(function () {
        fallbackCopy(text);
      });
      return;
    }

    fallbackCopy(text);
  }

  function setDiagnosticsResult(text) {
    var output = byId("last-task-diagnostics-output");
    if (helpers.renderMarkdown) {
      output.innerHTML = helpers.renderMarkdown(text);
    } else {
      output.textContent = text;
    }
    state.diagnosticsCopyText = text || "";
  }

  function refreshDiagnostics() {
    setDiagnosticsResult("正在刷新最近一次任务诊断...");
    var debugPath = "/provider/debug-last";
    if (state.traceId) {
      debugPath += "?traceId=" + encodeURIComponent(state.traceId);
    }
    return Promise.all([
      readAdapterJson(debugPath),
      readAdapterJson("/provider/status"),
      readAdapterJson("/provider/route-diagnostics"),
      readAdapterJson("/provider/task-api-keys")
    ]).then(function (results) {
      var markdown = renderProviderDiagnostics(results[0], results[1], results[2], results[3]);
      setDiagnosticsResult(markdown);
      setSettingsStatus("诊断信息已刷新。");
    });
  }

  function handleDiagnosticsDisclosureToggle(event) {
    if (event.currentTarget.open) {
      refreshDiagnostics();
    }
  }

  function copyDiagnostics() {
    var text = state.diagnosticsCopyText || byId("last-task-diagnostics-output").textContent || "";
    if (!text.trim()) {
      setSettingsStatus("暂无可复制的诊断信息。");
      return;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(function () {
        setSettingsStatus("诊断信息已复制。");
      }).catch(function () {
        fallbackCopy(text, setSettingsStatus);
      });
    }
    fallbackCopy(text, setSettingsStatus);
  }

  function applyDocumentReviewPrompt(documentType) {
    var nextType = DOCUMENT_REVIEW_PROMPTS[documentType] ? documentType : "technical_solution";
    state.technicalDocumentType = nextType;
    state.technicalReviewPrompt = DOCUMENT_REVIEW_PROMPTS[nextType];
    byId("technical-review-prompt").value = state.technicalReviewPrompt;
  }

  function fallbackCopy(text, feedback) {
    var textarea = document.createElement("textarea");
    var report = typeof feedback === "function" ? feedback : setStatus;
    textarea.value = text;
    textarea.setAttribute("readonly", "readonly");
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    document.body.appendChild(textarea);
    textarea.select();
    try {
      document.execCommand("copy");
      report("结果已复制。");
    } catch (error) {
      report("复制失败，请手动选择结果文本。");
    }
    document.body.removeChild(textarea);
  }

  function blockToWritebackLine(block) {
    if (!block) {
      return "";
    }
    if (block.type === "unorderedListItem") {
      return "• " + (block.text || "");
    }
    if (block.type === "orderedListItem") {
      return String(block.ordinal || 1) + ". " + (block.text || "");
    }
    return block.text || "";
  }

  function blockWritebackPrefixLength(block) {
    if (!block) {
      return 0;
    }
    if (block.type === "unorderedListItem") {
      return 2;
    }
    if (block.type === "orderedListItem") {
      return String(block.ordinal || 1).length + 2;
    }
    return 0;
  }

  function buildWritebackPlainText(blocks) {
    return blocks.map(blockToWritebackLine).filter(Boolean).join("\r");
  }

  function readValue(target, key) {
    try {
      return target ? target[key] : undefined;
    } catch (error) {
      return undefined;
    }
  }

  function setValue(target, key, value) {
    try {
      if (target && typeof target[key] !== "undefined") {
        target[key] = value;
        return true;
      }
    } catch (error) {
      return false;
    }
    return false;
  }

  function writeTextToTarget(target, text) {
    if (!target) {
      return false;
    }
    try {
      if (target.Range && typeof target.Range.Text !== "undefined") {
        target.Range.Text = text;
        return true;
      }
      if (typeof target.Text !== "undefined") {
        target.Text = text;
        return true;
      }
    } catch (error) {
      return false;
    }
    return false;
  }

  function getRangeFromTarget(target) {
    if (!target) {
      return null;
    }
    return readValue(target, "Range") || target;
  }

  function getRangeParagraph(range, index) {
    var paragraphs = readValue(range, "Paragraphs");
    if (!paragraphs) {
      return null;
    }
    if (helpers.getCollectionItem) {
      return helpers.getCollectionItem(paragraphs, index);
    }
    if (typeof paragraphs.Item === "function") {
      try {
        return paragraphs.Item(index);
      } catch (error) {
        return null;
      }
    }
    return paragraphs[index] || paragraphs[index - 1] || null;
  }

  function applyParagraphWritebackFormatting(range, blocks) {
    var formatted = false;
    blocks.forEach(function (block, index) {
      var paragraph = getRangeParagraph(range, index + 1);
      var paragraphRange = getRangeFromTarget(paragraph);
      var font = readValue(paragraphRange, "Font") || readValue(paragraph, "Font");
      var headingLevel = Math.min(block.level || 1, 3);
      var styleSet;

      if (block.type === "heading") {
        styleSet = setValue(paragraphRange, "Style", "标题 " + headingLevel);
        if (!styleSet) {
          styleSet = setValue(paragraphRange, "Style", "Heading " + headingLevel);
        }
        formatted = styleSet || formatted;
        formatted = setValue(font, "Bold", true) || formatted;
        formatted = setValue(font, "Size", headingLevel === 1 ? 16 : headingLevel === 2 ? 15 : 14) || formatted;
      }
    });
    return formatted;
  }

  function duplicateRange(range) {
    var duplicate = readValue(range, "Duplicate");
    if (typeof duplicate === "function") {
      return callNoArgs(duplicate, range);
    }
    return duplicate || null;
  }

  function applyBoldWritebackRuns(range, blocks) {
    var start = Number(readValue(range, "Start"));
    if (isNaN(start)) {
      return false;
    }

    var formatted = false;
    var offset = 0;
    blocks.forEach(function (block) {
      var line = blockToWritebackLine(block);
      var prefixLength = blockWritebackPrefixLength(block);
      var runOffset = prefixLength;

      (block.runs || []).forEach(function (run) {
        var runText = run.text || "";
        var runRange;
        if (run.bold && runText) {
          runRange = duplicateRange(range);
          if (runRange && typeof runRange.SetRange === "function") {
            try {
              runRange.SetRange(start + offset + runOffset, start + offset + runOffset + runText.length);
              formatted = setValue(readValue(runRange, "Font"), "Bold", true) || formatted;
            } catch (error) {
              return;
            }
          }
        }
        runOffset += runText.length;
      });

      offset += line.length + 1;
    });
    return formatted;
  }

  function tryApplyFormattedRewrite(target, text) {
    var blocks;
    var plainText;
    var range;
    if (!helpers.buildMarkdownWritebackBlocks) {
      return { ok: false, formatted: false, reason: "parser_unavailable" };
    }

    blocks = helpers.buildMarkdownWritebackBlocks(text);
    plainText = buildWritebackPlainText(blocks);
    if (!plainText) {
      return { ok: false, formatted: false, reason: "empty" };
    }
    if (!writeTextToTarget(target, plainText)) {
      return { ok: false, formatted: false, reason: "write_unavailable" };
    }

    range = getRangeFromTarget(target);
    var paragraphFormatted = applyParagraphWritebackFormatting(range, blocks);
    var boldFormatted = applyBoldWritebackRuns(range, blocks);
    return {
      ok: true,
      formatted: paragraphFormatted || boldFormatted,
      reason: "applied"
    };
  }

  function applyRewriteText(target, text, options) {
    var writeOptions = options || {};
    var formattedResult;
    var plainText;
    if (writeOptions.preferPlainText) {
      plainText = helpers.buildMarkdownWritebackBlocks
        ? buildWritebackPlainText(helpers.buildMarkdownWritebackBlocks(text))
        : text;
      if (writeTextToTarget(target, plainText || text)) {
        return { ok: true, formatted: false, reason: "plain_text_preferred" };
      }
      return { ok: false, formatted: false, reason: "plain_text_unavailable" };
    }

    formattedResult = tryApplyFormattedRewrite(target, text);
    if (formattedResult.ok) {
      return formattedResult;
    }
    if (writeTextToTarget(target, text)) {
      return { ok: true, formatted: false, reason: "plain_text_fallback" };
    }
    return formattedResult;
  }

  function applyRewrite() {
    var document = getActiveDocument();
    var applyResult = null;
    var currentDocSession;
    var activeResultRecord;
    var rewrittenText;
    var preferPlainText;
    if (!document || !state.rewriteResult) {
      return;
    }
    currentDocSession = helpers.getDocumentSessionId
      ? helpers.getDocumentSessionId(document)
      : state.documentSessionId;
    activeResultRecord = getActiveResultRecord("word.smart_write", currentDocSession);
    if (activeResultRecord && activeResultRecord.documentPayload) {
      state.latestDocumentPayload = activeResultRecord.documentPayload;
      state.latestSelectionMode = activeResultRecord.documentPayload.selectionMode || state.latestSelectionMode;
    }
    rewrittenText = state.rewriteResult.rewrittenText || "";
    preferPlainText = !shouldUseStructuredSmartWriteResult(rewrittenText);

    if (state.latestSelectionMode === "selection") {
      var writableSelection = getWritableSelection(document);
      var selectionCheck = helpers.canApplyRewriteToSelection
        ? helpers.canApplyRewriteToSelection(state.latestDocumentPayload.content.plainText, getSelectionText(document))
        : { ok: true };
      if (!selectionCheck.ok) {
        setStatus(selectionCheck.message);
        setResult(selectionCheck.message);
        return;
      }
      if (!writableSelection) {
        setStatus("未找到可写回的选区对象。");
        setResult("当前宿主未暴露可写回的选区对象，请反馈当前 WPS 版本、操作路径和选区截图。");
        return;
      }
      applyResult = applyRewriteText(writableSelection, rewrittenText, {
        preferPlainText: preferPlainText
      });
      if (!applyResult.ok) {
        setStatus("结果写回失败，请复制结果后手动粘贴。");
        setResult("当前宿主未开放可写回的正文对象，请复制结果后手动粘贴。");
        return;
      }
    } else if (document.Content) {
      applyResult = applyRewriteText(document.Content, rewrittenText, {
        preferPlainText: preferPlainText
      });
      if (!applyResult.ok) {
        setStatus("结果写回失败，请复制结果后手动粘贴。");
        setResult("当前宿主未开放可写回的正文对象，请复制结果后手动粘贴。");
        return;
      }
    }

    if (!applyResult) {
      setStatus("结果写回失败，请复制结果后手动粘贴。");
      setResult("当前宿主未开放可写回的正文对象，请复制结果后手动粘贴。");
      return;
    }

    state.pendingApplyAction = "";
    setApplyEnabled(false);
    if (!preferPlainText) {
      setStatus(applyResult.formatted ? "结果已尽量按结构化格式应用。" : "结果已按结构化文本应用。");
    } else {
      setStatus("结果已按原文段落形态应用。");
    }
  }

  function writingTaskLabel(taskType) {
    return taskType === "word.smart_imitation" ? "智能仿写" : "智能编写";
  }

  function writingJobPath(taskType) {
    return taskType === "word.smart_imitation"
      ? "/word/smart-imitation/jobs"
      : "/word/smart-write/jobs";
  }

  function writingJobUsesEvents(job) {
    if (job && typeof job.streamingEnabled === "boolean") {
      return job.streamingEnabled;
    }
    return Boolean(state.directStreamingEnabled);
  }

  function setWritingJob(jobId, taskType, mode) {
    state.writingJobId = jobId || "";
    state.writingJobTaskType = jobId ? taskType : "";
    state.writingJobMode = jobId ? mode : "";
    setModelTaskBusy(Boolean(jobId));
    if (!jobId) {
      setDocumentReviewCancelVisible(false);
    }
    renderWorkflowProfileStrip();
  }

  function startWritingWaitFeedback(jobId, taskType) {
    var timers = [];
    timers.push(setTimeout(function () {
      if (!state || state.writingJobId !== jobId) {
        return;
      }
      var currentDoc = (typeof helpers !== "undefined" && helpers && helpers.getDocumentSessionId && typeof getActiveDocument === "function")
        ? helpers.getDocumentSessionId(getActiveDocument())
        : (state && state.documentSessionId);
      var previewKey = [taskType, currentDoc, jobId].join("::");
      var preview = state && state.writingJobPreviews && state.writingJobPreviews[previewKey];
      if (preview && preview.text) {
        return;
      }
      if (typeof setStatus === "function") {
        setStatus("模型响应较慢，请稍候...");
      }
    }, 10000));

    timers.push(setTimeout(function () {
      if (!state || state.writingJobId !== jobId) {
        return;
      }
      var currentDoc = (typeof helpers !== "undefined" && helpers && helpers.getDocumentSessionId && typeof getActiveDocument === "function")
        ? helpers.getDocumentSessionId(getActiveDocument())
        : (state && state.documentSessionId);
      var previewKey = [taskType, currentDoc, jobId].join("::");
      var preview = state && state.writingJobPreviews && state.writingJobPreviews[previewKey];
      if (preview && preview.text) {
        return;
      }
      if (typeof setStatus === "function") {
        setStatus("模型后台仍在响应中，请继续等待...");
      }
    }, 30000));

    return function () {
      timers.forEach(function (timer) {
        clearTimeout(timer);
      });
    };
  }

  function stopWritingWaitFeedback() {
    if (typeof state !== "undefined" && state && typeof state.stopWritingWaitFeedback === "function") {
      try {
        state.stopWritingWaitFeedback();
      } catch (_) {}
      state.stopWritingWaitFeedback = null;
    }
  }

  function renderWritingJobProgress(job, taskType, jobId) {
    var label = writingTaskLabel(taskType);
    var phaseText = DOCUMENT_REVIEW_PHASE_TEXT[job.phase] || job.phase || "等待状态更新";
    var lines = [];
    if (job.status === "queued") {
      setStatus(label + "正在排队，当前位置：" + (job.queuePosition || 1) + "。");
      lines.push(label + "已进入共享任务队列。", "排队位置：" + (job.queuePosition || 1));
    } else {
      setStatus(label + "正在处理，当前阶段：" + phaseText + "。");
      lines.push(job.runningMessage || ("模型后台正在处理" + label + "。"), "当前阶段：" + phaseText);
    }
    lines.push("总耗时：" + Number(job.elapsedSeconds || 0) + " 秒", "任务编号：" + jobId);
    if (job.cancelRequested || job.phase === "stopping") {
      setDocumentReviewCancelVisible(true, true, "正在停止");
    } else if (job.status === "queued" && job.canCancel) {
      setDocumentReviewCancelVisible(true, false, "取消排队任务");
    } else if (job.status === "running" && job.canCancel) {
      setDocumentReviewCancelVisible(true, false, "停止生成");
    } else {
      setDocumentReviewCancelVisible(false, false);
    }

    var currentDoc = (helpers && helpers.getDocumentSessionId && typeof getActiveDocument === "function")
      ? helpers.getDocumentSessionId(getActiveDocument())
      : (state && state.documentSessionId);
    var previewKey = [taskType, currentDoc, jobId].join("::");
    var preview = state && state.writingJobPreviews && state.writingJobPreviews[previewKey];
    var output = byId("result-output");
    if (preview && preview.text) {
      if (output) {
        output.classList.remove("streaming-preview-wait");
      }
      return;
    }
    if (writingJobUsesEvents(job)) {
      var streamingPrompt;
      if (job.status === "queued") {
        streamingPrompt = label + "已进入队列。开始生成后，正文会逐步出现在这里。\n排队位置：第 " + (job.queuePosition || 1) + " 位";
      } else if (job.cancelRequested || job.phase === "stopping") {
        streamingPrompt = "正在停止生成。已出现的文字会保留，供查看和复制。";
      } else if (job.canCancel) {
        streamingPrompt = "正在生成增量文本预览。正文会逐步出现在这里。\n可以停止生成；已出现的文字只能查看和复制，还不是最终结果。";
      } else {
        streamingPrompt = "正在生成增量文本预览。正文会逐步出现在这里。\n已出现的文字只能查看和复制，还不是最终结果。";
      }
      setPlainResult(streamingPrompt);
      if (output) {
        output.classList.add("streaming-preview-wait");
      }
      return;
    }
    if (output) {
      output.classList.remove("streaming-preview-wait");
    }
    setPlainResult(lines.join("\n"));
  }

  function completeWritingJob(result, traceId, taskType, resumed, mode, jobId, docSessionId) {
    if (typeof stopWritingWaitFeedback === "function") {
      stopWritingWaitFeedback();
    }
    var completionTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var label = writingTaskLabel(taskType);
    var targetJobId = jobId || traceId || state.writingJobId || "";
    var targetDocSession = docSessionId || state.documentSessionId || "default";
    var activeJobRecord = getActiveWritingJobRecord(taskType, targetDocSession);
    var submittedDocumentPayload = activeJobRecord &&
      (!targetJobId || activeJobRecord.jobId === targetJobId)
      ? activeJobRecord.documentPayload
      : null;

    if (targetJobId) {
      releaseTaskSlotsForJob(targetJobId);
      if (helpers.releaseTaskSlot) {
        helpers.releaseTaskSlot(state.activeTaskSlots, "wps", taskType, targetDocSession, targetJobId);
      }
      clearWritingActiveJob(targetJobId, taskType, targetDocSession);
      var previewKey = [taskType, targetDocSession, targetJobId].join("::");
      if (state && state.writingJobPreviews && state.writingJobPreviews[previewKey]) {
        if (state.writingJobPreviews[previewKey].renderTimer) {
          clearTimeout(state.writingJobPreviews[previewKey].renderTimer);
        }
        delete state.writingJobPreviews[previewKey];
      }
    }
    setActiveWritingJobRecord(taskType, targetDocSession, null);

    var isCurrentGlobalJob = (!targetJobId || state.writingJobId === targetJobId);
    if (isCurrentGlobalJob) {
      setWritingJob("", "", "");
      state.writingJobStartedAt = 0;
      state.writingJobPollErrorCount = 0;
      setModelTaskBusy(false);
    }

    var canApply = (taskType === "word.smart_write") && !resumed && Boolean(submittedDocumentPayload);
    var pendingApplyAction = taskType === "word.smart_write" && canApply ? "rewrite" : "";
    var resultRecord = {
      result: result || {},
      traceId: traceId || targetJobId || "",
      taskType: taskType,
      documentSessionId: targetDocSession,
      resumed: Boolean(resumed),
      pendingApplyAction: pendingApplyAction,
      documentPayload: canApply ? submittedDocumentPayload : null,
      completedAt: Date.now()
    };
    setActiveResultRecord(taskType, targetDocSession, resultRecord);

    var notice = result && result.historyNotice ? "（" + result.historyNotice + "）" : "";

    if (state.historyOpen) {
      state.historyUnreadCount = (state.historyUnreadCount || 0) + 1;
      updateHistoryBadge();
      setStatus(label + "结果已在后台生成。" + notice);
      return;
    }

    var targetMode = mode || (taskType === "word.smart_imitation" ? "smartImitation" : "smartWrite");
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    var isCurrentView = (state.currentMode === targetMode) && (!targetDocSession || targetDocSession === currentDoc || !currentDoc);

    if (isCurrentView) {
      if (resultRecord.documentPayload) {
        state.latestDocumentPayload = resultRecord.documentPayload;
        state.latestSelectionMode = resultRecord.documentPayload.selectionMode || state.latestSelectionMode;
      }
      state.pendingApplyAction = resultRecord.pendingApplyAction;
      state.rewriteResult = setSmartWriteResult(result || {}, taskType);
      setApplyEnabled(state.pendingApplyAction === "rewrite");
      setTrace(traceId || targetJobId || "");
      if (taskType === "word.smart_imitation") {
        hideCompareForSmartImitation();
      }
      setStatus(label + "结果已生成。" + notice + (resumed && taskType === "word.smart_write" ? "为保护原选区，本次恢复结果仅供预览和复制。" : ""));
      recordTaskFirstRender(targetJobId, traceId || targetJobId || "", taskType, completionTimestamp);
    } else {
      state.historyUnreadCount = (state.historyUnreadCount || 0) + 1;
      updateHistoryBadge();
      setStatus(label + "结果已在后台生成。" + notice);
    }
  }

  function failWritingJob(jobId, taskType, mode, error, docSessionId) {
    if (typeof stopWritingWaitFeedback === "function") {
      stopWritingWaitFeedback();
    }
    var targetJobId = jobId || "";
    var targetDocSession = docSessionId || state.documentSessionId || "default";
    var previewKey = [taskType, targetDocSession, targetJobId].join("::");
    var preview = state.writingJobPreviews && state.writingJobPreviews[previewKey];
    var partialText = (preview && preview.text) || "";

    if (targetJobId) {
      releaseTaskSlotsForJob(targetJobId);
      if (helpers.releaseTaskSlot) {
        helpers.releaseTaskSlot(state.activeTaskSlots, "wps", taskType, targetDocSession, targetJobId);
      }
      clearWritingActiveJob(targetJobId, taskType, targetDocSession);
      if (preview) {
        if (preview.renderTimer) {
          clearTimeout(preview.renderTimer);
        }
        delete state.writingJobPreviews[previewKey];
      }
    }
    setActiveWritingJobRecord(taskType, targetDocSession, null);
    setActiveResultRecord(taskType, targetDocSession, null);

    var targetMode = mode || (taskType === "word.smart_imitation" ? "smartImitation" : "smartWrite");
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    var isCurrentView = (state.currentMode === targetMode) && (!targetDocSession || targetDocSession === currentDoc || !currentDoc);

    if (isCurrentView || (targetJobId && state.writingJobId === targetJobId)) {
      setWritingJob("", "", "");
      state.writingJobStartedAt = 0;
      state.writingJobPollErrorCount = 0;
      setModelTaskBusy(false);
    }
    var errorMsg = (error && error.message) || describeFetchError(error) || "后台任务执行失败。";
    if (isCurrentView) {
      if (partialText) {
        setPlainResult(partialText, partialText);
        setApplyEnabled(false);
        setStatus(writingTaskLabel(taskType) + "失败：" + errorMsg + "，已保留已接收内容部分预览（只读，不可写回）。");
      } else {
        setStatus(writingTaskLabel(taskType) + "失败：" + errorMsg);
        setResult(errorMsg);
      }
    }
  }

  function updateHistoryBadge() {
    var badge = byId("history-unread-badge");
    if (!badge) {
      return;
    }
    var count = Number(state.historyUnreadCount || 0);
    if (count > 0) {
      badge.textContent = count > 99 ? "99+" : String(count);
      badge.hidden = false;
    } else {
      badge.textContent = "0";
      badge.hidden = true;
    }
  }

  function switchWordHistoryView(open) {
    state.historyOpen = Boolean(open);
    var historyView = byId("word-history-view");
    var resultSection = byId("word-result-section");
    if (historyView) {
      historyView.hidden = !state.historyOpen;
    }
    if (resultSection) {
      resultSection.hidden = state.historyOpen;
    }
    if (state.historyOpen) {
      state.historyUnreadCount = 0;
      updateHistoryBadge();
      loadAndRenderWritingHistory();
    } else {
      var taskType = getCurrentWorkflowTaskType();
      var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
      if (taskType === "word.format_review") {
        if (!state.viewingHistoryReport) {
          var activeRecord = getActiveResultRecord("word.format_review", currentDoc);
          if (activeRecord && activeRecord.result) {
            var res = activeRecord.result;
            setTrace(activeRecord.traceId || activeRecord.jobId || "");
            var fmtReport = res.report || res;
            var fmtJobId = res.reportId || res.jobId || activeRecord.jobId || activeRecord.traceId;
            state.deterministicFormatReviewReport = fmtReport;
            state.deterministicFormatReviewIssueJobId = fmtJobId;
            renderDeterministicFormatReviewReport(fmtReport, fmtJobId);
          }
        }
      } else if (taskType === "word.document_review") {
        if (!state.viewingHistoryReport) {
          var activeRecord = getActiveResultRecord("word.document_review", currentDoc);
          if (activeRecord && activeRecord.result) {
            var res = activeRecord.result;
            setTrace(activeRecord.traceId || "");
            if (res.reportType === "full_document_review" || res.report) {
              renderFullDocumentReviewReport(res.report || res, res.reportId || activeRecord.traceId);
            } else {
              renderDocumentReviewResult(res);
            }
          }
        }
      } else {
        var activeRecord = getActiveResultRecord(taskType, currentDoc);
        if (activeRecord) {
          var res = activeRecord.result || activeRecord;
          if (activeRecord.documentPayload) {
            state.latestDocumentPayload = activeRecord.documentPayload;
            state.latestSelectionMode = activeRecord.documentPayload.selectionMode || state.latestSelectionMode;
          }
          state.rewriteResult = setSmartWriteResult(res, taskType);
          var canApply = state.currentMode === "smartWrite" &&
            !activeRecord.resumed &&
            activeRecord.pendingApplyAction === "rewrite" &&
            Boolean(activeRecord.documentPayload);
          state.pendingApplyAction = canApply ? "rewrite" : "";
          setApplyEnabled(canApply);
          setTrace(activeRecord.traceId || "");
          if (taskType === "word.smart_imitation") {
            hideCompareForSmartImitation();
          }
        }
      }
    }
  }

  function loadAndRenderWritingHistory(targetTaskType) {
    var contentEl = byId("word-history-content");
    if (contentEl) {
      contentEl.innerHTML = '<div class="word-history-empty">正在加载历史记录...</div>';
    }
    var taskType = targetTaskType || getCurrentWorkflowTaskType();
    state.historyTaskType = taskType;
    var currentSeq = (state.historyLoadSequence || 0) + 1;
    state.historyLoadSequence = currentSeq;
    return request("/history?taskType=" + encodeURIComponent(taskType), null, {
      timeoutMs: 8000
    }).then(function (body) {
      if (state.historyLoadSequence !== currentSeq || state.historyTaskType !== taskType) {
        return [];
      }
      var data = body && body.data;
      var items = (data && Array.isArray(data.items)) ? data.items : (Array.isArray(data) ? data : []);
      state.historyItems = items;
      if (contentEl) {
        contentEl.innerHTML = helpers.renderWritingHistoryList(state.historyItems);
      }
      return items;
    }).catch(function (error) {
      if (state.historyLoadSequence !== currentSeq || state.historyTaskType !== taskType) {
        return;
      }
      if (contentEl) {
        contentEl.innerHTML = '<div class="word-history-empty">读取历史记录失败：' + (helpers.escapeHtml ? helpers.escapeHtml(error.message) : error.message) + '</div>';
      }
    });
  }

  function handleClearWritingHistory() {
    var taskType = state.historyTaskType || getCurrentWorkflowTaskType();
    return request("/history?taskType=" + encodeURIComponent(taskType), null, {
      method: "DELETE",
      timeoutMs: 8000
    }).then(function () {
      state.historyItems = [];
      var contentEl = byId("word-history-content");
      if (contentEl) {
        contentEl.innerHTML = helpers.renderWritingHistoryList([]);
      }
      setStatus("历史记录已清空。");
    }).catch(function (error) {
      setStatus("清空历史记录失败：" + error.message);
    });
  }

  function handleWritingHistoryContentClick(event) {
    var target = event.target;
    if (!target) {
      return;
    }
    var viewBtn = target.closest ? target.closest(".btn-history-view") : null;
    var copyBtn = target.closest ? target.closest(".btn-history-copy") : null;
    var deleteBtn = target.closest ? target.closest(".btn-history-delete") : null;

    if (viewBtn) {
      var id = viewBtn.getAttribute("data-history-id");
      handleWritingHistoryViewItem(id, viewBtn);
      return;
    }
    if (copyBtn) {
      var copyId = copyBtn.getAttribute("data-history-id");
      handleWritingHistoryCopyItem(copyId);
      return;
    }
    if (deleteBtn) {
      var deleteId = deleteBtn.getAttribute("data-history-id");
      handleWritingHistoryDeleteItem(deleteId);
      return;
    }
  }

  function handleWritingHistoryViewItem(id, btn) {
    var item = null;
    for (var i = 0; i < (state.historyItems || []).length; i += 1) {
      if (state.historyItems[i].id === id) {
        item = state.historyItems[i];
        break;
      }
    }
    if (!item) {
      return;
    }
    var card = btn.closest ? btn.closest(".word-history-card") : null;
    if (!card) {
      return;
    }
    var existingDetail = card.querySelector(".word-history-card-detail");
    if (existingDetail) {
      if (existingDetail.hidden) {
        existingDetail.hidden = false;
        btn.textContent = "收起";
      } else {
        existingDetail.hidden = true;
        btn.textContent = "查看";
      }
      return;
    }
    var detailDiv = document.createElement("div");
    detailDiv.className = "word-history-card-detail";
    detailDiv.style.marginTop = "8px";
    detailDiv.style.paddingTop = "8px";
    detailDiv.style.borderTop = "1px dashed var(--hairline, #e2e8f0)";
    detailDiv.style.fontSize = "12px";
    detailDiv.style.lineHeight = "1.5";

    var result = item.result || {};
    var actionsDiv = card.querySelector(".word-history-card-actions");

    if (result.reportType === "format_review" || item.taskType === "word.format_review") {
      var formatJobId = result.reportId || result.jobId || item.jobId;
      detailDiv.innerHTML = '<div class="history-detail-loading">正在读取格式审查专用报告...</div>';
      btn.textContent = "收起";
      if (actionsDiv) {
        card.insertBefore(detailDiv, actionsDiv);
      } else {
        card.appendChild(detailDiv);
      }
      return request("/word/format-review/jobs/" + encodeURIComponent(formatJobId) + "/report?format=summary", null, {
        timeoutMs: 8000
      }).then(function (reportBody) {
        var report = reportBody.data || {};
        var summary = report.summary || result.summary || {};
        var issueCount = Number(report.issueCount !== undefined ? report.issueCount : (result.issueCount || 0));
        var summaryText = "格式审查报告（共 " + issueCount + " 项问题）";
        var openBtnHtml = '<div style="margin-top:8px;"><button type="button" class="btn btn-secondary btn-sm btn-open-format-report btn-open-full-report">在窗格中查看完整报告</button></div>';
        detailDiv.innerHTML = '<div>' + summaryText + '</div>' + openBtnHtml;
        var openBtn = detailDiv.querySelector(".btn-open-format-report") || detailDiv.querySelector(".btn-open-full-report");
        if (openBtn) {
          openBtn.addEventListener("click", function () {
            state.viewingHistoryReport = {
              report: report,
              jobId: formatJobId,
              taskType: "word.format_review",
              documentDisplayName: item.documentDisplayName
            };
            switchWordHistoryView(false);
            renderDeterministicFormatReviewReport(report, formatJobId);
          });
        }
      }).catch(function () {
        detailDiv.innerHTML = '<div class="history-report-expired" style="color:var(--danger, #dc2626);">专用报告已过期或不可用。</div>';
      });
    }

    if (result.reportType === "full_document_review") {
      var fullJobId = result.reportId || result.jobId || item.jobId;
      detailDiv.innerHTML = '<div class="history-detail-loading">正在读取全篇审查专用报告...</div>';
      btn.textContent = "收起";
      if (actionsDiv) {
        card.insertBefore(detailDiv, actionsDiv);
      } else {
        card.appendChild(detailDiv);
      }
      return request("/word/document-review/full/jobs/" + encodeURIComponent(fullJobId) + "/report", null, {
        timeoutMs: 8000
      }).then(function (reportBody) {
        var report = reportBody.data || {};
        var summaryText = helpers.escapeHtml ? helpers.escapeHtml(report.summary || result.summary || "") : (report.summary || result.summary || "");
        var issueCount = Number(report.issueCount !== undefined ? report.issueCount : (result.issueCount || 0));
        var openBtnHtml = '<div style="margin-top:8px;"><button type="button" class="btn btn-secondary btn-sm btn-open-full-report">在窗格中查看完整报告</button></div>';
        detailDiv.innerHTML = '<div>' + summaryText + '（共 ' + issueCount + ' 项问题）</div>' + openBtnHtml;
        var openBtn = detailDiv.querySelector(".btn-open-full-report");
        if (openBtn) {
          openBtn.addEventListener("click", function () {
            state.viewingHistoryReport = {
              report: report,
              jobId: fullJobId,
              documentDisplayName: item.documentDisplayName
            };
            switchWordHistoryView(false);
            renderFullDocumentReviewReport(report, fullJobId).catch(function (err) {
              setStatus("打开报告失败：" + describeFetchError(err));
            });
          });
        }
      }).catch(function () {
        detailDiv.innerHTML = '<div class="history-report-expired" style="color:var(--danger, #dc2626);">专用报告已过期或不可用。</div>';
      });
    }

    if (item.taskType === "word.document_review") {
      var docSummary = helpers.escapeHtml ? helpers.escapeHtml(result.summary || "无审查摘要") : (result.summary || "无审查摘要");
      var docIssueCount = Number(result.issueCount || 0);
      var categoryParts = [];
      if (result.categoryCounts) {
        for (var cat in result.categoryCounts) {
          if (Object.prototype.hasOwnProperty.call(result.categoryCounts, cat)) {
            categoryParts.push(cat + ": " + result.categoryCounts[cat]);
          }
        }
      }
      var catStr = categoryParts.length ? ('<div style="margin-top:4px;color:var(--text-muted, #64748b);">问题分类：' + helpers.escapeHtml(categoryParts.join(", ")) + '</div>') : "";
      detailDiv.innerHTML = '<div><strong>' + docSummary + '</strong></div>' +
        '<div>发现问题：' + docIssueCount + ' 项</div>' + catStr;
      if (actionsDiv) {
        card.insertBefore(detailDiv, actionsDiv);
      } else {
        card.appendChild(detailDiv);
      }
      btn.textContent = "收起";
      return;
    }

    var text = result.rewrittenText || result.plainText || "";
    var renderedHtml = helpers.renderMarkdown
      ? helpers.renderMarkdown(text)
      : (helpers.escapeHtml ? helpers.escapeHtml(text) : text);
    detailDiv.innerHTML = renderedHtml;

    if (actionsDiv) {
      card.insertBefore(detailDiv, actionsDiv);
    } else {
      card.appendChild(detailDiv);
    }
    btn.textContent = "收起";
  }

  function handleWritingHistoryCopyItem(id) {
    var item = null;
    for (var i = 0; i < (state.historyItems || []).length; i += 1) {
      if (state.historyItems[i].id === id) {
        item = state.historyItems[i];
        break;
      }
    }
    if (!item) {
      setStatus("未找到对应历史记录。");
      return;
    }
    var res = item.result || {};
    var text = res.plainText || res.rewrittenText || "";
    if (!text) {
      text = JSON.stringify(res, null, 2);
    }
    copyText(text, "历史结果已复制。");
  }

  function handleWritingHistoryDeleteItem(id) {
    if (!id) {
      return Promise.resolve();
    }
    return request("/history/" + encodeURIComponent(id), null, {
      method: "DELETE",
      timeoutMs: 8000
    }).then(function () {
      state.historyItems = (state.historyItems || []).filter(function (it) {
        return it.id !== id;
      });
      var container = byId("word-history-content");
      if (container) {
        container.innerHTML = helpers.renderWritingHistoryList(state.historyItems);
      }
      setStatus("已删除该条历史记录。");
    }).catch(function (error) {
      setStatus("删除历史记录失败：" + error.message);
    });
  }

  function isFatalWritingPollError(error) {
    var code = error && error.adapterCode || "";
    return code.indexOf("SMART_WRITE_JOB_") === 0 ||
      code.indexOf("SMART_IMITATION_JOB_") === 0 ||
      code === "LONG_TASK_QUEUE_FULL" ||
      code === "REQUEST_VALIDATION_FAILED";
  }

  function scheduleWritingPoll(jobId, taskType, mode, resumed, delayMs, docSessionId) {
    setTimeout(function () {
      pollWritingJob(jobId, taskType, mode, resumed, docSessionId);
    }, delayMs);
  }

  function pollWritingJob(jobId, taskType, mode, resumed, docSessionId) {
    if (!jobId) {
      return;
    }
    var targetDocSession = docSessionId || state.documentSessionId || "default";
    request(writingJobPath(taskType) + "/" + encodeURIComponent(jobId) + "?resume=1", null, {
      timeoutMs: WRITING_POLL_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      var job = body.data || {};
      state.writingJobPollErrorCount = 0;
      saveWritingActiveJob({
        jobId: jobId,
        taskType: taskType,
        mode: mode,
        documentSessionId: targetDocSession,
        traceId: body.traceId || job.traceId || "",
        startedAt: state.writingJobStartedAt || Date.now()
      });
      if (job.status === "completed") {
        releaseTaskSlotsForJob(jobId);
        if (helpers.releaseTaskSlot) {
          helpers.releaseTaskSlot(state.activeTaskSlots, "wps", taskType, targetDocSession, jobId);
        }
        clearWritingActiveJob(jobId, taskType, targetDocSession);
        completeWritingJob(job.result || {}, body.traceId || job.traceId || jobId, taskType, resumed, mode, jobId, targetDocSession);
        return;
      }
      if (job.status === "cancelled") {
        releaseTaskSlotsForJob(jobId);
        if (helpers.releaseTaskSlot) {
          helpers.releaseTaskSlot(state.activeTaskSlots, "wps", taskType, targetDocSession, jobId);
        }
        clearWritingActiveJob(jobId, taskType, targetDocSession);
        setActiveWritingJobRecord(taskType, targetDocSession, null);

        var targetMode = mode || (taskType === "word.smart_imitation" ? "smartImitation" : "smartWrite");
        var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
        var isCurrentView = (state.currentMode === targetMode) && (!targetDocSession || targetDocSession === currentDoc || !currentDoc);
        var previewKey = [taskType, targetDocSession, jobId].join("::");
        var preview = state.writingJobPreviews && state.writingJobPreviews[previewKey];
        var partialText = (preview && preview.text) || "";
        if (preview) {
          if (preview.renderTimer) {
            clearTimeout(preview.renderTimer);
          }
          delete state.writingJobPreviews[previewKey];
        }

        if (isCurrentView || state.writingJobId === jobId) {
          setWritingJob("", "", "");
          setModelTaskBusy(false);
        }
        if (isCurrentView) {
          if (partialText) {
            setPlainResult(partialText, partialText);
            setApplyEnabled(false);
            setStatus(writingTaskLabel(taskType) + "已停止生成，保留已生成部分预览（只读，不可写回）。");
          } else {
            setStatus("排队中的" + writingTaskLabel(taskType) + "任务已取消。");
            setPlainResult("排队任务已取消，未调用模型后台。\n任务编号：" + jobId);
          }
        }
        return;
      }
      if (job.status === "failed") {
        failWritingJob(jobId, taskType, mode, job.error, targetDocSession);
        return;
      }
      if (state.currentMode === mode) {
        renderWritingJobProgress(Object.assign({}, job, { streamingEnabled: false }), taskType, jobId);
      }
      scheduleWritingPoll(jobId, taskType, mode, resumed, WRITING_POLL_INTERVAL_MS, targetDocSession);
    }).catch(function (error) {
      state.writingJobPollErrorCount += 1;
      if (isFatalWritingPollError(error)) {
        failWritingJob(jobId, taskType, mode, error, targetDocSession);
        return;
      }
      if (state.currentMode === mode) {
        setStatus(writingTaskLabel(taskType) + "状态查询暂时失败，将继续自动刷新。");
        setPlainResult([
          "状态查询暂时未连上本地 adapter；这不代表模型后台任务失败。",
          "已重试：" + state.writingJobPollErrorCount,
          "任务编号：" + jobId,
          "最近错误：" + describeFetchError(error)
        ].join("\n"));
      }
      scheduleWritingPoll(jobId, taskType, mode, resumed, WRITING_POLL_RETRY_DELAY_MS, targetDocSession);
    });
  }

  function appendWritingJobPreviewDelta(consumerKey, delta, taskType, jobId, targetDocSession, mode) {
    if (!delta || typeof delta !== "string") {
      return;
    }
    state.writingJobPreviews = state.writingJobPreviews || {};
    var preview = state.writingJobPreviews[consumerKey];
    if (!preview) {
      preview = {
        jobId: jobId,
        taskType: taskType,
        documentSessionId: targetDocSession,
        mode: mode,
        text: "",
        lastRenderAt: 0,
        renderTimer: null
      };
      state.writingJobPreviews[consumerKey] = preview;
    }
    preview.text += delta;
    scheduleWritingJobPreviewRender(consumerKey);
  }

  function setWritingJobPreviewSnapshot(consumerKey, snapshot, taskType, jobId, targetDocSession, mode) {
    if (!snapshot || typeof snapshot.text !== "string") {
      return;
    }
    state.writingJobPreviews = state.writingJobPreviews || {};
    var preview = state.writingJobPreviews[consumerKey];
    if (!preview) {
      preview = {
        jobId: jobId,
        taskType: taskType,
        documentSessionId: targetDocSession,
        mode: mode,
        text: "",
        lastRenderAt: 0,
        renderTimer: null
      };
      state.writingJobPreviews[consumerKey] = preview;
    }
    preview.text = snapshot.text;
    scheduleWritingJobPreviewRender(consumerKey);
  }

  function scheduleWritingJobPreviewRender(consumerKey) {
    var preview = state && state.writingJobPreviews && state.writingJobPreviews[consumerKey];
    if (!preview) {
      return;
    }
    var now = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var elapsed = now - (preview.lastRenderAt || 0);

    function renderNow() {
      if (preview.renderTimer) {
        clearTimeout(preview.renderTimer);
        preview.renderTimer = null;
      }
      preview.lastRenderAt = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
      renderWritingJobPreview(consumerKey);
    }

    if (elapsed >= 50) {
      renderNow();
    } else if (!preview.renderTimer) {
      var remaining = Math.max(0, 50 - elapsed);
      preview.renderTimer = setTimeout(function () {
        renderNow();
      }, remaining);
    }
  }

  function flushWritingJobPreviewRender(consumerKey) {
    var preview = state && state.writingJobPreviews && state.writingJobPreviews[consumerKey];
    if (!preview) {
      return;
    }
    if (preview.renderTimer) {
      clearTimeout(preview.renderTimer);
      preview.renderTimer = null;
    }
    preview.lastRenderAt = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    renderWritingJobPreview(consumerKey);
  }

  function renderWritingJobPreview(consumerKey) {
    var preview = state && state.writingJobPreviews && state.writingJobPreviews[consumerKey];
    if (!preview) {
      return;
    }
    var currentDoc = (helpers && helpers.getDocumentSessionId && typeof getActiveDocument === "function")
      ? helpers.getDocumentSessionId(getActiveDocument())
      : (state && state.documentSessionId);
    var targetMode = preview.mode || (preview.taskType === "word.smart_imitation" ? "smartImitation" : "smartWrite");
    var isCurrent = (state && state.currentMode === targetMode) &&
      (state && state.writingJobId === preview.jobId) &&
      (!preview.documentSessionId || preview.documentSessionId === currentDoc || !currentDoc);

    if (!isCurrent) {
      return;
    }

    var output = byId("result-output");
    if (!output) {
      return;
    }
    output.hidden = false;
    output.classList.remove("markdown-body");
    output.classList.remove("streaming-preview-wait");
    output.classList.add("plain-output");

    var viewSwitch = byId("result-view-switch");
    if (viewSwitch) {
      viewSwitch.hidden = true;
    }
    if (typeof clearWritingPolicyUsage === "function") {
      clearWritingPolicyUsage();
    }
    if (typeof hideCompareForSmartImitation === "function") {
      hideCompareForSmartImitation();
    }

    var isAtBottom = (output.scrollHeight - output.scrollTop - output.clientHeight) <= 30;
    output.textContent = preview.text;
    state.copyText = preview.text;

    if (isAtBottom) {
      output.scrollTop = output.scrollHeight;
    }
  }

  function pollWritingJobEvents(jobId, taskType, mode, resumed, docSessionId, afterSequence, consecutiveErrors, consumerVersion) {
    if (!jobId) {
      return;
    }
    var waitMs = typeof WRITING_EVENTS_WAIT_MS !== "undefined" ? WRITING_EVENTS_WAIT_MS : 25000;
    var reqTimeoutMs = typeof WRITING_EVENTS_REQUEST_TIMEOUT_MS !== "undefined" ? WRITING_EVENTS_REQUEST_TIMEOUT_MS : 35000;
    var targetDocSession = docSessionId || (state && state.documentSessionId) || "default";
    var seq = typeof afterSequence === "number" ? afterSequence : 0;
    var errors = typeof consecutiveErrors === "number" ? consecutiveErrors : 0;
    var consumerKey = [taskType, targetDocSession, jobId].join("::");
    state.writingEventConsumers = state.writingEventConsumers || {};
    var activeConsumerVersion = consumerVersion;
    if (typeof activeConsumerVersion !== "number") {
      activeConsumerVersion = Number(state.writingEventConsumers[consumerKey] || 0) + 1;
      state.writingEventConsumers[consumerKey] = activeConsumerVersion;
    }

    function isCurrentConsumer() {
      return state.writingEventConsumers[consumerKey] === activeConsumerVersion;
    }

    function stopCurrentConsumer() {
      if (isCurrentConsumer()) {
        delete state.writingEventConsumers[consumerKey];
      }
    }

    function isCurrentWritingView() {
      var currentDoc = (helpers && helpers.getDocumentSessionId && typeof getActiveDocument === "function")
        ? helpers.getDocumentSessionId(getActiveDocument())
        : state.documentSessionId;
      return state.currentMode === mode &&
        state.writingJobId === jobId &&
        (!targetDocSession || targetDocSession === currentDoc || !currentDoc);
    }
    var url = writingJobPath(taskType) + "/" + encodeURIComponent(jobId) + "/events?afterSequence=" + seq + "&waitMs=" + waitMs;

    request(url, null, {
      timeoutMs: reqTimeoutMs
    }).then(function (body) {
      if (!isCurrentConsumer()) {
        return;
      }
      var payload = body.data || {};
      var events = payload.events || [];
      var nextSequence = (typeof payload.latestSequence === "number") ? payload.latestSequence : seq;
      var isTerminal = Boolean(payload.terminal);
      var terminalStatus = payload.status || (events.length > 0 ? events[events.length - 1].status : "");

      saveWritingActiveJob({
        jobId: jobId,
        taskType: taskType,
        mode: mode,
        documentSessionId: targetDocSession,
        traceId: body.traceId || jobId,
        startedAt: (state && state.writingJobStartedAt) || Date.now()
      });

      var snapshotSequence = -1;
      if (payload.previewSnapshot) {
        snapshotSequence = (typeof payload.previewSnapshot.latestSequence === "number")
          ? payload.previewSnapshot.latestSequence
          : nextSequence;
        if (typeof setWritingJobPreviewSnapshot === "function") {
          setWritingJobPreviewSnapshot(consumerKey, payload.previewSnapshot, taskType, jobId, targetDocSession, mode);
        }
        if (isCurrentWritingView()) {
          renderWritingJobProgress(payload.previewSnapshot, taskType, jobId);
        }
      }

      for (var i = 0; i < events.length; i++) {
        var evt = events[i];
        if (typeof evt.sequence === "number" && evt.sequence <= snapshotSequence) {
          continue;
        }
        if (typeof evt.sequence === "number" && evt.sequence > nextSequence) {
          nextSequence = evt.sequence;
        }
        if (evt.type === "delta" && typeof evt.delta === "string") {
          if (typeof appendWritingJobPreviewDelta === "function") {
            appendWritingJobPreviewDelta(consumerKey, evt.delta, taskType, jobId, targetDocSession, mode);
          }
        } else if (isCurrentWritingView()) {
          renderWritingJobProgress(evt, taskType, jobId);
        }
      }

      if (payload.previewTruncated && !isTerminal && isCurrentWritingView()) {
        setStatus("正文预览已达到 512 KiB 上限，后台仍在生成完整结果。");
      }

      if (isTerminal || terminalStatus === "completed" || terminalStatus === "cancelled" || terminalStatus === "failed") {
        if (terminalStatus === "completed") {
          stopCurrentConsumer();
          if (typeof stopWritingWaitFeedback === "function") {
            stopWritingWaitFeedback();
          }
          if (typeof flushWritingJobPreviewRender === "function") {
            flushWritingJobPreviewRender(consumerKey);
          }
          pollWritingJob(jobId, taskType, mode, resumed, targetDocSession);
          return;
        }
        if (terminalStatus === "cancelled") {
          stopCurrentConsumer();
          if (typeof stopWritingWaitFeedback === "function") {
            stopWritingWaitFeedback();
          }
          var preview = state.writingJobPreviews && state.writingJobPreviews[consumerKey];
          var partialText = (preview && preview.text) || (payload.previewSnapshot && payload.previewSnapshot.text) || "";
          if (state.writingJobPreviews && state.writingJobPreviews[consumerKey]) {
            if (state.writingJobPreviews[consumerKey].renderTimer) {
              clearTimeout(state.writingJobPreviews[consumerKey].renderTimer);
            }
            delete state.writingJobPreviews[consumerKey];
          }
          if (typeof releaseTaskSlotsForJob === "function") {
            releaseTaskSlotsForJob(jobId);
          }
          if (typeof helpers !== "undefined" && helpers && helpers.releaseTaskSlot) {
            helpers.releaseTaskSlot(state.activeTaskSlots, "wps", taskType, targetDocSession, jobId);
          }
          if (typeof clearWritingActiveJob === "function") {
            clearWritingActiveJob(jobId, taskType, targetDocSession);
          }
          if (typeof setActiveWritingJobRecord === "function") {
            setActiveWritingJobRecord(taskType, targetDocSession, null);
          }

          var targetMode = mode || (taskType === "word.smart_imitation" ? "smartImitation" : "smartWrite");
          var currentDoc = (typeof helpers !== "undefined" && helpers && helpers.getDocumentSessionId && typeof getActiveDocument === "function")
            ? helpers.getDocumentSessionId(getActiveDocument())
            : (state && state.documentSessionId);
          var isCurrentView = (!state || state.currentMode === targetMode) && (!targetDocSession || targetDocSession === currentDoc || !currentDoc);

          if (isCurrentView || (state && state.writingJobId === jobId)) {
            if (typeof setWritingJob === "function") {
              setWritingJob("", "", "");
            }
            if (typeof setModelTaskBusy === "function") {
              setModelTaskBusy(false);
            }
            if (typeof setDocumentReviewCancelVisible === "function") {
              setDocumentReviewCancelVisible(false, false);
            }
          }
          if (isCurrentView) {
            var label = typeof writingTaskLabel === "function" ? writingTaskLabel(taskType) : "写作";
            if (partialText) {
              if (typeof setPlainResult === "function") {
                setPlainResult(partialText, partialText);
              }
              if (typeof setApplyEnabled === "function") {
                setApplyEnabled(false);
              }
              if (typeof setStatus === "function") {
                setStatus(label + "已停止生成，保留已生成部分预览（只读，不可写回）。");
              }
            } else {
              if (typeof setStatus === "function") {
                setStatus("排队中的" + label + "任务已取消。");
              }
              if (typeof setPlainResult === "function") {
                setPlainResult("排队任务已取消，未调用模型后台。\n任务编号：" + jobId);
              }
            }
          }
          return;
        }
        if (terminalStatus === "failed") {
          stopCurrentConsumer();
          if (typeof stopWritingWaitFeedback === "function") {
            stopWritingWaitFeedback();
          }
          var preview = state.writingJobPreviews && state.writingJobPreviews[consumerKey];
          var partialText = (preview && preview.text) || (payload.previewSnapshot && payload.previewSnapshot.text) || "";
          if (state.writingJobPreviews && state.writingJobPreviews[consumerKey]) {
            if (state.writingJobPreviews[consumerKey].renderTimer) {
              clearTimeout(state.writingJobPreviews[consumerKey].renderTimer);
            }
            delete state.writingJobPreviews[consumerKey];
          }
          if (partialText) {
            if (typeof releaseTaskSlotsForJob === "function") {
              releaseTaskSlotsForJob(jobId);
            }
            if (typeof helpers !== "undefined" && helpers && helpers.releaseTaskSlot) {
              helpers.releaseTaskSlot(state.activeTaskSlots, "wps", taskType, targetDocSession, jobId);
            }
            if (typeof clearWritingActiveJob === "function") {
              clearWritingActiveJob(jobId, taskType, targetDocSession);
            }
            if (typeof setActiveWritingJobRecord === "function") {
              setActiveWritingJobRecord(taskType, targetDocSession, null);
            }

            var targetMode = mode || (taskType === "word.smart_imitation" ? "smartImitation" : "smartWrite");
            var currentDoc = (typeof helpers !== "undefined" && helpers && helpers.getDocumentSessionId && typeof getActiveDocument === "function")
              ? helpers.getDocumentSessionId(getActiveDocument())
              : (state && state.documentSessionId);
            var isCurrentView = (!state || state.currentMode === targetMode) && (!targetDocSession || targetDocSession === currentDoc || !currentDoc);

            if (isCurrentView || (state && state.writingJobId === jobId)) {
              if (typeof setWritingJob === "function") {
                setWritingJob("", "", "");
              }
              if (typeof setModelTaskBusy === "function") {
                setModelTaskBusy(false);
              }
              if (typeof setDocumentReviewCancelVisible === "function") {
                setDocumentReviewCancelVisible(false, false);
              }
            }
            if (isCurrentView) {
              var label = typeof writingTaskLabel === "function" ? writingTaskLabel(taskType) : "写作";
              var errorMsg = (payload.error && payload.error.message) || "后台任务执行失败。";
              if (typeof setPlainResult === "function") {
                setPlainResult(partialText, partialText);
              }
              if (typeof setApplyEnabled === "function") {
                setApplyEnabled(false);
              }
              if (typeof setStatus === "function") {
                setStatus(label + "失败：" + errorMsg + "，已保留已接收内容部分预览（只读，不可写回）。");
              }
            }
            return;
          }
          failWritingJob(jobId, taskType, mode, payload.error, targetDocSession);
          return;
        }
      }

      pollWritingJobEvents(jobId, taskType, mode, resumed, targetDocSession, nextSequence, 0, activeConsumerVersion);
    }).catch(function (error) {
      if (!isCurrentConsumer()) {
        return;
      }
      var status = error && (error.httpStatus || error.status);
      if (status === 404) {
        stopCurrentConsumer();
        pollWritingJob(jobId, taskType, mode, resumed, targetDocSession);
        return;
      }
      if (isFatalWritingPollError(error)) {
        stopCurrentConsumer();
        failWritingJob(jobId, taskType, mode, error, targetDocSession);
        return;
      }
      var nextErrors = errors + 1;
      if (nextErrors >= 3) {
        stopCurrentConsumer();
        pollWritingJob(jobId, taskType, mode, resumed, targetDocSession);
        return;
      }
      setTimeout(function () {
        pollWritingJobEvents(jobId, taskType, mode, resumed, targetDocSession, seq, nextErrors, activeConsumerVersion);
      }, 1000);
    });
  }

  function startWritingJob(payload, taskType, mode, docSessionId, docDisplayName) {
    var document = getActiveDocument();
    var docSession = docSessionId || payload.documentSessionId || (helpers.getDocumentSessionId ? helpers.getDocumentSessionId(document) : "doc_session_default");
    var docName = docDisplayName || payload.documentDisplayName || (helpers.getDocumentDisplayName ? helpers.getDocumentDisplayName(document) : "未命名文档.docx");
    var jobId;
    var startedAt;

    state.documentSessionId = docSession;
    if (helpers.isTaskSlotBusy && helpers.isTaskSlotBusy(state.activeTaskSlots, "wps", taskType, docSession)) {
      setModelTaskBusy(false);
      setStatus("已有" + writingTaskLabel(taskType) + "任务尚未结束，请等待当前任务完成。");
      return;
    }

    jobId = buildWritingClientJobId(taskType);
    startedAt = Date.now();
    payload.clientJobId = jobId;
    payload.host = "wps";
    payload.documentSessionId = docSession;
    payload.documentDisplayName = docName;

    if (helpers.claimTaskSlot) {
      helpers.claimTaskSlot(state.activeTaskSlots, "wps", taskType, docSession, jobId);
    }

    setWritingJob(jobId, taskType, mode);
    state.writingJobStartedAt = startedAt;
    state.writingJobPollErrorCount = 0;
    var taskPerformance = beginTaskPerformance(
      jobId,
      taskType,
      Number(payload._clickTimestamp || startedAt),
      Number(payload._clickToFeedbackMs || 0)
    );
    var jobRecord = {
      jobId: jobId,
      taskType: taskType,
      mode: mode,
      documentSessionId: docSession,
      documentPayload: JSON.parse(JSON.stringify(payload)),
      streamingEnabled: Boolean(state.directStreamingEnabled),
      startedAt: startedAt
    };
    setActiveWritingJobRecord(taskType, docSession, jobRecord);
    saveWritingActiveJob(jobRecord);

    request(writingJobPath(taskType), payload, { timeoutMs: WRITING_POLL_REQUEST_TIMEOUT_MS })
      .then(function (body) {
        var now = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
        var baseClick = taskPerformance.clickTimestamp || startedAt;
        var clickToAdapterAcceptedMs = Math.max(0, Math.round(now - baseClick));
        taskPerformance.clickToAdapterAcceptedMs = clickToAdapterAcceptedMs;
        var job = body.data || {};
        var returnedJobId = job.jobId || jobId;
        bindTaskPerformanceTrace(
          jobId,
          body.traceId || job.traceId || returnedJobId,
          returnedJobId
        );
        setWritingJob(returnedJobId, taskType, mode);
        setTrace(body.traceId || job.traceId || returnedJobId);
        jobRecord.jobId = returnedJobId;
        jobRecord.streamingEnabled = writingJobUsesEvents(job);
        setActiveWritingJobRecord(taskType, docSession, jobRecord);
        saveWritingActiveJob({
          jobId: returnedJobId,
          taskType: taskType,
          mode: mode,
          documentSessionId: docSession,
          traceId: body.traceId || job.traceId || "",
          streamingEnabled: jobRecord.streamingEnabled,
          startedAt: startedAt
        });
        if (job.status === "completed") {
          completeWritingJob(job.result || {}, body.traceId || job.traceId || returnedJobId, taskType, false, mode, returnedJobId, docSession);
          return;
        }
        if (job.status === "failed") {
          failWritingJob(returnedJobId, taskType, mode, job.error, docSession);
          return;
        }
        if (state.currentMode === mode) {
          renderWritingJobProgress(job, taskType, returnedJobId);
        }
        if (typeof stopWritingWaitFeedback === "function") {
          stopWritingWaitFeedback();
        }
        if (typeof startWritingWaitFeedback === "function") {
          state.stopWritingWaitFeedback = startWritingWaitFeedback(returnedJobId, taskType);
        }
        if (writingJobUsesEvents(job) && typeof pollWritingJobEvents === "function") {
          pollWritingJobEvents(returnedJobId, taskType, mode, false, docSession, 0, 0);
        } else {
          pollWritingJob(returnedJobId, taskType, mode, false, docSession);
        }
      }).catch(function (error) {
        if (isFatalWritingPollError(error)) {
          failWritingJob(jobId, taskType, mode, error, docSession);
          return;
        }
        setStatus(writingTaskLabel(taskType) + "提交响应未确认，正在按任务编号恢复查询...");
        if (writingJobUsesEvents(jobRecord) && typeof pollWritingJobEvents === "function") {
          pollWritingJobEvents(jobId, taskType, mode, false, docSession, 0, 0);
        } else {
          pollWritingJob(jobId, taskType, mode, false, docSession);
        }
      });
  }

  function resumeWritingActiveJob() {
    var document = getActiveDocument();
    var docSession = helpers.getDocumentSessionId ? helpers.getDocumentSessionId(document) : "doc_session_default";
    var taskType = getCurrentWorkflowTaskType();

    var active = loadWritingActiveJob(taskType, docSession);
    if (!active || !active.jobId || active.mode !== state.currentMode) {
      return;
    }
    if (active.documentSessionId && docSession && active.documentSessionId !== docSession) {
      return;
    }
    state.documentSessionId = docSession;

    if (helpers.claimTaskSlot) {
      helpers.claimTaskSlot(state.activeTaskSlots, "wps", active.taskType, docSession, active.jobId);
    }

    setWritingJob(active.jobId, active.taskType, active.mode);
    state.writingJobStartedAt = active.startedAt || Date.now();
    state.writingJobPollErrorCount = 0;
    var jobRecord = {
      jobId: active.jobId,
      taskType: active.taskType,
      mode: active.mode,
      documentSessionId: docSession,
      startedAt: state.writingJobStartedAt
    };
    setActiveWritingJobRecord(active.taskType, docSession, jobRecord);
    setTrace(active.traceId || active.jobId);
    setApplyEnabled(false);
    setStatus("已恢复未完成的" + writingTaskLabel(active.taskType) + "任务，正在查询结果...");
    var previewKey = [active.taskType, docSession, active.jobId].join("::");
    var preview = state && state.writingJobPreviews && state.writingJobPreviews[previewKey];
    if (preview && preview.text) {
      renderWritingJobPreview(previewKey);
    } else {
      setPlainResult("检测到未完成的写作任务，将继续查询 adapter 后台状态。\n任务编号：" + active.jobId);
    }
    if (writingJobUsesEvents(active) && typeof pollWritingJobEvents === "function") {
      pollWritingJobEvents(active.jobId, active.taskType, active.mode, true, docSession, 0, 0);
    } else {
      pollWritingJob(active.jobId, active.taskType, active.mode, true, docSession);
    }
  }

  function cancelQueuedWritingJob() {
    var jobId = state.writingJobId;
    var taskType = state.writingJobTaskType;
    if (!jobId || !taskType) {
      return;
    }
    if (typeof stopWritingWaitFeedback === "function") {
      stopWritingWaitFeedback();
    }
    setDocumentReviewCancelVisible(true, true, "正在停止");
    if (typeof setStatus === "function") {
      setStatus("正在停止生成，请稍候...");
    }
    request(writingJobPath(taskType) + "/" + encodeURIComponent(jobId) + "?resume=1", null, {
      method: "DELETE",
      timeoutMs: WRITING_POLL_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      var job = body.data || {};
      if (job.status === "cancelled") {
        releaseTaskSlotsForJob(jobId);
        if (helpers && helpers.releaseTaskSlot) {
          helpers.releaseTaskSlot(state.activeTaskSlots, "wps", taskType, state.documentSessionId, jobId);
        }
        clearWritingActiveJob(jobId, taskType, state.documentSessionId);
        setActiveWritingJobRecord(taskType, state.documentSessionId, null);
        setWritingJob("", "", "");
        setModelTaskBusy(false);
        setDocumentReviewCancelVisible(false, false);
        var consumerKey = [taskType, state.documentSessionId, jobId].join("::");
        var preview = state && state.writingJobPreviews && state.writingJobPreviews[consumerKey];
        var previewText = (preview && preview.text) || (job.previewSnapshot && job.previewSnapshot.text) || (job.result && job.result.previewText) || "";
        if (previewText) {
          if (typeof setPlainResult === "function") {
            setPlainResult(previewText, previewText);
          }
          if (typeof setApplyEnabled === "function") {
            setApplyEnabled(false);
          }
          setStatus(writingTaskLabel(taskType) + "已停止生成，保留已生成部分预览（只读，不可写回）。");
        } else {
          setStatus("排队中的" + writingTaskLabel(taskType) + "任务已取消。");
          setPlainResult("排队任务已取消，未调用模型后台。\n任务编号：" + jobId);
        }
        return;
      }
      if (job.status === "completed") {
        completeWritingJob(job.result || {}, body.traceId || job.traceId || jobId, taskType, false, state.writingJobMode, jobId, state.documentSessionId);
        return;
      }
      renderWritingJobProgress(job, taskType, jobId);
    }).catch(function (error) {
      setDocumentReviewCancelVisible(true, false, "停止生成");
      setStatus("取消任务失败：" + describeFetchError(error));
    });
  }

  function extractFullDocumentReviewBody() {
    var document = getActiveDocument();
    var paragraphs;
    var tables;
    var body;
    if (!document) {
      throw new Error("未检测到活动文档。");
    }
    paragraphs = helpers.collectFullDocumentReviewParagraphs
      ? helpers.collectFullDocumentReviewParagraphs(document)
      : collectParagraphs(document, {
        avoidFallbackTextRead: true,
        excludeTableParagraphs: true
      });
    tables = helpers.collectFullDocumentReviewTables
      ? helpers.collectFullDocumentReviewTables(document)
      : [];
    body = helpers.buildFullDocumentReviewBody({
      paragraphs: paragraphs,
      tables: tables
    }, 120000);
    body.documentId = "wps-document-" + helpers.sha256Text(getDocumentName(document)).slice(0, 24);
    body.editSignal = helpers.readFullDocumentReviewEditSignal
      ? helpers.readFullDocumentReviewEditSignal(document)
      : "";
    body.batches = helpers.buildFullDocumentReviewBatches
      ? helpers.buildFullDocumentReviewBatches(body, 3500)
      : [{
        sequence: 0,
        batchId: "batch-0",
        blocks: body.blocks,
        characterCount: body.reviewCharacterCount,
        contentSha256: body.contentSha256
      }];
    return body;
  }

  function markFullDocumentReviewAnchorVerification(jobId, issueId, verification) {
    if (!jobId || !issueId || (verification !== "verified" && verification !== "unverified")) {
      return Promise.resolve();
    }
    return request(
      "/word/document-review/full/jobs/" + encodeURIComponent(jobId) +
        "/issues/" + encodeURIComponent(issueId),
      { anchorVerification: verification },
      { method: "PATCH", timeoutMs: DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS }
    );
  }

  function locateFullDocumentReviewIssue(issue, jobId) {
    var document = getActiveDocument();
    var anchor = issue && issue.sourceAnchor || {};
    var originalText;
    var location = String(anchor.location || issue && issue.location || "body");
    var target;
    var range;
    var text;
    var occurrences = [];
    var index;
    var start;
    var end;
    var expectedOffset;
    var nearbyOccurrences;
    var paragraphs;
    var tables;
    var table;
    var rows;
    var row;
    var cells;
    function failLocation(message) {
      if (issue) {
        issue.anchorVerification = "unverified";
      }
      setStatus(message);
      markFullDocumentReviewAnchorVerification(jobId, issue && issue.issueId, "unverified")
        .catch(function () {
          setStatus(message + "（定位状态未能写回服务器。）");
        });
      return false;
    }
    if (!document || String(issue && issue.anchorVerification || "") !== "verified") {
      return failLocation("该问题的原文锚点未通过快照校验，未自动跳转。");
    }
    originalText = String(issue && issue.originalText || "");
    if (!document || !originalText) {
      return failLocation("缺少可验证的原文锚点，未自动定位。");
    }
    if (location === "table") {
      tables = readValue(document, "Tables") || readValue(document, "tables") || [];
      var tablePath = Array.isArray(anchor.tablePath) && anchor.tablePath.length
        ? anchor.tablePath : [{ tableIndex: Number(anchor.tableIndex || 0) }];
      table = helpers.getCollectionItem
        ? helpers.getCollectionItem(tables, Number(tablePath[0].tableIndex || 0))
        : null;
      for (var pathIndex = 1; table && pathIndex < tablePath.length; pathIndex += 1) {
        var parentPath = tablePath[pathIndex];
        var parentRows = readValue(table, "Rows") || readValue(table, "rows") || [];
        var parentRow = helpers.getCollectionItem
          ? helpers.getCollectionItem(parentRows, Number(parentPath.rowIndex || 0))
          : null;
        var parentCells = parentRow && (readValue(parentRow, "Cells") || readValue(parentRow, "cells") || []);
        var parentCell = helpers.getCollectionItem
          ? helpers.getCollectionItem(parentCells, Number(parentPath.columnIndex || 0))
          : null;
        var nestedTables = parentCell && (readValue(parentCell, "Tables") || readValue(parentCell, "tables") || []);
        table = helpers.getCollectionItem
          ? helpers.getCollectionItem(nestedTables, Number(parentPath.tableIndex || 0))
          : null;
      }
      rows = table && (readValue(table, "Rows") || readValue(table, "rows") || []);
      row = helpers.getCollectionItem
        ? helpers.getCollectionItem(rows, Number(anchor.rowIndex || 0))
        : null;
      cells = row && (readValue(row, "Cells") || readValue(row, "cells") || []);
      target = helpers.getCollectionItem
        ? helpers.getCollectionItem(cells, Number(anchor.columnIndex || 0))
        : null;
      range = getRangeFromTarget(target);
    } else {
      paragraphs = getParagraphs(document);
      target = helpers.getCollectionItem
        ? helpers.getCollectionItem(paragraphs, Number(anchor.paragraphIndex || 0))
        : null;
      range = getRangeFromTarget(target);
    }
    text = String(readValue(range, "Text") || readValue(range, "text") || "")
      .replace(/[\r\u0007]+$/g, "");
    if (!range) {
      return failLocation("原文结构单元已不存在，未自动跳转。");
    }
    index = text.indexOf(originalText);
    while (index >= 0) {
      occurrences.push(index);
      index = text.indexOf(originalText, index + Math.max(originalText.length, 1));
    }
    expectedOffset = Number(issue && issue.anchorStart);
    if (isFinite(expectedOffset) && expectedOffset >= 0 &&
        text.slice(expectedOffset, expectedOffset + originalText.length) === originalText) {
      occurrences = [expectedOffset];
    } else {
      nearbyOccurrences = occurrences.filter(function (candidate) {
        return isFinite(expectedOffset) && Math.abs(candidate - expectedOffset) <= 512;
      });
      occurrences = nearbyOccurrences;
    }
    if (occurrences.length !== 1) {
      return failLocation("原文无法在预期" + (location === "table" ? "表格单元格" : "段落") + "内唯一匹配，未自动跳转。");
    }
    index = occurrences[0];
    start = Number(readValue(range, "Start"));
    if (isNaN(start)) {
      return failLocation("当前 WPS 未提供可验证的原文范围，未自动跳转。");
    }
    end = start + index + originalText.length;
    try {
      if (typeof range.SetRange === "function") {
        range.SetRange(start + index, end);
      } else if (typeof range.setRange === "function") {
        range.setRange(start + index, end);
      } else {
        return failLocation("当前 WPS 不支持保守范围定位。");
      }
      if (typeof range.Select === "function") {
        range.Select();
      } else if (typeof range.select === "function") {
        range.select();
      }
      issue.anchorVerification = "verified";
      setStatus("已按原始范围或预期附近的唯一原文匹配定位；文档变化后仍以人工复核为准。");
      return true;
    } catch (error) {
      return failLocation("原文定位失败，未修改文档正文。");
    }
  }

  function renderFullDocumentReviewIssuePage(report, pageData, jobId) {
    var snapshot = report && report.snapshot || {};
    var coverage = report && report.coverage || {};
    var capacity = report && report.capacity || {};
    var issues = pageData && Array.isArray(pageData.items) ? pageData.items : [];
    var excludedRegions = Array.isArray(coverage.excludedRegions) ? coverage.excludedRegions : [];
    var lines = [
      "# 全篇审查报告",
      "",
      report && report.summary || "审查已完成。",
      report && report.globalSummary ? "\n## 跨片全局结论\n" + report.globalSummary : "",
      report && Array.isArray(report.globalFindings) && report.globalFindings.length
        ? "\n## 跨片发现\n" + report.globalFindings.map(function (finding) {
          return "- [" + (finding.severity || "未标注") + "] " +
            (finding.summary || "") + "（" + (finding.findingId || "未标识") + "）";
        }).join("\n") : "",
      "",
      "## 快照与覆盖",
      "- 快照编号：" + (snapshot.snapshotId || "未记录"),
      "- 快照哈希：" + String(snapshot.contentSha256 || "").slice(0, 16),
      "- 已审查字符：" + Number(coverage.reviewedCharacterCount || 0),
      "- 已审查段落：" + Number(coverage.reviewedParagraphCount || 0),
      "- 已审查表格：" + Number(coverage.reviewedTableCount || 0),
      "- 已审查单元格：" + Number(coverage.reviewedCellCount || 0),
      "- 容量等级：" + (capacity.label || capacity.tier || "未记录"),
      "- 初始分片估算：" + Number(capacity.initialChunkCount || 0),
      "- 调用上限：" + Number(capacity.callLimit || 0),
      "- 覆盖状态：" + (coverage.status === "complete" ? "声明范围覆盖完整" : "覆盖未完成"),
      "- 问题枚举：" + (report && report.enumerationStatus === "complete" ? "完整" : "受限"),
      "- 未审查区域：" + (excludedRegions.length ? excludedRegions.join("、") : "未披露"),
      "",
      "覆盖完整仅表示声明范围未被静默截断，不承诺检出全部问题。",
      "",
      "## 问题清单（第 " + Number(pageData && pageData.page || 1) + " 页，共 " +
        Number(pageData && pageData.total || 0) + " 项）"
    ];
    if (!issues.length) {
      lines.push("未返回结构化问题；这不表示文档不存在其他问题。");
    }
    issues.forEach(function (issue) {
      lines.push("");
      lines.push("### " + (issue.issueId || "未标识问题") + " · " + (issue.problem || "审查问题"));
      lines.push("- 严重程度：" + (issue.severity || "未标注"));
      lines.push("- 处理状态：" + (issue.status || "open"));
      lines.push("- 问题类别：" + (issue.category || "未标注"));
      lines.push("- 原文锚点：" + (issue.anchorId || "未标注"));
      lines.push("- 原文：" + (issue.originalText || "未提供"));
      lines.push("- 建议：" + (issue.suggestion || "请人工复核。"));
      if (issue.suggestedRewrite) {
        lines.push("- 建议改写：" + issue.suggestedRewrite);
      }
    });
    if (pageData && pageData.nextCursor) {
      lines.push("");
      lines.push("下一页游标：" + pageData.nextCursor);
    }
    setResult(lines.join("\n"), lines.join("\n"));
    if (state.viewingHistoryReport) {
      var banner = document.createElement("div");
      banner.className = "history-report-return-banner";
      banner.style.cssText = "display:flex;justify-content:space-between;align-items:center;background:var(--bg-subtle, #f1f5f9);padding:8px 12px;margin-bottom:12px;border-radius:4px;font-size:12px;border:1px solid var(--hairline, #e2e8f0);";
      var docName = state.viewingHistoryReport.documentDisplayName || "历史";
      banner.innerHTML = '<span>当前正在查看历史审查报告（' + (helpers.escapeHtml ? helpers.escapeHtml(docName) : docName) + '）</span><button type="button" class="btn btn-secondary btn-sm btn-return-active-review">返回当前审查结果</button>';
      var output = byId("result-output");
      if (output && output.firstChild) {
        output.insertBefore(banner, output.firstChild);
      } else if (output) {
        output.appendChild(banner);
      }
      var returnBtn = banner.querySelector(".btn-return-active-review");
      if (returnBtn) {
        returnBtn.addEventListener("click", function () {
          restoreActiveReviewResult();
        });
      }
    }
    setStatus("全篇审查只读报告已生成。");
    var controls = byId("full-document-review-issue-controls");
    var previous = byId("btn-full-review-previous-page");
    var next = byId("btn-full-review-next-page");
    var exportJson = byId("btn-full-review-export-json");
    var exportMarkdown = byId("btn-full-review-export-markdown");
    var pageStatus = byId("full-review-page-status");
    var actions = byId("full-review-issue-actions");
    var filterNames = ["severity", "category", "location", "status", "sort"];
    if (!controls || !previous || !next || !exportJson || !exportMarkdown ||
        !pageStatus || !actions) {
      return;
    }
    controls.hidden = false;
    filterNames.forEach(function (name) {
      var select = byId("full-review-filter-" + name);
      var value = state.fullDocumentReviewIssueFilters[name] || "";
      if (select && select.value !== value) {
        select.value = value;
      }
    });
    pageStatus.textContent = "第 " + Number(pageData && pageData.page || 1) + " 页，共 " +
      Number(pageData && pageData.total || 0) + " 项";
    previous.disabled = state.fullDocumentReviewIssueCursorHistory.length <= 1;
    next.disabled = !pageData.nextCursor;
    exportJson.onclick = function () {
      downloadFullDocumentReviewExport(jobId, "json");
    };
    exportMarkdown.onclick = function () {
      downloadFullDocumentReviewExport(jobId, "markdown");
    };
    previous.onclick = function () {
      var history = state.fullDocumentReviewIssueCursorHistory;
      if (history.length <= 1) {
        return;
      }
      history.pop();
      loadFullDocumentReviewIssuePage(jobId, report, history[history.length - 1]);
    };
    next.onclick = function () {
      if (!pageData.nextCursor) {
        return;
      }
      state.fullDocumentReviewIssueCursorHistory.push(pageData.nextCursor);
      loadFullDocumentReviewIssuePage(jobId, report, pageData.nextCursor);
    };
    actions.textContent = "";
    issues.forEach(function (issue) {
      var row = document.createElement("div");
      var locate = document.createElement("button");
      var copyOriginal = document.createElement("button");
      var copySuggestion = document.createElement("button");
      var processed = document.createElement("button");
      var ignored = document.createElement("button");
      row.className = "full-review-issue-row";
      row.textContent = (issue.issueId || "问题") + "［" +
        (issue.category || "未分类") + "／" + (issue.severity || "未标注") + "］：" +
        (issue.problem || "审查问题") +
        (issue.duplicateGroupSize > 1 ? "（重复组 " + issue.duplicateGroupSize + " 处）" : "") +
        (issue.anchorVerification !== "verified" ? "（锚点未验证）" : "");
      locate.type = "button";
      locate.textContent = "定位原文";
      copyOriginal.type = "button";
      copyOriginal.textContent = "复制原文";
      copySuggestion.type = "button";
      copySuggestion.textContent = "复制建议";
      processed.type = "button";
      processed.textContent = "标记已处理";
      ignored.type = "button";
      ignored.textContent = "标记已忽略";
      processed.disabled = issue.status === "processed";
      ignored.disabled = issue.status === "ignored";
      locate.addEventListener("click", function () {
        locateFullDocumentReviewIssue(issue, jobId);
      });
      copyOriginal.addEventListener("click", function () {
        writeClipboardText(issue.originalText || "", "原文已复制。");
      });
      copySuggestion.addEventListener("click", function () {
        writeClipboardText(issue.suggestion || "", "修改建议已复制。");
      });
      processed.addEventListener("click", function () {
        updateFullDocumentReviewIssueStatus(jobId, issue.issueId, "processed")
          .then(function () {
            loadFullDocumentReviewIssuePage(jobId, report, pageData._cursor || "");
          });
      });
      ignored.addEventListener("click", function () {
        updateFullDocumentReviewIssueStatus(jobId, issue.issueId, "ignored")
          .then(function () {
            loadFullDocumentReviewIssuePage(jobId, report, pageData._cursor || "");
          });
      });
      row.appendChild(locate);
      row.appendChild(copyOriginal);
      row.appendChild(copySuggestion);
      if (issue.suggestedRewrite) {
        var copyRewrite = document.createElement("button");
        copyRewrite.type = "button";
        copyRewrite.textContent = "复制改写";
        copyRewrite.addEventListener("click", function () {
          writeClipboardText(issue.suggestedRewrite, "建议改写已复制。");
        });
        row.appendChild(copyRewrite);
      }
      row.appendChild(processed);
      row.appendChild(ignored);
      actions.appendChild(row);
    });
  }

  function loadFullDocumentReviewIssuePage(jobId, report, cursor) {
    var filters = state.fullDocumentReviewIssueFilters || {};
    var path = "/word/document-review/full/jobs/" + encodeURIComponent(jobId) +
      "/issues?pageSize=20&sort=" + encodeURIComponent(filters.sort || "source");
    ["severity", "category", "location", "status"].forEach(function (name) {
      if (filters[name]) {
        path += "&" + name + "=" + encodeURIComponent(filters[name]);
      }
    });
    if (cursor) {
      path += "&cursor=" + encodeURIComponent(cursor);
    }
    return request(path, null, {
      timeoutMs: DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      var pageData = body.data || {};
      pageData._cursor = cursor || "";
      state.fullDocumentReviewIssueJobId = jobId;
      state.fullDocumentReviewIssueReport = report;
      renderFullDocumentReviewIssuePage(report, pageData, jobId);
    });
  }

  function updateFullDocumentReviewIssueStatus(jobId, issueId, status) {
    if (!jobId || !issueId || (status !== "processed" && status !== "ignored" && status !== "open")) {
      return Promise.reject(new Error("全篇审查问题状态参数无效。"));
    }
    return request(
      "/word/document-review/full/jobs/" + encodeURIComponent(jobId) +
        "/issues/" + encodeURIComponent(issueId),
      { status: status },
      { method: "PATCH", timeoutMs: DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS }
    );
  }

  function changeFullDocumentReviewIssueFilter(name, value) {
    if (!state.fullDocumentReviewIssueFilters ||
        ["severity", "category", "location", "status", "sort"].indexOf(name) < 0) {
      return;
    }
    state.fullDocumentReviewIssueFilters[name] = String(value || "");
    state.fullDocumentReviewIssueCursorHistory = [""];
    if (state.fullDocumentReviewIssueJobId && state.fullDocumentReviewIssueReport) {
      loadFullDocumentReviewIssuePage(
        state.fullDocumentReviewIssueJobId,
        state.fullDocumentReviewIssueReport,
        ""
      ).catch(function (error) {
        setStatus("问题筛选读取失败：" + describeFetchError(error));
      });
    }
  }

  function downloadFullDocumentReviewExport(jobId, format) {
    var path = "/word/document-review/full/jobs/" + encodeURIComponent(jobId) +
      "/report?format=" + encodeURIComponent(format);
    return fetch(ADAPTER_BASE_URL + path).then(function (response) {
      if (!response.ok) {
        return response.json().then(function (body) {
          throw new Error(body.message || "全篇审查报告导出失败。");
        });
      }
      return format === "markdown" ? response.text() : response.json();
    }).then(function (body) {
      var extension = format === "markdown" ? "md" : "json";
      var text = format === "markdown" ? body : JSON.stringify(body.data || body, null, 2);
      var blob = new Blob([text], { type: format === "markdown" ? "text/markdown" : "application/json" });
      var objectUrl = URL.createObjectURL(blob);
      var link = document.createElement("a");
      link.href = objectUrl;
      link.download = "word-full-review." + extension;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(objectUrl);
    }).catch(function (error) {
      setStatus("全篇审查报告导出失败：" + describeFetchError(error));
    });
  }

  function markDeterministicFormatReviewAnchorVerification(jobId, issueId, verification) {
    if (!jobId || !issueId || ["verified", "unverified"].indexOf(verification) < 0) {
      return Promise.resolve();
    }
    return request(
      "/word/format-review/jobs/" + encodeURIComponent(jobId) +
        "/issues/" + encodeURIComponent(issueId),
      { anchorVerification: verification },
      { method: "PATCH", timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS }
    );
  }

  function locateDeterministicFormatReviewIssue(issue, jobId) {
    var document = getActiveDocument();
    var anchor = issue && issue.sourceAnchor || {};
    var identity = state.deterministicFormatReviewDocumentIdentity || {};
    var currentName = getDocumentName(document);
    var currentHostId = String(readValue(document, "Id") || readValue(document, "ID") || currentName);
    var target;
    var range;
    var paragraphs;
    var text;
    var expectedText = String(anchor.text || "");
    var paragraphIndex = Number(anchor.paragraphIndex);
    var start;
    var occurrences = [];
    var index;
    var adjacentIds;
    var currentAdjacentIds;
    function failLocation(message) {
      if (issue) {
        issue.anchorVerification = "unverified";
      }
      setStatus(message);
      markDeterministicFormatReviewAnchorVerification(jobId, issue && issue.issueId, "unverified")
        .catch(function () {});
      return false;
    }
    if (!document || String(issue && issue.anchorVerification || "") !== "verified" ||
        !expectedText || !anchor.textSha256 || !anchor.adjacentStructureSha256) {
      return failLocation("该格式问题缺少可验证锚点，未自动跳转。");
    }
    if ((identity.hostDocumentId && String(identity.hostDocumentId) !== currentHostId) ||
        (identity.documentIdSha256 && helpers.sha256Text(currentName) !== identity.documentIdSha256)) {
      return failLocation("当前文档身份与格式审查快照不一致，未自动跳转。");
    }
    paragraphs = getParagraphs(document);
    target = helpers.getCollectionItem
      ? helpers.getCollectionItem(paragraphs, paragraphIndex)
      : null;
    range = getRangeFromTarget(target);
    if (!range) {
      return failLocation("格式审查锚点对应的段落已不存在，未自动跳转。");
    }
    text = String(readValue(range, "Text") || readValue(range, "text") || "")
      .replace(/[\r\u0007]+$/g, "");
    if (helpers.sha256Text(text) !== String(anchor.textSha256)) {
      return failLocation("格式审查锚点文本已变化，未自动跳转。");
    }
    adjacentIds = Array.isArray(anchor.adjacentBlockIds) ? anchor.adjacentBlockIds : [];
    currentAdjacentIds = [];
    [-1, 0, 1].forEach(function (offset) {
      var neighborIndex = paragraphIndex + offset;
      var neighbor = helpers.getCollectionItem
        ? helpers.getCollectionItem(paragraphs, neighborIndex)
        : null;
      if (issue && issue.ruleId === "structure.heading_hierarchy") {
        var neighborText = neighbor && String(readValue(neighbor, "Text") || readValue(neighbor, "text") || "")
          .replace(/[\r\u0007]+$/g, "").trim();
        if (neighbor && neighborText) {
          currentAdjacentIds.push("format-paragraph-" + neighborIndex);
        }
        return;
      }
      var neighborId = neighbor && (readValue(neighbor, "BlockId") || readValue(neighbor, "blockId") ||
        readValue(neighbor, "Id") || readValue(neighbor, "ID"));
      if (neighborId) {
        currentAdjacentIds.push(String(neighborId));
      }
    });
    if (adjacentIds.length && (currentAdjacentIds.length !== adjacentIds.length ||
        helpers.sha256Text(JSON.stringify(currentAdjacentIds)) !== String(anchor.adjacentStructureSha256))) {
      return failLocation("格式审查锚点相邻结构无法唯一验证，未自动跳转。");
    }
    index = text.indexOf(expectedText);
    while (index >= 0) {
      occurrences.push(index);
      index = text.indexOf(expectedText, index + Math.max(expectedText.length, 1));
    }
    if (occurrences.length !== 1) {
      return failLocation("格式审查锚点文本无法唯一匹配，未自动跳转。");
    }
    start = Number(readValue(range, "Start"));
    if (isNaN(start)) {
      return failLocation("当前 WPS 未提供可验证的格式范围，未自动跳转。");
    }
    try {
      if (typeof range.SetRange === "function") {
        range.SetRange(start + occurrences[0], start + occurrences[0] + expectedText.length);
      } else if (typeof range.setRange === "function") {
        range.setRange(start + occurrences[0], start + occurrences[0] + expectedText.length);
      } else {
        return failLocation("当前 WPS 不支持保守范围定位。");
      }
      if (typeof range.Select === "function") {
        range.Select();
      } else if (typeof range.select === "function") {
        range.select();
      }
      setStatus("已通过文档身份、文本和相邻结构验证，定位到格式问题原文。");
      return true;
    } catch (error) {
      return failLocation("格式问题定位失败，未修改文档正文。");
    }
  }

  function renderDeterministicFormatReviewIssuePage(report, pageData, jobId) {
    var summary = report && report.summary || {};
    var issues = pageData && Array.isArray(pageData.items) ? pageData.items : [];
    var view = helpers.presentDeterministicFormatReviewIssueView
      ? helpers.presentDeterministicFormatReviewIssueView({
        summary: summary,
        issues: issues,
        total: Number(pageData && pageData.total || report && report.issueCount || issues.length)
      })
      : null;
    if (view) {
      setResult(view.previewText, view.previewText);
    } else {
      setResult("# 格式审查报告\n\n当前版本无法生成中文报告，请重新审查。");
    }
    if (state.viewingHistoryReport) {
      var banner = document.createElement("div");
      banner.className = "history-report-return-banner";
      banner.style.cssText = "display:flex;justify-content:space-between;align-items:center;background:var(--bg-subtle, #f1f5f9);padding:8px 12px;margin-bottom:12px;border-radius:4px;font-size:12px;border:1px solid var(--hairline, #e2e8f0);";
      var docName = state.viewingHistoryReport.documentDisplayName || "历史";
      banner.innerHTML = '<span>当前正在查看历史审查报告（' + (helpers.escapeHtml ? helpers.escapeHtml(docName) : docName) + '）</span><button type="button" class="btn btn-secondary btn-sm btn-return-active-review">返回当前审查结果</button>';
      var output = byId("result-output");
      if (output && output.firstChild) {
        output.insertBefore(banner, output.firstChild);
      } else if (output) {
        output.appendChild(banner);
      }
      var returnBtn = banner.querySelector(".btn-return-active-review");
      if (returnBtn) {
        returnBtn.addEventListener("click", function () {
          restoreActiveReviewResult();
        });
      }
    }
    renderDeterministicFormatReviewDiagnostics(report, issues);
    setStatus("确定性格式审查只读报告已生成。");
    var controls = byId("deterministic-format-review-issue-controls");
    var previous = byId("btn-format-review-previous-page");
    var next = byId("btn-format-review-next-page");
    var pageStatus = byId("format-review-page-status");
    var exportJson = byId("btn-format-review-export-json");
    var exportMarkdown = byId("btn-format-review-export-markdown");
    var actions = byId("format-review-issue-actions");
    if (!controls || !previous || !next || !pageStatus || !exportJson || !exportMarkdown || !actions) {
      return;
    }
    controls.hidden = false;
    ["rule", "dataStatus", "status", "sort"].forEach(function (name) {
      var field = byId("format-review-filter-" + name.replace("dataStatus", "data-status"));
      if (field && field.value !== String(state.deterministicFormatReviewIssueFilters[name] || "")) {
        field.value = state.deterministicFormatReviewIssueFilters[name] || "";
      }
    });
    pageStatus.textContent = helpers.formatDeterministicFormatReviewPageStatus
      ? helpers.formatDeterministicFormatReviewPageStatus({
        page: Number(pageData && pageData.page || 1),
        locationGroupCount: Number(pageData && pageData.locationGroupCount || 0),
        pageSize: Number(pageData && pageData.pageSize || 20)
      })
      : ("第 " + Number(pageData && pageData.page || 1) + " / 1 页");
    var filterCountEl = byId("format-review-filter-count");
    var filterCount = helpers.countEnabledFormatReviewFilters
      ? helpers.countEnabledFormatReviewFilters(state.deterministicFormatReviewIssueFilters)
      : 0;
    if (filterCountEl) {
      filterCountEl.hidden = filterCount <= 0;
      filterCountEl.textContent = String(filterCount);
    }
    previous.disabled = state.deterministicFormatReviewIssueCursorHistory.length <= 1;
    next.disabled = !pageData.nextCursor;
    exportJson.onclick = function () {
      if (helpers.setFormatReviewAnchoredPanelOpen) {
        helpers.setFormatReviewAnchoredPanelOpen(byId("format-review-more-menu"), byId("btn-format-review-more"), false);
      }
      downloadDeterministicFormatReviewExport(jobId, "json");
    };
    exportMarkdown.onclick = function () {
      if (helpers.setFormatReviewAnchoredPanelOpen) {
        helpers.setFormatReviewAnchoredPanelOpen(byId("format-review-more-menu"), byId("btn-format-review-more"), false);
      }
      downloadDeterministicFormatReviewExport(jobId, "markdown");
    };
    previous.onclick = function () {
      var history = state.deterministicFormatReviewIssueCursorHistory;
      if (history.length <= 1) { return; }
      history.pop();
      loadDeterministicFormatReviewIssuePage(jobId, report, history[history.length - 1]);
    };
    next.onclick = function () {
      if (!pageData.nextCursor) { return; }
      state.deterministicFormatReviewIssueCursorHistory.push(pageData.nextCursor);
      loadDeterministicFormatReviewIssuePage(jobId, report, pageData.nextCursor);
    };
    actions.textContent = "";
    if (view && view.html) {
      actions.innerHTML = view.html;
      Array.prototype.forEach.call(actions.querySelectorAll("[data-format-review-action]"), function (button) {
        var action = button.getAttribute("data-format-review-action");
        var issueId = button.getAttribute("data-issue-id");
        var issue = issues.filter(function (item) {
          return String(item && item.issueId || "") === String(issueId || "");
        })[0];
        if (action === "toggle-location") {
          button.addEventListener("click", function () {
            var card = button.closest ? button.closest(".review-location-card") : null;
            var body = card && card.querySelector ? card.querySelector(".review-location-body") : null;
            var expanded = button.getAttribute("aria-expanded") === "true";
            button.setAttribute("aria-expanded", expanded ? "false" : "true");
            if (body) {
              body.hidden = expanded;
            }
          });
          return;
        }
        if (!issue) {
          return;
        }
        if (action === "locate") {
          button.addEventListener("click", function () {
            locateDeterministicFormatReviewIssue(issue, jobId);
          });
          return;
        }
        if (action === "processed") {
          button.addEventListener("click", function () {
            updateDeterministicFormatReviewIssueStatus(jobId, issue.issueId, "processed");
          });
          return;
        }
        if (action === "ignored") {
          button.addEventListener("click", function () {
            updateDeterministicFormatReviewIssueStatus(jobId, issue.issueId, "ignored");
          });
        }
      });
    }
  }

  function loadDeterministicFormatReviewIssuePage(jobId, report, cursor) {
    var filters = state.deterministicFormatReviewIssueFilters || {};
    var path = "/word/format-review/jobs/" + encodeURIComponent(jobId) +
      "/issues?pageSize=20&sort=" + encodeURIComponent(filters.sort || "source");
    if (filters.rule) { path += "&ruleId=" + encodeURIComponent(filters.rule); }
    if (filters.dataStatus) { path += "&dataStatus=" + encodeURIComponent(filters.dataStatus); }
    if (filters.status) { path += "&status=" + encodeURIComponent(filters.status); }
    if (cursor) { path += "&cursor=" + encodeURIComponent(cursor); }
    return request(path, null, { timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS }).then(function (body) {
      var pageData = body.data || {};
      pageData._cursor = cursor || "";
      state.deterministicFormatReviewIssueJobId = jobId;
      state.deterministicFormatReviewReport = report;
      renderDeterministicFormatReviewIssuePage(report, pageData, jobId);
    });
  }

  function loadDeterministicFormatReviewReport(jobId, docSessionId) {
    var targetDocSession = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
    return request("/word/format-review/jobs/" + encodeURIComponent(jobId) + "/report?format=summary", null, {
      timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      var report = body.data || {};
      state.deterministicFormatReviewIssueCursorHistory = [""];
      if (!state.viewingHistoryReport) {
        setActiveResultRecord("word.format_review", targetDocSession, {
          result: {
            reportType: "format_review",
            report: report,
            jobId: jobId,
            reportId: jobId
          },
          jobId: jobId,
          traceId: body.traceId || jobId,
          taskType: "word.format_review",
          documentSessionId: targetDocSession
        });
      }
      var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
      if (!currentDoc || !targetDocSession || currentDoc === targetDocSession) {
        return loadDeterministicFormatReviewIssuePage(jobId, report, "");
      }
      return Promise.resolve();
    });
  }

  function renderDeterministicFormatReviewReport(report, jobId) {
    state.deterministicFormatReviewIssueCursorHistory = [""];
    return loadDeterministicFormatReviewIssuePage(jobId, report, "");
  }

  function updateDeterministicFormatReviewIssueStatus(jobId, issueId, status) {
    if (!jobId || !issueId || ["open", "processed", "ignored"].indexOf(status) < 0) {
      return Promise.reject(new Error("格式审查问题状态参数无效。"));
    }
    return request(
      "/word/format-review/jobs/" + encodeURIComponent(jobId) + "/issues/" + encodeURIComponent(issueId),
      { status: status },
      { method: "PATCH", timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS }
    ).then(function () {
      return loadDeterministicFormatReviewIssuePage(
        jobId, state.deterministicFormatReviewReport,
        state.deterministicFormatReviewIssueCursorHistory.slice(-1)[0] || ""
      );
    });
  }

  function changeDeterministicFormatReviewIssueFilter(name, value) {
    if (!state.deterministicFormatReviewIssueFilters ||
        ["rule", "dataStatus", "status", "sort"].indexOf(name) < 0) {
      return;
    }
    state.deterministicFormatReviewIssueFilters[name] = String(value || "");
    state.deterministicFormatReviewIssueCursorHistory = [""];
    if (state.deterministicFormatReviewIssueJobId && state.deterministicFormatReviewReport) {
      loadDeterministicFormatReviewIssuePage(
        state.deterministicFormatReviewIssueJobId,
        state.deterministicFormatReviewReport,
        ""
      ).catch(function (error) { setStatus("格式问题筛选读取失败：" + describeFetchError(error)); });
    }
  }

  function downloadDeterministicFormatReviewExport(jobId, format) {
    var path = "/word/format-review/jobs/" + encodeURIComponent(jobId) +
      "/report?format=" + encodeURIComponent(format);
    return fetch(ADAPTER_BASE_URL + path).then(function (response) {
      if (!response.ok) {
        return response.json().then(function (body) { throw new Error(body.message || "格式审查报告导出失败。"); });
      }
      return format === "markdown" ? response.text() : response.json();
    }).then(function (body) {
      var extension = format === "markdown" ? "md" : "json";
      var text = format === "markdown" ? body : JSON.stringify(body.data || body, null, 2);
      var blob = new Blob([text], { type: format === "markdown" ? "text/markdown" : "application/json" });
      var objectUrl = URL.createObjectURL(blob);
      var link = document.createElement("a");
      link.href = objectUrl;
      link.download = "word-format-review." + extension;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(objectUrl);
    }).catch(function (error) { setStatus("格式审查报告导出失败：" + describeFetchError(error)); });
  }

  function renderFullDocumentReviewReport(report, jobId) {
    var snapshot = report && report.snapshot || {};
    var coverage = report && report.coverage || {};
    var excludedRegions = Array.isArray(coverage.excludedRegions) ? coverage.excludedRegions : [];
    var enumerationStatus = report && report.enumerationStatus || "limited";
    var issueEnumerationLabel = "问题枚举：" +
      (enumerationStatus === "complete" ? "完整" : "受限");
    var disclaimer = report && report.disclaimer ||
      "覆盖完整仅表示声明范围未被静默截断，不承诺检出全部问题。";
    state.fullDocumentReviewReportMetadata = {
      snapshotId: snapshot.snapshotId || "",
      coverageStatus: coverage.status || "",
      excludedRegions: excludedRegions,
      issueEnumeration: issueEnumerationLabel,
      disclaimer: disclaimer
    };
    state.fullDocumentReviewIssueFilters = {
      severity: "",
      category: "",
      location: "",
      status: "",
      sort: "source"
    };
    state.fullDocumentReviewIssueCursorHistory = [""];
    return loadFullDocumentReviewIssuePage(jobId, report, "");
  }

  function pollFullDocumentReviewJob(jobId, docSessionId) {
    var targetDocSession = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
    if (!jobId || state.fullDocumentReviewJobId !== jobId) {
      return;
    }
    request("/word/document-review/full/jobs/" + encodeURIComponent(jobId), null, {
      timeoutMs: DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      var job = body.data || {};
      if (state.fullDocumentReviewJobId !== jobId) {
        return;
      }
      if (job.status === "completed") {
        var completionTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
        return request("/word/document-review/full/jobs/" + encodeURIComponent(jobId) + "/report", null, {
          timeoutMs: DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS
        }).then(function (reportBody) {
          var reportData = reportBody.data || {};
          cleanupFullDocumentReviewTerminal(targetDocSession, jobId);
          renderFullDocumentReviewEntry();
          setActiveResultRecord("word.document_review", targetDocSession, {
            result: {
              reportType: "full_document_review",
              report: reportData,
              reportId: jobId
            },
            traceId: jobId,
            jobId: jobId,
            taskType: "word.document_review.full",
            documentSessionId: targetDocSession,
            completedAt: Date.now()
          });
          var renderPromise = renderFullDocumentReviewReport(reportData, jobId);
          if (renderPromise && typeof renderPromise.then === "function") {
            return renderPromise.then(function () {
              if (typeof recordTaskFirstRender === "function") {
                recordTaskFirstRender(jobId, body.traceId || job.traceId || jobId, "word.document_review.full", completionTimestamp);
              }
            }).catch(function (error) {
              setStatus("全篇审查报告分页读取失败：" + describeFetchError(error));
            });
          } else if (typeof recordTaskFirstRender === "function") {
            recordTaskFirstRender(jobId, body.traceId || job.traceId || jobId, "word.document_review.full", completionTimestamp);
          }
        });
      }
      if (job.status === "failed" || job.status === "cancelled") {
        var terminalMessage = job.error && job.error.message || "全篇审查未生成报告。";
        cleanupFullDocumentReviewTerminal(targetDocSession, jobId);
        renderFullDocumentReviewEntry();
        setStatus(job.status === "cancelled" ? "全篇审查已取消。" : "全篇审查失败：" + terminalMessage);
        setResult(terminalMessage);
        return;
      }
      setDocumentReviewCancelVisible(Boolean(job.canCancel), false);
      state.fullDocumentReviewPollErrorCount = 0;
      setStatus("全篇审查：" + (DOCUMENT_REVIEW_PHASE_TEXT[job.phase] || job.phase || "处理中"));
      setTimeout(function () {
        pollFullDocumentReviewJob(jobId, targetDocSession);
      }, DOCUMENT_REVIEW_POLL_INTERVAL_MS);
    }).catch(function (error) {
      if (state.fullDocumentReviewJobId !== jobId) {
        return;
      }
      if (isFullDocumentReviewPermanentPollError(error)) {
        cleanupFullDocumentReviewTerminal(targetDocSession, jobId);
        renderFullDocumentReviewEntry();
        setStatus(Number(error.httpStatus) === 404
          ? "原全篇审查任务不存在或已过期，请重新发起。"
          : "原全篇审查任务已无法继续查询，请检查配置后重新发起。");
        setResult(describeFetchError(error));
        return;
      }
      state.fullDocumentReviewPollErrorCount += 1;
      setStatus("全篇审查连接暂时中断，正在保留任务并重试：" + describeFetchError(error));
      setTimeout(function () {
        pollFullDocumentReviewJob(jobId, targetDocSession);
      }, Math.min(30000, DOCUMENT_REVIEW_POLL_INTERVAL_MS *
        Math.pow(2, Math.min(state.fullDocumentReviewPollErrorCount, 4))));
    });
  }

  function extractFullDocumentReviewBodyYielding(loopOptions) {
    var document = getActiveDocument();
    var paragraphs;
    var tables;
    var body;
    if (!document) {
      return Promise.reject(new Error("未检测到活动文档。"));
    }
    var requestedLoopOptions = loopOptions || {};
    var expectedEditSignal = requestedLoopOptions.expectedEditSignal;
    var expectedDocumentSessionId = requestedLoopOptions.expectedDocumentSessionId;
    var lOpts = {
      budgetMs: requestedLoopOptions.budgetMs || 32,
      delayMs: requestedLoopOptions.delayMs,
      onProgress: requestedLoopOptions.onProgress,
      checkCancelled: function () {
        if (requestedLoopOptions.checkCancelled) {
          requestedLoopOptions.checkCancelled();
        }
        ensureFullDocumentReviewPreparation(expectedEditSignal, expectedDocumentSessionId);
      }
    };
    var collectParas = helpers.collectFullDocumentReviewParagraphsYielding
      ? helpers.collectFullDocumentReviewParagraphsYielding(document, lOpts)
      : Promise.resolve(helpers.collectFullDocumentReviewParagraphs
          ? helpers.collectFullDocumentReviewParagraphs(document)
          : collectParagraphs(document, { avoidFallbackTextRead: true, excludeTableParagraphs: true }));

    return collectParas.then(function (collectedParagraphs) {
      paragraphs = collectedParagraphs;
      if (lOpts.checkCancelled) {
        lOpts.checkCancelled();
      }
      return helpers.collectFullDocumentReviewTablesYielding
        ? helpers.collectFullDocumentReviewTablesYielding(document, lOpts)
        : Promise.resolve(helpers.collectFullDocumentReviewTables
            ? helpers.collectFullDocumentReviewTables(document)
            : []);
    }).then(function (collectedTables) {
      tables = collectedTables;
      if (lOpts.checkCancelled) {
        lOpts.checkCancelled();
      }
      body = helpers.buildFullDocumentReviewBody({
        paragraphs: paragraphs,
        tables: tables
      }, 120000);
      body.documentId = "wps-document-" + helpers.sha256Text(getDocumentName(document)).slice(0, 24);
      body.editSignal = helpers.readFullDocumentReviewEditSignal
        ? helpers.readFullDocumentReviewEditSignal(document)
        : "";
      body.documentSessionId = expectedDocumentSessionId || "";
      body.batches = helpers.buildFullDocumentReviewBatches
        ? helpers.buildFullDocumentReviewBatches(body, 3500)
        : [{
          sequence: 0,
          batchId: "batch-0",
          blocks: body.blocks,
          characterCount: body.reviewCharacterCount,
          contentSha256: body.contentSha256
        }];
      return body;
    });
  }

  function uploadFullDocumentReviewBatches(session, body) {
    var batches = Array.isArray(body && body.batches) ? body.batches : [];
    return batches.reduce(function (promise, batch) {
      return promise.then(function () {
        return new Promise(function (resolve) {
          setTimeout(resolve, 0);
        });
      }).then(function () {
        ensureFullDocumentReviewPreparation(body.editSignal, body.documentSessionId);
        return request(
          "/word/document-review/full/snapshots/" + encodeURIComponent(session.sessionId) +
            "/batches/" + batch.sequence,
          {
            uploadToken: session.uploadToken,
            batchId: batch.batchId,
            blocks: batch.blocks,
            characterCount: batch.characterCount,
            contentSha256: batch.contentSha256,
            structureSha256: batch.structureSha256,
            range: batch.range,
            editSequence: body.editSignal
          },
          { method: "PUT" }
        );
      });
    }, Promise.resolve());
  }

  function ensureFullDocumentReviewPreparation(editSignal, documentSessionId) {
    var document;
    var currentSignal;
    var currentDocumentSessionId;
    if (state.fullDocumentReviewCancelRequested) {
      throw new Error("已取消全篇审查准备，未调用模型。");
    }
    document = getActiveDocument();
    if (!document) {
      throw new Error("活动文档已关闭，已停止全篇审查并清理快照。");
    }
    currentDocumentSessionId = helpers.getDocumentSessionId
      ? helpers.getDocumentSessionId(document)
      : state.documentSessionId;
    if (documentSessionId && String(currentDocumentSessionId || "") !== String(documentSessionId)) {
      throw new Error("检测到活动文档已切换，已停止全篇审查并清理快照。");
    }
    currentSignal = helpers.readFullDocumentReviewEditSignal
      ? helpers.readFullDocumentReviewEditSignal(document)
      : "";
    if (editSignal !== null && typeof editSignal !== "undefined" &&
        String(currentSignal || "") !== String(editSignal || "")) {
      throw new Error("检测到文档在全篇审查准备期间被编辑，已停止并清理快照。");
    }
  }

  function runFullDocumentReview() {
    var clickTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var readiness = getFullDocumentReviewReadiness();
    var firstPass;
    var session = null;
    var firstPassStartedAt = null;
    var localExtractionMs = 0;
    var preparationDocument = getActiveDocument();
    var currentDoc = (helpers.getDocumentSessionId && preparationDocument)
      ? helpers.getDocumentSessionId(preparationDocument) : state.documentSessionId;
    var preparationEditSignal = helpers.readFullDocumentReviewEditSignal && preparationDocument
      ? helpers.readFullDocumentReviewEditSignal(preparationDocument) : "";
    var extractionLoopOptions = {
      budgetMs: 32,
      expectedEditSignal: preparationEditSignal,
      expectedDocumentSessionId: currentDoc
    };
    var docDisplayName = (helpers.getDocumentDisplayName && preparationDocument)
      ? helpers.getDocumentDisplayName(preparationDocument)
      : (state.documentDisplayName || "Word 文档");
    if (!state.fullDocumentReviewEnabled || !readiness.fullDocumentReviewReady) {
      setStatus(readiness.label || "全篇审查尚未就绪。");
      return;
    }
    var directReadiness = typeof validateActiveDirectTaskSelection === "function"
      ? validateActiveDirectTaskSelection("word.document_review")
      : { valid: true };
    if (directReadiness && !directReadiness.valid) {
      setStatus(directReadiness.error || readiness.label || "全篇审查尚未就绪。");
      return;
    }
    if (helpers.isTaskSlotBusy && helpers.isTaskSlotBusy(state.activeTaskSlots, "wps", "word.document_review.full", currentDoc)) {
      setStatus("当前文档已存在进行中的全篇审查任务，请等待其完成。");
      return;
    }
    if (state.fullDocumentReviewJobId || state.documentReviewJobId) {
      setStatus("已有文档审查任务尚未结束。");
      return;
    }

    state.fullDocumentReviewReportMetadata = null;
    state.fullDocumentReviewIssueFilters = null;
    state.fullDocumentReviewIssueCursorHistory = [""];
    state.fullDocumentReviewReport = null;
    state.fullDocumentReviewIssueJobId = "";
    var controls = byId("full-document-review-issue-controls");
    if (controls) {
      controls.hidden = true;
    }
    setActiveResultRecord("word.document_review", currentDoc, null);

    setModelTaskBusy(true);
    state.fullDocumentReviewPreparing = true;
    state.fullDocumentReviewCancelRequested = false;
    setDocumentReviewCancelVisible(true, false);
    renderFullDocumentReviewEntry();
    setPlainResult("正在准备全篇审查...");
    setStatus("正在执行第一遍轻量抽取...");
    var feedbackTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var clickToFeedbackMs = Math.max(0, Math.round(feedbackTimestamp - clickTimestamp));
    firstPassStartedAt = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    return extractFullDocumentReviewBodyYielding(extractionLoopOptions).then(function (body) {
      firstPass = body;
      ensureFullDocumentReviewPreparation(firstPass.editSignal, currentDoc);
      firstPass.firstPassDurationMs = Math.max(0, Math.round(
        ((typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now()) - firstPassStartedAt
      ));
      localExtractionMs += firstPass.firstPassDurationMs;
      setStatus("正在创建全篇审查快照...");
      return request("/word/document-review/full/snapshots", {
        documentId: firstPass.documentId,
        documentType: state.technicalDocumentType,
        reviewPrompt: state.technicalReviewPrompt,
        writingPolicyScene: getWritingPolicyScene(),
        host: "wps",
        documentSessionId: currentDoc,
        documentDisplayName: docDisplayName,
        coverage: {
          includedRegions: ["body", "tables"],
          excludedRegions: ["headers", "footers", "footnotes", "endnotes", "comments",
            "revisions", "textBoxes", "shapes", "images", "formulas", "charts",
            "attachments", "hiddenText"]
        }
      });
    }).then(function (body) {
      session = body.data || {};
      ensureFullDocumentReviewPreparation(firstPass.editSignal, currentDoc);
      return uploadFullDocumentReviewBatches(session, firstPass);
    }).then(function () {
      setStatus("正在执行第二遍轻量哈希验证...");
      firstPass.secondPassStartedAt = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
      ensureFullDocumentReviewPreparation(firstPass.editSignal, currentDoc);
      return extractFullDocumentReviewBodyYielding(extractionLoopOptions);
    }).then(function (secondPass) {
      secondPass.secondPassDurationMs = Math.max(0, Math.round(
        ((typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now()) - firstPass.secondPassStartedAt
      ));
      localExtractionMs += secondPass.secondPassDurationMs;
      if (firstPass.contentSha256 !== secondPass.contentSha256 ||
          firstPass.structureSha256 !== secondPass.structureSha256 ||
          firstPass.reviewCharacterCount !== secondPass.reviewCharacterCount ||
          firstPass.blocks.length !== secondPass.blocks.length ||
          firstPass.tableCount !== secondPass.tableCount ||
          firstPass.cellCount !== secondPass.cellCount ||
          firstPass.batches.length !== secondPass.batches.length ||
          firstPass.editSignal !== secondPass.editSignal) {
        throw new Error("两遍正文与表格校验不一致，请停止编辑后重新发起全篇审查。");
      }
      return request(
        "/word/document-review/full/snapshots/" + encodeURIComponent(session.sessionId) + "/commit",
        {
          uploadToken: session.uploadToken,
          batchCount: firstPass.batches.length,
          reviewCharacterCount: firstPass.reviewCharacterCount,
          contentSha256: firstPass.contentSha256,
          verificationSha256: secondPass.contentSha256,
          verification: {
            batchCount: secondPass.batches.length,
            reviewCharacterCount: secondPass.reviewCharacterCount,
            contentSha256: secondPass.contentSha256,
            structureSha256: secondPass.structureSha256,
            blockCount: secondPass.blocks.length,
            tableCount: secondPass.tableCount,
            cellCount: secondPass.cellCount,
            editSequence: secondPass.editSignal
          }
        }
      );
    }).then(function (body) {
      var snapshot = body.data || {};
      var capacity = snapshot.capacity || {};
      ensureFullDocumentReviewPreparation(firstPass.editSignal, currentDoc);
      session.snapshotToken = snapshot.snapshotToken;
      setStatus("快照完成：" + firstPass.reviewCharacterCount + " 个审查字符，初始约 " +
        Number(capacity.initialChunkCount || 0) + " 个分片，调用上限 " +
        Number(capacity.callLimit || 0) + " 次。");
      if (capacity.requiresConfirmation) {
        setStatus("大型文档已冻结，等待确认后才会调用模型。");
        if (typeof window === "undefined" || typeof window.confirm !== "function" ||
            !window.confirm("本次全篇审查将处理 " + firstPass.reviewCharacterCount +
              " 个审查字符，初始约 " + capacity.initialChunkCount +
              " 个分片，调用上限 " + capacity.callLimit + " 次。是否继续？")) {
          throw new Error("已取消大型全篇审查，快照未调用模型并将清理。");
        }
      }
      return request("/word/document-review/full/jobs", {
        snapshotId: snapshot.snapshotId,
        snapshotToken: session.snapshotToken,
        confirmLarge: Boolean(capacity.requiresConfirmation),
        confirmationToken: snapshot.confirmationToken || "",
        host: "wps",
        documentSessionId: currentDoc,
        documentDisplayName: docDisplayName
      });
    }).then(function (body) {
      var job = body.data || {};
      if (!job.jobId) {
        throw new Error("Adapter 未返回全篇审查任务编号。");
      }
      var now = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
      var taskPerformance = (typeof beginTaskPerformance === "function")
        ? beginTaskPerformance(
            job.jobId,
            "word.document_review.full",
            clickTimestamp,
            clickToFeedbackMs
          )
        : null;
      if (taskPerformance) {
        taskPerformance.localExtractionMs = localExtractionMs;
        taskPerformance.clickToAdapterAcceptedMs = Math.max(0, Math.round(now - clickTimestamp));
      }
      if (typeof bindTaskPerformanceTrace === "function") {
        bindTaskPerformanceTrace(job.jobId, body.traceId || job.traceId || job.jobId, job.jobId);
      }
      setTrace(body.traceId || job.traceId || job.jobId);
      state.fullDocumentReviewPreparing = false;
      state.fullDocumentReviewCancelRequested = false;
      state.fullDocumentReviewJobId = job.jobId;
      state.fullDocumentReviewPollErrorCount = 0;
      if (helpers.claimTaskSlot) {
        helpers.claimTaskSlot(state.activeTaskSlots, "wps", "word.document_review.full", currentDoc, job.jobId);
      }
      saveFullDocumentReviewActiveJob(job.jobId, currentDoc);
      setActiveReviewJobRecord("word.document_review.full", currentDoc, {
        jobId: job.jobId,
        host: "wps",
        taskType: "word.document_review.full",
        startedAt: Date.now(),
        documentSessionId: currentDoc
      });
      renderFullDocumentReviewEntry();
      setStatus("全篇审查任务已提交。");
      pollFullDocumentReviewJob(job.jobId, currentDoc);
    }).catch(function (error) {
      state.fullDocumentReviewPreparing = false;
      state.fullDocumentReviewCancelRequested = false;
      return discardFullDocumentReviewSnapshot(session).then(function () {
        cleanupFullDocumentReviewTerminal(currentDoc);
        renderFullDocumentReviewEntry();
        var errMsg = describeFetchError(error);
        setStatus(errMsg.indexOf("取消") >= 0 ? errMsg : ("全篇审查失败：" + errMsg));
        setResult(errMsg);
      });
    });
  }

  function discardFullDocumentReviewSnapshot(session) {
    var target = session || state.fullDocumentReviewSnapshot;
    if (!target || !target.sessionId || !target.uploadToken) {
      return Promise.resolve();
    }
    return request(
      "/word/document-review/full/snapshots/" + encodeURIComponent(target.sessionId),
      { uploadToken: target.uploadToken, snapshotToken: target.snapshotToken },
      { method: "DELETE" }
    ).catch(function () { return null; });
  }

  function cancelFullDocumentReviewJob() {
    var jobId = state.fullDocumentReviewJobId;
    if (!jobId) {
      return;
    }
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    request("/word/document-review/full/jobs/" + encodeURIComponent(jobId), null, {
      method: "DELETE",
      timeoutMs: DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      if (body.data && body.data.status === "cancelled") {
        cleanupFullDocumentReviewTerminal(currentDoc, jobId);
        renderFullDocumentReviewEntry();
        setStatus("排队中的全篇审查任务已取消。");
      }
    }).catch(function (error) {
      setStatus("取消全篇审查失败：" + describeFetchError(error));
    });
  }

  function cancelFullDocumentReviewPreparation() {
    state.fullDocumentReviewCancelRequested = true;
    setStatus("正在取消全篇审查准备并清理暂存快照...");
  }

  function resumeFullDocumentReviewActiveJob() {
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    var active = loadFullDocumentReviewActiveJob(currentDoc);
    if (!state.fullDocumentReviewEnabled || !active || !active.jobId) {
      return false;
    }
    if (active.host && active.host !== "wps") {
      return false;
    }
    if (active.taskType && active.taskType !== "word.document_review.full") {
      return false;
    }
    if (active.documentSessionId && currentDoc && active.documentSessionId !== currentDoc) {
      return false;
    }
    state.fullDocumentReviewJobId = active.jobId;
    state.fullDocumentReviewPollErrorCount = 0;
    if (helpers.claimTaskSlot) {
      helpers.claimTaskSlot(state.activeTaskSlots, "wps", "word.document_review.full", currentDoc, active.jobId);
    }
    setActiveReviewJobRecord("word.document_review.full", currentDoc, active);
    setModelTaskBusy(true);
    renderFullDocumentReviewEntry();
    setStatus("正在续查未完成的全篇审查任务...");
    pollFullDocumentReviewJob(active.jobId, currentDoc);
    return true;
  }

  function startDocumentReviewWaitFeedback() {
    var timers = [];
    timers.push(setTimeout(function () {
      setStatus("模型后台正在处理文档审查，请继续等待...");
      setPlainResult("文档审查请求已提交，模型后台正在处理。较长文本或繁忙时可能需要更久，请保持 WPS 和 adapter 打开。");
    }, 8000));
    timers.push(setTimeout(function () {
      setStatus("文档审查仍在等待模型后台返回...");
      setPlainResult("文档审查仍在等待模型后台返回。若模型后台已完成但此处长时间未更新，请到“设置-最近一次任务诊断”查看 trace 和 provider 状态。");
    }, 30000));
    return function () {
      timers.forEach(function (timer) {
        clearTimeout(timer);
      });
    };
  }

  function runDocumentReview() {
    var clickTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var localExtractionMs = 0;
    var scope;
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    var docDisplayName = (helpers.getDocumentDisplayName && getActiveDocument)
      ? helpers.getDocumentDisplayName(getActiveDocument())
      : (state.documentDisplayName || "Word 文档");
    if (helpers.isTaskSlotBusy && helpers.isTaskSlotBusy(state.activeTaskSlots, "wps", "word.document_review", currentDoc)) {
      setStatus("当前文档已存在进行中的文档审查任务，请等待其完成。");
      return;
    }
    if (state.documentReviewJobId) {
      setStatus("已有文档审查任务尚未结束，请等待当前任务完成。排队任务可使用“取消排队任务”。");
      return;
    }
    scope = resolveSelectionScope(false);
    if (!scope.ok) {
      setStatus(scope.message);
      setResult(scope.message);
      return;
    }
    var modelReadiness = typeof validateActiveDirectTaskSelection === "function"
      ? validateActiveDirectTaskSelection("word.document_review")
      : { valid: true };
    if (modelReadiness && !modelReadiness.valid) {
      var unreadyMsg = modelReadiness.error || "所选模型服务尚未就绪，无法执行文档审查。";
      setStatus(unreadyMsg);
      setResult(unreadyMsg);
      return;
    }
    resetSmartWritePreviewState();
    resetDocumentReviewState();
    clearDocumentReviewActiveJob(null, currentDoc);
    setActiveResultRecord("word.document_review", currentDoc, null);

    setModelTaskBusy(true);
    setStatus("正在读取文档审查范围...");
    setPlainResult("正在读取文档审查范围，请稍候。");
    setApplyEnabled(false);
    var feedbackTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var clickToFeedbackMs = Math.max(0, Math.round(feedbackTimestamp - clickTimestamp));

    setTimeout(function () {
      var stopWaiting;
      var clientJobId;
      var startedAt;
      try {
        var extractionStartedAt = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
        state.latestDocumentPayload = extractDocument(scope.selectionMode, null, DOCUMENT_REVIEW_EXTRACTION_OPTIONS);
        localExtractionMs = Math.max(0, Math.round(
          ((typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now()) - extractionStartedAt
        ));
        state.latestDocumentPayload.writingPolicyScene = getWritingPolicyScene();
        state.latestSelectionMode = state.latestDocumentPayload.selectionMode;
        state.latestDocumentPayload.host = "wps";
        state.latestDocumentPayload.documentSessionId = currentDoc;
        state.latestDocumentPayload.documentDisplayName = docDisplayName;
      } catch (error) {
        setModelTaskBusy(false);
        setStatus(error.message);
        setResult(error.message);
        return;
      }

      setStatus("正在提交文档审查请求...");
      setPlainResult("文档审查请求已提交，正在等待模型后台返回。");
      stopWaiting = startDocumentReviewWaitFeedback();
      state.documentReviewStopWaiting = stopWaiting;
      clientJobId = buildDocumentReviewClientJobId();
      startedAt = Date.now();
      state.latestDocumentPayload.clientJobId = clientJobId;
      setDocumentReviewJobId(clientJobId);
      state.documentReviewPollStartedAt = startedAt;
      state.documentReviewPollErrorCount = 0;
      var taskPerformance = (typeof beginTaskPerformance === "function")
        ? beginTaskPerformance(
            clientJobId,
            "word.document_review",
            clickTimestamp,
            clickToFeedbackMs
          )
        : null;
      if (taskPerformance) {
        taskPerformance.localExtractionMs = localExtractionMs;
      }
      if (helpers.claimTaskSlot) {
        helpers.claimTaskSlot(state.activeTaskSlots, "wps", "word.document_review", currentDoc, clientJobId);
      }
      var activeRecord = {
        jobId: clientJobId,
        host: "wps",
        taskType: "word.document_review",
        traceId: "",
        startedAt: startedAt,
        documentSessionId: currentDoc
      };
      saveDocumentReviewActiveJob(activeRecord);
      setActiveReviewJobRecord("word.document_review", currentDoc, activeRecord);
      request("/word/document-review/jobs", state.latestDocumentPayload, {
        timeoutMs: DOCUMENT_REVIEW_POLL_REQUEST_TIMEOUT_MS
      })
        .then(function (body) {
          var job = body.data || {};
          var jobId = job.jobId || clientJobId || body.traceId;
          if (state.documentReviewJobId !== clientJobId) {
            return;
          }
          var now = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
          var baseClick = (taskPerformance && taskPerformance.clickTimestamp) || clickTimestamp || startedAt;
          if (taskPerformance) {
            taskPerformance.clickToAdapterAcceptedMs = Math.max(0, Math.round(now - baseClick));
          }
          if (typeof bindTaskPerformanceTrace === "function") {
            bindTaskPerformanceTrace(
              clientJobId,
              body.traceId || job.traceId || jobId,
              jobId
            );
          }
          setTrace(body.traceId || job.traceId || jobId);
          if (!jobId) {
            cleanupDocumentReviewTerminal(currentDoc, clientJobId);
            stopDocumentReviewWaitFeedback(stopWaiting);
            setStatus("文档审查失败：adapter 未返回后台任务编号。");
            setResult("adapter 未返回后台任务编号，请重试或查看最近一次任务诊断。");
            return;
          }
          setDocumentReviewJobId(jobId);
          state.documentReviewPollStartedAt = startedAt;
          state.documentReviewPollErrorCount = 0;
          var updatedRecord = {
            jobId: jobId,
            host: "wps",
            taskType: "word.document_review",
            traceId: body.traceId || job.traceId || "",
            startedAt: startedAt,
            documentSessionId: currentDoc
          };
          saveDocumentReviewActiveJob(updatedRecord);
          setActiveReviewJobRecord("word.document_review", currentDoc, updatedRecord);
          if (job.status === "completed") {
            cleanupDocumentReviewTerminal(currentDoc, jobId);
            stopDocumentReviewWaitFeedback(stopWaiting);
            completeDocumentReview(job.result || {}, body.traceId || job.traceId || jobId, currentDoc, jobId);
            return;
          }
          renderDocumentReviewJobProgress(job, jobId);
          pollDocumentReviewJob(state.documentReviewJobId, stopWaiting, true, currentDoc);
        })
        .catch(function (error) {
          var message;
          message = describeDocumentReviewError(error);
          if (state.documentReviewJobId !== clientJobId) {
            return;
          }
          if (isFatalDocumentReviewPollError(error)) {
            cleanupDocumentReviewTerminal(currentDoc, clientJobId);
            stopDocumentReviewWaitFeedback(stopWaiting);
            setStatus("文档审查失败：" + message);
            setResult(message);
            return;
          }
          setStatus("文档审查提交响应未确认，正在按任务编号恢复状态查询...");
          setPlainResult([
            "文档审查任务可能已经提交到 adapter，但任务窗格没有收到确认响应。",
            "将按本地任务编号继续查询；如果 adapter 未收到请求，会返回任务不存在。",
            "任务编号：" + clientJobId,
            "最近错误：" + message
          ].join("\n"));
          pollDocumentReviewJob(clientJobId, stopWaiting, false, currentDoc);
        });
    }, 0);
  }

  function loadDeterministicFormatReviewActiveJob(docSessionId) {
    try {
      if (!window.localStorage) {
        return null;
      }
      var currentDoc = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
      var raw;
      if (currentDoc) {
        raw = window.localStorage.getItem(getReviewActiveJobStorageKey("word.format_review", currentDoc));
        if (raw) {
          return JSON.parse(raw);
        }
      }
      raw = window.localStorage.getItem(DETERMINISTIC_FORMAT_REVIEW_ACTIVE_JOB_STORAGE_KEY);
      if (raw) {
        var legacy = JSON.parse(raw);
        if (!currentDoc || !legacy.documentSessionId || legacy.documentSessionId === currentDoc) {
          return legacy;
        }
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  function saveDeterministicFormatReviewActiveJob(jobId, startedAt, docSessionId) {
    if (!jobId) {
      return;
    }
    var currentDoc = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
    try {
      if (window.localStorage) {
        var record = JSON.stringify({
          jobId: jobId,
          host: "wps",
          taskType: "word.format_review",
          documentSessionId: currentDoc || "",
          startedAt: startedAt || Date.now(),
          frontendVersion: FRONTEND_BUILD_VERSION
        });
        if (currentDoc) {
          window.localStorage.setItem(getReviewActiveJobStorageKey("word.format_review", currentDoc), record);
        }
        window.localStorage.setItem(DETERMINISTIC_FORMAT_REVIEW_ACTIVE_JOB_STORAGE_KEY, record);
      }
    } catch (error) {
      // In-memory polling remains active when the host disables localStorage.
    }
  }

  function clearDeterministicFormatReviewActiveJob(jobId, docSessionId) {
    var active;
    try {
      if (!window.localStorage) {
        return;
      }
      var currentDoc = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
      if (currentDoc) {
        window.localStorage.removeItem(getReviewActiveJobStorageKey("word.format_review", currentDoc));
      }
      for (var i = window.localStorage.length - 1; i >= 0; i -= 1) {
        var k = window.localStorage.key(i);
        if (k && k.indexOf("ai-wps:review-active-job:word.format_review:") === 0) {
          var val = window.localStorage.getItem(k);
          if (val) {
            try {
              var parsed = JSON.parse(val);
              if (!jobId || (parsed && parsed.jobId === jobId)) {
                window.localStorage.removeItem(k);
              }
            } catch (e) {}
          }
        }
      }
      active = null;
      try {
        var rawLegacy = window.localStorage.getItem(DETERMINISTIC_FORMAT_REVIEW_ACTIVE_JOB_STORAGE_KEY);
        if (rawLegacy) {
          active = JSON.parse(rawLegacy);
        }
      } catch (e) {}
      if (!jobId || (active && active.jobId === jobId)) {
        window.localStorage.removeItem(DETERMINISTIC_FORMAT_REVIEW_ACTIVE_JOB_STORAGE_KEY);
      }
    } catch (error) {
      // Storage cleanup must not block the terminal state.
    }
  }

  function clearDeterministicFormatReviewPresentation() {
    var controls = byId("deterministic-format-review-issue-controls");
    var diagnostics = byId("deterministic-format-review-diagnostics");
    var diagnosticsContent = byId("deterministic-format-review-diagnostics-content");
    state.deterministicFormatReviewReport = null;
    state.deterministicFormatReviewIssueJobId = "";
    state.deterministicFormatReviewIssueCursorHistory = [];
    if (controls) {
      controls.hidden = true;
    }
    if (diagnostics) {
      diagnostics.hidden = true;
      diagnostics.open = false;
    }
    if (diagnosticsContent) {
      diagnosticsContent.textContent = "";
    }
  }

  function renderDeterministicFormatReviewDiagnostics(report, issues) {
    var disclosure = byId("deterministic-format-review-diagnostics");
    var content = byId("deterministic-format-review-diagnostics-content");
    var summary = report && report.summary || {};
    if (!disclosure || !content) {
      return;
    }
    content.textContent = JSON.stringify({
      machineSummary: summary,
      formatFactDiagnostics: summary.formatFactDiagnostics || {},
      machineIssues: Array.isArray(issues) ? issues : []
    }, null, 2);
    disclosure.hidden = false;
  }

  function expireDeterministicFormatReviewJob(jobId, message, docSessionId) {
    var targetDocSession = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    cleanupDeterministicFormatReviewTerminal(targetDocSession, jobId);
    if (!currentDoc || !targetDocSession || currentDoc === targetDocSession) {
      clearDeterministicFormatReviewPresentation();
      setModelTaskBusy(false);
      setDocumentReviewCancelVisible(false, false);
      setStatus(message || "格式审查任务已失效，请重新审查。");
      setPlainResult("本次格式审查任务已失效，旧结果不会复用。请重新点击“开始格式审查”。");
    }
  }

  function resumeDeterministicFormatReviewActiveJob() {
    var active;
    var startedAt;
    var jobId;
    if (state.currentMode !== "formatReview" ||
        !state.deterministicFormatReviewEnabled ||
        state.deterministicFormatReviewJobId) {
      return false;
    }
    var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
    active = loadDeterministicFormatReviewActiveJob(currentDoc);
    if (!active || !active.jobId) {
      return false;
    }
    if (active.documentSessionId && currentDoc && active.documentSessionId !== currentDoc) {
      return false;
    }
    if (active.host && active.host !== "wps") {
      return false;
    }
    if (active.taskType && active.taskType !== "word.format_review") {
      return false;
    }
    startedAt = Number(active.startedAt) || Date.now();
    if (Date.now() - startedAt >= DETERMINISTIC_FORMAT_REVIEW_POLL_MAX_WAIT_MS) {
      cleanupDeterministicFormatReviewTerminal(currentDoc, active.jobId);
      return false;
    }
    jobId = String(active.jobId);
    if (helpers.claimTaskSlot) {
      helpers.claimTaskSlot(state.activeTaskSlots, "wps", "word.format_review", currentDoc, jobId);
    }
    request("/word/format-review/jobs/" + encodeURIComponent(jobId), null, {
      timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      var job = body.data || {};
      if (state.currentMode !== "formatReview" ||
          state.deterministicFormatReviewJobId ||
          state.modelTaskBusy) {
        return;
      }
      if (job.status === "completed") {
        cleanupDeterministicFormatReviewTerminal(currentDoc, jobId);
        loadDeterministicFormatReviewReport(jobId, currentDoc).then(function () {
          if (state.currentMode === "formatReview") {
            setStatus("已恢复当前格式审查结果。");
          }
        }).catch(function (error) {
          if (state.currentMode === "formatReview") {
            setStatus("格式审查已完成，但报告读取失败：" + describeFetchError(error));
          }
        });
        return;
      }
      if (job.status === "failed" || job.status === "cancelled") {
        clearDeterministicFormatReviewActiveJob(jobId, currentDoc);
        cleanupDeterministicFormatReviewTerminal(currentDoc, jobId);
        return;
      }
      state.deterministicFormatReviewJobId = jobId;
      state.deterministicFormatReviewPollStartedAt = startedAt;
      state.deterministicFormatReviewPollErrorCount = 0;
      setModelTaskBusy(true);
      setDocumentReviewCancelVisible(true, false);
      setStatus("正在恢复格式审查后台任务...");
      setPlainResult("正在恢复格式审查后台任务，旧结果不会复用。\n任务编号：" + jobId);
      pollDeterministicFormatReviewJob(jobId, currentDoc);
    }).catch(function (error) {
      if (state.deterministicFormatReviewJobId || state.modelTaskBusy) {
        return;
      }
      if (error && error.adapterCode === "DETERMINISTIC_FORMAT_REVIEW_JOB_NOT_FOUND") {
        clearDeterministicFormatReviewActiveJob(jobId, currentDoc);
        cleanupDeterministicFormatReviewTerminal(currentDoc, jobId);
        return;
      }
      state.deterministicFormatReviewJobId = jobId;
      state.deterministicFormatReviewPollStartedAt = startedAt;
      state.deterministicFormatReviewPollErrorCount = 0;
      setModelTaskBusy(true);
      setDocumentReviewCancelVisible(true, false);
      setStatus("正在恢复格式审查后台任务...");
      setPlainResult("正在恢复格式审查后台任务，旧结果不会复用。\n任务编号：" + jobId);
      pollDeterministicFormatReviewJob(jobId, currentDoc);
    });
    return true;
  }

  function pollDeterministicFormatReviewJob(jobId, docSessionId) {
    var targetDocSession = docSessionId || ((helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId);
    if (!jobId || state.deterministicFormatReviewJobId !== jobId) {
      return;
    }
    request("/word/format-review/jobs/" + encodeURIComponent(jobId), null, {
      timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      var job = body.data || {};
      if (state.deterministicFormatReviewJobId !== jobId) {
        return;
      }
      var currentDoc = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
      var isMatchingDoc = Boolean(!currentDoc || !targetDocSession || currentDoc === targetDocSession);
      setTrace(body.traceId || job.traceId || jobId);
      if (job.status === "completed") {
        var completionTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
        cleanupDeterministicFormatReviewTerminal(targetDocSession, jobId);
        loadDeterministicFormatReviewReport(jobId, targetDocSession).then(function () {
          if (isMatchingDoc && state.currentMode === "formatReview") {
            setModelTaskBusy(false);
            setDocumentReviewCancelVisible(false, false);
            setStatus("确定性格式审查完成，结构化报告已生成。");
          }
          if (typeof recordTaskFirstRender === "function") {
            recordTaskFirstRender(jobId, body.traceId || job.traceId || jobId, "word.format_review.deterministic", completionTimestamp);
          }
        }).catch(function (error) {
          if (isMatchingDoc && state.currentMode === "formatReview") {
            clearDeterministicFormatReviewPresentation();
            setModelTaskBusy(false);
            setDocumentReviewCancelVisible(false, false);
            setStatus("确定性格式审查完成，但报告读取失败：" + describeFetchError(error));
            setPlainResult("本次格式审查已完成，但中文报告未能读取；旧结果不会复用，请重新审查。");
          }
        });
        return;
      }
      if (job.status === "failed" || job.status === "cancelled") {
        cleanupDeterministicFormatReviewTerminal(targetDocSession, jobId);
        if (isMatchingDoc && state.currentMode === "formatReview") {
          clearDeterministicFormatReviewPresentation();
          setModelTaskBusy(false);
          setDocumentReviewCancelVisible(false, false);
          setStatus("确定性格式审查" + (job.status === "cancelled" ? "已取消。" : "失败。"));
          setPlainResult(job.status === "cancelled"
            ? "本次格式审查已取消，旧结果不会复用。"
            : "本次格式审查后台任务失败，旧结果不会复用，请重新审查。");
        }
        return;
      }
      if (isMatchingDoc && state.currentMode === "formatReview") {
        setStatus(job.runningMessage || "正在执行确定性格式审查...");
        setPlainResult("确定性格式审查任务已提交，正在按本地规则生成结构化结果。\n任务编号：" + jobId);
      }
      setTimeout(function () {
        pollDeterministicFormatReviewJob(jobId, targetDocSession);
      }, DETERMINISTIC_FORMAT_REVIEW_POLL_INTERVAL_MS);
    }).catch(function (error) {
      if (state.deterministicFormatReviewJobId !== jobId) {
        return;
      }
      state.deterministicFormatReviewPollErrorCount += 1;
      if (error && error.adapterCode === "DETERMINISTIC_FORMAT_REVIEW_JOB_NOT_FOUND") {
        expireDeterministicFormatReviewJob(jobId, "格式审查后台任务不存在或已过期，请重新审查。", targetDocSession);
        return;
      }
      if (!state.deterministicFormatReviewPollStartedAt) {
        state.deterministicFormatReviewPollStartedAt = Date.now();
      }
      if (state.deterministicFormatReviewPollErrorCount >= DETERMINISTIC_FORMAT_REVIEW_POLL_MAX_ERRORS ||
          Date.now() - state.deterministicFormatReviewPollStartedAt >= DETERMINISTIC_FORMAT_REVIEW_POLL_MAX_WAIT_MS) {
        expireDeterministicFormatReviewJob(jobId, "格式审查任务状态查询超时，请重新审查。", targetDocSession);
        return;
      }
      saveDeterministicFormatReviewActiveJob(jobId, state.deterministicFormatReviewPollStartedAt, targetDocSession);
      var currentDocOnCatch = (helpers.getDocumentSessionId && getActiveDocument) ? helpers.getDocumentSessionId(getActiveDocument()) : state.documentSessionId;
      var isMatchingDocOnCatch = Boolean(!currentDocOnCatch || !targetDocSession || currentDocOnCatch === targetDocSession);
      if (isMatchingDocOnCatch && state.currentMode === "formatReview") {
        setDocumentReviewCancelVisible(true, false);
        setStatus("暂时无法读取格式审查任务状态，正在自动恢复（第 " +
          state.deterministicFormatReviewPollErrorCount + " 次）...");
      }
      setTimeout(function () {
        pollDeterministicFormatReviewJob(jobId, targetDocSession);
      }, DETERMINISTIC_FORMAT_REVIEW_POLL_RETRY_DELAY_MS);
    });
  }

  function cancelDeterministicFormatReviewJob() {
    var jobId = state.deterministicFormatReviewJobId;
    if (!jobId) {
      return;
    }
    setDocumentReviewCancelVisible(true, true);
    request("/word/format-review/jobs/" + encodeURIComponent(jobId), null, {
      method: "DELETE",
      timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS
    }).then(function (body) {
      if (body.data && body.data.status === "cancelled") {
        clearDeterministicFormatReviewActiveJob(jobId);
        state.deterministicFormatReviewJobId = "";
        state.deterministicFormatReviewPollStartedAt = 0;
        state.deterministicFormatReviewPollErrorCount = 0;
        state.deterministicFormatReviewSnapshot = null;
        clearDeterministicFormatReviewPresentation();
        setModelTaskBusy(false);
        setDocumentReviewCancelVisible(false, false);
        setStatus("确定性格式审查任务已取消，未保留问题实例。");
        setPlainResult("确定性格式审查任务已取消。");
        return;
      }
      setStatus("已请求取消确定性格式审查任务，正在等待后台确认。");
    }).catch(function (error) {
      setDocumentReviewCancelVisible(true, false);
      setStatus("取消确定性格式审查失败：" + describeFetchError(error));
    });
  }

  function cancelDeterministicFormatReviewPreparation() {
    state.deterministicFormatReviewCancelRequested = true;
    setStatus("正在取消格式审查准备并清理暂存快照...");
  }

  function discardDeterministicFormatReviewSnapshot(explicitSnapshot) {
    var snapshot = explicitSnapshot || state.deterministicFormatReviewSnapshot;
    state.deterministicFormatReviewImageObjects = {};
    state.deterministicFormatReviewSnapshot = null;
    if (!snapshot || !snapshot.snapshotId || !(snapshot.snapshotToken || snapshot.uploadToken)) {
      return;
    }
    request(
      "/word/format-review/snapshots/" + encodeURIComponent(snapshot.snapshotId),
      { snapshotToken: snapshot.snapshotToken || snapshot.uploadToken },
      {
        method: "DELETE",
        timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS
      }
    ).catch(function () {
      // The adapter also expires abandoned snapshots; cleanup must not hide the original error.
    });
  }

  function collectDeterministicFormatReviewImages(document, paragraphs) {
    var images = [];
    var objects = {};
    var sources = [
      helpers.firstDefined(readValue(document, "InlineShapes"), readValue(document, "inlineShapes")),
      helpers.firstDefined(readValue(document, "Shapes"), readValue(document, "shapes"))
    ];
    var paragraphList = Array.isArray(paragraphs) ? paragraphs : [];

    function readImageObject(item, index, sourceType) {
      var type = helpers.firstDefined(readValue(item, "Type"), readValue(item, "type"));
      var typeText = String(type || "").toLowerCase();
      var isFloatingPicture = sourceType !== "floating" ||
        type === 13 || type === 11 || /picture|image|inlinepicture|inline_image/.test(typeText) ||
        readValue(item, "IsPicture") === true || readValue(item, "isPicture") === true;
      var hostId = String(helpers.firstDefined(
        readValue(item, "Id"), readValue(item, "ID"), readValue(item, "Name"), readValue(item, "name")
      ) || (sourceType + "-" + index));
      var imageId = "wps-image-" + helpers.sha256Text(sourceType + ":" + hostId + ":" + index).slice(0, 24);
      var paragraphIndex = Number(helpers.firstDefined(
        readValue(item, "ParagraphIndex"), readValue(item, "paragraphIndex"),
        readValue(item, "AnchorParagraphIndex"), readValue(item, "anchorParagraphIndex")
      ) || 0);
      if (!isFloatingPicture) {
        return;
      }
      var altText = String(helpers.firstDefined(
        readValue(item, "AlternativeText"), readValue(item, "AltText"), readValue(item, "altText")
      ) || "");
      var nearbyParas = paragraphList.filter(function (paragraph) {
        var indexValue = Number(paragraph && paragraph.index || 0);
        return paragraphIndex > 0 && Math.abs(indexValue - paragraphIndex) <= 1 && paragraph.text;
      });
      var nearby = nearbyParas.map(function (paragraph) { return String(paragraph.text || ""); });
      var hasCaption = nearby.some(function (text) {
        return /^(图|figure)\s*[0-9０-９一二三四五六七八九十]+[：:.、\s]/i.test(text.trim());
      });
      var rangeSource = paragraphList.filter(function (paragraph) {
        return Number(paragraph && paragraph.index || 0) === paragraphIndex;
      })[0] || nearbyParas[0] || {};
      var fact = {
        imageId: imageId,
        groupId: String(helpers.firstDefined(readValue(item, "GroupID"), readValue(item, "groupId")) || imageId),
        fingerprint: helpers.sha256Text(sourceType + ":" + hostId + ":" + paragraphIndex),
        captionStatus: hasCaption ? "present" : "missing",
        associationStatus: "missing",
        supported: true,
        altText: altText.slice(0, 2000),
        nearbyText: nearby.join(" ").slice(0, 4000),
        paragraphIndex: paragraphIndex,
        range: rangeSource.range || {}
      };
      images.push(fact);
      objects[imageId] = item;
    }

    sources.forEach(function (collection, sourceIndex) {
      var count = helpers.readCollectionCount(collection);
      for (var index = 1; index <= count; index += 1) {
        readImageObject(helpers.getCollectionItem(collection, index), index, sourceIndex === 0 ? "inline" : "floating");
      }
    });
    return { facts: images, objects: objects };
  }

  function saveFormatReviewImageAsPng(imageObject, slotPath) {
    if (!imageObject || typeof imageObject.SaveAsPicture !== "function") {
      throw new Error("当前 WPS 图片对象不支持 SaveAsPicture PNG 导出。");
    }
    if (!slotPath || typeof slotPath !== "string") {
      throw new Error("Adapter 未返回受控图片槽位。");
    }
    // WPS SaveAsPicture filter id 2 is PNG. The Adapter validates the file
    // container, owner, dimensions and hash after this call.
    imageObject.SaveAsPicture(slotPath, 2);
  }

  function extractDeterministicFormatReviewSnapshot(scope) {
    var document = getActiveDocument();
    var payload;
    var documentName;
    var editSequence;
    var documentIdentity;
    var tables = [];
    var contextBlocks = [];
    if (!document) {
      throw new Error("未检测到活动文档。");
    }
    payload = extractDocument(
      scope.selectionMode,
      null,
      DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS
    );
    documentName = getDocumentName(document);
    editSequence = helpers.readFullDocumentReviewEditSignal
      ? helpers.readFullDocumentReviewEditSignal(document)
      : "";
    documentIdentity = {
      documentIdSha256: helpers.sha256Text(documentName).slice(0, 64),
      hostDocumentId: String(readValue(document, "Id") || readValue(document, "ID") || documentName)
    };
    if (helpers.collectFullDocumentReviewTables) {
      if (scope.selectionMode === "selection") {
        var selectionSources = getSelectionSources(document);
        for (var sourceIndex = 0; sourceIndex < selectionSources.length; sourceIndex += 1) {
          var selectedTables = helpers.collectFullDocumentReviewTables(
            selectionSources[sourceIndex], DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS
          );
          if (selectedTables.length) {
            tables = selectedTables;
            break;
          }
        }
      } else {
        tables = helpers.collectFullDocumentReviewTables(
          document, DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS
        );
      }
    }
    payload.content.documentStructure = payload.content.documentStructure || {};
    payload.content.documentStructure.tables = tables;
    var imageCollection = collectDeterministicFormatReviewImages(
      document, payload.content.paragraphs || []
    );
    payload.content.documentStructure.imageInventory = imageCollection.facts;
    if (scope.selectionMode === "selection" && helpers.collectParagraphs) {
      var selectedIndexes = (payload.content.paragraphs || []).map(function (paragraph) {
        return Number(paragraph.index || 0);
      }).filter(function (index) { return index > 0; });
      var semanticIndexes = selectedIndexes.concat(tables.map(function (table) {
        return Number(table.paragraphIndex || 0);
      }).filter(function (index) { return index > 0; }));
      if (semanticIndexes.length) {
        helpers.collectParagraphs(document, {
          maxParagraphTextLength: 500,
          avoidFallbackTextRead: true
        }).forEach(function (paragraph) {
          var paragraphIndex = Number(paragraph.index || 0);
          var styleName = String(paragraph.styleName || paragraph.style_name || "");
          var paragraphText = String(paragraph.text || "").trim();
          var isCaption = /caption|题注/i.test(styleName) ||
            /^(图|表)\s*[0-9０-９一二三四五六七八九十]+[：:.、\s]/.test(paragraphText);
          if (selectedIndexes.indexOf(paragraphIndex) < 0 && isCaption && semanticIndexes.some(function (index) {
            return Math.abs(paragraphIndex - index) <= 1;
          })) {
            payload.content.paragraphs.push({
              index: paragraphIndex,
              text: paragraphText,
              styleName: paragraph.styleName || paragraph.style_name || "Caption",
              fontName: paragraph.fontName || paragraph.font_name || "",
              fontSize: paragraph.fontSize,
              bold: Boolean(paragraph.bold),
              italic: Boolean(paragraph.italic),
              underline: paragraph.underline,
              alignment: paragraph.alignment || "",
              outlineLevel: helpers.normalizeWpsOutlineLevel
                ? helpers.normalizeWpsOutlineLevel(paragraph.outlineLevel)
                : paragraph.outlineLevel,
              captionFor: paragraph.captionFor || "",
              range: { paragraphIndex: paragraphIndex }
            });
          } else if (selectedIndexes.length && selectedIndexes.indexOf(paragraphIndex) < 0 &&
              Math.abs(paragraphIndex - selectedIndexes[0]) <= 1) {
            contextBlocks.push({
              blockId: "format-context-paragraph-" + paragraphIndex,
              paragraphIndex: paragraphIndex,
              text: paragraph.text || "",
              format: {
                styleName: paragraph.styleName || "",
                outlineLevel: helpers.normalizeWpsOutlineLevel
                  ? helpers.normalizeWpsOutlineLevel(paragraph.outlineLevel)
                  : paragraph.outlineLevel,
                dataStatus: "context_only"
              },
              range: { paragraphIndex: paragraphIndex }
            });
          }
        });
      }
    }
    var body = helpers.buildDeterministicFormatReviewBody(payload, {
      contextBlocks: contextBlocks,
      documentIdentity: documentIdentity,
      editSequence: editSequence,
      coverage: (function () {
        var cov = helpers.collectFormatReviewCoverage
          ? helpers.collectFormatReviewCoverage(document) : {};
        if (scope.selectionMode === "selection") {
          delete cov.tocRegions;
          delete cov.suspectedTocRegions;
        }
        return cov;
      })(),
      scope: {
        mode: scope.selectionMode,
        expandedToSemanticUnits: scope.selectionMode === "selection",
        selectedTextSha256: scope.selectionMode === "selection"
          ? helpers.sha256Text(scope.selectedText || getSelectionText(document)) : "",
        contextOnly: contextBlocks.map(function (block) { return block.blockId; })
      },
      imageFacts: imageCollection.facts
    });
    body._imageObjects = imageCollection.objects;
    return body;
  }

  function extractDeterministicFormatReviewSnapshotYielding(scope, loopOptions) {
    var document = getActiveDocument();
    var payload;
    var documentName;
    var editSequence;
    var documentIdentity;
    var documentSessionId;
    var tables = [];
    var contextBlocks = [];
    var imageCollection;
    if (!document) {
      return Promise.reject(new Error("未检测到活动文档。"));
    }
    documentName = getDocumentName(document);
    editSequence = helpers.readFullDocumentReviewEditSignal
      ? helpers.readFullDocumentReviewEditSignal(document)
      : "";
    documentIdentity = {
      documentIdSha256: helpers.sha256Text(documentName).slice(0, 64),
      hostDocumentId: String(readValue(document, "Id") || readValue(document, "ID") || documentName)
    };
    documentSessionId = scope.documentSessionId || (helpers.getDocumentSessionId
      ? helpers.getDocumentSessionId(document) : state.documentSessionId);
    var lOpts = loopOptions || {
      budgetMs: 32,
      checkCancelled: function () {
        ensureDeterministicFormatReviewPreparation(
          editSequence, documentIdentity, documentSessionId
        );
      }
    };
    if (lOpts.checkCancelled) {
      try {
        lOpts.checkCancelled();
      } catch (err) {
        return Promise.reject(err);
      }
    }
    return extractDocumentYielding(
      scope.selectionMode,
      null,
      DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS,
      lOpts
    ).then(function (extractedPayload) {
      payload = extractedPayload;
      if (lOpts.checkCancelled) {
        lOpts.checkCancelled();
      }
      if (helpers.collectFullDocumentReviewTablesYielding) {
        if (scope.selectionMode === "selection") {
          var selectionSources = getSelectionSources(document);
          var sourceIndex = 0;
          function checkNextSource() {
            if (sourceIndex >= selectionSources.length) {
              return Promise.resolve([]);
            }
            return helpers.collectFullDocumentReviewTablesYielding(
              selectionSources[sourceIndex],
              DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS,
              lOpts
            ).then(function (selectedTables) {
              if (selectedTables.length) {
                return selectedTables;
              }
              sourceIndex += 1;
              return checkNextSource();
            });
          }
          return checkNextSource();
        } else {
          return helpers.collectFullDocumentReviewTablesYielding(
            document,
            DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS,
            lOpts
          );
        }
      } else if (helpers.collectFullDocumentReviewTables) {
        if (scope.selectionMode === "selection") {
          var selSources = getSelectionSources(document);
          for (var sIdx = 0; sIdx < selSources.length; sIdx += 1) {
            var sTables = helpers.collectFullDocumentReviewTables(
              selSources[sIdx], DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS
            );
            if (sTables.length) {
              return Promise.resolve(sTables);
            }
          }
          return Promise.resolve([]);
        } else {
          return Promise.resolve(helpers.collectFullDocumentReviewTables(
            document, DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS
          ));
        }
      }
      return Promise.resolve([]);
    }).then(function (collectedTables) {
      tables = collectedTables;
      payload.content.documentStructure = payload.content.documentStructure || {};
      payload.content.documentStructure.tables = tables;
      if (lOpts.checkCancelled) {
        lOpts.checkCancelled();
      }
      return helpers.collectDeterministicFormatReviewImagesYielding
        ? helpers.collectDeterministicFormatReviewImagesYielding(document, payload.content.paragraphs || [], lOpts)
        : Promise.resolve(collectDeterministicFormatReviewImages(document, payload.content.paragraphs || []));
    }).then(function (collectedImages) {
      imageCollection = collectedImages;
      payload.content.documentStructure.imageInventory = imageCollection.facts;
      if (lOpts.checkCancelled) {
        lOpts.checkCancelled();
      }
      var captionPromise = Promise.resolve();
      if (scope.selectionMode === "selection" && helpers.collectParagraphs) {
        var selectedIndexes = (payload.content.paragraphs || []).map(function (paragraph) {
          return Number(paragraph.index || 0);
        }).filter(function (index) { return index > 0; });
        var semanticIndexes = selectedIndexes.concat(tables.map(function (table) {
          return Number(table.paragraphIndex || 0);
        }).filter(function (index) { return index > 0; }));
        if (semanticIndexes.length) {
          var captionOptions = {
            maxParagraphTextLength: 500,
            avoidFallbackTextRead: true
          };
          var getParasPromise = helpers.collectParagraphsYielding
            ? helpers.collectParagraphsYielding(document, captionOptions, lOpts)
            : Promise.resolve(helpers.collectParagraphs(document, captionOptions));
          captionPromise = getParasPromise.then(function (allParas) {
            allParas.forEach(function (paragraph) {
              var paragraphIndex = Number(paragraph.index || 0);
              var styleName = String(paragraph.styleName || paragraph.style_name || "");
              var paragraphText = String(paragraph.text || "").trim();
              var isCaption = /caption|题注/i.test(styleName) ||
                /^(图|表)\s*[0-9０-９一二三四五六七八九十]+[：:.、\s]/.test(paragraphText);
              if (selectedIndexes.indexOf(paragraphIndex) < 0 && isCaption && semanticIndexes.some(function (index) {
                return Math.abs(paragraphIndex - index) <= 1;
              })) {
                payload.content.paragraphs.push({
                  index: paragraphIndex,
                  text: paragraphText,
                  styleName: paragraph.styleName || paragraph.style_name || "Caption",
                  fontName: paragraph.fontName || paragraph.font_name || "",
                  fontSize: paragraph.fontSize,
                  bold: Boolean(paragraph.bold),
                  italic: Boolean(paragraph.italic),
                  underline: paragraph.underline,
                  alignment: paragraph.alignment || "",
                  outlineLevel: helpers.normalizeWpsOutlineLevel
                    ? helpers.normalizeWpsOutlineLevel(paragraph.outlineLevel)
                    : paragraph.outlineLevel,
                  captionFor: paragraph.captionFor || "",
                  range: { paragraphIndex: paragraphIndex }
                });
              } else if (selectedIndexes.length && selectedIndexes.indexOf(paragraphIndex) < 0 &&
                  Math.abs(paragraphIndex - selectedIndexes[0]) <= 1) {
                contextBlocks.push({
                  blockId: "format-context-paragraph-" + paragraphIndex,
                  paragraphIndex: paragraphIndex,
                  text: paragraph.text || "",
                  format: {
                    styleName: paragraph.styleName || "",
                    outlineLevel: helpers.normalizeWpsOutlineLevel
                      ? helpers.normalizeWpsOutlineLevel(paragraph.outlineLevel)
                      : paragraph.outlineLevel,
                    dataStatus: "context_only"
                  },
                  range: { paragraphIndex: paragraphIndex }
                });
              }
            });
          });
        }
      }
      return captionPromise;
    }).then(function () {
      if (lOpts.checkCancelled) {
        lOpts.checkCancelled();
      }
      var body = helpers.buildDeterministicFormatReviewBody(payload, {
        contextBlocks: contextBlocks,
        documentIdentity: documentIdentity,
        editSequence: editSequence,
        coverage: (function () {
          var cov = helpers.collectFormatReviewCoverage
            ? helpers.collectFormatReviewCoverage(document) : {};
          if (scope.selectionMode === "selection") {
            delete cov.tocRegions;
            delete cov.suspectedTocRegions;
          }
          return cov;
        })(),
        scope: {
          mode: scope.selectionMode,
          expandedToSemanticUnits: scope.selectionMode === "selection",
          selectedTextSha256: scope.selectionMode === "selection"
            ? helpers.sha256Text(scope.selectedText || getSelectionText(document)) : "",
          contextOnly: contextBlocks.map(function (block) { return block.blockId; })
        },
        imageFacts: imageCollection.facts
      });
      body._imageObjects = imageCollection.objects;
      body.documentSessionId = documentSessionId || "";
      return body;
    });
  }

  function ensureDeterministicFormatReviewPreparation(editSequence, documentIdentity,
      documentSessionId) {
    var document = getActiveDocument();
    var currentSequence;
    var currentName;
    var currentDocumentSessionId;
    if (state.deterministicFormatReviewCancelRequested) {
      throw new Error("已取消格式审查准备，未调用模型。");
    }
    if (!document) {
      throw new Error("活动文档已关闭，已安全中止格式审查并清理快照。");
    }
    currentSequence = helpers.readFullDocumentReviewEditSignal
      ? helpers.readFullDocumentReviewEditSignal(document)
      : "";
    currentName = getDocumentName(document);
    currentDocumentSessionId = helpers.getDocumentSessionId
      ? helpers.getDocumentSessionId(document)
      : state.documentSessionId;
    if (String(editSequence || "") !== String(currentSequence || "") ||
        String(documentIdentity && documentIdentity.hostDocumentId || "") !==
          String(readValue(document, "Id") || readValue(document, "ID") || currentName) ||
        (documentSessionId && String(currentDocumentSessionId || "") !== String(documentSessionId))) {
      throw new Error("检测到文档编辑或文档身份变化，已安全中止格式审查并清理快照。");
    }
  }

  function uploadDeterministicFormatReviewBatches(session, body) {
    var batches = Array.isArray(body && body.batches) ? body.batches : [];
    return batches.reduce(function (promise, batch) {
      return promise.then(function () {
        return new Promise(function (resolve) { setTimeout(resolve, 0); });
      }).then(function () {
        ensureDeterministicFormatReviewPreparation(
          body.editSequence, body.documentIdentity, body.documentSessionId
        );
        return request(
          "/word/format-review/snapshots/" + encodeURIComponent(session.snapshotId) +
            "/batches/" + batch.sequence,
          {
            uploadToken: session.uploadToken || session.snapshotToken,
            batchId: batch.batchId,
            blocks: batch.blocks,
            characterCount: batch.characterCount,
            contentSha256: batch.contentSha256,
            structureSha256: batch.structureSha256,
            formatSha256: batch.formatSha256,
            editSequence: body.editSequence
          },
          { method: "PUT", timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS }
        );
      });
    }, Promise.resolve());
  }

  function exportDeterministicFormatReviewImageGroups(session, body) {
    var imageObjects = state.deterministicFormatReviewImageObjects || {};
    var committedGroups = 0;

    function next(remainingCalls) {
      ensureDeterministicFormatReviewPreparation(
        body.editSequence, body.documentIdentity, body.documentSessionId
      );
      return request(
        "/word/format-review/snapshots/" + encodeURIComponent(session.snapshotId) + "/image-groups",
        {
          uploadToken: session.uploadToken || session.snapshotToken,
          documentIdentity: body.documentIdentity,
          editSequence: body.editSequence,
          remainingCalls: remainingCalls
        },
        { method: "POST", timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS }
      ).then(function (groupBody) {
        var data = groupBody.data || {};
        if (data.status !== "allocated" || !data.group) {
          return data;
        }
        var group = data.group;
        (group.assets || []).forEach(function (asset) {
          var imageObject = imageObjects[String(asset.imageId || "")];
          if (!imageObject) {
            throw new Error("未找到图片对象，已停止受控图片导出。");
          }
          ensureDeterministicFormatReviewPreparation(
            body.editSequence, body.documentIdentity, body.documentSessionId
          );
          saveFormatReviewImageAsPng(imageObject, asset.slotPath);
        });
        ensureDeterministicFormatReviewPreparation(
          body.editSequence, body.documentIdentity, body.documentSessionId
        );
        return request(
          "/word/format-review/snapshots/" + encodeURIComponent(session.snapshotId) +
            "/image-groups/" + encodeURIComponent(group.groupId) + "/commit",
          {
            uploadToken: session.uploadToken || session.snapshotToken,
            documentIdentity: body.documentIdentity,
            editSequence: body.editSequence
          },
          { method: "POST", timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS }
        ).then(function () {
          committedGroups += 1;
          return next(Math.max(0, Number(remainingCalls || 0) - 1));
        });
      });
    }

    return next(16).then(function (result) {
      return { result: result, committedGroups: committedGroups };
    });
  }

  function runDeterministicFormatReview() {
    var clickTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var localExtractionMs = 0;
    var scope;
    var firstPass;
    var session = null;
    var document = getActiveDocument();
    var currentDoc = (helpers.getDocumentSessionId && document) ? helpers.getDocumentSessionId(document) : state.documentSessionId;
    var docDisplayName = (helpers.getDocumentDisplayName && document) ? helpers.getDocumentDisplayName(document) : (state.documentDisplayName || "未命名文档.docx");
    // Extraction is bounded by DETERMINISTIC_FORMAT_REVIEW_EXTRACTION_OPTIONS.
    if (!state.deterministicFormatReviewEnabled) {
      setStatus("无法开始格式审查。");
      setPlainResult(
        "当前本地服务未开放格式审查。请确认本地 Adapter 已升级到当前版本并重新启动，" +
        "然后再次尝试。如仍无法使用，请前往“设置 > 高级诊断”查看详情。"
      );
      return;
    }
    if (helpers.isTaskSlotBusy && helpers.isTaskSlotBusy(state.activeTaskSlots, "wps", "word.format_review", currentDoc)) {
      setStatus("已有格式审查任务正在执行，请等待当前任务完成。");
      return;
    }
    if (state.deterministicFormatReviewJobId || state.modelTaskBusy) {
      setStatus("已有格式审查任务正在执行，请等待当前任务完成。");
      return;
    }
    var modelReadiness = typeof validateActiveDirectTaskSelection === "function"
      ? validateActiveDirectTaskSelection("word.format_review")
      : { valid: true };
    if (!modelReadiness.valid) {
      setStatus(modelReadiness.error || "模型配置不可用，请前往设置检查模型目录或配置。");
      setPlainResult(modelReadiness.error || "模型配置不可用，请前往设置检查模型目录或配置。");
      return;
    }
    scope = resolveSelectionScope(false);
    if (!scope.ok) {
      setStatus(scope.message);
      setResult(scope.message);
      return;
    }
    scope.documentSessionId = currentDoc;
    setActiveResultRecord("word.format_review", currentDoc, null);
    clearDeterministicFormatReviewPresentation();
    clearDeterministicFormatReviewActiveJob(null, currentDoc);
    if (helpers.claimTaskSlot) {
      helpers.claimTaskSlot(state.activeTaskSlots, "wps", "word.format_review", currentDoc, null);
    }
    state.deterministicFormatReviewJobId = "";
    state.deterministicFormatReviewPollStartedAt = Date.now();
    state.deterministicFormatReviewPollErrorCount = 0;
    state.deterministicFormatReviewPreparing = true;
    state.deterministicFormatReviewCancelRequested = false;
    setModelTaskBusy(true);
    setDocumentReviewCancelVisible(true, false);
    setStatus("正在执行第一遍格式语义抽取...");
    setPlainResult("正在分批读取格式语义单元，请稍候。不会修改 Word 文档。");
    var feedbackTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var clickToFeedbackMs = Math.max(0, Math.round(feedbackTimestamp - clickTimestamp));

    function prepareFirstPass(snapshot) {
      firstPass = snapshot;
      firstPass.batches = helpers.buildDeterministicFormatReviewBatches(firstPass, 3500);
      state.deterministicFormatReviewImageObjects = firstPass._imageObjects || {};
      ensureDeterministicFormatReviewPreparation(
        firstPass.editSequence, firstPass.documentIdentity, firstPass.documentSessionId
      );
      state.deterministicFormatReviewDocumentIdentity = firstPass.documentIdentity;
      state.latestSelectionMode = firstPass.selectionMode;
      setStatus("正在创建格式快照会话...");
      return request("/word/format-review/snapshots", {
        documentId: firstPass.documentId,
        selectionMode: firstPass.selectionMode,
        documentIdentity: firstPass.documentIdentity,
        documentSessionId: currentDoc || "",
        documentDisplayName: docDisplayName || "",
        host: "wps",
        editSequence: firstPass.editSequence,
        templateId: firstPass.templateId,
        formatSnapshotSchemaVersion: firstPass.formatSnapshotSchemaVersion,
        formatFactSchemaVersion: firstPass.formatFactSchemaVersion,
        pageSetup: firstPass.pageSetup,
        pageSetupFacts: firstPass.pageSetupFacts,
        scope: firstPass.scope,
        coverage: firstPass.coverage
      }, {
        timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS
      });
    }

    var extractionStartedAt = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var firstPassPromise;
    if (typeof extractDeterministicFormatReviewSnapshotYielding === "function") {
      firstPassPromise = extractDeterministicFormatReviewSnapshotYielding(scope).then(function (snapshot) {
        localExtractionMs += Math.max(0, Math.round(
          ((typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now()) - extractionStartedAt
        ));
        return prepareFirstPass(snapshot);
      });
    } else {
      firstPass = extractDeterministicFormatReviewSnapshot(scope);
      localExtractionMs += Math.max(0, Math.round(
        ((typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now()) - extractionStartedAt
      ));
      firstPassPromise = prepareFirstPass(firstPass);
    }

    return firstPassPromise.then(function (snapshotBody) {
      session = snapshotBody.data || {};
      state.deterministicFormatReviewSnapshot = session;
      setTrace(snapshotBody.traceId || session.snapshotId || "");
      setStatus("正在上传第一遍格式事实，共 " + firstPass.batches.length + " 个批次...");
      return uploadDeterministicFormatReviewBatches(session, firstPass);
    }).then(function () {
      setStatus("正在执行第二遍格式结构与指纹验证...");
      ensureDeterministicFormatReviewPreparation(
        firstPass.editSequence, firstPass.documentIdentity, firstPass.documentSessionId
      );
      var secondExtractionStartedAt = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
      if (typeof extractDeterministicFormatReviewSnapshotYielding === "function") {
        return extractDeterministicFormatReviewSnapshotYielding(scope).then(function (secondPass) {
          localExtractionMs += Math.max(0, Math.round(
            ((typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now()) - secondExtractionStartedAt
          ));
          return secondPass;
        });
      }
      return new Promise(function (resolve, reject) {
        setTimeout(function () {
          try {
            var secondPass = extractDeterministicFormatReviewSnapshot(scope);
            localExtractionMs += Math.max(0, Math.round(
              ((typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now()) - secondExtractionStartedAt
            ));
            resolve(secondPass);
          } catch (error) {
            reject(error);
          }
        }, 0);
      });
    }).then(function (secondPass) {
      secondPass.batches = helpers.buildDeterministicFormatReviewBatches(secondPass, 3500);
      if (firstPass.contentSha256 !== secondPass.contentSha256 ||
          firstPass.structureSha256 !== secondPass.structureSha256 ||
          firstPass.formatSha256 !== secondPass.formatSha256 ||
          firstPass.reviewCharacterCount !== secondPass.reviewCharacterCount ||
          firstPass.blocks.length !== secondPass.blocks.length ||
          JSON.stringify(firstPass.coverage) !== JSON.stringify(secondPass.coverage) ||
          firstPass.batches.length !== secondPass.batches.length ||
          firstPass.editSequence !== secondPass.editSequence ||
          JSON.stringify(firstPass.documentIdentity) !== JSON.stringify(secondPass.documentIdentity)) {
        throw new Error("两遍格式结构、对象、覆盖或格式指纹不一致，请停止编辑后重新发起格式审查。");
      }
      return request(
        "/word/format-review/snapshots/" + encodeURIComponent(session.snapshotId) + "/commit",
        {
          uploadToken: session.uploadToken || session.snapshotToken,
          batchCount: firstPass.batches.length,
          blockCount: firstPass.blocks.length,
          reviewCharacterCount: firstPass.reviewCharacterCount,
          contentSha256: firstPass.contentSha256,
          structureSha256: firstPass.structureSha256,
          formatSha256: firstPass.formatSha256,
          coverage: firstPass.coverage,
          verification: {
            batchCount: secondPass.batches.length,
            blockCount: secondPass.blocks.length,
            reviewCharacterCount: secondPass.reviewCharacterCount,
            contentSha256: secondPass.contentSha256,
            structureSha256: secondPass.structureSha256,
            formatSha256: secondPass.formatSha256,
            documentIdentity: secondPass.documentIdentity,
            editSequence: secondPass.editSequence,
            coverage: secondPass.coverage
          }
        },
        { method: "POST", timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS }
      );
    }).then(function (commitBody) {
      var committed = commitBody.data || {};
      state.deterministicFormatReviewSnapshot = committed;
      setStatus("正在按受控槽位导出缺失图题图片...");
      return exportDeterministicFormatReviewImageGroups(session, firstPass).then(function () {
        return commitBody;
      });
    }).then(function (commitBody) {
      var committed = commitBody.data || {};
      state.deterministicFormatReviewSnapshot = committed;
      state.deterministicFormatReviewPreparing = false;
      state.deterministicFormatReviewCancelRequested = false;
      state.deterministicFormatReviewJobId = "format-client-" +
        Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
      state.deterministicFormatReviewPollStartedAt = Date.now();
      setTrace(commitBody.traceId || committed.snapshotId || "");
      setStatus("正在提交确定性格式审查后台任务...");
      return request("/word/format-review/jobs", {
        snapshotId: committed.snapshotId,
        snapshotToken: committed.snapshotToken,
        clientJobId: state.deterministicFormatReviewJobId,
        documentSessionId: currentDoc || "",
        documentDisplayName: docDisplayName || "",
        host: "wps"
      }, { timeoutMs: DETERMINISTIC_FORMAT_REVIEW_REQUEST_TIMEOUT_MS });
    }).then(function (jobBody) {
      var job = jobBody.data || {};
      var requestedJobId = state.deterministicFormatReviewJobId;
      var jobId = job.jobId || requestedJobId || jobBody.traceId;
      if (!jobId) {
        throw new Error("adapter 未返回确定性格式审查任务编号。");
      }
      var now = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
      var taskPerformance = (typeof beginTaskPerformance === "function")
        ? beginTaskPerformance(
            jobId,
            "word.format_review.deterministic",
            clickTimestamp,
            clickToFeedbackMs
          )
        : null;
      if (taskPerformance) {
        taskPerformance.localExtractionMs = localExtractionMs;
        taskPerformance.clickToAdapterAcceptedMs = Math.max(0, Math.round(now - clickTimestamp));
      }
      if (typeof bindTaskPerformanceTrace === "function") {
        bindTaskPerformanceTrace(jobId, jobBody.traceId || job.traceId || jobId, jobId);
      }
      setTrace(jobBody.traceId || job.traceId || jobId);
      state.deterministicFormatReviewJobId = jobId;
      saveDeterministicFormatReviewActiveJob(jobId, state.deterministicFormatReviewPollStartedAt, currentDoc);
      setActiveReviewJobRecord("word.format_review", currentDoc, {
        jobId: jobId,
        host: "wps",
        taskType: "word.format_review",
        documentSessionId: currentDoc,
        startedAt: state.deterministicFormatReviewPollStartedAt
      });
      if (helpers.claimTaskSlot) {
        helpers.claimTaskSlot(state.activeTaskSlots, "wps", "word.format_review", currentDoc, jobId);
      }
      state.deterministicFormatReviewPollErrorCount = 0;
      setDocumentReviewCancelVisible(true, false);
      pollDeterministicFormatReviewJob(jobId, currentDoc);
    }).catch(function (error) {
      state.deterministicFormatReviewPreparing = false;
      state.deterministicFormatReviewCancelRequested = false;
      cleanupDeterministicFormatReviewTerminal(currentDoc, state.deterministicFormatReviewJobId);
      discardDeterministicFormatReviewSnapshot(session);
      clearDeterministicFormatReviewPresentation();
      setModelTaskBusy(false);
      setDocumentReviewCancelVisible(false, false);
      var errMsg = describeFetchError(error);
      setStatus(errMsg.indexOf("取消") >= 0 ? errMsg : ("确定性格式审查失败：" + errMsg));
      setResult(errMsg);
    });
  }

  function runSmartWriteAction() {
    var clickTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var document = getActiveDocument();
    var docSession = helpers.getDocumentSessionId ? helpers.getDocumentSessionId(document) : "doc_session_default";
    var docDisplayName = helpers.getDocumentDisplayName ? helpers.getDocumentDisplayName(document) : "未命名文档.docx";
    state.documentSessionId = docSession;

    if (helpers.isTaskSlotBusy && helpers.isTaskSlotBusy(state.activeTaskSlots, "wps", "word.smart_write", docSession)) {
      setStatus("已有智能编写任务正在进行中，请等待当前任务完成。");
      return;
    }

    var modelReadiness = typeof validateActiveDirectTaskSelection === "function"
      ? validateActiveDirectTaskSelection("word.smart_write")
      : { valid: true };
    if (!modelReadiness.valid) {
      setStatus(modelReadiness.error || "模型配置不可用，请前往设置检查模型目录或配置。");
      return;
    }

    var selectionScope = resolveSelectionScope(true);
    if (!selectionScope.ok) {
      setStatus(selectionScope.message);
      return;
    }

    var config = modeConfig[state.currentMode] || modeConfig.smartWrite;
    setModelTaskBusy(true);
    setStatus("正在读取选中文本...");
    var clickFeedbackTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var clickToFeedbackMs = Math.max(0, Math.round(clickFeedbackTimestamp - clickTimestamp));
    resetSmartWritePreviewState();
    setActiveResultRecord("word.smart_write", docSession, null);
    setPlainResult("正在读取选中文本，请稍候。");
    setApplyEnabled(false);

    setTimeout(function () {
      try {
        state.latestDocumentPayload = extractDocument(
          "selection",
          state.writeAction || "rewrite",
          SMART_WRITE_EXTRACTION_OPTIONS
        );
        state.latestDocumentPayload.writingPolicyScene = getWritingPolicyScene();
        state.latestSelectionMode = state.latestDocumentPayload.selectionMode;
        state.latestDocumentPayload.host = "wps";
        state.latestDocumentPayload.documentSessionId = docSession;
        state.latestDocumentPayload.documentDisplayName = docDisplayName;
        state.latestDocumentPayload._clickTimestamp = clickTimestamp;
        state.latestDocumentPayload._clickToFeedbackMs = clickToFeedbackMs;
      } catch (error) {
        setModelTaskBusy(false);
        setStatus(error.message);
        setResult(error.message);
        return;
      }

      setStatus(config.runningText);
      startWritingJob(state.latestDocumentPayload, "word.smart_write", "smartWrite");
    }, 0);
  }

  function runSmartImitationAction() {
    var clickTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var document = getActiveDocument();
    var docSession = helpers.getDocumentSessionId ? helpers.getDocumentSessionId(document) : "doc_session_default";
    var docDisplayName = helpers.getDocumentDisplayName ? helpers.getDocumentDisplayName(document) : "未命名文档.docx";
    state.documentSessionId = docSession;

    if (helpers.isTaskSlotBusy && helpers.isTaskSlotBusy(state.activeTaskSlots, "wps", "word.smart_imitation", docSession)) {
      setStatus("已有智能仿写任务正在进行中，请等待当前任务完成。");
      return;
    }

    var imitationModelReadiness = typeof validateActiveDirectTaskSelection === "function"
      ? validateActiveDirectTaskSelection("word.smart_imitation")
      : { valid: true };
    if (!imitationModelReadiness.valid) {
      setStatus(imitationModelReadiness.error || "模型配置不可用，请前往设置检查模型目录或配置。");
      return;
    }

    var templateText = String(byId("imitation-template-text").value || "").trim();
    var requirement = String(byId("imitation-requirement").value || "").trim();
    var referenceMaterial = String(byId("imitation-reference-material").value || "").trim();
    var paragraphs;
    var config = modeConfig[state.currentMode] || modeConfig.smartImitation;

    if (!templateText) {
      setStatus("请先提供仿写模板。");
      return;
    }
    if (!requirement) {
      setStatus("请填写仿写需求。");
      return;
    }

    resetSmartWritePreviewState();
    state.pendingApplyAction = "";
    setApplyEnabled(false);
    setActiveResultRecord("word.smart_imitation", docSession, null);

    paragraphs = helpers.collectParagraphsFromText
      ? helpers.collectParagraphsFromText(templateText, SMART_WRITE_EXTRACTION_OPTIONS)
      : [];

    state.latestDocumentPayload = {
      documentId: "smart-imitation",
      scene: "word",
      selectionMode: "selection",
      host: "wps",
      documentSessionId: docSession,
      documentDisplayName: docDisplayName,
      writingPolicyScene: getWritingPolicyScene(),
      _clickTimestamp: clickTimestamp,
      content: {
        plainText: templateText,
        paragraphs: paragraphs,
        headings: []
      },
      options: {
        imitationRequirement: requirement,
        imitationReferenceMaterial: referenceMaterial
      }
    };
    state.latestSelectionMode = "selection";

    setModelTaskBusy(true);
    setStatus(config.runningText);
    var clickFeedbackTimestamp = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    var clickToFeedbackMs = Math.max(0, Math.round(clickFeedbackTimestamp - clickTimestamp));
    state.latestDocumentPayload._clickToFeedbackMs = clickToFeedbackMs;
    setPlainResult("正在生成仿写内容，请稍候。");
    startWritingJob(state.latestDocumentPayload, "word.smart_imitation", "smartImitation");
  }

  function getWritingPolicyScene() {
    var select = byId("writing-policy-scene");
    var scene = helpers.normalizeWritingPolicyScene
      ? helpers.normalizeWritingPolicyScene(select && select.value)
      : "auto";
    state.writingPolicyScene = scene;
    return scene;
  }

  function saveWritingPolicyScene(value) {
    var scene = helpers.normalizeWritingPolicyScene
      ? helpers.normalizeWritingPolicyScene(value)
      : "auto";
    var taskType = getCurrentWorkflowTaskType();
    var key = helpers.writingPolicySceneStorageKey
      ? helpers.writingPolicySceneStorageKey(taskType)
      : "ai-wps:writing-policy-scene:" + taskType;
    state.writingPolicyScene = scene;
    try {
      if (window.localStorage) {
        window.localStorage.setItem(key, scene);
      }
    } catch (error) {
      // Some WPS WebView modes disable localStorage; the in-memory choice still works.
    }
  }

  function restoreWritingPolicyScene() {
    var select = byId("writing-policy-scene");
    var taskType = getCurrentWorkflowTaskType();
    var key = helpers.writingPolicySceneStorageKey
      ? helpers.writingPolicySceneStorageKey(taskType)
      : "ai-wps:writing-policy-scene:" + taskType;
    var scene = "auto";
    try {
      scene = window.localStorage ? window.localStorage.getItem(key) : "auto";
    } catch (error) {
      scene = "auto";
    }
    scene = helpers.normalizeWritingPolicyScene
      ? helpers.normalizeWritingPolicyScene(scene)
      : "auto";
    state.writingPolicyScene = scene;
    if (select) {
      select.value = scene;
    }
  }

  function applyPreview() {
    if (state.pendingApplyAction === "rewrite") {
      applyRewrite();
    }
  }

  function runPrimaryAction() {
    if (state.adapterHealthStatus === "recovery" || !state.modelTasksAllowed) {
      setStatus("Adapter 当前处于恢复模式，模型任务已被安全阻止。");
      return;
    }
    if (state.workflowProfileMutationBusy) {
      setStatus("模型配置正在更新，请稍后再提交任务。");
      return;
    }
    setInterruptedRetryVisible(false);
    if (state.currentMode === "smartImitation") {
      runSmartImitationAction();
      return;
    }
    if (state.currentMode === "smartWrite") {
      runSmartWriteAction();
      return;
    }
    if (state.currentMode === "documentReview") {
      runDocumentReview();
      return;
    }
    if (state.currentMode === "formatReview") {
      runDeterministicFormatReview();
    }
  }

  function bindDirectServiceEvents() {
    if (!helpers.bindDirectServiceEvents) {
      return;
    }
    helpers.bindDirectServiceEvents({
      byId: byId,
      handlers: {
        openCreate: function () {
          openDirectServiceEditor("create", "");
        },
        listAction: handleDirectServiceAction,
        closeEditor: closeDirectServiceEditor,
        saveEditor: saveDirectServiceEditor,
        refreshModels: refreshDirectServiceModelsInEditor,
        validateService: validateDirectService,
        cancelDelete: hideDirectServiceDeleteDialog,
        confirmDelete: confirmDirectServiceDelete,
        clearKey: clearDirectServiceApiKey,
        editorInput: function (id) {
          state.directServiceEditor.dirty = true;
          var err = byId("direct-service-editor-error");
          if (err) {
            err.textContent = "";
          }
          if (id === "direct-service-url") {
            updateDirectServiceUrlImpact();
          }
        },
        taskServiceChange: handleTaskDirectServiceSelectChange,
        validateTaskSelection: validateTaskModelSelection,
        authorizeTaskImages: function () { return performTaskImageAction("image-authorization", true); },
        revokeTaskImages: function () { return performTaskImageAction("image-authorization", false); },
        validateTaskImages: function () { return performTaskImageAction("validate-image"); },
        saveTaskSelection: saveTaskModelSelection
      }
    });
  }

  function bindEvents() {
    var workflowHelpButton = byId("workflow-help-button");
    var workflowHelpPopover = byId("workflow-help-popover");
    var workflowHelpHeading = document.querySelector(".workflow-settings-heading");
    var writingPolicyLayerButtons = document.querySelectorAll("[data-writing-policy-layer]");
    var writingPolicyLayerIndex;
    byId("btn-open-settings").addEventListener("click", function () {
      toggleSettingsShortcut();
    });
    byId("btn-cancel-document-review-job").addEventListener("click", function () {
      if (state.writingJobId) {
        cancelQueuedWritingJob();
      } else if (state.fullDocumentReviewJobId) {
        cancelFullDocumentReviewJob();
      } else if (state.deterministicFormatReviewJobId) {
        cancelDeterministicFormatReviewJob();
      } else if (state.fullDocumentReviewPreparing) {
        cancelFullDocumentReviewPreparation();
      } else if (state.deterministicFormatReviewPreparing) {
        cancelDeterministicFormatReviewPreparation();
      } else {
        cancelQueuedDocumentReviewJob();
      }
    });
    byId("btn-run-full-document-review").addEventListener("click", runFullDocumentReview);
    ["severity", "category", "location", "status", "sort"].forEach(function (name) {
      byId("full-review-filter-" + name).addEventListener("change", function (event) {
        changeFullDocumentReviewIssueFilter(name, event.target.value);
      });
    });
    byId("format-review-filter-rule").addEventListener("change", function (event) {
      changeDeterministicFormatReviewIssueFilter("rule", event.target.value);
    });
    byId("format-review-filter-status").addEventListener("change", function (event) {
      changeDeterministicFormatReviewIssueFilter("status", event.target.value);
    });
    byId("format-review-filter-data-status").addEventListener("change", function (event) {
      changeDeterministicFormatReviewIssueFilter("dataStatus", event.target.value);
    });
    byId("format-review-filter-sort").addEventListener("change", function (event) {
      changeDeterministicFormatReviewIssueFilter("sort", event.target.value);
    });
    byId("btn-format-review-filter").addEventListener("click", function () {
      var panel = byId("format-review-filter-panel");
      var menu = byId("format-review-more-menu");
      var open = panel.hidden;
      if (helpers.setFormatReviewAnchoredPanelOpen) {
        helpers.setFormatReviewAnchoredPanelOpen(
          panel,
          byId("btn-format-review-filter"),
          open,
          menu,
          byId("btn-format-review-more")
        );
      }
    });
    byId("btn-format-review-more").addEventListener("click", function () {
      var panel = byId("format-review-filter-panel");
      var menu = byId("format-review-more-menu");
      var open = menu.hidden;
      if (helpers.setFormatReviewAnchoredPanelOpen) {
        helpers.setFormatReviewAnchoredPanelOpen(
          menu,
          byId("btn-format-review-more"),
          open,
          panel,
          byId("btn-format-review-filter")
        );
      }
    });
    var formatFilterPanelEl = byId("format-review-filter-panel");
    var formatFilterTriggerEl = byId("btn-format-review-filter");
    var formatMoreMenuEl = byId("format-review-more-menu");
    var formatMoreTriggerEl = byId("btn-format-review-more");
    if (formatFilterPanelEl) {
      formatFilterPanelEl.addEventListener("focusout", function (event) {
        if (helpers.handleFormatReviewAnchoredPanelFocusout) {
          helpers.handleFormatReviewAnchoredPanelFocusout(event, {
            panel: formatFilterPanelEl,
            trigger: formatFilterTriggerEl
          });
        }
      });
    }
    if (formatMoreMenuEl) {
      formatMoreMenuEl.addEventListener("focusout", function (event) {
        if (helpers.handleFormatReviewAnchoredPanelFocusout) {
          helpers.handleFormatReviewAnchoredPanelFocusout(event, {
            panel: formatMoreMenuEl,
            trigger: formatMoreTriggerEl
          });
        }
      });
    }
    byId("btn-resubmit-interrupted-job").addEventListener("click", runPrimaryAction);
    byId("template-select").addEventListener("change", function (event) {
      state.selectedTemplateId = event.target.value;
    });
    byId("write-action").addEventListener("change", function (event) {
      state.writeAction = event.target.value;
    });
    byId("rewrite-style").addEventListener("change", function (event) {
      state.rewriteStyle = event.target.value;
      updateRewritePromptPreview();
    });
    byId("focus-point").addEventListener("change", function (event) {
      state.focusPoint = event.target.value;
      updateRewritePromptPreview();
    });
    byId("length-mode").addEventListener("change", function (event) {
      state.lengthMode = event.target.value;
      updateRewritePromptPreview();
    });
    byId("user-instruction").addEventListener("input", function (event) {
      state.userInstruction = event.target.value;
    });
    byId("writing-policy-scene").addEventListener("change", function (event) {
      saveWritingPolicyScene(event.target.value);
    });
    byId("technical-document-type").addEventListener("change", function (event) {
      applyDocumentReviewPrompt(event.target.value);
    });
    byId("technical-review-prompt").addEventListener("input", function (event) {
      state.technicalReviewPrompt = event.target.value;
    });
    byId("imitation-template-text").addEventListener("input", function (event) {
      state.imitationTemplateText = event.target.value;
    });
    byId("imitation-requirement").addEventListener("input", function (event) {
      state.imitationRequirement = event.target.value;
    });
    byId("imitation-reference-material").addEventListener("input", function (event) {
      state.imitationReferenceMaterial = event.target.value;
    });
    byId("btn-save-provider-url").addEventListener("click", saveProviderBaseUrl);
    byId("btn-cancel-provider-url").addEventListener("click", closeProviderUrlEditor);
    byId("btn-edit-provider-url").addEventListener("click", function () {
      state.providerUrlEditorOpen = true;
      byId("provider-url-details").open = true;
      byId("provider-base-url").focus();
      syncSettingsRefreshController();
    });
    byId("btn-refresh-diagnostics").addEventListener("click", refreshDiagnostics);
    byId("btn-copy-diagnostics").addEventListener("click", copyDiagnostics);
    byId("btn-recovery-refresh").addEventListener("click", function () {
      refreshConfig({ silent: false });
    });
    byId("btn-recovery-backup").addEventListener("click", createRecoveryBackup);
    byId("btn-recovery-diagnostics").addEventListener("click", exportRecoveryDiagnostics);
    byId("diagnostics-disclosure").addEventListener("toggle", handleDiagnosticsDisclosureToggle);
    byId("task-model-config-trigger").addEventListener("click", handleTaskModelConfigTriggerClick);
    byId("task-model-config-trigger").addEventListener("keydown", handleTaskModelConfigKeydown);
    byId("task-model-config-menu").addEventListener("click", handleTaskModelConfigMenuClick);
    byId("task-model-config-menu").addEventListener("keydown", handleTaskModelConfigKeydown);
    bindTaskModelConfigPress(byId("task-model-config-trigger"));
    byId("workflow-task-tabs").addEventListener("click", handleWorkflowTaskTabClick);
    byId("workflow-task-tabs").addEventListener("keydown", handleWorkflowTaskTabKeydown);
    workflowHelpButton.addEventListener("click", function () {
      var pinned = !state.workflowHelpPinned;
      setWorkflowHelpOpen(pinned, pinned);
    });
    workflowHelpButton.addEventListener("mouseenter", function () {
      setWorkflowHelpOpen(true);
    });
    workflowHelpButton.addEventListener("focusin", function () {
      setWorkflowHelpOpen(true);
    });
    workflowHelpButton.addEventListener("mouseleave", function () {
      if (!state.workflowHelpPinned) {
        setWorkflowHelpOpen(false, false);
      }
    });
    workflowHelpButton.addEventListener("focusout", function (event) {
      if (!state.workflowHelpPinned && !workflowHelpButton.contains(event.relatedTarget)) {
        setWorkflowHelpOpen(false, false);
      }
    });
    document.addEventListener("click", function (event) {
      var strip = byId("workflow-profile-strip");
      if (state.taskModelConfigMenu && state.taskModelConfigMenu.open && strip && !strip.contains(event.target)) {
        closeTaskModelConfigMenu(false);
      }
      if (!workflowHelpHeading.contains(event.target) && !workflowHelpPopover.contains(event.target)) {
        setWorkflowHelpOpen(false, false);
      }
      var filterPanel = byId("format-review-filter-panel");
      var filterTrigger = byId("btn-format-review-filter");
      var moreMenu = byId("format-review-more-menu");
      var moreTrigger = byId("btn-format-review-more");
      if (helpers.setFormatReviewAnchoredPanelOpen) {
        if (filterPanel && !filterPanel.hidden && !filterPanel.contains(event.target) && (!filterTrigger || !filterTrigger.contains(event.target))) {
          helpers.setFormatReviewAnchoredPanelOpen(filterPanel, filterTrigger, false);
        }
        if (moreMenu && !moreMenu.hidden && !moreMenu.contains(event.target) && (!moreTrigger || !moreTrigger.contains(event.target))) {
          helpers.setFormatReviewAnchoredPanelOpen(moreMenu, moreTrigger, false);
        }
      }
    });
    document.addEventListener("keydown", function (event) {
      var filterPanel = byId("format-review-filter-panel");
      var moreMenu = byId("format-review-more-menu");
      if (event.key === "Escape" && !workflowHelpPopover.hidden) {
        setWorkflowHelpOpen(false, false);
        workflowHelpButton.focus();
        return;
      }
      if (helpers.handleFormatReviewAnchoredPanelKeydown && filterPanel && !filterPanel.hidden) {
        helpers.handleFormatReviewAnchoredPanelKeydown(event, {
          panel: filterPanel,
          trigger: byId("btn-format-review-filter"),
          activeElement: document.activeElement
        });
        return;
      }
      if (helpers.handleFormatReviewAnchoredPanelKeydown && moreMenu && !moreMenu.hidden) {
        helpers.handleFormatReviewAnchoredPanelKeydown(event, {
          panel: moreMenu,
          trigger: byId("btn-format-review-more"),
          activeElement: document.activeElement
        });
      }
    });
    document.addEventListener("visibilitychange", syncSettingsRefreshController);
    document.addEventListener("visibilitychange", syncScopeWatcher);
    byId("btn-new-workflow-profile").addEventListener("click", function (event) {
      handleWorkflowProfileManagerAction({ target: event.currentTarget });
    });
    byId("workflow-profile-manager").addEventListener("click", handleWorkflowProfileManagerAction);
    byId("workflow-profile-manager").addEventListener("input", markWorkflowProfileEditorDirty);
    byId("workflow-profile-manager").addEventListener("change", handleModelConfigurationEditorChange);
    byId("workflow-editor-view").addEventListener("click", handleWorkflowProfileManagerAction);
    byId("workflow-editor-view").addEventListener("input", markWorkflowProfileEditorDirty);
    byId("workflow-editor-view").addEventListener("change", handleModelConfigurationEditorChange);
    byId("btn-open-writing-policy-manager").addEventListener("click", openWritingPolicyPresetView);
    for (writingPolicyLayerIndex = 0; writingPolicyLayerIndex < writingPolicyLayerButtons.length; writingPolicyLayerIndex += 1) {
      writingPolicyLayerButtons[writingPolicyLayerIndex].addEventListener("click", handleWritingPolicyLayerClick);
    }
    byId("btn-writing-policy-preset-back").addEventListener("click", function () {
      setWritingPolicyView("home");
    });
    byId("writing-policy-preset-pack-select").addEventListener("change", function (event) {
      selectWritingPolicyPresetPack(event.target.value);
    });
    byId("writing-policy-preset-item-list").addEventListener("click", handleWritingPolicyPresetAction);
    byId("btn-writing-policy-preset-previous").addEventListener("click", function () {
      changeWritingPolicyPresetPage(-1);
    });
    byId("btn-writing-policy-preset-next").addEventListener("click", function () {
      changeWritingPolicyPresetPage(1);
    });
    byId("btn-writing-policy-open-organization").addEventListener("click", openWritingPolicyScopeView);
    byId("btn-retry-writing-policy-summary").addEventListener("click", loadWritingPolicySummary);
    byId("btn-writing-policy-scope-back").addEventListener("click", function () {
      setWritingPolicyView("home");
    });
    byId("writing-policy-scope-list").addEventListener("click", handleWritingPolicyScopeClick);
    byId("btn-writing-policy-list-back").addEventListener("click", function () {
      setWritingPolicyView("scope");
    });
    byId("writing-policy-type-switch").addEventListener("click", handleWritingPolicyTypeClick);
    byId("writing-policy-type-switch").addEventListener("keydown", handleWritingPolicyTypeKeydown);
    byId("writing-policy-search-input").addEventListener("input", function (event) {
      scheduleWritingPolicySearch(event.target.value);
    });
    byId("btn-writing-policy-add").addEventListener("click", function () {
      if (!state.writingPolicyListError && !state.writingPolicyMutationBusy) {
        openWritingPolicyEditor(null);
      }
    });
    byId("writing-policy-item-list").addEventListener("click", handleWritingPolicyListClick);
    byId("btn-writing-policy-previous").addEventListener("click", function () {
      changeWritingPolicyPage(-1);
    });
    byId("btn-writing-policy-next").addEventListener("click", function () {
      changeWritingPolicyPage(1);
    });
    byId("btn-retry-writing-policy-list").addEventListener("click", loadWritingPolicyItems);
    byId("btn-writing-policy-editor-back").addEventListener("click", closeWritingPolicyEditor);
    byId("btn-cancel-writing-policy-editor").addEventListener("click", closeWritingPolicyEditor);
    byId("btn-save-writing-policy-item").addEventListener("click", saveWritingPolicyItem);
    byId("btn-writing-policy-delete").addEventListener("click", deleteWritingPolicyItem);
    byId("writing-policy-editor-view").addEventListener("input", function () {
      if (state.writingPolicyEditor) {
        state.writingPolicyEditorDirty = true;
      }
    });
    byId("writing-policy-editor-view").addEventListener("change", function () {
      if (state.writingPolicyEditor) {
        state.writingPolicyEditorDirty = true;
      }
    });
    byId("btn-writing-policy-import-entry").addEventListener("click", openWritingPolicyImport);
    byId("btn-writing-policy-more").addEventListener("click", openWritingPolicyMore);
    byId("btn-writing-policy-more-back").addEventListener("click", closeWritingPolicyMore);
    byId("btn-writing-policy-more-import").addEventListener("click", openWritingPolicyImport);
    byId("btn-writing-policy-import-back").addEventListener("click", closeWritingPolicyImport);
    byId("writing-policy-import-file").addEventListener("change", handleWritingPolicyImportFileChange);
    byId("btn-preview-writing-policy-import").addEventListener("click", previewWritingPolicyImport);
    byId("writing-policy-import-conflict-list").addEventListener("change", handleWritingPolicyConflictDecision);
    byId("btn-apply-writing-policy-import").addEventListener("click", applyWritingPolicyImport);
    byId("btn-writing-policy-download-csv-template").addEventListener("click", function () {
      runWritingPolicyDownload(
        "/writing-policies/import-template.csv",
        "writing-policies-import-template.csv",
        "CSV 导入模板已下载。"
      );
    });
    byId("btn-writing-policy-download-xlsx-template").addEventListener("click", function () {
      runWritingPolicyDownload(
        "/writing-policies/import-template.xlsx",
        "writing-policies-import-template.xlsx",
        "XLSX 导入模板已下载。"
      );
    });
    byId("btn-writing-policy-export-csv").addEventListener("click", function () {
      exportWritingPolicies("csv");
    });
    byId("btn-writing-policy-export-xlsx").addEventListener("click", function () {
      exportWritingPolicies("xlsx");
    });
    byId("btn-writing-policy-download-backup").addEventListener("click", function () {
      runWritingPolicyDownload(
        "/writing-policies/backup",
        "writing-policies-backup.db",
        "写作规范库备份已下载。"
      );
    });
    byId("btn-writing-policy-refresh-diagnostics").addEventListener("click", refreshWritingPolicyDiagnostics);
    byId("btn-apply").addEventListener("click", applyPreview);
    byId("btn-copy-result").addEventListener("click", copyResult);
    byId("btn-run-primary").addEventListener("click", runPrimaryAction);
    byId("result-output").addEventListener("click", handleDocumentReviewAction);
    byId("btn-copy-review-record").addEventListener("click", copyDocumentReviewRecord);
    byId("btn-preview-review-record").addEventListener("click", toggleDocumentReviewRecordPreview);
    byId("btn-result-preview").addEventListener("click", function () {
      setResultViewMode("preview");
    });
    byId("btn-result-compare").addEventListener("click", function () {
      setResultViewMode("compare");
    });
    byId("btn-result-plain").addEventListener("click", function () {
      setResultViewMode("plain");
    });
    var btnViewHistory = byId("btn-view-history");
    if (btnViewHistory) {
      btnViewHistory.addEventListener("click", function () {
        switchWordHistoryView(true);
      });
    }
    var btnHistoryBack = byId("btn-history-back");
    if (btnHistoryBack) {
      btnHistoryBack.addEventListener("click", function () {
        switchWordHistoryView(false);
      });
    }
    var btnClearHistory = byId("btn-clear-history");
    if (btnClearHistory) {
      btnClearHistory.addEventListener("click", handleClearWritingHistory);
    }
    var historyContent = byId("word-history-content");
    if (historyContent) {
      historyContent.addEventListener("click", handleWritingHistoryContentClick);
    }

    bindDirectServiceEvents();
  }

  if (!isTaskpanePage()) {
    window.openTaskpane = function (mode) {
      return switchMode(mode || "smartWrite");
    };
    return;
  }

  bindEvents();
  byId("frontend-version-line").textContent = FRONTEND_BUILD_VERSION;
  byId("technical-review-prompt").value = state.technicalReviewPrompt;
  renderFallbackTemplateOptions();
  renderWritingPolicyManagerView();
  renderWritingPolicySummary();
  renderDirectServicesList();
  renderTaskModelSelectionSection();
  restoreWritingPolicyScene();
  state.settingsRefreshController = helpers.createSettingsRefreshController({
    intervalMs: 30000,
    refresh: function () {
      return refreshConfig({ silent: true });
    }
  });
  state.scopeWatcher = helpers.createWordSelectionWatcher({
    intervalMs: 2000,
    getEventSource: getWordSelectionEventSource,
    refresh: updateScopeIndicator
  });
  switchMode(getInitialMode());
  if (!state.settingsRefreshController.isRunning()) {
    refreshConfig({ silent: false });
  }
  syncScopeWatcher();
})();
