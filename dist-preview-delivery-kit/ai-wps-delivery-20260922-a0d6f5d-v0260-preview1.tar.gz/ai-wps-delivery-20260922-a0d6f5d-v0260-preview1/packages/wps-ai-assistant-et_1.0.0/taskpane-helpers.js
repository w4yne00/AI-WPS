(function (root, factory) {
  var exports = factory();
  root.WpsAiAssistantHelpers = exports;
  if (typeof module === "object" && module.exports) {
    module.exports = exports;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  function normalizeText(text) {
    return String(text || "").replace(/\r/g, "").trim();
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function makeTextHash(value) {
    var text = String(value || "");
    var hash = 2166136261;
    var index;
    for (index = 0; index < text.length; index += 1) {
      hash = Math.imul(hash ^ text.charCodeAt(index), 16777619) >>> 0;
    }
    return ("00000000" + hash.toString(16)).slice(-8);
  }

  function countUnicodeCodePoints(text) {
    return Array.from(String(text == null ? "" : text)).length;
  }

  function validateExcelSmartFillInstruction(value) {
    var text = String(value == null ? "" : value);
    if (countUnicodeCodePoints(text) > 4000) {
      throw new Error("智能填写说明最多 4000 个字符。");
    }
    return text;
  }

  function requireExcelSmartFillInstruction(value) {
    var text = validateExcelSmartFillInstruction(value);
    if (!String(text || "").trim()) {
      throw new Error("请填写需要生成什么。");
    }
    return text;
  }

  function createExcelSmartFillItemId() {
    var randomSource = (typeof globalThis !== "undefined" && globalThis.crypto) ||
      (typeof crypto !== "undefined" ? crypto : null);
    var bytes = [];
    var index;
    var hex = "";
    var buffer;
    if (!randomSource || typeof randomSource.getRandomValues !== "function") {
      throw new Error("当前环境缺少安全随机源，无法生成智能填写项标识。");
    }
    buffer = new Uint8Array(16);
    randomSource.getRandomValues(buffer);
    for (index = 0; index < 16; index += 1) {
      bytes.push(buffer[index]);
    }
    for (index = 0; index < bytes.length; index += 1) {
      hex += ("0" + bytes[index].toString(16)).slice(-2);
    }
    return "sf_" + hex;
  }

  function parseExcelA1Cell(address) {
    var match = String(address || "").replace(/^.*!/, "").match(/\$?([A-Za-z]+)\$?([0-9]+)/);
    var letters;
    var column = 0;
    var index;
    if (!match) {
      return null;
    }
    letters = match[1].toUpperCase();
    for (index = 0; index < letters.length; index += 1) {
      column = column * 26 + (letters.charCodeAt(index) - 64);
    }
    return { row: Number(match[2]), column: column };
  }

  function sanitizeMarkdownUrl(value) {
    var url = String(value || "").trim();
    if (/^(https?:\/\/|mailto:)/i.test(url)) {
      return url;
    }
    return "";
  }

  function renderInlineMarkdown(value) {
    var tokens = [];
    var text = String(value || "");

    function storeToken(html) {
      var token = "\u0000MDTOKEN" + tokens.length + "\u0000";
      tokens.push({ token: token, html: html });
      return token;
    }

    text = text.replace(/`([^`]+)`/g, function (_match, code) {
      return storeToken("<code>" + escapeHtml(code) + "</code>");
    });

    text = text.replace(/(!?)\[([^\]]+)\]\(([^)\s]+)\)/g, function (match, _imagePrefix, label) {
      return storeToken(escapeHtml(label || match));
    });

    text = escapeHtml(text)
      .replace(/==([^=\n]+)==/g, '<mark class="smart-diff-highlight">$1</mark>')
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/\*([^*]+)\*/g, "<em>$1</em>");

    tokens.forEach(function (entry) {
      text = text.split(escapeHtml(entry.token)).join(entry.html);
    });
    return text;
  }

  function renderMarkdown(markdown) {
    var lines = String(markdown || "").replace(/\r/g, "").split("\n");
    var html = [];
    var paragraph = [];
    var listType = "";
    var inCode = false;
    var codeLang = "";
    var codeLines = [];
    var tableRows = [];

    function closeList() {
      if (listType) {
        html.push("</" + listType + ">");
        listType = "";
      }
    }

    function flushParagraph() {
      if (paragraph.length) {
        closeList();
        html.push("<p>" + paragraph.map(renderInlineMarkdown).join("<br>") + "</p>");
        paragraph = [];
      }
    }

    function splitTableRow(line) {
      var value = String(line || "").trim();
      if (value.charAt(0) === "|") {
        value = value.slice(1);
      }
      if (value.charAt(value.length - 1) === "|") {
        value = value.slice(0, -1);
      }
      return value.split("|").map(function (cell) {
        return cell.trim();
      });
    }

    function isTableSeparator(line) {
      var cells = splitTableRow(line);
      return cells.length > 0 && cells.every(function (cell) {
        return /^:?-{3,}:?$/.test(cell);
      });
    }

    function isTableLine(line) {
      return /\|/.test(line || "");
    }

    function flushTable() {
      if (tableRows.length < 2 || !isTableSeparator(tableRows[1])) {
        tableRows.forEach(function (row) {
          paragraph.push(row.trim());
        });
        tableRows = [];
        return;
      }

      flushParagraph();
      closeList();
      var headers = splitTableRow(tableRows[0]);
      var bodyRows = tableRows.slice(2);
      html.push('<div class="markdown-table-wrap">');
      bodyRows.forEach(function (row) {
        var cells = splitTableRow(row);
        html.push('<div class="markdown-table-block">');
        headers.forEach(function (header, index) {
          html.push(
            '<div class="markdown-table-field"><span class="markdown-table-label">' +
            renderInlineMarkdown(header) +
            '</span><span class="markdown-table-value">' +
            renderInlineMarkdown(cells[index] || "") +
            "</span></div>"
          );
        });
        html.push("</div>");
      });
      html.push("</div>");
      tableRows = [];
    }

    function openList(nextType) {
      flushParagraph();
      if (listType !== nextType) {
        closeList();
        html.push("<" + nextType + ">");
        listType = nextType;
      }
    }

    lines.forEach(function (line) {
      var codeFence = line.match(/^```([A-Za-z0-9_-]*)\s*$/);
      var heading = line.match(/^(#{1,6})\s+(.+)$/);
      var unordered = line.match(/^\s*[-*+]\s+(.+)$/);
      var ordered = line.match(/^\s*\d+\.\s+(.+)$/);
      var quote = line.match(/^>\s?(.+)$/);
      var divider = /^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/.test(line);

      if (inCode) {
        if (codeFence) {
          html.push(
            '<pre><code' +
            (codeLang ? ' class="language-' + escapeHtml(codeLang) + '"' : "") +
            ">" +
            escapeHtml(codeLines.join("\n")) +
            "</code></pre>"
          );
          inCode = false;
          codeLang = "";
          codeLines = [];
          return;
        }
        codeLines.push(line);
        return;
      }

      if (tableRows.length && !isTableLine(line)) {
        flushTable();
      }

      if (codeFence) {
        flushTable();
        flushParagraph();
        closeList();
        inCode = true;
        codeLang = codeFence[1] || "";
        codeLines = [];
        return;
      }

      if (!line.trim()) {
        flushTable();
        flushParagraph();
        closeList();
        return;
      }

      if (isTableLine(line)) {
        tableRows.push(line);
        return;
      }

      if (heading) {
        flushTable();
        flushParagraph();
        closeList();
        html.push(
          "<h" + heading[1].length + ">" +
          renderInlineMarkdown(heading[2]) +
          "</h" + heading[1].length + ">"
        );
        return;
      }

      if (divider) {
        flushTable();
        flushParagraph();
        closeList();
        html.push("<hr>");
        return;
      }

      if (unordered) {
        flushTable();
        openList("ul");
        html.push("<li>" + renderInlineMarkdown(unordered[1]) + "</li>");
        return;
      }

      if (ordered) {
        flushTable();
        openList("ol");
        html.push("<li>" + renderInlineMarkdown(ordered[1]) + "</li>");
        return;
      }

      if (quote) {
        flushTable();
        flushParagraph();
        closeList();
        html.push("<blockquote>" + renderInlineMarkdown(quote[1]) + "</blockquote>");
        return;
      }

      paragraph.push(line.trim());
    });

    if (inCode) {
      html.push(
        '<pre><code' +
        (codeLang ? ' class="language-' + escapeHtml(codeLang) + '"' : "") +
        ">" +
        escapeHtml(codeLines.join("\n")) +
        "</code></pre>"
      );
    }
    flushTable();
    flushParagraph();
    closeList();

    return html.join("\n");
  }

  function stripInlineMarkdownForWriteback(value) {
    return String(value || "")
      .replace(/`([^`]+)`/g, "$1")
      .replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1")
      .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
      .replace(/\*\*([^*]+)\*\*/g, "$1")
      .replace(/\*([^*]+)\*/g, "$1")
      .replace(/\*{1,3}/g, "");
  }

  function buildInlineWritebackRuns(value) {
    var runs = [];
    var source = String(value || "");
    var pattern = /\*\*([^*]+)\*\*/g;
    var lastIndex = 0;
    var match;

    while ((match = pattern.exec(source)) !== null) {
      if (match.index > lastIndex) {
        runs.push({
          text: stripInlineMarkdownForWriteback(source.slice(lastIndex, match.index)),
          bold: false
        });
      }
      runs.push({
        text: stripInlineMarkdownForWriteback(match[1]),
        bold: true
      });
      lastIndex = pattern.lastIndex;
    }

    if (lastIndex < source.length) {
      runs.push({
        text: stripInlineMarkdownForWriteback(source.slice(lastIndex)),
        bold: false
      });
    }

    return runs.filter(function (run) {
      return Boolean(run.text);
    });
  }

  function buildMarkdownWritebackBlocks(markdown) {
    var lines = String(markdown || "").replace(/\r/g, "").split("\n");
    var blocks = [];
    var paragraph = [];
    var inCode = false;
    var codeLines = [];

    function pushBlock(type, text, extras) {
      var cleanText = stripInlineMarkdownForWriteback(text);
      var block;
      var key;
      if (!cleanText) {
        return;
      }
      block = {
        type: type,
        text: cleanText,
        runs: buildInlineWritebackRuns(text)
      };
      extras = extras || {};
      for (key in extras) {
        if (Object.prototype.hasOwnProperty.call(extras, key)) {
          block[key] = extras[key];
        }
      }
      blocks.push(block);
    }

    function flushParagraph() {
      if (!paragraph.length) {
        return;
      }
      pushBlock("paragraph", paragraph.join("\n"));
      paragraph = [];
    }

    lines.forEach(function (line) {
      var codeFence = line.match(/^```([A-Za-z0-9_-]*)\s*$/);
      var heading = line.match(/^(#{1,6})\s+(.+)$/);
      var unordered = line.match(/^\s*[-*+]\s+(.+)$/);
      var ordered = line.match(/^\s*(\d+)\.\s+(.+)$/);
      var divider = /^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/.test(line);

      if (inCode) {
        if (codeFence) {
          pushBlock("paragraph", codeLines.join("\n"));
          inCode = false;
          codeLines = [];
          return;
        }
        codeLines.push(line);
        return;
      }

      if (codeFence) {
        flushParagraph();
        inCode = true;
        codeLines = [];
        return;
      }

      if (!line.trim()) {
        flushParagraph();
        return;
      }

      if (divider) {
        flushParagraph();
        return;
      }

      if (heading) {
        flushParagraph();
        pushBlock("heading", heading[2], { level: heading[1].length });
        return;
      }

      if (unordered) {
        flushParagraph();
        pushBlock("unorderedListItem", unordered[1]);
        return;
      }

      if (ordered) {
        flushParagraph();
        pushBlock("orderedListItem", ordered[2], { ordinal: Number(ordered[1]) });
        return;
      }

      paragraph.push(line.trim());
    });

    if (inCode) {
      pushBlock("paragraph", codeLines.join("\n"));
    }
    flushParagraph();
    return blocks;
  }

  function hasStructuredSmartWriteContent(value) {
    var text = String(value || "").replace(/\r/g, "\n");
    var lines = text.split("\n");
    var nonEmpty = lines.filter(function (line) {
      return Boolean(line.trim());
    });

    if (!text.trim()) {
      return false;
    }
    if (/(^|\n)\s{0,3}#{1,6}\s+\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*[-*+•·]\s+\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*\d+[.)．、]\s+\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*[一二三四五六七八九十]+[、.．]\s*\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*[（(][一二三四五六七八九十\d]+[）)]\s*\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*第[一二三四五六七八九十\d]+[章节条]\s*\S/.test(text)) {
      return true;
    }
    if (/\*\*[^*\n]+\*\*/.test(text)) {
      return true;
    }
    if (/\|.+\|/.test(text) && /(^|\n)\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*(\n|$)/.test(text)) {
      return true;
    }
    if (nonEmpty.length >= 2 && nonEmpty.some(function (line) {
      return line.split("\t").length >= 2;
    })) {
      return true;
    }
    return false;
  }

  function shouldUseStructuredSmartWriteResult(originalText, rewrittenText) {
    return hasStructuredSmartWriteContent(originalText) || hasStructuredSmartWriteContent(rewrittenText);
  }

  function getSmartWriteParagraphs(value) {
    return String(value || "")
      .replace(/\r/g, "\n")
      .split(/\n+/)
      .map(function (line) {
        return line.trim();
      })
      .filter(Boolean);
  }

  function normalizeSmartWriteLineBreaks(value) {
    return String(value || "")
      .replace(/\r/g, "\n")
      .replace(/[ \t]+\n/g, "\n")
      .replace(/\n[ \t]+/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function breakInlineSmartWriteStructure(value) {
    var text = normalizeSmartWriteLineBreaks(value);
    var boundary = "([。！？；;!?””）\\)])";
    var patterns = [
      new RegExp(boundary + "\\s*(#{1,6}\\s+\\S)", "g"),
      new RegExp(boundary + "\\s*([一二三四五六七八九十]+[、.．]\\s*\\S)", "g"),
      new RegExp(boundary + "\\s*([（(][一二三四五六七八九十\\d]+[）)]\\s*\\S)", "g"),
      new RegExp(boundary + "\\s*(第[一二三四五六七八九十\\d]+[章节条]\\s*\\S)", "g"),
      new RegExp(boundary + "\\s*(\\d+[.)．、]\\s+\\S)", "g"),
      new RegExp(boundary + "\\s*([-*+•·]\\s+\\S)", "g")
    ];
    patterns.forEach(function (pattern) {
      text = text.replace(pattern, "$1\n\n$2");
    });
    return normalizeSmartWriteLineBreaks(text);
  }

  function splitSmartWriteSentences(value) {
    var text = normalizeSmartWriteLineBreaks(value);
    var matches = text.match(/[^。！？；!?;]+[。！？；!?;]*/g);
    if (!matches || !matches.length) {
      return text ? [text] : [];
    }
    return matches.map(function (sentence) {
      return sentence.trim();
    }).filter(Boolean);
  }

  function distributeSmartWriteSentences(sentences, targetCount) {
    var paragraphs = [];
    var totalLength = 0;
    var consumedLength = 0;
    var sentenceIndex = 0;
    var lengthIndex;

    for (lengthIndex = 0; lengthIndex < sentences.length; lengthIndex += 1) {
      totalLength += sentences[lengthIndex].length;
    }

    for (var paragraphIndex = 0; paragraphIndex < targetCount; paragraphIndex += 1) {
      var remainingParagraphs = targetCount - paragraphIndex;
      var paragraphSentences = [];
      var targetLength = totalLength * (paragraphIndex + 1) / targetCount;

      if (remainingParagraphs === 1) {
        paragraphSentences = sentences.slice(sentenceIndex);
        sentenceIndex = sentences.length;
      } else {
        while (sentenceIndex < sentences.length - (remainingParagraphs - 1)) {
          paragraphSentences.push(sentences[sentenceIndex]);
          consumedLength += sentences[sentenceIndex].length;
          sentenceIndex += 1;
          if (consumedLength >= targetLength) {
            break;
          }
        }
      }

      if (paragraphSentences.length) {
        paragraphs.push(paragraphSentences.join(""));
      }
    }

    return paragraphs.filter(Boolean);
  }

  function formatSmartWriteResult(originalText, rewrittenText) {
    var normalized = normalizeSmartWriteLineBreaks(rewrittenText);
    var originalParagraphs;
    var targetCount;
    var structuredText;
    var sentences;
    var distributed;

    if (!normalized) {
      return "";
    }
    if (getSmartWriteParagraphs(normalized).length >= 2) {
      return normalized;
    }

    structuredText = breakInlineSmartWriteStructure(normalized);
    if (getSmartWriteParagraphs(structuredText).length >= 2) {
      return structuredText;
    }

    originalParagraphs = getSmartWriteParagraphs(originalText);
    if (originalParagraphs.length < 2) {
      return normalized;
    }

    targetCount = Math.min(originalParagraphs.length, 6);
    sentences = splitSmartWriteSentences(normalized);
    if (sentences.length < targetCount) {
      return normalized;
    }

    distributed = distributeSmartWriteSentences(sentences, targetCount);
    return distributed.length >= 2 ? distributed.join("\n\n") : normalized;
  }

  function normalizeSmartWriteComparisonLine(value) {
    return String(value || "").replace(/\s+/g, "").trim();
  }

  function sanitizeSmartWriteHighlightText(value) {
    return String(value || "").replace(/==/g, "＝");
  }

  function getSmartWriteCommonPrefixLength(left, right) {
    var index = 0;
    var maxLength = Math.min(left.length, right.length);
    while (index < maxLength && left.charAt(index) === right.charAt(index)) {
      index += 1;
    }
    return index;
  }

  function getSmartWriteCommonSuffixLength(left, right, prefixLength) {
    var suffixLength = 0;
    var maxLength = Math.min(left.length, right.length) - prefixLength;
    while (
      suffixLength < maxLength &&
      left.charAt(left.length - 1 - suffixLength) === right.charAt(right.length - 1 - suffixLength)
    ) {
      suffixLength += 1;
    }
    return suffixLength;
  }

  function markSmartWriteInsertedSegment(value) {
    return value ? "==" + sanitizeSmartWriteHighlightText(value) + "==" : "";
  }

  function markSmartWriteDiffSegments(originalText, rewrittenText) {
    var original = String(originalText || "");
    var rewritten = String(rewrittenText || "");
    var originalLength = original.length;
    var rewrittenLength = rewritten.length;
    var matrixSize = originalLength * rewrittenLength;
    var dp;
    var i;
    var j;
    var pieces = [];
    var pending = "";

    if (!rewrittenLength) {
      return "";
    }
    if (!originalLength) {
      return markSmartWriteInsertedSegment(rewritten);
    }
    if (matrixSize > 40000) {
      return markSmartWriteInsertedSegment(rewritten);
    }

    dp = new Array(originalLength + 1);
    for (i = 0; i <= originalLength; i += 1) {
      dp[i] = new Array(rewrittenLength + 1).fill(0);
    }

    for (i = originalLength - 1; i >= 0; i -= 1) {
      for (j = rewrittenLength - 1; j >= 0; j -= 1) {
        if (original.charAt(i) === rewritten.charAt(j)) {
          dp[i][j] = dp[i + 1][j + 1] + 1;
        } else {
          dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1]);
        }
      }
    }

    function flushPending() {
      if (pending) {
        pieces.push(markSmartWriteInsertedSegment(pending));
        pending = "";
      }
    }

    i = 0;
    j = 0;
    while (j < rewrittenLength) {
      if (i < originalLength && original.charAt(i) === rewritten.charAt(j)) {
        flushPending();
        pieces.push(rewritten.charAt(j));
        i += 1;
        j += 1;
      } else if (i < originalLength && (j >= rewrittenLength || dp[i + 1][j] >= dp[i][j + 1])) {
        i += 1;
      } else {
        pending += rewritten.charAt(j);
        j += 1;
      }
    }
    flushPending();

    return pieces.join("");
  }

  function markSmartWriteChangedText(originalValue, rewrittenValue) {
    var rewritten = String(rewrittenValue || "");
    var original = String(originalValue || "");
    var edgeMatch = rewritten.match(/^(\s*)([\s\S]*?)(\s*)$/);
    var leading = edgeMatch ? edgeMatch[1] : "";
    var body = edgeMatch ? edgeMatch[2] : rewritten;
    var trailing = edgeMatch ? edgeMatch[3] : "";
    var originalBody = original.trim();
    var prefixLength;
    var suffixLength;
    var changedStart;
    var changedEnd;
    var changedText;
    var originalChangedText;

    if (!body || normalizeSmartWriteComparisonLine(original) === normalizeSmartWriteComparisonLine(rewritten)) {
      return rewritten;
    }

    prefixLength = getSmartWriteCommonPrefixLength(originalBody, body);
    suffixLength = getSmartWriteCommonSuffixLength(originalBody, body, prefixLength);
    changedStart = prefixLength;
    changedEnd = body.length - suffixLength;
    changedText = body.slice(changedStart, changedEnd);
    originalChangedText = originalBody.slice(prefixLength, originalBody.length - suffixLength);

    if (!changedText) {
      return rewritten;
    }

    return leading +
      body.slice(0, changedStart) +
      markSmartWriteDiffSegments(originalChangedText, changedText) +
      body.slice(changedEnd) +
      trailing;
  }

  function getSmartWriteComparableLineText(line) {
    var text = String(line || "");
    var match = text.match(/^(\s*#{1,6}\s+)(.+)$/) ||
      text.match(/^(\s*[-*+]\s+)(.+)$/) ||
      text.match(/^(\s*\d+\.\s+)(.+)$/) ||
      text.match(/^(>\s?)(.+)$/);
    return match ? match[2] : text;
  }

  function markSmartWriteTableLine(originalLine, line) {
    var originalCells = String(originalLine || "").split("|");
    return String(line || "").split("|").map(function (cell, index) {
      var trimmed = cell.trim();
      if (!trimmed || /^:?-{3,}:?$/.test(trimmed)) {
        return cell;
      }
      return markSmartWriteChangedText(originalCells[index] || "", cell);
    }).join("|");
  }

  function markSmartWriteComparisonLine(originalLine, line) {
    var text = String(line || "");
    var originalText = String(originalLine || "");
    var tableSeparator = /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(text);
    var match;
    if (!text.trim()) {
      return text;
    }
    if (tableSeparator) {
      return text;
    }
    if (text.indexOf("|") >= 0) {
      return markSmartWriteTableLine(originalText, text);
    }
    match = text.match(/^(\s*#{1,6}\s+)(.+)$/);
    if (match) {
      return match[1] + markSmartWriteChangedText(getSmartWriteComparableLineText(originalText), match[2]);
    }
    match = text.match(/^(\s*[-*+]\s+)(.+)$/);
    if (match) {
      return match[1] + markSmartWriteChangedText(getSmartWriteComparableLineText(originalText), match[2]);
    }
    match = text.match(/^(\s*\d+\.\s+)(.+)$/);
    if (match) {
      return match[1] + markSmartWriteChangedText(getSmartWriteComparableLineText(originalText), match[2]);
    }
    match = text.match(/^(>\s?)(.+)$/);
    if (match) {
      return match[1] + markSmartWriteChangedText(getSmartWriteComparableLineText(originalText), match[2]);
    }
    return markSmartWriteChangedText(originalText, text);
  }

  function buildHighlightedSmartWriteResult(originalText, rewrittenText) {
    var originalLines = normalizeSmartWriteLineBreaks(originalText)
      .split("\n")
      .map(function (line) {
        return line.trim();
      })
      .filter(Boolean);
    var rewrittenLines = normalizeSmartWriteLineBreaks(rewrittenText).split("\n");
    var originalIndex = 0;
    return rewrittenLines.map(function (line) {
      var cleanLine = line.trim();
      var originalLine;
      var changed;
      if (!cleanLine) {
        return line;
      }
      originalLine = originalLines[originalIndex] || "";
      changed = normalizeSmartWriteComparisonLine(cleanLine) !== normalizeSmartWriteComparisonLine(originalLine);
      originalIndex += 1;
      return changed ? markSmartWriteComparisonLine(originalLine, line) : line;
    }).join("\n");
  }

  function buildSmartWritePreviewModel(result) {
    var source = result || {};
    var originalText = normalizeSmartWriteLineBreaks(source.originalText || "");
    var rewrittenText = formatSmartWriteResult(originalText, source.rewrittenText || "");
    var hasOriginal = Boolean(originalText);
    var highlightedText = hasOriginal ? buildHighlightedSmartWriteResult(originalText, rewrittenText) : rewrittenText;
    var comparisonMarkdown = "";

    if (hasOriginal && rewrittenText) {
      comparisonMarkdown = [
        "### 原文",
        "",
        originalText,
        "",
        "### 智能编写结果",
        "",
        highlightedText
      ].join("\n");
    } else {
      comparisonMarkdown = rewrittenText;
    }

    return {
      previewMarkdown: rewrittenText,
      plainText: rewrittenText,
      comparisonMarkdown: comparisonMarkdown,
      hasOriginal: hasOriginal,
      hasStructuredResult: shouldUseStructuredSmartWriteResult(originalText, rewrittenText)
    };
  }

  var FORMAT_REVIEW_GROUP_ORDER = [
    "page_setup",
    "heading",
    "body_text",
    "paragraph",
    "caption_note",
    "other"
  ];
  var FORMAT_REVIEW_GROUP_TEXT = {
    page_setup: "页面设置",
    heading: "标题层级",
    body_text: "正文格式",
    paragraph: "段落格式",
    caption_note: "图表题/注释",
    other: "其他格式项"
  };
  var FORMAT_REVIEW_ROLE_TEXT = {
    document_title: "文档标题",
    heading1: "一级标题",
    heading2: "二级标题",
    heading3: "三级标题",
    heading4: "四级标题",
    caption: "图表题",
    note: "无编号注",
    numbered_note: "有编号注",
    list1_numbered: "一级编号列项",
    list1_plain: "一级无编号列项",
    list2_numbered: "二级编号列项",
    list2_plain: "二级无编号列项",
    appendix_title: "附录标题",
    appendix_heading1: "附录一级标题",
    appendix_heading2: "附录二级标题",
    appendix_heading3: "附录三级标题",
    table_body: "表正文",
    body: "正文",
    page_setup: "页面设置"
  };
  var FORMAT_REVIEW_RULE_TEXT = {
    page_setup: "页面设置",
    style_name: "段落样式",
    font_name: "字体",
    font_size: "字号",
    line_spacing: "行距",
    alignment: "对齐方式",
    first_line_indent: "首行缩进"
  };
  var FORMAT_REVIEW_TEMPLATE_TEXT = {
    "technical-document-template-rules": "技术文档模板规则"
  };
  var FORMAT_REVIEW_STYLE_TEXT = {
    Normal: "正文样式（Normal）",
    Body: "正文样式（Body）",
    body: "正文样式",
    "heading 1": "一级标题样式（heading 1）",
    "heading 2": "二级标题样式（heading 2）",
    "heading 3": "三级标题样式（heading 3）",
    "heading 4": "四级标题样式（heading 4）",
    Caption: "图表题样式（Caption）",
    caption: "图表题样式（caption）"
  };
  var FORMAT_REVIEW_ALIGNMENT_TEXT = {
    left: "左对齐",
    center: "居中",
    right: "右对齐",
    justify: "两端对齐",
    justified: "两端对齐",
    distribute: "分散对齐",
    distributed: "分散对齐",
    "0": "左对齐",
    "1": "居中",
    "2": "右对齐",
    "3": "两端对齐",
    "4": "分散对齐"
  };
  var FORMAT_REVIEW_FONT_TEXT = {
    simsun: "宋体",
    "songti sc": "宋体",
    "songti": "宋体",
    "宋体": "宋体",
    simhei: "黑体",
    "黑体": "黑体",
    kaiti: "楷体",
    "楷体": "楷体",
    fangsong: "仿宋",
    "仿宋": "仿宋"
  };
  var FORMAT_REVIEW_SIZE_TEXT = {
    "22": "二号",
    "18": "小二",
    "16": "三号",
    "15": "小三",
    "14": "四号",
    "12": "小四",
    "10.5": "五号",
    "9": "小五"
  };

  function formatReviewGroupItems(items, getKey) {
    var grouped = {};
    (items || []).forEach(function (item) {
      var key = getKey(item) || "other";
      if (!grouped[key]) {
        grouped[key] = [];
      }
      grouped[key].push(item);
    });
    return grouped;
  }

  function getFormatReviewGroup(issue) {
    var ruleId = String((issue && issue.ruleId) || "");
    var role = String((issue && issue.role) || "");
    if (ruleId === "page_setup") {
      return "page_setup";
    }
    if (role.indexOf("heading") >= 0 || role.indexOf("title") >= 0) {
      return "heading";
    }
    if (ruleId === "style_name" || ruleId === "font_name" || ruleId === "font_size") {
      return "body_text";
    }
    if (ruleId === "line_spacing" || ruleId === "alignment" || ruleId === "first_line_indent") {
      return "paragraph";
    }
    if (role.indexOf("caption") >= 0 || role.indexOf("note") >= 0 || ruleId.indexOf("caption") >= 0 || ruleId.indexOf("note") >= 0) {
      return "caption_note";
    }
    return "other";
  }

  function formatAiFallbackReason(reason) {
    var reasonText = {
      no_paragraphs: "未读取到正文段落，未调用模型后台；请确认当前文档对象能暴露正文段落或全文文本。",
      provider_not_configured: "统一 API URL 或格式审查任务 API Key 未形成可用配置，已使用本地模板规则。",
      dify_response_not_role_json: "模型后台未返回段落角色 JSON，已使用本地模板规则。",
      provider_request_failed: "模型后台请求失败，已使用本地模板规则。",
      dify_response_no_valid_roles: "模型后台返回的角色无效，已使用本地模板规则。",
      dify_returned_no_roles: "模型后台未返回有效段落角色，已使用本地模板规则。",
      ai_budget_limited: "文档段落较多，AI 角色识别仅处理前 40 段；其余段落已使用本地模板规则。"
    };
    return reasonText[reason] || (reason ? "未记录的 AI 兜底原因，已使用本地模板规则。" : "");
  }

  function formatReviewRole(role) {
    return FORMAT_REVIEW_ROLE_TEXT[String(role || "")] || "未识别角色";
  }

  function formatReviewRule(ruleId) {
    return FORMAT_REVIEW_RULE_TEXT[String(ruleId || "")] || "其他格式项";
  }

  function formatReviewTemplate(templateId) {
    return FORMAT_REVIEW_TEMPLATE_TEXT[String(templateId || "")] || "当前格式模板";
  }

  function parseFormatReviewNumber(value) {
    var match = String(value || "").match(/-?\d+(?:\.\d+)?/);
    return match ? Number(match[0]) : null;
  }

  function formatReviewFontName(value) {
    var raw = String(value || "").trim();
    var normalized = raw.toLowerCase();
    return FORMAT_REVIEW_FONT_TEXT[normalized] || FORMAT_REVIEW_FONT_TEXT[raw] || raw || "未读取";
  }

  function formatReviewFontSize(value) {
    var numeric = parseFormatReviewNumber(value);
    var key;
    var label;
    if (numeric === null || isNaN(numeric)) {
      return String(value || "").trim() || "未读取";
    }
    key = String(Math.round(numeric * 10) / 10).replace(/\.0$/, "");
    label = FORMAT_REVIEW_SIZE_TEXT[key];
    return label ? label + "（" + key + "pt）" : key + "pt";
  }

  function formatReviewStyleName(value) {
    var raw = String(value || "").trim();
    return FORMAT_REVIEW_STYLE_TEXT[raw] || raw || "未读取";
  }

  function formatReviewAlignment(value) {
    var raw = String(value || "").trim();
    var key = raw.toLowerCase();
    return FORMAT_REVIEW_ALIGNMENT_TEXT[key] || FORMAT_REVIEW_ALIGNMENT_TEXT[raw] || raw || "未读取";
  }

  function formatReviewLineSpacing(value) {
    var numeric = parseFormatReviewNumber(value);
    if (numeric === null || isNaN(numeric)) {
      return String(value || "").trim() || "未读取";
    }
    if (Math.abs(numeric - 1) < 0.01) {
      return "单倍行距（1倍）";
    }
    if (Math.abs(numeric - 1.5) < 0.01) {
      return "1.5 倍行距";
    }
    return numeric + " 倍行距";
  }

  function formatReviewIndent(value) {
    var numeric = parseFormatReviewNumber(value);
    if (numeric === null || isNaN(numeric)) {
      return String(value || "").trim() || "未读取";
    }
    if (Math.abs(numeric) < 0.01) {
      return "无首行缩进";
    }
    if (Math.abs(numeric - 480) <= 20 || Math.abs(numeric - 640) <= 20) {
      return "首行缩进 2 字符（约 " + numeric + " twips）";
    }
    return "首行缩进约 " + numeric + " twips";
  }

  function formatReviewPageSetup(value) {
    var raw = String(value || "").trim();
    if (!raw || raw === "{}") {
      return "未读取";
    }
    if (raw.charAt(0) !== "{") {
      return raw;
    }
    try {
      var data = JSON.parse(raw);
      var parts = [];
      if (data.paperSize || data.PaperSize) {
        parts.push("纸张：" + (data.paperSize || data.PaperSize));
      }
      if (data.marginTop || data.marginBottom || data.marginLeft || data.marginRight) {
        parts.push(
          "页边距：上 " + (data.marginTop || "未读") +
          "、下 " + (data.marginBottom || "未读") +
          "、左 " + (data.marginLeft || "未读") +
          "、右 " + (data.marginRight || "未读")
        );
      }
      return parts.length ? parts.join("；") : raw;
    } catch (error) {
      return raw;
    }
  }

  function formatReviewValue(ruleId, value, isExpected) {
    var rule = String(ruleId || "");
    if (rule === "font_name") {
      return isExpected ? "宋体" : formatReviewFontName(value);
    }
    if (rule === "font_size") {
      return isExpected ? "小四（12pt）" : formatReviewFontSize(value);
    }
    if (rule === "style_name") {
      return formatReviewStyleName(value);
    }
    if (rule === "alignment") {
      return formatReviewAlignment(value);
    }
    if (rule === "line_spacing") {
      return formatReviewLineSpacing(value);
    }
    if (rule === "first_line_indent") {
      return formatReviewIndent(value);
    }
    if (rule === "page_setup") {
      return isExpected ? "A4 页面及模板页边距" : formatReviewPageSetup(value);
    }
    return String(value || "").trim() || (isExpected ? "按模板要求" : "未读取");
  }

  function normalizeFormatReviewSuggestion(issue) {
    var rule = String((issue && issue.ruleId) || "");
    var suggestion = String((issue && issue.suggestion) || "").trim();
    if (rule === "font_size") {
      return "字号调整为小四。";
    }
    if (rule === "font_name") {
      return "字体调整为宋体。";
    }
    if (rule === "alignment") {
      var expected = formatReviewAlignment(issue && issue.expectedValue);
      return "对齐方式调整为" + expected + "。";
    }
    if (rule === "style_name") {
      return "按" + formatReviewRole(issue && issue.role) + "套用模板样式。";
    }
    if (rule === "line_spacing") {
      var lineSpacing = parseFormatReviewNumber(issue && issue.expectedValue);
      if (lineSpacing !== null && !isNaN(lineSpacing)) {
        if (Math.abs(lineSpacing - 1) < 0.01) {
          return "行距调整为单倍行距。";
        }
        return "行距调整为 " + lineSpacing + " 倍。";
      }
      return "按模板要求调整行距。";
    }
    if (rule === "first_line_indent") {
      return "按模板要求调整首行缩进。";
    }
    if (rule === "page_setup") {
      return suggestion.replace(/^建议/, "") || "按模板设置页面和页边距。";
    }
    return suggestion || "按模板要求调整。";
  }

  function formatReviewParagraphLabel(issue) {
    if (!issue || issue.ruleId === "page_setup" || issue.paragraphIndex === 0) {
      return "页面";
    }
    return "P" + (issue.paragraphIndex || 0);
  }

  function formatReviewIssueTitle(issue) {
    return formatReviewParagraphLabel(issue) + " " +
      formatReviewRole(issue.role) + " - " +
      (issue.message || (formatReviewRule(issue.ruleId) + "不符合模板要求。")).replace(/。$/, "");
  }

  function describeFormatReviewProvider(value) {
    var provider = String(value || "local");
    if (provider === "local") {
      return "本地规则";
    }
    if (provider === "mock") {
      return "模拟服务";
    }
    if (provider.indexOf("enterprise-dify-chat") === 0) {
      return "AI 辅助 + 本地规则";
    }
    return "外部服务";
  }

  function summarizeFormatReviewDistribution(grouped) {
    var parts = [];
    FORMAT_REVIEW_GROUP_ORDER.forEach(function (group) {
      var count = grouped[group] ? grouped[group].length : 0;
      if (count) {
        parts.push(FORMAT_REVIEW_GROUP_TEXT[group] + " " + count);
      }
    });
    return parts.length ? parts.join("、") : "无";
  }

  function renderReadableFormatReview(data) {
    var summary = data && data.summary ? data.summary : {};
    var issues = data && data.issues ? data.issues : [];
    var grouped = formatReviewGroupItems(issues, getFormatReviewGroup);
    var lines = [
      "格式审查结果",
      "",
      "## 审查概览",
      "",
      "- 检查范围：" + (summary.scope === "selection" ? "选中内容" : "全文"),
      "- 问题总数：" + (summary.issueCount || issues.length || 0),
      "- 扫描段落：" + (typeof summary.paragraphCount !== "undefined" ? summary.paragraphCount : "未统计"),
      "- 问题分布：" + summarizeFormatReviewDistribution(grouped),
      "- 识别来源：" + describeFormatReviewProvider(summary.provider),
      "",
      "以下仅显示需要调整的格式项，正文内容不会在检查中改写。",
      ""
    ];

    if (!issues.length) {
      lines.push("当前范围未发现明显格式问题。");
      lines.push("");
      lines.push("## 诊断信息");
      lines.push("");
      lines.push("- 模板：" + formatReviewTemplate(summary.templateId));
      lines.push("- 识别来源：" + describeFormatReviewProvider(summary.provider));
      return lines.join("\n").trim();
    }

    lines.push("## 优先处理清单");
    lines.push("");
    lines.push("| 段落 | 问题类型 | 当前值 | 模板要求 | 建议 |");
    lines.push("| --- | --- | --- | --- | --- |");
    issues.slice(0, 12).forEach(function (issue) {
      lines.push(
        "| " + formatReviewParagraphLabel(issue) +
        " | " + formatReviewRule(issue.ruleId) +
        " | " + formatReviewValue(issue.ruleId, issue.currentValue, false) +
        " | " + formatReviewValue(issue.ruleId, issue.expectedValue, true) +
        " | " + normalizeFormatReviewSuggestion(issue) +
        " |"
      );
    });
    if (issues.length > 12) {
      lines.push("");
      lines.push("优先处理清单仅展示前 12 项；完整问题见下方详细分组。");
    }
    lines.push("");
    lines.push("## 详细问题");
    lines.push("");
    FORMAT_REVIEW_GROUP_ORDER.forEach(function (group) {
      var groupIssues = grouped[group] || [];
      if (!groupIssues.length) {
        return;
      }
      lines.push("### " + FORMAT_REVIEW_GROUP_TEXT[group] + "（" + groupIssues.length + "）");
      lines.push("");
      groupIssues.forEach(function (issue) {
        lines.push("#### " + formatReviewIssueTitle(issue));
        lines.push("- 现状：" + formatReviewValue(issue.ruleId, issue.currentValue, false));
        lines.push("- 要求：" + formatReviewValue(issue.ruleId, issue.expectedValue, true));
        lines.push("- 建议：" + normalizeFormatReviewSuggestion(issue));
        lines.push("");
      });
    });

    lines.push("## 诊断信息");
    lines.push("");
    lines.push("- 模板：" + formatReviewTemplate(summary.templateId));
    lines.push("- 识别来源：" + describeFormatReviewProvider(summary.provider));
    if (typeof summary.aiClassifiedParagraphCount !== "undefined") {
      lines.push(
        "- AI 识别段落：" + (summary.aiClassifiedParagraphCount || 0) +
        "；本地兜底段落：" + (summary.localFallbackParagraphCount || 0)
      );
    }
    if (summary.aiInvalidRoleCount || summary.aiOutOfBatchCount) {
      lines.push(
        "- AI 无效角色：" + (summary.aiInvalidRoleCount || 0) +
        "；越界段落：" + (summary.aiOutOfBatchCount || 0)
      );
    }
    var aiFallbackText = formatAiFallbackReason(summary.aiFallbackReason);
    if (aiFallbackText) {
      lines.push("- AI 兜底原因：" + aiFallbackText);
    }
    return lines.join("\n").trim();
  }

  var DOCUMENT_REVIEW_CATEGORY_TEXT = {
    typo: "错别字",
    expression: "语言表达",
    logic: "逻辑表达",
    fluency: "通畅性",
    professional: "专业性"
  };
  var DOCUMENT_REVIEW_STATUS_TEXT = {
    pending: "待处理",
    done: "已处理",
    ignored: "已忽略"
  };

  function buildDocumentReviewRecord(data, statusByIndex) {
    var source = data || {};
    var issues = source.issues || [];
    var statuses = statusByIndex || {};
    var counts = {
      pending: 0,
      done: 0,
      ignored: 0
    };
    var lines = [
      "文档审查处理记录",
      "",
      "## 处理概览",
      "",
      "- 审查摘要：" + (source.summary || "未提供"),
      "- 问题总数：" + issues.length
    ];

    issues.forEach(function (_, index) {
      var status = statuses[String(index)] || "pending";
      if (!Object.prototype.hasOwnProperty.call(counts, status)) {
        status = "pending";
      }
      counts[status] += 1;
    });

    lines.push("- 待处理：" + counts.pending);
    lines.push("- 已处理：" + counts.done);
    lines.push("- 已忽略：" + counts.ignored);
    lines.push("");

    if (!issues.length) {
      lines.push("未发现需要处理的问题。");
      return lines.join("\n").trim();
    }

    lines.push("## 问题清单");
    lines.push("");
    issues.forEach(function (issue, index) {
      var status = statuses[String(index)] || "pending";
      if (!DOCUMENT_REVIEW_STATUS_TEXT[status]) {
        status = "pending";
      }
      lines.push(
        "### " + (index + 1) + ". " +
        (DOCUMENT_REVIEW_CATEGORY_TEXT[issue.category] || "其他问题") +
        "（" + DOCUMENT_REVIEW_STATUS_TEXT[status] + "）"
      );
      lines.push("- 位置：" + (issue.location || "未标注"));
      lines.push("- 原文：" + (issue.originalText || issue.original_text || "未提供"));
      lines.push("- 问题：" + (issue.problem || "未提供"));
      lines.push("- 建议：" + (issue.suggestion || "未提供"));
      if (issue.suggestedRewrite || issue.suggested_rewrite) {
        lines.push("- 建议改写：" + (issue.suggestedRewrite || issue.suggested_rewrite));
      }
      lines.push("");
    });

    return lines.join("\n").trim();
  }

  function getEffectiveSelectionText(selectionOrSources) {
    if (!selectionOrSources) {
      return "";
    }
    if (Array.isArray(selectionOrSources)) {
      for (var i = 0; i < selectionOrSources.length; i += 1) {
        var value = getEffectiveSelectionText(selectionOrSources[i]);
        if (value) {
          return value;
        }
      }
      return "";
    }
    return normalizeText(
      selectionOrSources.Text ||
      (selectionOrSources.Range && selectionOrSources.Range.Text) ||
      (selectionOrSources.TextRange && selectionOrSources.TextRange.Text) ||
      ""
    );
  }

  function getWritableSelection(sources) {
    for (var i = 0; i < sources.length; i += 1) {
      var selection = sources[i];
      if (!selection) {
        continue;
      }
      if (typeof selection.Text !== "undefined") {
        return selection;
      }
      if (selection.Range && typeof selection.Range.Text !== "undefined") {
        return selection;
      }
    }
    return null;
  }

  function resolveRewriteScope(options) {
    var selectionText = normalizeText(options.selectionText);
    if (options.requireSelection && !selectionText) {
      return {
        ok: false,
        selectionMode: "selection",
        scopeLabel: "当前范围：全文",
        message: "请先用鼠标选中一段文字，再执行改写或续写。"
      };
    }

    if (selectionText) {
      return {
        ok: true,
        selectionMode: "selection",
        scopeLabel: "当前范围：选中文本",
        selectedText: selectionText
      };
    }

    return {
      ok: true,
      selectionMode: "document",
      scopeLabel: "当前范围：全文"
    };
  }

  function canApplyRewriteToSelection(originalText, currentSelectionText) {
    if (!normalizeText(currentSelectionText)) {
      return {
        ok: false,
        message: "当前未检测到有效选区，无法安全写回改写结果。"
      };
    }

    if (normalizeText(originalText) !== normalizeText(currentSelectionText)) {
      return {
        ok: false,
        message: "选区已变化，请重新选中原文后再应用改写结果。"
      };
    }

    return { ok: true };
  }

  function resolveScalarValue(value, depth) {
    var resolved = typeof value === "function" ? safeCall(value, null) : value;
    var keys;
    var index;
    var nested;
    var primitive;
    depth = depth || 0;
    if (typeof resolved === "undefined" || resolved === null) {
      return resolved;
    }
    if (typeof resolved === "string" || typeof resolved === "number" || typeof resolved === "boolean") {
      return resolved;
    }
    if (depth >= 3 || Array.isArray(resolved) || typeof resolved !== "object") {
      return undefined;
    }
    keys = ["value", "Value", "text", "Text"];
    for (index = 0; index < keys.length; index += 1) {
      nested = safeRead(resolved, keys[index]);
      if (typeof nested !== "undefined" && nested !== null) {
        return resolveScalarValue(nested, depth + 1);
      }
    }
    if (typeof resolved.valueOf === "function" && resolved.valueOf !== Object.prototype.valueOf) {
      primitive = safeCall(resolved.valueOf, resolved);
      if (primitive !== resolved) {
        return resolveScalarValue(primitive, depth + 1);
      }
    }
    if (typeof resolved.toString === "function" && resolved.toString !== Object.prototype.toString) {
      primitive = safeCall(resolved.toString, resolved);
      if (primitive && primitive !== "[object Object]") {
        return primitive;
      }
    }
    return undefined;
  }

  function normalizeNumber(value) {
    var resolved = resolveScalarValue(value);
    if (resolved === null || typeof resolved === "undefined" || resolved === "") {
      return null;
    }
    var numeric = Number(resolved);
    return isNaN(numeric) ? null : numeric;
  }

  function normalizeFontSize(value) {
    var numeric = normalizeNumber(value);
    return numeric && numeric > 0 ? numeric : null;
  }

  function normalizeAlignmentValue(value, fallback) {
    var resolved = resolveScalarValue(value);
    var text;
    var map = {
      "0": "left",
      "1": "center",
      "2": "right",
      "3": "justify",
      "4": "distribute",
      left: "left",
      center: "center",
      centered: "center",
      centre: "center",
      right: "right",
      justify: "justify",
      justified: "justify",
      distributed: "distribute",
      distribute: "distribute",
      "左对齐": "left",
      "居中": "center",
      "居中对齐": "center",
      "右对齐": "right",
      "两端对齐": "justify",
      "分散对齐": "distribute",
      wdalignparagraphleft: "left",
      wdalignparagraphcenter: "center",
      wdalignparagraphright: "right",
      wdalignparagraphjustify: "justify",
      wdalignparagraphdistribute: "distribute"
    };
    if (typeof resolved === "undefined" || resolved === null || resolved === "") {
      return fallback || "";
    }
    text = String(resolved).trim();
    return map[text.toLowerCase()] || map[text] || text;
  }

  function firstDefined() {
    for (var i = 0; i < arguments.length; i += 1) {
      if (typeof arguments[i] !== "undefined" && arguments[i] !== null) {
        return arguments[i];
      }
    }
    return null;
  }

  function normalizePositiveInteger(value) {
    var numeric = Number(value);
    if (isNaN(numeric) || numeric <= 0) {
      return null;
    }
    return Math.floor(numeric);
  }

  function normalizeCollectOptions(options) {
    var source = typeof options === "number" ? { maxParagraphs: options } : (options || {});
    return {
      maxParagraphs: normalizePositiveInteger(source.maxParagraphs),
      maxParagraphTextLength: normalizePositiveInteger(source.maxParagraphTextLength),
      avoidFallbackTextRead: Boolean(source.avoidFallbackTextRead)
    };
  }

  function limitTextLength(value, maxLength) {
    var text = String(value || "");
    if (maxLength && text.length > maxLength) {
      return text.slice(0, maxLength);
    }
    return text;
  }

  function safeRead(object, key) {
    if (!object) {
      return undefined;
    }
    try {
      return object[key];
    } catch (error) {
      return undefined;
    }
  }

  function safeCall(fn, thisArg) {
    if (typeof fn !== "function") {
      return undefined;
    }
    try {
      return fn.call(thisArg);
    } catch (error) {
      return undefined;
    }
  }

  function resolveRange(object) {
    var range = firstDefined(safeRead(object, "Range"), safeRead(object, "range"));
    return typeof range === "function" ? safeCall(range, object) : range;
  }

  function normalizeParagraphText(text) {
    return String(text || "")
      .replace(/\u0007/g, "")
      .replace(/\r/g, "\n")
      .replace(/\n+$/g, "");
  }

  function toSafeString(value, fallback) {
    var resolved = resolveScalarValue(value);
    if (typeof resolved === "undefined" || resolved === null) {
      return fallback || "";
    }
    if (typeof resolved === "string") {
      return resolved;
    }
    if (typeof resolved === "number" || typeof resolved === "boolean") {
      return String(resolved);
    }
    return fallback || "";
  }

  function normalizeInteger(value) {
    var numeric = normalizeNumber(typeof value === "function" ? safeCall(value, null) : value);
    if (numeric === null) {
      return null;
    }
    return Math.round(numeric);
  }

  function readText(object) {
    var range = resolveRange(object);
    return normalizeParagraphText(toSafeString(firstDefined(
      safeRead(object, "Text"),
      safeRead(object, "text"),
      safeRead(range, "Text"),
      safeRead(range, "text"),
      safeRead(safeRead(object, "TextRange"), "Text"),
      safeRead(safeRead(range, "TextRange"), "Text")
    )));
  }

  function readDocumentText(document) {
    var content = safeRead(document, "Content") || safeRead(document, "content");
    var range = resolveRange(document);
    return normalizeParagraphText(toSafeString(firstDefined(
      safeRead(document, "Text"),
      safeRead(document, "text"),
      safeRead(content, "Text"),
      safeRead(content, "text"),
      safeRead(range, "Text"),
      safeRead(range, "text")
    )));
  }

  function readStyleName(paragraph) {
    var range = resolveRange(paragraph);
    var style = firstDefined(
      safeRead(paragraph, "Style"),
      safeRead(paragraph, "style"),
      safeRead(range, "Style"),
      safeRead(range, "style")
    );
    if (typeof style === "string") {
      return style;
    }
    return toSafeString(firstDefined(
      safeRead(paragraph, "StyleNameLocal"),
      safeRead(paragraph, "styleName"),
      safeRead(paragraph, "StyleName"),
      safeRead(range, "StyleNameLocal"),
      safeRead(range, "StyleName"),
      safeRead(style, "NameLocal"),
      safeRead(style, "Name"),
      "Body"
    ), "Body");
  }

  function readFont(paragraph) {
    var range = resolveRange(paragraph);
    return firstDefined(
      safeRead(paragraph, "Font"),
      safeRead(range, "Font"),
      {}
    );
  }

  function readParagraphFormat(paragraph) {
    var range = resolveRange(paragraph);
    return firstDefined(
      safeRead(paragraph, "ParagraphFormat"),
      safeRead(range, "ParagraphFormat"),
      {}
    );
  }

  function readCollectionCount(collection) {
    if (!collection) {
      return 0;
    }
    var count = typeof collection.length === "number" ? collection.length : null;
    if (count === null) {
      count = typeof collection.Count === "function" ? safeCall(collection.Count, collection) : safeRead(collection, "Count");
    }
    if (typeof count === "undefined" || count === null) {
      count = typeof collection.count === "function" ? safeCall(collection.count, collection) : safeRead(collection, "count");
    }
    count = Number(count);
    return isNaN(count) || count < 0 ? 0 : count;
  }

  function getCollectionItem(collection, oneBasedIndex) {
    if (!collection || oneBasedIndex < 1) {
      return null;
    }
    var zeroBasedIndex = oneBasedIndex - 1;
    if (typeof collection.length === "number" && collection[zeroBasedIndex]) {
      return collection[zeroBasedIndex];
    }
    if (typeof collection.Item === "function") {
      return safeCall(function () { return collection.Item(oneBasedIndex); }, collection);
    }
    if (typeof collection.item === "function") {
      return safeCall(function () { return collection.item(oneBasedIndex); }, collection);
    }
    return collection[oneBasedIndex] || collection[zeroBasedIndex] || null;
  }

  function getParagraphCollection(document) {
    var content = safeRead(document, "Content") || safeRead(document, "content");
    var range = resolveRange(document);
    return firstDefined(
      safeRead(document, "Paragraphs"),
      safeRead(document, "paragraphs"),
      safeRead(content, "Paragraphs"),
      safeRead(content, "paragraphs"),
      safeRead(range, "Paragraphs"),
      safeRead(range, "paragraphs"),
      []
    );
  }

  function collectParagraphsFromText(text, options) {
    var collectOptions = normalizeCollectOptions(options);
    var normalized = String(text || "").replace(/\r/g, "\n");
    if (!normalized.trim()) {
      return [];
    }
    var lines = normalized.split(/\n+/).map(function (line) {
      return line.trim();
    }).filter(Boolean);
    if (collectOptions.maxParagraphs) {
      lines = lines.slice(0, collectOptions.maxParagraphs);
    }
    return lines.map(function (line, index) {
      return {
        index: index + 1,
        text: limitTextLength(line, collectOptions.maxParagraphTextLength),
        styleName: "Normal",
        fontName: "",
        fontSize: null,
        bold: false,
        italic: false,
        underline: null,
        alignment: "",
        outlineLevel: 0,
        lineSpacing: null,
        firstLineIndent: null,
        spaceBefore: null,
        spaceAfter: null,
        leftIndent: null,
        rightIndent: null
      };
    });
  }

  function collectParagraphs(document, options) {
    var collectOptions = normalizeCollectOptions(options);
    var collection = getParagraphCollection(document);
    var count = readCollectionCount(collection);
    if (collectOptions.maxParagraphs) {
      count = Math.min(count, collectOptions.maxParagraphs);
    }
    var items = [];
    for (var i = 1; i <= count; i += 1) {
      var paragraph = getCollectionItem(collection, i);
      if (!paragraph) {
        continue;
      }
      var font = readFont(paragraph);
      var paragraphFormat = readParagraphFormat(paragraph);
      items.push({
        index: i,
        text: limitTextLength(readText(paragraph), collectOptions.maxParagraphTextLength),
        styleName: readStyleName(paragraph),
        fontName: toSafeString(firstDefined(safeRead(font, "NameFarEast"), safeRead(font, "Name")), ""),
        fontSize: normalizeFontSize(safeRead(font, "Size")),
        bold: Boolean(safeRead(font, "Bold")),
        italic: Boolean(safeRead(font, "Italic")),
        underline: normalizeInteger(firstDefined(safeRead(font, "Underline"), null)),
        alignment: normalizeAlignmentValue(safeRead(paragraphFormat, "Alignment"), ""),
        outlineLevel: normalizeInteger(firstDefined(safeRead(paragraphFormat, "OutlineLevel"), 0)),
        lineSpacing: normalizeNumber(firstDefined(safeRead(paragraphFormat, "LineSpacing"), safeRead(paragraphFormat, "lineSpacing"), null)),
        firstLineIndent: normalizeNumber(firstDefined(safeRead(paragraphFormat, "FirstLineIndent"), safeRead(paragraphFormat, "firstLineIndent"), null)),
        spaceBefore: normalizeNumber(firstDefined(safeRead(paragraphFormat, "SpaceBefore"), safeRead(paragraphFormat, "spaceBefore"), null)),
        spaceAfter: normalizeNumber(firstDefined(safeRead(paragraphFormat, "SpaceAfter"), safeRead(paragraphFormat, "spaceAfter"), null)),
        leftIndent: normalizeNumber(firstDefined(safeRead(paragraphFormat, "LeftIndent"), safeRead(paragraphFormat, "leftIndent"), null)),
        rightIndent: normalizeNumber(firstDefined(safeRead(paragraphFormat, "RightIndent"), safeRead(paragraphFormat, "rightIndent"), null))
      });
    }
    if (items.length) {
      return items;
    }
    if (collectOptions.avoidFallbackTextRead) {
      return [];
    }
    return collectParagraphsFromText(readDocumentText(document), collectOptions);
  }

  function collectParagraphsFromSelectionSources(selectionSources, selectedText, options) {
    var sources = Array.isArray(selectionSources) ? selectionSources : [selectionSources];
    var collectOptions = normalizeCollectOptions(options);
    var paragraphs;
    var index;
    for (index = 0; index < sources.length; index += 1) {
      if (!sources[index]) {
        continue;
      }
      paragraphs = collectParagraphs(sources[index], {
        maxParagraphs: collectOptions.maxParagraphs,
        maxParagraphTextLength: collectOptions.maxParagraphTextLength,
        avoidFallbackTextRead: true
      });
      if (paragraphs.length) {
        return paragraphs;
      }
    }
    return collectParagraphsFromText(selectedText, options);
  }

  function buildDocumentStructure(options) {
    var paragraphs = options.paragraphs || [];
    var headings = options.headings || [];
    return {
      doc_name: options.documentId || "unnamed.docx",
      template_id: options.templateId || "technical-document-template-rules",
      selection_mode: options.selectionMode || "document",
      page_setup: options.pageSetup || {},
      paragraphs: paragraphs.map(function (paragraph) {
        return {
          index: paragraph.index,
          text: paragraph.text || "",
          style_name: paragraph.styleName || paragraph.style_name || "",
          font_family: paragraph.fontName || paragraph.font_family || "",
          font_size_pt: normalizeFontSize(firstDefined(paragraph.fontSize, paragraph.font_size_pt)),
          bold: Boolean(paragraph.bold),
          italic: Boolean(paragraph.italic),
          underline: paragraph.underline || null,
          alignment: normalizeAlignmentValue(paragraph.alignment, ""),
          outline_level: normalizeNumber(firstDefined(paragraph.outlineLevel, paragraph.outline_level)),
          line_spacing: normalizeNumber(firstDefined(paragraph.lineSpacing, paragraph.line_spacing)),
          first_line_indent: normalizeNumber(firstDefined(paragraph.firstLineIndent, paragraph.first_line_indent)),
          space_before: normalizeNumber(firstDefined(paragraph.spaceBefore, paragraph.space_before)),
          space_after: normalizeNumber(firstDefined(paragraph.spaceAfter, paragraph.space_after)),
          left_indent: normalizeNumber(firstDefined(paragraph.leftIndent, paragraph.left_indent)),
          right_indent: normalizeNumber(firstDefined(paragraph.rightIndent, paragraph.right_indent))
        };
      }),
      headings: headings.map(function (heading) {
        return {
          level: heading.level || heading.outlineLevel || 0,
          text: heading.text || "",
          paragraph_index: heading.paragraphIndex || heading.index || null
        };
      }),
      tables: options.tables || [],
      captions: options.captions || [],
      capabilities: {
        page_setup_extracted: Boolean(options.pageSetup && Object.keys(options.pageSetup).length),
        paragraph_style_extracted: paragraphs.length > 0,
        table_extracted: Boolean(options.tables && options.tables.length),
        header_footer_extracted: false
      }
    };
  }

  function normalizeWorkflowProfileData(data, taskType) {
    var source = data && typeof data === "object" ? data : {};
    var profiles = Array.isArray(source.configurations) ? source.configurations :
      (Array.isArray(source.profiles) ? source.profiles : []);
    var normalized = profiles.filter(function (profile) {
      return profile && profile.taskType === taskType && profile.id;
    }).map(function (profile) {
      return {
        id: String(profile.id),
        taskType: taskType,
        name: String(profile.name || "未命名配置"),
        note: String(profile.note || ""),
        keyConfigured: Boolean(profile.keyConfigured),
        complete: typeof profile.complete === "boolean" ? profile.complete : Boolean(profile.keyConfigured),
        accessMethod: String(profile.accessMethod || "workflow_platform"),
        serviceBaseUrl: String(profile.serviceBaseUrl || ""),
        callPath: String(profile.callPath || ""),
        modelName: String(profile.modelName || ""),
        temperature: profile.temperature,
        maxOutputTokens: profile.maxOutputTokens,
        contextWindowTokens: Number(profile.contextWindowTokens || 40000),
        missingFields: Array.isArray(profile.missingFields) ? profile.missingFields : [],
        configVersion: Number(profile.configVersion || 1),
        lastValidation: profile.lastValidation || null,
        createdAt: String(profile.createdAt || ""),
        updatedAt: String(profile.updatedAt || "")
      };
    });
    var activeId = String(source.activeConfigurationId || source.activeProfileId || "");
    var activeExists = normalized.some(function (profile) {
      return profile.id === activeId;
    });
    return {
      taskType: taskType,
      activeProfileId: activeExists ? activeId : "",
      profileCount: normalized.length,
      profiles: normalized
    };
  }

  function getActiveWorkflowProfileName(data) {
    var profiles = data && Array.isArray(data.profiles) ? data.profiles : [];
    var activeId = data ? data.activeProfileId : "";
    var index;
    for (index = 0; index < profiles.length; index += 1) {
      if (profiles[index].id === activeId) {
        return profiles[index].name;
      }
    }
    var directServices = data && Array.isArray(data.directServices) ? data.directServices : [];
    for (index = 0; index < directServices.length; index += 1) {
      if (directServices[index].id === activeId) {
        return directServices[index].name;
      }
    }
    return "尚未配置";
  }

  function deriveModelInterfaceState(input) {
    var source = input || {};
    var taskTypes = Array.isArray(source.taskTypes) ? source.taskTypes : [];
    var profilesByTask = source.profilesByTask || {};
    var readyCount = 0;
    var totalCount = taskTypes.length;
    var taskIndex;
    var profileIndex;
    var data;
    var profiles;
    var directServices;
    var matched;

    if (source.detectable === false) {
      return { code: "unavailable", label: "无法检测", readyCount: 0, totalCount: totalCount };
    }

    for (taskIndex = 0; taskIndex < taskTypes.length; taskIndex += 1) {
      data = profilesByTask[taskTypes[taskIndex]] || {};
      profiles = Array.isArray(data.profiles) ? data.profiles : [];
      directServices = Array.isArray(data.directServices) ? data.directServices : [];
      matched = false;
      for (profileIndex = 0; profileIndex < profiles.length; profileIndex += 1) {
        if (profiles[profileIndex]
          && profiles[profileIndex].id === data.activeProfileId
          && profiles[profileIndex].complete) {
          readyCount += 1;
          matched = true;
          break;
        }
      }
      if (!matched) {
        for (profileIndex = 0; profileIndex < directServices.length; profileIndex += 1) {
          if (directServices[profileIndex]
            && directServices[profileIndex].id === data.activeProfileId
            && directServices[profileIndex].keyConfigured
            && directServices[profileIndex].serviceBaseUrl) {
            readyCount += 1;
            break;
          }
        }
      }
    }

    if (totalCount === 0 || readyCount === 0) {
      return { code: "unconfigured", label: "未配置", readyCount: readyCount, totalCount: totalCount };
    }
    if (readyCount === totalCount) {
      return { code: "ready", label: "已就绪", readyCount: readyCount, totalCount: totalCount };
    }
    return {
      code: "partial",
      label: "部分就绪 · " + readyCount + "/" + totalCount,
      readyCount: readyCount,
      totalCount: totalCount
    };
  }

  function normalizeAdapterHealth(value, connected) {
    var source = value && typeof value === "object" ? value : {};
    var policy = source.operationPolicy && typeof source.operationPolicy === "object"
      ? source.operationPolicy
      : {};
    var status = String(source.status || "").toLowerCase();
    if (connected === false) {
      status = "unavailable";
    } else if (status === "ok") {
      status = "ready";
    } else if (["ready", "degraded", "recovery"].indexOf(status) < 0) {
      status = "recovery";
    }
    var recovery = status === "recovery";
    var degraded = status === "degraded";
    return {
      status: status,
      connected: status !== "unavailable",
      badgeClass: status === "ready" ? "badge-ok" : (degraded ? "badge-warn" : "badge-error"),
      badgeLabel: status === "ready" ? "已连接" : (
        degraded ? "增强降级" : (recovery ? "恢复模式" : "未连接")
      ),
      summary: degraded
        ? "Adapter 已连接，写作规范增强能力降级，核心功能可继续使用。"
        : (recovery
          ? "Adapter 已连接但处于恢复模式，配置变更和模型任务已被阻止。"
          : (status === "unavailable" ? "无法连接本地 Adapter。" : "Adapter 已连接。")),
      configurationMutationsAllowed: !recovery && policy.configurationMutationsAllowed !== false,
      modelTasksAllowed: !recovery && policy.modelTasksAllowed !== false,
      writingPolicyMutationsAllowed: !recovery && !degraded && policy.writingPolicyMutationsAllowed !== false
    };
  }

  function createSettingsRefreshController(options) {
    var settings = options || {};
    var refresh = typeof settings.refresh === "function" ? settings.refresh : function () {};
    var setIntervalFn = typeof settings.setIntervalFn === "function"
      ? settings.setIntervalFn
      : (typeof setInterval === "function" ? setInterval : function () { return 0; });
    var clearIntervalFn = typeof settings.clearIntervalFn === "function"
      ? settings.clearIntervalFn
      : (typeof clearInterval === "function" ? clearInterval : function () {});
    var intervalMs = typeof settings.intervalMs === "number" ? settings.intervalMs : 30000;
    var timerId = null;

    return {
      start: function () {
        if (timerId !== null) {
          return;
        }
        refresh();
        timerId = setIntervalFn(refresh, intervalMs);
      },
      stop: function () {
        if (timerId === null) {
          return;
        }
        clearIntervalFn(timerId);
        timerId = null;
      },
      isRunning: function () {
        return timerId !== null;
      }
    };
  }

  function extractExcelFormulaSelection(range, options) {
    var settings = options || {};
    var maxRows = Number(settings.maxRows || 30);
    var maxColumns = Number(settings.maxColumns || 20);
    var maxCellTextLength = Number(settings.maxCellTextLength || 120);
    var maxFormulaLength = Number(settings.maxFormulaLength || 1000);
    var maxTotalTextLength = Number(settings.maxTotalTextLength || 20000);
    function readOwned(owner, keys) {
      var index;
      var value;
      if (!owner) {
        return undefined;
      }
      for (index = 0; index < keys.length; index += 1) {
        value = safeRead(owner, keys[index]);
        if (typeof value === "function") {
          value = safeCall(value, owner);
        }
        if (typeof value !== "undefined" && value !== null) {
          return value;
        }
      }
      return undefined;
    }

    var rows = readOwned(range, ["Rows", "rows"]);
    var columns = readOwned(range, ["Columns", "columns"]);
    var rowCount = readCollectionCount(rows);
    var columnCount = readCollectionCount(columns);
    var cellsCollection = readOwned(range, ["Cells", "cells"]) || range;
    var capturedRows = Math.min(rowCount, maxRows);
    var capturedColumns = Math.min(columnCount, maxColumns);
    var totalLength = 0;
    var truncated = rowCount > maxRows || columnCount > maxColumns;
    var matrix = [];
    var headers = [];
    var rowIndex;
    var columnIndex;

    function getCell(row, column) {
      var item = safeRead(cellsCollection, "Item") || safeRead(cellsCollection, "item");
      if (typeof item === "function") {
        try {
          return item.call(cellsCollection, row, column);
        } catch (error) {
          return null;
        }
      }
      return safeRead(cellsCollection, row + "," + column) || null;
    }

    function bounded(value, limit) {
      var text = toSafeString(value, "").replace(/\r/g, "").trim();
      var remaining;
      if (text.length > limit) {
        text = text.slice(0, limit);
        truncated = true;
      }
      remaining = Math.max(maxTotalTextLength - totalLength, 0);
      if (text.length > remaining) {
        text = text.slice(0, remaining);
        truncated = true;
      }
      totalLength += text.length;
      return text;
    }

    function readFormula(cell) {
      var hasFormulaValue = resolveScalarValue(readOwned(
        cell,
        ["HasFormula", "hasFormula"]
      ));
      var hasFormulaText;
      var formulaKeys = [
        "Formula",
        "formula",
        "FormulaLocal",
        "formulaLocal",
        "FormulaR1C1",
        "formulaR1C1"
      ];
      var index;
      var formula;

      if (typeof hasFormulaValue === "boolean" && !hasFormulaValue) {
        return "";
      }
      if (typeof hasFormulaValue === "number" && hasFormulaValue === 0) {
        return "";
      }
      if (typeof hasFormulaValue === "string") {
        hasFormulaText = hasFormulaValue.trim().toLowerCase();
        if (hasFormulaText === "false" || hasFormulaText === "0" || hasFormulaText === "no") {
          return "";
        }
      }

      for (index = 0; index < formulaKeys.length; index += 1) {
        formula = toSafeString(readOwned(cell, [formulaKeys[index]]), "")
          .replace(/\r/g, "")
          .trim();
        if (formula.charAt(0) === "=") {
          return bounded(formula, maxFormulaLength);
        }
      }
      return "";
    }

    function readRawValue(cell) {
      return resolveScalarValue(readOwned(
        cell,
        ["Value2", "value2", "Value", "value"]
      ));
    }

    function classifyCell(text, formula, rawValue) {
      if (formula) {
        return "formula";
      }
      if (!text && (typeof rawValue === "undefined" || rawValue === null || rawValue === "")) {
        return "blank";
      }
      if (typeof rawValue === "boolean") {
        return "boolean";
      }
      if (typeof rawValue === "number") {
        return "number";
      }
      if (/^#(?:N\/A|VALUE!|REF!|DIV\/0!|NAME\?|NUM!|NULL!)/i.test(text)) {
        return "error";
      }
      return text ? "text" : "unknown";
    }

    if (!range || !rowCount || !columnCount) {
      throw new Error("未读取到明确选区，请先框选相关表格范围。");
    }

    for (rowIndex = 1; rowIndex <= capturedRows; rowIndex += 1) {
      var row = [];
      for (columnIndex = 1; columnIndex <= capturedColumns; columnIndex += 1) {
        var cell = getCell(rowIndex, columnIndex) || {};
        var rawValue = readRawValue(cell);
        var text = bounded(firstDefined(
          readOwned(cell, ["Text", "text"]),
          rawValue,
          ""
        ), maxCellTextLength);
        var formula = readFormula(cell);
        var address = toSafeString(firstDefined(
          readOwned(cell, ["Address", "address"]),
          ""
        ), "").trim();
        row.push({
          address: address,
          text: text,
          valueType: classifyCell(text, formula, rawValue),
          formula: formula
        });
        if (rowIndex === 1) {
          headers.push(text || "列" + columnIndex);
        }
      }
      matrix.push(row);
    }

    return {
      sheetName: String(settings.sheetName || "").trim(),
      address: toSafeString(firstDefined(
        readOwned(range, ["Address", "address"]),
        ""
      ), "").trim(),
      headers: headers,
      cells: matrix,
      rowCount: rowCount,
      columnCount: columnCount,
      truncated: truncated
    };
  }

  function displayExcelSmartFillSourceAddress(address) {
    var text = String(address || "").trim();
    if (text.indexOf("!") >= 0) {
      text = text.split("!").pop();
    }
    return text.replace(/\$/g, "");
  }

  function formatExcelSmartFillSourceSummary(sheetName, address, headerCount, dataRowCount) {
    if (!sheetName && !address) {
      return "数据范围：未检测到当前选区";
    }
    return "数据范围：" + sheetName + "!" + address + " · " + headerCount + " 行表头 · " + dataRowCount + " 行数据";
  }

  function isExcelSmartFillSafetyStateReady(state) {
    return Boolean(state && state.known === true && state.present === true);
  }

  function readExcelSmartFillBoundCount(owner, keys) {
    var objectState = readSmartFillPropertyState(owner, keys, true);
    var countState;
    var count;
    if (!isExcelSmartFillSafetyStateReady(objectState) || !objectState.value) {
      return { known: false, value: 0 };
    }
    countState = readSmartFillPropertyState(objectState.value, ["Count", "count"], false);
    if (!isExcelSmartFillSafetyStateReady(countState)) {
      return { known: false, value: 0 };
    }
    count = Number(countState.value);
    if (!isFinite(count) || count <= 0) {
      return { known: false, value: 0 };
    }
    return { known: true, value: count };
  }

  function readExcelSmartFillRangeAddress(range) {
    var state = readSmartFillPropertyState(range, ["Address", "address"], false);
    var text;
    if (!isExcelSmartFillSafetyStateReady(state)) {
      return { known: false, value: "" };
    }
    text = String(state.value == null ? "" : state.value).trim();
    if (!text || /^function\b/.test(text)) {
      return { known: false, value: "" };
    }
    return { known: true, value: text };
  }

  function readExcelSmartFillRangeSheetName(range) {
    var worksheetState = readSmartFillPropertyState(range, ["Worksheet", "worksheet"], true);
    var nameState;
    var name;
    if (!isExcelSmartFillSafetyStateReady(worksheetState) || !worksheetState.value) {
      return { known: false, value: "" };
    }
    nameState = readSmartFillPropertyState(worksheetState.value, ["Name", "name"], false);
    if (!isExcelSmartFillSafetyStateReady(nameState)) {
      return { known: false, value: "" };
    }
    name = String(nameState.value == null ? "" : nameState.value).trim();
    if (!name) {
      return { known: false, value: "" };
    }
    return { known: true, value: name };
  }

  function canRetryExcelSmartFillFromFrozenSource(source, items) {
    return Boolean(
      source &&
      Array.isArray(source.rows) &&
      source.rows.length > 0 &&
      Array.isArray(items) &&
      items.length > 0
    );
  }

  function readExcelSmartFillSourceMetadata(range, options) {
    var settings = options || {};
    var maxDataRows = Number(settings.maxSourceRows || 500);
    var maxSourceColumns = Number(settings.maxSourceColumns || 50);
    var addressState = range ? readExcelSmartFillRangeAddress(range) : { known: false, value: "" };
    var sheetState = range ? readExcelSmartFillRangeSheetName(range) : { known: false, value: "" };
    var expectedSheet = String(settings.sourceSheetName || settings.sheetName || "").trim();
    var rowsState = range ? readExcelSmartFillBoundCount(range, ["Rows", "rows"]) : { known: false, value: 0 };
    var columnsState = range ? readExcelSmartFillBoundCount(range, ["Columns", "columns"]) : { known: false, value: 0 };
    var areasState = range ? readExcelSmartFillBoundCount(range, ["Areas", "areas"]) : { known: true, value: 1 };
    var rawAddress = addressState.known ? addressState.value : "";
    var address = displayExcelSmartFillSourceAddress(rawAddress);
    var sheetName = sheetState.known ? sheetState.value : "";
    var rows = rowsState.known ? rowsState.value : 0;
    var columns = columnsState.known ? columnsState.value : 0;
    var areas = areasState.known ? areasState.value : 0;
    var headerCount = 0;
    var dataRowCount = 0;
    var summary;
    function fail(error, extra) {
      extra = extra || {};
      return {
        ok: false,
        error: error,
        summary: extra.summary || summary || "数据范围：未检测到当前选区",
        sheetName: extra.sheetName != null ? extra.sheetName : sheetName,
        address: extra.address != null ? extra.address : address,
        headerCount: extra.headerCount != null ? extra.headerCount : headerCount,
        dataRowCount: extra.dataRowCount != null ? extra.dataRowCount : dataRowCount,
        rawAddress: rawAddress,
        rowCount: rows,
        columnCount: columns
      };
    }

    if (!range || !rowsState.known || !columnsState.known || !rows || !columns) {
      return fail("未读取到明确来源区域，请先选中来源数据。", {
        summary: "数据范围：未检测到当前选区",
        headerCount: 0,
        dataRowCount: 0
      });
    }

    headerCount = 1;
    dataRowCount = Math.max(rows - 1, 0);
    summary = formatExcelSmartFillSourceSummary(
      sheetName || "当前工作表",
      address || "未识别地址",
      headerCount,
      dataRowCount
    );

    if (!addressState.known || !parseExcelA1Cell(address || rawAddress)) {
      return fail("无法读取来源地址，请重新选择来源范围。");
    }

    if (!areasState.known || areas > 1) {
      return fail("来源必须是同一工作表中的连续矩形区域。");
    }

    if (!sheetState.known || !sheetName) {
      return fail("无法证明来源属于同一工作表。");
    }
    if (expectedSheet && expectedSheet !== sheetName) {
      return fail("无法证明来源属于同一工作表。");
    }

    if (dataRowCount < 1) {
      return fail("来源必须包含一行表头和至少一行数据。", { dataRowCount: 0 });
    }

    if (columns > maxSourceColumns) {
      return fail("智能填写来源最多支持 " + maxSourceColumns + " 列，不能静默截断。");
    }

    if (dataRowCount > maxDataRows) {
      return fail("来源数据行最多 " + maxDataRows + " 行。");
    }

    return {
      ok: true,
      error: "",
      summary: summary,
      sheetName: sheetName,
      address: address,
      headerCount: headerCount,
      dataRowCount: dataRowCount,
      rawAddress: rawAddress,
      rowCount: rows,
      columnCount: columns
    };
  }

  function analyzeExcelSmartFillSourceRange(range, options) {
    var settings = options || {};
    var metadata = readExcelSmartFillSourceMetadata(range, settings);
    var maxCellTextLength = Number(settings.maxCellTextLength || 2000);
    var maxTotalTextLength = Number(settings.maxTotalTextLength || 200000);
    var sheetName = metadata.sheetName;
    var rawAddress = metadata.rawAddress;
    var address = metadata.address;
    var rows = metadata.rowCount;
    var columns = metadata.columnCount;
    var headerCount = 0;
    var dataRowCount = 0;
    var headers = [];
    var sourceRows = [];
    var dataSheetRows = [];
    var rowIndex;
    var columnIndex;
    var cell;
    var hidden;
    var merged;
    var hasHidden = false;
    var hasMerged = false;
    var hasUnreadSafety = false;
    var displayed;
    var hiddenState;
    var rowState;
    var columnState;
    var rowHidden;
    var columnHidden;
    var mergedState;
    var formulaState;
    var textState;
    var totalLength = 0;
    var summary;

    function getCell(row, column) {
      var cells = range && range.Cells;
      if (!cells || typeof cells.Item !== "function") {
        return null;
      }
      return cells.Item(row, column);
    }

    function bounded(text) {
      var value = String(text || "");
      var length = countUnicodeCodePoints(value);
      if (length > maxCellTextLength) {
        throw new Error("智能填写单元格文本最多 " + maxCellTextLength + " 个字符，不能静默截断。");
      }
      if (totalLength + length > maxTotalTextLength) {
        throw new Error("智能填写上下文文本总量超过 " + maxTotalTextLength + " 个字符，不能静默截断。");
      }
      totalLength += length;
      return value;
    }

    if (!metadata.ok) {
      return {
        ok: false,
        error: metadata.error,
        summary: metadata.summary,
        sheetName: sheetName,
        address: address,
        headerCount: metadata.headerCount,
        dataRowCount: metadata.dataRowCount,
        rawAddress: rawAddress,
        headers: [],
        rows: [],
        dataSheetRows: [],
        columnCount: columns
      };
    }

    headerCount = metadata.headerCount;
    dataRowCount = metadata.dataRowCount;
    summary = metadata.summary;

    for (rowIndex = 1; rowIndex <= rows; rowIndex += 1) {
      var rowValues = [];
      for (columnIndex = 1; columnIndex <= columns; columnIndex += 1) {
        cell = getCell(rowIndex, columnIndex);
        if (!cell) {
          hasUnreadSafety = true;
          rowValues.push("");
          continue;
        }
        hiddenState = readSmartFillBooleanState(cell, ["Hidden", "hidden"]);
        rowState = readSmartFillPropertyState(cell, ["EntireRow", "entireRow"], true);
        columnState = readSmartFillPropertyState(cell, ["EntireColumn", "entireColumn"], true);
        rowHidden = isExcelSmartFillSafetyStateReady(rowState)
          ? readSmartFillBooleanState(rowState.value, ["Hidden", "hidden"])
          : { known: false, present: false, value: null };
        columnHidden = isExcelSmartFillSafetyStateReady(columnState)
          ? readSmartFillBooleanState(columnState.value, ["Hidden", "hidden"])
          : { known: false, present: false, value: null };
        mergedState = readSmartFillBooleanState(cell, ["MergeCells", "mergeCells"]);
        formulaState = readSmartFillFormulaState(cell);
        textState = readSmartFillPropertyState(cell, ["Text", "text"], false);
        if (!hiddenState.known ||
            !isExcelSmartFillSafetyStateReady(rowHidden) ||
            !isExcelSmartFillSafetyStateReady(columnHidden) ||
            !isExcelSmartFillSafetyStateReady(mergedState) ||
            !formulaState.known ||
            !isExcelSmartFillSafetyStateReady(textState)) {
          hasUnreadSafety = true;
        }
        hidden = hiddenState.value === true || rowHidden.value === true || columnHidden.value === true;
        merged = mergedState.value === true;
        if (hidden) {
          hasHidden = true;
        }
        if (merged) {
          hasMerged = true;
        }
        if (formulaState.isFormula) {
          displayed = "";
        } else if (!textState.present || textState.value == null) {
          displayed = "";
        } else {
          displayed = bounded(String(textState.value).replace(/\r/g, ""));
        }
        rowValues.push(displayed);
      }
      if (rowIndex === 1) {
        headers = rowValues;
      } else {
        sourceRows.push(rowValues);
        dataSheetRows.push(Number(cell && cell.Row) || rowIndex);
      }
    }

    if (hasUnreadSafety) {
      return {
        ok: false,
        error: "无法安全读取来源单元格状态，请取消隐藏或公式单元格后重试。",
        summary: summary,
        sheetName: sheetName,
        address: address,
        headerCount: headerCount,
        dataRowCount: dataRowCount,
        rawAddress: rawAddress,
        headers: headers,
        rows: sourceRows,
        dataSheetRows: dataSheetRows
      };
    }
    if (hasMerged) {
      return {
        ok: false,
        error: "来源不能包含合并单元格。",
        summary: summary,
        sheetName: sheetName,
        address: address,
        headerCount: headerCount,
        dataRowCount: dataRowCount,
        rawAddress: rawAddress,
        headers: headers,
        rows: sourceRows,
        dataSheetRows: dataSheetRows
      };
    }
    if (hasHidden) {
      return {
        ok: false,
        error: "来源不能包含隐藏行、列或单元格。",
        summary: summary,
        sheetName: sheetName,
        address: address,
        headerCount: headerCount,
        dataRowCount: dataRowCount,
        rawAddress: rawAddress,
        headers: headers,
        rows: sourceRows,
        dataSheetRows: dataSheetRows
      };
    }

    return {
      ok: true,
      error: "",
      summary: summary,
      sheetName: sheetName,
      address: address,
      headerCount: headerCount,
      dataRowCount: dataRowCount,
      rawAddress: rawAddress,
      headers: headers,
      rows: sourceRows,
      dataSheetRows: dataSheetRows,
      columnCount: columns
    };
  }

  function inspectExcelSmartFillSourceSelection(range, options) {
    var analysis = readExcelSmartFillSourceMetadata(range, options);
    return {
      ok: analysis.ok,
      error: analysis.error,
      summary: analysis.summary,
      sheetName: analysis.sheetName,
      address: analysis.address,
      headerCount: analysis.headerCount,
      dataRowCount: analysis.dataRowCount
    };
  }

  function monotonicNow() {
    return (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
  }

  function runChunkedSteps(processStep, options) {
    options = options || {};
    var budgetMs = Number(options.budgetMs || 32);
    var checkCancelled = options.checkCancelled;
    var delayMs = typeof options.delayMs === "number" ? options.delayMs : 0;
    return new Promise(function (resolve, reject) {
      function runSlice() {
        var sliceStart = monotonicNow();
        function continueAfterStep(finished) {
          if (finished) {
            resolve();
            return;
          }
          if (monotonicNow() - sliceStart >= budgetMs) {
            setTimeout(runSlice, delayMs);
            return;
          }
          next();
        }
        function next() {
          var result;
          while (true) {
            try {
              if (checkCancelled) {
                checkCancelled();
              }
              result = processStep();
            } catch (error) {
              reject(error);
              return;
            }
            if (result && typeof result.then === "function") {
              result.then(continueAfterStep, reject);
              return;
            }
            if (result) {
              resolve();
              return;
            }
            if (monotonicNow() - sliceStart >= budgetMs) {
              setTimeout(runSlice, delayMs);
              return;
            }
          }
        }
        next();
      }
      runSlice();
    });
  }

  function analyzeExcelSmartFillSourceRangeYielding(range, options, loopOptions) {
    var settings = options || {};
    var lOpts = loopOptions || {};
    if (settings.budgetMs || settings.checkCancelled || settings.onProgress || typeof settings.delayMs === "number") {
      lOpts = {
        budgetMs: settings.budgetMs || lOpts.budgetMs || 32,
        checkCancelled: settings.checkCancelled || lOpts.checkCancelled,
        onProgress: settings.onProgress || lOpts.onProgress,
        delayMs: typeof settings.delayMs === "number" ? settings.delayMs : (lOpts.delayMs || 0)
      };
    }
    var metadata = readExcelSmartFillSourceMetadata(range, settings);
    var maxCellTextLength = Number(settings.maxCellTextLength || 2000);
    var maxTotalTextLength = Number(settings.maxTotalTextLength || 200000);
    var sheetName = metadata.sheetName;
    var rawAddress = metadata.rawAddress;
    var address = metadata.address;
    var rows = metadata.rowCount;
    var columns = metadata.columnCount;
    var headerCount = 0;
    var dataRowCount = 0;
    var headers = [];
    var sourceRows = [];
    var dataSheetRows = [];
    var cell;
    var hidden;
    var merged;
    var hasHidden = false;
    var hasMerged = false;
    var hasUnreadSafety = false;
    var displayed;
    var hiddenState;
    var rowState;
    var columnState;
    var rowHidden;
    var columnHidden;
    var mergedState;
    var formulaState;
    var textState;
    var totalLength = 0;
    var summary;

    function getCell(row, column) {
      var cells = range && range.Cells;
      if (!cells || typeof cells.Item !== "function") {
        return null;
      }
      return cells.Item(row, column);
    }

    function bounded(text) {
      var value = String(text || "");
      var length = countUnicodeCodePoints(value);
      if (length > maxCellTextLength) {
        throw new Error("智能填写单元格文本最多 " + maxCellTextLength + " 个字符，不能静默截断。");
      }
      if (totalLength + length > maxTotalTextLength) {
        throw new Error("智能填写上下文文本总量超过 " + maxTotalTextLength + " 个字符，不能静默截断。");
      }
      totalLength += length;
      return value;
    }

    if (!metadata.ok) {
      return Promise.resolve({
        ok: false,
        error: metadata.error,
        summary: metadata.summary,
        sheetName: sheetName,
        address: address,
        headerCount: metadata.headerCount,
        dataRowCount: metadata.dataRowCount,
        rawAddress: rawAddress,
        headers: [],
        rows: [],
        dataSheetRows: [],
        columnCount: columns
      });
    }

    headerCount = metadata.headerCount;
    dataRowCount = metadata.dataRowCount;
    summary = metadata.summary;

    var rowIndex = 1;
    var columnIndex = 1;
    var rowValues = [];
    return runChunkedSteps(function () {
      if (rowIndex > rows) {
        return true;
      }
      cell = getCell(rowIndex, columnIndex);
      if (!cell) {
        hasUnreadSafety = true;
        rowValues.push("");
      } else {
        hiddenState = readSmartFillBooleanState(cell, ["Hidden", "hidden"]);
        rowState = readSmartFillPropertyState(cell, ["EntireRow", "entireRow"], true);
        columnState = readSmartFillPropertyState(cell, ["EntireColumn", "entireColumn"], true);
        rowHidden = isExcelSmartFillSafetyStateReady(rowState)
          ? readSmartFillBooleanState(rowState.value, ["Hidden", "hidden"])
          : { known: false, present: false, value: null };
        columnHidden = isExcelSmartFillSafetyStateReady(columnState)
          ? readSmartFillBooleanState(columnState.value, ["Hidden", "hidden"])
          : { known: false, present: false, value: null };
        mergedState = readSmartFillBooleanState(cell, ["MergeCells", "mergeCells"]);
        formulaState = readSmartFillFormulaState(cell);
        textState = readSmartFillPropertyState(cell, ["Text", "text"], false);
        if (!hiddenState.known ||
            !isExcelSmartFillSafetyStateReady(rowHidden) ||
            !isExcelSmartFillSafetyStateReady(columnHidden) ||
            !isExcelSmartFillSafetyStateReady(mergedState) ||
            !formulaState.known ||
            !isExcelSmartFillSafetyStateReady(textState)) {
          hasUnreadSafety = true;
        }
        hidden = hiddenState.value === true || rowHidden.value === true || columnHidden.value === true;
        merged = mergedState.value === true;
        if (hidden) {
          hasHidden = true;
        }
        if (merged) {
          hasMerged = true;
        }
        if (formulaState.isFormula) {
          displayed = "";
        } else if (!textState.present || textState.value == null) {
          displayed = "";
        } else {
          displayed = bounded(String(textState.value).replace(/\r/g, ""));
        }
        rowValues.push(displayed);
      }
      columnIndex += 1;
      if (columnIndex <= columns) {
        return false;
      }
      if (rowIndex === 1) {
        headers = rowValues;
      } else {
        sourceRows.push(rowValues);
        dataSheetRows.push(Number(cell && cell.Row) || rowIndex);
      }
      if (typeof lOpts.onProgress === "function") {
        lOpts.onProgress({
          processedRows: rowIndex,
          totalRows: rows,
          processedCells: rowIndex * columns,
          totalCells: rows * columns
        });
      }
      rowIndex += 1;
      columnIndex = 1;
      rowValues = [];
      return false;
    }, lOpts).then(function () {
      if (hasUnreadSafety) {
        return {
          ok: false,
          error: "无法安全读取来源单元格状态，请取消隐藏或公式单元格后重试。",
          summary: summary,
          sheetName: sheetName,
          address: address,
          headerCount: headerCount,
          dataRowCount: dataRowCount,
          rawAddress: rawAddress,
          headers: headers,
          rows: sourceRows,
          dataSheetRows: dataSheetRows
        };
      }
      if (hasMerged) {
        return {
          ok: false,
          error: "来源不能包含合并单元格。",
          summary: summary,
          sheetName: sheetName,
          address: address,
          headerCount: headerCount,
          dataRowCount: dataRowCount,
          rawAddress: rawAddress,
          headers: headers,
          rows: sourceRows,
          dataSheetRows: dataSheetRows
        };
      }
      if (hasHidden) {
        return {
          ok: false,
          error: "来源不能包含隐藏行、列或单元格。",
          summary: summary,
          sheetName: sheetName,
          address: address,
          headerCount: headerCount,
          dataRowCount: dataRowCount,
          rawAddress: rawAddress,
          headers: headers,
          rows: sourceRows,
          dataSheetRows: dataSheetRows
        };
      }

      return {
        ok: true,
        error: "",
        summary: summary,
        sheetName: sheetName,
        address: address,
        headerCount: headerCount,
        dataRowCount: dataRowCount,
        rawAddress: rawAddress,
        headers: headers,
        rows: sourceRows,
        dataSheetRows: dataSheetRows,
        columnCount: columns
      };
    });
  }

  function extractExcelSmartFillSourcePayload(range, options) {
    var settings = options || {};
    var analysis = analyzeExcelSmartFillSourceRange(range, settings);
    var createItemId = typeof settings.createItemId === "function"
      ? settings.createItemId
      : createExcelSmartFillItemId;
    var source;
    if (!analysis.ok) {
      throw new Error(analysis.error);
    }
    source = {
      sheetName: analysis.sheetName,
      address: analysis.rawAddress,
      headers: analysis.headers,
      rows: analysis.rows,
      rowCount: analysis.rows.length,
      columnCount: analysis.columnCount,
      truncated: false
    };
    source.snapshotHash = makeTextHash(JSON.stringify({
      sheetName: source.sheetName,
      address: source.address,
      headers: source.headers,
      rows: source.rows
    }));
    return {
      workbookId: String(settings.workbookId || "active-workbook"),
      scene: "excel",
      source: source,
      items: analysis.rows.map(function (_row, index) {
        var sheetRow = analysis.dataSheetRows[index] || (index + 2);
        return {
          itemId: createItemId(),
          sourceRowIndex: index + 1,
          sourceRowLabel: "第 " + sheetRow + " 行"
        };
      })
    };
  }

  function extractExcelSmartFillSourcePayloadYielding(range, options, loopOptions) {
    var settings = options || {};
    var lOpts = loopOptions || {};
    return analyzeExcelSmartFillSourceRangeYielding(range, settings, lOpts).then(function (analysis) {
      if (!analysis.ok) {
        throw new Error(analysis.error);
      }
      var createItemId = typeof settings.createItemId === "function"
        ? settings.createItemId
        : createExcelSmartFillItemId;
      var source = {
        sheetName: analysis.sheetName,
        address: analysis.rawAddress,
        headers: analysis.headers,
        rows: analysis.rows,
        rowCount: analysis.rows.length,
        columnCount: analysis.columnCount,
        truncated: false
      };
      source.snapshotHash = makeTextHash(JSON.stringify({
        sheetName: source.sheetName,
        address: source.address,
        headers: source.headers,
        rows: source.rows
      }));
      return {
        workbookId: String(settings.workbookId || "active-workbook"),
        scene: "excel",
        source: source,
        items: analysis.rows.map(function (_row, index) {
          var sheetRow = analysis.dataSheetRows[index] || (index + 2);
          return {
            itemId: createItemId(),
            sourceRowIndex: index + 1,
            sourceRowLabel: "第 " + sheetRow + " 行"
          };
        })
      };
    });
  }

  function sliceExcelSmartFillSourceForRetry(source, item) {
    var index = Number(item && item.sourceRowIndex) - 1;
    var rows = source && Array.isArray(source.rows) ? source.rows : [];
    var row;
    if (!source || index < 0 || index >= rows.length || !Array.isArray(rows[index])) {
      throw new Error("未找到需要重试的智能填写项。");
    }
    row = rows[index].slice();
    return {
      sheetName: source.sheetName,
      address: source.address,
      snapshotHash: source.snapshotHash || "",
      headers: Array.isArray(source.headers) ? source.headers.slice() : [],
      rows: [row],
      rowCount: 1,
      columnCount: Number(source.columnCount) || row.length,
      truncated: false
    };
  }

  function buildExcelSmartFillReadonlyPreview(data, targets) {
    var items = data && Array.isArray(data.items) ? data.items : [];
    var targetList = Array.isArray(targets) ? targets : [];
    var html = [
      '<div class="smart-fill-preview-head">',
      "<strong>智能填写预览</strong>",
      '<span class="field-hint">写入前请核对生成结果；本页为只读预览。</span>',
      "</div>"
    ];
    function previewRowLabel(item) {
      var index;
      var target;
      if (item && item.sourceRowLabel) {
        return item.sourceRowLabel;
      }
      for (index = 0; index < targetList.length; index += 1) {
        target = targetList[index];
        if (target && item && target.itemId === item.itemId) {
          return target.sourceRowLabel || target.address || item.itemId;
        }
      }
      return item && item.itemId ? item.itemId : "";
    }
    if (!items.length) {
      html.push('<p class="field-hint">未返回可展示的目标结果。</p>');
      return html.join("");
    }
    html.push('<div class="smart-fill-result-list">');
    items.forEach(function (item) {
      var completed = item && item.status === "completed";
      var failed = item && item.status === "failed";
      var unprocessed = item && item.status === "unprocessed";
      var value = completed ? String(item.value == null ? "" : item.value) : "";
      var statusLabel = completed ? "可写入" : (failed ? "失败" : (unprocessed ? "未处理" : "信息不足"));
      var statusClass = completed
        ? "is-complete"
        : (failed ? "is-failed" : (unprocessed ? "is-unprocessed" : "is-insufficient"));
      html.push(
        '<article class="smart-fill-result-item">',
        '<div class="smart-fill-result-meta">',
        "<span>" + escapeHtml(previewRowLabel(item)) + "</span>",
        '<span class="smart-fill-result-status ' + statusClass + '">' +
          statusLabel + "</span>",
        "</div>",
        '<p class="smart-fill-result-value">' + escapeHtml(completed ? value : statusLabel) + "</p>",
        "</article>"
      );
    });
    html.push("</div>");
    return html.join("");
  }

  function createExcelSmartFillPreview(result, fingerprint) {
    return {
      result: result || null,
      consumed: false,
      status: result ? "ready" : "empty",
      editingInputs: false,
      fingerprint: fingerprint || null,
      invalidReason: "",
      targetError: "",
      writeFailureReason: "",
      manualReviewAddresses: [],
      writtenCount: 0,
      skippedCount: 0
    };
  }

  function excelSmartFillFingerprintsEqual(left, right) {
    if (!left || !right) {
      return false;
    }
    return String(left.sourceAddress || "") === String(right.sourceAddress || "") &&
      String(left.sourceSnapshotHash || "") === String(right.sourceSnapshotHash || "") &&
      String(left.instruction || "") === String(right.instruction || "") &&
      String(left.workbookId || "") === String(right.workbookId || "") &&
      String(left.sheetName || "") === String(right.sheetName || "");
  }

  function buildExcelSmartFillEditFingerprint(frozen, options) {
    var settings = options || {};
    var frozenFp = frozen || {};
    var live = settings.liveSource || {};
    var instruction = settings.instruction != null ? settings.instruction : frozenFp.instruction;
    var frozenAddress = normalizeExcelSmartFillA1Address(frozenFp.sourceAddress);
    var frozenSheet = String(frozenFp.sheetName || "");
    var frozenWorkbook = String(frozenFp.workbookId || "");
    var liveAddress = "";
    var liveSheet = "";
    var liveWorkbook = String(settings.workbookId || live.workbookId || "");
    var baseline = normalizeExcelSmartFillA1Address(settings.baselineAddress);
    var nextAddress = frozenFp.sourceAddress || "";
    var nextSheet = frozenSheet;
    var nextWorkbook = frozenWorkbook;
    if (live.ok) {
      liveAddress = normalizeExcelSmartFillA1Address(live.rawAddress || live.address);
      liveSheet = String(live.sheetName || "");
      if (liveWorkbook && frozenWorkbook && liveWorkbook !== frozenWorkbook) {
        nextAddress = live.rawAddress || live.address || nextAddress;
        nextSheet = liveSheet || nextSheet;
        nextWorkbook = liveWorkbook;
      } else if (liveAddress && liveAddress === baseline) {
        nextAddress = frozenFp.sourceAddress || "";
        nextSheet = frozenSheet;
        nextWorkbook = frozenWorkbook;
      } else if (
        liveAddress &&
        (liveAddress !== frozenAddress || (liveSheet && liveSheet !== frozenSheet))
      ) {
        nextAddress = live.rawAddress || live.address || nextAddress;
        nextSheet = liveSheet || nextSheet;
        if (liveWorkbook) {
          nextWorkbook = liveWorkbook;
        }
      }
    }
    return {
      sourceAddress: nextAddress,
      sourceSnapshotHash: frozenFp.sourceSnapshotHash || "",
      instruction: instruction || "",
      workbookId: nextWorkbook,
      sheetName: nextSheet
    };
  }

  function returnToExcelSmartFillEdit(preview) {
    if (!preview || preview.consumed || preview.status === "locked") {
      return preview;
    }
    preview.editingInputs = true;
    return preview;
  }

  function syncExcelSmartFillPreviewWithInputs(preview, nextFingerprint) {
    if (!preview || preview.consumed || preview.status === "locked") {
      return preview;
    }
    if (excelSmartFillFingerprintsEqual(preview.fingerprint, nextFingerprint)) {
      return preview;
    }
    preview.status = "invalid";
    preview.editingInputs = true;
    preview.invalidReason = "来源范围或填写意图已变化，旧预览已失效。请重新生成后再写入。";
    return preview;
  }

  function markExcelSmartFillPreviewTargetRejected(preview, message) {
    if (!preview) {
      return preview;
    }
    preview.targetError = String(message || "目标预检失败。");
    return preview;
  }

  function clearExcelSmartFillPreviewTargetError(preview) {
    if (!preview) {
      return preview;
    }
    preview.targetError = "";
    return preview;
  }

  function resetExcelSmartFillDraftWriteConflicts(drafts) {
    var list = Array.isArray(drafts) ? drafts : [];
    list.forEach(function (draft) {
      if (draft && draft.status === "write_conflict") {
        draft.status = "completed";
        draft.selected = true;
      }
    });
    return list;
  }

  function markExcelSmartFillPreviewWriteFailed(preview, details) {
    var info = details || {};
    var addresses = Array.isArray(info.addresses) ? info.addresses.slice() : [];
    var reason = String(info.message || "写入失败。");
    if (!preview) {
      return preview;
    }
    preview.consumed = false;
    if (preview.status !== "invalid") {
      preview.status = "ready";
    }
    preview.manualReviewAddresses = addresses;
    if (!info.compensated && addresses.length) {
      reason += " 以下地址需要人工核对：" + addresses.join("、");
    }
    preview.writeFailureReason = reason;
    return preview;
  }

  function describeExcelSmartFillPreviewLifecycle(preview, options) {
    var settings = options || {};
    var frozenSource = settings.frozenSource;
    var hasFrozenSource = frozenSource === undefined
      ? true
      : Boolean(frozenSource && frozenSource.snapshotHash);
    var empty = !preview || !preview.result;
    var status = empty
      ? "empty"
      : (preview.status || (preview.consumed ? "locked" : "ready"));
    var invalid = status === "invalid";
    var locked = status === "locked" || Boolean(preview && preview.consumed);
    var writeEnabled = !empty && status === "ready" && !locked && hasFrozenSource;
    var reason = preview && preview.invalidReason ? String(preview.invalidReason) : "";
    var writeFailureReason = preview && preview.writeFailureReason
      ? String(preview.writeFailureReason)
      : "";
    var manualReviewAddresses = preview && Array.isArray(preview.manualReviewAddresses)
      ? preview.manualReviewAddresses.slice()
      : [];
    var writtenCount = preview ? Number(preview.writtenCount || 0) : 0;
    var skippedCount = preview ? Number(preview.skippedCount || 0) : 0;
    var summary = locked
      ? ("写入 " + writtenCount + " 个单元格，跳过 " + skippedCount + " 个。")
      : "";
    return {
      status: locked ? "locked" : status,
      writeEnabled: writeEnabled,
      showReturnToEdit: !empty && !locked && !invalid && !preview.editingInputs,
      showStartNew: locked,
      sourceInputsVisible: empty || Boolean(preview && preview.editingInputs) || invalid,
      previewReadonly: empty ? false : (locked || invalid),
      reason: reason,
      targetError: preview && preview.targetError ? String(preview.targetError) : "",
      writeFailureReason: writeFailureReason,
      manualReviewAddresses: manualReviewAddresses,
      overallWriteSuccess: false,
      writtenCount: writtenCount,
      skippedCount: skippedCount,
      summary: summary
    };
  }

  function resolveExcelSmartFillLifecycleControls(preview, options) {
    var life = describeExcelSmartFillPreviewLifecycle(preview, options);
    var busy = Boolean(options && options.busy);
    var empty = life.status === "empty";
    var locked = life.status === "locked";
    var editing = Boolean(preview && preview.editingInputs);
    return {
      generateHidden: empty ? false : (locked || (!editing && life.status === "ready")),
      generateDisabled: busy,
      writeHidden: empty || locked,
      writeDisabled: busy || !life.writeEnabled,
      returnToEditHidden: !life.showReturnToEdit,
      startNewHidden: !life.showStartNew,
      startNewDisabled: busy || !locked,
      sourceInputsHidden: !life.sourceInputsVisible
    };
  }

  function buildExcelSmartFillLifecyclePreview(preview, targets, drafts, options) {
    var life = describeExcelSmartFillPreviewLifecycle(preview, options);
    var html = [];
    var result = preview && preview.result;
    if (life.status === "invalid") {
      html.push(
        '<div class="smart-fill-lifecycle-banner is-invalid" role="status">',
        "<strong>失效智能填写预览</strong>",
        '<p class="field-hint">' + escapeHtml(life.reason) + "</p>",
        "</div>"
      );
    }
    if (life.writeFailureReason) {
      html.push(
        '<div class="smart-fill-lifecycle-banner is-write-failed" role="status">',
        '<p class="field-hint">' + escapeHtml(life.writeFailureReason) + "</p>",
        "</div>"
      );
    }
    if (life.status === "locked") {
      html.push(
        '<div class="smart-fill-lifecycle-banner is-locked" role="status">',
        "<strong>智能填写已写入</strong>",
        '<p class="field-hint">' + escapeHtml(life.summary) + "</p>",
        "</div>"
      );
    }
    if (life.targetError) {
      html.push(
        '<p class="field-hint" role="status">' + escapeHtml(life.targetError) + "</p>"
      );
    }
    if (!result) {
      return html.join("");
    }
    if (life.previewReadonly) {
      html.push(buildExcelSmartFillReadonlyPreview(result, targets || []));
    } else {
      html.push(buildExcelSmartFillEditorPreview(result, targets || [], drafts || [], options));
    }
    return html.join("");
  }

  function consumeExcelSmartFillPreview(preview) {
    if (!preview || preview.consumed || !preview.result) {
      throw new Error("同一预览不能重复提交写入。");
    }
    preview.consumed = true;
    preview.status = "locked";
    return preview;
  }

  function finalizeExcelSmartFillWriteSuccess(preview, summary) {
    var counts = summary || {};
    if (preview && preview.consumed) {
      throw new Error("同一预览不能重复提交写入。");
    }
    try {
      consumeExcelSmartFillPreview(preview);
    } catch (error) {
      if (preview && !preview.result) {
        preview.consumed = true;
        preview.status = "locked";
      } else {
        throw error;
      }
    }
    if (preview) {
      preview.writtenCount = Number(counts.writtenCount || 0);
      preview.skippedCount = Number(counts.skippedCount || 0);
      preview.editingInputs = false;
      preview.writeFailureReason = "";
      preview.targetError = "";
    }
    return preview;
  }

  function startNewExcelSmartFill(preview) {
    return null;
  }

  function sanitizeRestoredExcelSmartFillState(stateLike) {
    var input = stateLike || {};
    return {
      smartFillResult: input.smartFillResult || null,
      smartFillSource: input.smartFillSource || null,
      smartFillItems: Array.isArray(input.smartFillItems) ? input.smartFillItems : [],
      smartFillTarget: null,
      smartFillLiveTarget: null
    };
  }

  function normalizeExcelSmartFillA1Address(value) {
    var text = String(value || "").replace(/^.*!/, "").replace(/\$/g, "").toUpperCase();
    var parts = text.split(":");
    if (parts.length === 2 && parts[0] === parts[1]) {
      return parts[0];
    }
    return text;
  }

  function excelSmartFillItemsAddressRange(items) {
    var list = Array.isArray(items) ? items : [];
    var first;
    var last;
    if (!list.length) {
      return "";
    }
    first = normalizeExcelSmartFillA1Address(list[0] && list[0].address);
    last = normalizeExcelSmartFillA1Address(list[list.length - 1] && list[list.length - 1].address);
    if (!first) {
      return "";
    }
    return first === last ? first : first + ":" + last;
  }

  function validateExcelSmartFillTarget(target) {
    var items = target && Array.isArray(target.items) ? target.items : [];
    var firstRow;
    var firstColumn;
    if (!items.length) {
      throw new Error("未读取到明确目标区域，请先选中需要填写的单元格。");
    }
    firstRow = Number(items[0].row);
    firstColumn = Number(items[0].column);
    if (!isFinite(firstRow) || !isFinite(firstColumn)) {
      throw new Error("智能填写目标缺少有效的行列坐标。");
    }
    items.forEach(function (item, index) {
      if (Number(item.column) !== firstColumn) {
        throw new Error("智能填写目标必须是连续的单列区域。");
      }
      if (Number(item.row) !== firstRow + index) {
        throw new Error("智能填写目标必须是连续的单列区域。");
      }
      if (item.isFormula || item.isMerged || item.isProtected || item.isHidden ||
          ["blank", "text", "number", "boolean", "date"].indexOf(item.originalValueType || "blank") === -1) {
        throw new Error("目标区域包含公式、合并、受保护或隐藏单元格，无法执行智能填写。");
      }
    });
    return true;
  }

  function checkExcelSmartFillRangesOverlap(addr1, addr2) {
    if (!addr1 || !addr2) {
      return false;
    }
    var p1 = String(addr1).replace(/^.*!/, "").split(":");
    var p2 = String(addr2).replace(/^.*!/, "").split(":");
    var r1Start = parseExcelA1Cell(p1[0]);
    var r1End = parseExcelA1Cell(p1[1] || p1[0]);
    var r2Start = parseExcelA1Cell(p2[0]);
    var r2End = parseExcelA1Cell(p2[1] || p2[0]);
    if (!r1Start || !r1End || !r2Start || !r2End) {
      return false;
    }
    var r1MinRow = Math.min(r1Start.row, r1End.row);
    var r1MaxRow = Math.max(r1Start.row, r1End.row);
    var r1MinCol = Math.min(r1Start.column, r1End.column);
    var r1MaxCol = Math.max(r1Start.column, r1End.column);
    var r2MinRow = Math.min(r2Start.row, r2End.row);
    var r2MaxRow = Math.max(r2Start.row, r2End.row);
    var r2MinCol = Math.min(r2Start.column, r2End.column);
    var r2MaxCol = Math.max(r2Start.column, r2End.column);
    return Math.max(r1MinRow, r2MinRow) <= Math.min(r1MaxRow, r2MaxRow) &&
           Math.max(r1MinCol, r2MinCol) <= Math.min(r1MaxCol, r2MaxCol);
  }

  function getSmartFillRangeCell(range, relativeRow, relativeCol, sheetRow, sheetCol) {
    if (!range) {
      return null;
    }
    var cells = range.Cells || range.cells;
    if (cells && typeof cells.Item === "function") {
      try {
        var cell = cells.Item(relativeRow, relativeCol);
        if (cell) {
          return cell;
        }
      } catch (err) {}
      try {
        var absCell = cells.Item(sheetRow, sheetCol);
        if (absCell) {
          return absCell;
        }
      } catch (err2) {}
    }
    if (cells && typeof cells === "object") {
      return cells[sheetRow + "," + sheetCol] || cells[relativeRow + "," + relativeCol] || null;
    }
    return null;
  }

  function inspectExcelSmartFillTargetSelection(range, options) {
    var settings = options || {};
    var source = settings.source || {};
    var expectedSheet = settings.sourceSheetName || source.sheetName || "";
    var expectedAddress = settings.sourceAddress || source.address || "";
    var previewItems = Array.isArray(settings.previewItems) ? settings.previewItems : [];
    var draftItems = Array.isArray(settings.draftItems) ? settings.draftItems : [];
    var expectedCount = typeof settings.itemCount === "number" ? settings.itemCount : previewItems.length;
    var rawAddress;
    var address;
    var sheetName;
    var rows;
    var columns;
    var areas;

    if (!range) {
      return {
        ok: false,
        summary: "写入位置：未检测到目标选区",
        error: "未读取到明确目标区域，请先在工作表中选择目标单元格。"
      };
    }

    try {
      rawAddress = typeof range.Address === "function" ? range.Address() : range.Address;
    } catch (e) {
      rawAddress = "";
    }
    if (!rawAddress) {
      return {
        ok: false,
        summary: "写入位置：未检测到目标选区",
        error: "未读取到明确目标区域，请先在工作表中选择目标单元格。"
      };
    }

    address = displayExcelSmartFillSourceAddress(rawAddress);
    try {
      sheetName = (range.Worksheet && range.Worksheet.Name) || settings.targetSheetName || "";
    } catch (e) {
      sheetName = settings.targetSheetName || "";
    }
    try {
      rows = Number((range.Rows && range.Rows.Count) || 0);
      columns = Number((range.Columns && range.Columns.Count) || 0);
      areas = Number((range.Areas && range.Areas.Count) || 1);
    } catch (e) {
      return {
        ok: false,
        summary: "写入位置：" + address,
        error: "无法安全读取目标区域尺寸，请重新选择目标。"
      };
    }

    // 1. Same worksheet
    if (expectedSheet && sheetName && sheetName !== expectedSheet) {
      return {
        ok: false,
        sheetName: sheetName,
        address: address,
        rawAddress: rawAddress,
        cellCount: rows,
        summary: "写入位置：" + address,
        error: "目标区域必须与来源位于同一工作表（" + expectedSheet + "）。"
      };
    }

    // 2. Single column continuous
    if (areas > 1 || columns !== 1) {
      return {
        ok: false,
        sheetName: sheetName,
        address: address,
        rawAddress: rawAddress,
        cellCount: rows,
        summary: "写入位置：" + address,
        error: "目标区域必须是连续单列区域。"
      };
    }

    // 3. Count matching total preview items
    if (expectedCount > 0 && rows !== expectedCount) {
      return {
        ok: false,
        sheetName: sheetName,
        address: address,
        rawAddress: rawAddress,
        cellCount: rows,
        summary: "写入位置：" + address,
        error: "目标单元格数量（" + rows + "）与填写项数量（" + expectedCount + "）不一致，请选择包含 " + expectedCount + " 个单元格的单列区域。"
      };
    }

    // 4. Overlap with source
    if (expectedAddress && checkExcelSmartFillRangesOverlap(expectedAddress, rawAddress)) {
      return {
        ok: false,
        sheetName: sheetName,
        address: address,
        rawAddress: rawAddress,
        cellCount: rows,
        summary: "写入位置：" + address,
        error: "目标区域不得与来源数据区域重叠。"
      };
    }

    // 5. Check cell safety & count overwrites
    var origin = parseExcelA1Cell(String(rawAddress).split(":")[0]);
    var startRow = origin ? origin.row : 1;
    var startCol = origin ? origin.column : 1;
    var draftById = {};
    draftItems.forEach(function (d) {
      if (d && d.itemId) {
        draftById[d.itemId] = d;
      }
    });

    var writableCount = 0;
    var overwriteCount = 0;
    var r;
    for (r = 1; r <= rows; r += 1) {
      var sheetRow = startRow + r - 1;
      var cell = getSmartFillRangeCell(range, r, 1, sheetRow, startCol);
      if (!cell) {
        return {
          ok: false,
          sheetName: sheetName,
          address: address,
          rawAddress: rawAddress,
          summary: "写入位置：" + address,
          error: "无法安全读取目标单元格状态。"
        };
      }
      var snapshot = readSmartFillCellSnapshot(cell);
      if (!snapshot || !snapshot.readable) {
        return {
          ok: false,
          sheetName: sheetName,
          address: address,
          rawAddress: rawAddress,
          summary: "写入位置：" + address,
          error: "无法安全读取目标单元格状态。"
        };
      }
      if (snapshot.isFormula) {
        return {
          ok: false,
          sheetName: sheetName,
          address: address,
          rawAddress: rawAddress,
          summary: "写入位置：" + address,
          error: "目标区域包含公式单元格，智能填写禁止覆盖公式。"
        };
      }
      if (snapshot.isMerged) {
        return {
          ok: false,
          sheetName: sheetName,
          address: address,
          rawAddress: rawAddress,
          summary: "写入位置：" + address,
          error: "目标区域包含合并单元格，智能填写不支持写入合并单元格。"
        };
      }
      if (snapshot.isHidden) {
        return {
          ok: false,
          sheetName: sheetName,
          address: address,
          rawAddress: rawAddress,
          summary: "写入位置：" + address,
          error: "目标区域包含隐藏单元格，无法执行智能填写。"
        };
      }
      if (snapshot.isProtected) {
        return {
          ok: false,
          sheetName: sheetName,
          address: address,
          rawAddress: rawAddress,
          summary: "写入位置：" + address,
          error: "目标区域包含受保护单元格，无法执行智能填写。"
        };
      }

      var previewItem = previewItems[r - 1];
      var itemId = previewItem ? previewItem.itemId : "";
      var draft = itemId ? draftById[itemId] : null;
      var isCompleted = previewItem ? previewItem.status === "completed" : false;
      var isSelected = draft ? Boolean(draft.selected) : isCompleted;
      var isWriteable = isCompleted && isSelected && (!draft || Boolean(String(draft.value || "").trim()));
      if (isWriteable) {
        writableCount += 1;
        var existingText = String(snapshot.rawValue != null ? snapshot.rawValue : (snapshot.text || "")).trim();
        if (snapshot.valueType !== "blank" && existingText.length > 0) {
          overwriteCount += 1;
        }
      }
    }

    return {
      ok: true,
      sheetName: sheetName,
      address: address,
      rawAddress: rawAddress,
      cellCount: rows,
      writableCount: writableCount,
      overwriteCount: overwriteCount,
      summary: "写入位置：" + address + " · " + rows + " 个单元格 · 将写入 " + writableCount + " 项",
      error: ""
    };
  }

  function mapExcelSmartFillPreviewToTarget(range, options) {
    var settings = options || {};
    var source = settings.source || {};
    var previewItems = Array.isArray(settings.previewItems) ? settings.previewItems : [];
    var inspection = inspectExcelSmartFillTargetSelection(range, settings);
    if (!inspection.ok) {
      throw new Error(inspection.error || "目标选区无效。");
    }
    var origin = parseExcelA1Cell(String(inspection.rawAddress).split(":")[0]);
    var startRow = origin ? origin.row : 1;
    var startCol = origin ? origin.column : 1;

    var jobId = String(settings.jobId || "");
    var workbookId = String(settings.workbookId || "");
    var sourceSnapshotHash = String((source && source.snapshotHash) || settings.sourceSnapshotHash || "");
    var resultRevision = settings.resultRevision || 1;

    var targetItems = previewItems.map(function (item, index) {
      var sheetRow = startRow + index;
      var sheetColumn = startCol;
      var colLetters = "";
      var tempCol = sheetColumn;
      while (tempCol > 0) {
        var rem = (tempCol - 1) % 26;
        colLetters = String.fromCharCode(65 + rem) + colLetters;
        tempCol = Math.floor((tempCol - 1) / 26);
      }
      var cellAddress = "$" + colLetters + "$" + sheetRow;
      var cell = getSmartFillRangeCell(range, index + 1, 1, sheetRow, sheetColumn);
      if (!cell) {
        throw new Error("无法安全读取目标单元格状态。");
      }
      var snapshot = readSmartFillCellSnapshot(cell);
      if (!snapshot || !snapshot.readable) {
        throw new Error("无法安全读取目标单元格状态。");
      }
      if (snapshot.isFormula) {
        throw new Error("目标区域包含公式单元格，智能填写禁止覆盖公式。");
      }
      if (snapshot.isMerged) {
        throw new Error("目标区域包含合并单元格，智能填写不支持写入合并单元格。");
      }
      if (snapshot.isHidden) {
        throw new Error("目标区域包含隐藏单元格，无法执行智能填写。");
      }
      if (snapshot.isProtected) {
        throw new Error("目标区域包含受保护单元格，无法执行智能填写。");
      }

      return {
        itemId: item.itemId,
        address: cellAddress,
        row: sheetRow,
        column: sheetColumn,
        originalValue: String(snapshot.rawValue == null ? "" : snapshot.rawValue),
        originalValueType: snapshot.valueType || "blank",
        originalFormula: snapshot.formula || "",
        isFormula: snapshot.isFormula || false,
        isMerged: snapshot.isMerged || false,
        isProtected: snapshot.isProtected || false,
        isHidden: snapshot.isHidden || false,
        snapshotHash: snapshot.snapshotHash || "",
        originalSnapshot: snapshot
      };
    });

    var target = {
      sheetName: inspection.sheetName,
      address: inspection.rawAddress,
      items: targetItems
    };

    var commitContext = {
      jobId: jobId,
      workbookId: workbookId,
      sourceSnapshotHash: sourceSnapshotHash,
      resultRevision: resultRevision,
      targetSheetName: inspection.sheetName,
      targetAddress: inspection.rawAddress,
      itemCount: targetItems.length
    };

    return {
      ok: true,
      jobId: jobId,
      schemaVersion: "excel.smart_fill.v2",
      workbookId: workbookId,
      sourceSnapshotHash: sourceSnapshotHash,
      resultRevision: resultRevision,
      sheetName: inspection.sheetName,
      address: inspection.rawAddress,
      items: targetItems,
      target: target,
      commitContext: commitContext,
      writableCount: inspection.writableCount,
      overwriteCount: inspection.overwriteCount
    };
  }

  function scalarText(value) {
    return toSafeString(value, "").replace(/\r/g, "");
  }

  function readSmartFillPropertyState(owner, keys, preserveObject) {
    var keyIndex;
    var rawValue;
    var value;
    if (!owner) {
      return { known: true, present: false, value: undefined };
    }
    for (keyIndex = 0; keyIndex < keys.length; keyIndex += 1) {
      try {
        rawValue = owner[keys[keyIndex]];
        if (typeof rawValue === "function") {
          rawValue = rawValue.call(owner);
        }
      } catch (error) {
        return { known: false, present: true, value: undefined };
      }
      if (typeof rawValue === "undefined" || rawValue === null) {
        continue;
      }
      if (preserveObject) {
        return { known: true, present: true, value: rawValue };
      }
      value = resolveScalarValue(rawValue);
      if (typeof value === "undefined" || value === null) {
        return { known: false, present: true, value: undefined };
      }
      return { known: true, present: true, value: value };
    }
    return { known: true, present: false, value: undefined };
  }

  function isDateNumberFormat(fmt) {
    var cleaned;
    if (typeof fmt !== "string") {
      return false;
    }
    cleaned = fmt.replace(/"[^"]*"/g, "");
    return /[yYmMdDhHsS]/.test(cleaned) && !/^\s*0(?:\.0+)?%?\s*$/.test(cleaned);
  }

  function isDateCell(cell, rawValue) {
    var formatState;
    if (rawValue instanceof Date) {
      return true;
    }
    if (typeof rawValue === "number" && cell) {
      formatState = readSmartFillPropertyState(cell, [
        "NumberFormat", "numberFormat", "NumberFormatLocal", "numberFormatLocal"
      ], false);
      if (formatState && formatState.present && isDateNumberFormat(formatState.value)) {
        return true;
      }
    }
    return false;
  }

  function readSmartFillBooleanState(owner, keys) {
    var state = readSmartFillPropertyState(owner, keys, false);
    var value;
    if (!state.known || !state.present) {
      return { known: state.known, present: state.present, value: null };
    }
    value = state.value;
    if (typeof value === "boolean") {
      return { known: true, present: true, value: value };
    }
    if (typeof value === "number" && isFinite(value)) {
      return { known: true, present: true, value: value !== 0 };
    }
    if (typeof value === "string") {
      if (/^(true|yes|1|是)$/i.test(value.trim())) {
        return { known: true, present: true, value: true };
      }
      if (/^(false|no|0|否)$/i.test(value.trim())) {
        return { known: true, present: true, value: false };
      }
    }
    return { known: false, present: true, value: null };
  }

  function readSmartFillFormulaState(cell) {
    var hasFormula = readSmartFillBooleanState(cell, ["HasFormula", "hasFormula"]);
    var formulaState = readSmartFillPropertyState(cell, [
      "Formula", "formula", "FormulaLocal", "formulaLocal", "FormulaR1C1", "formulaR1C1"
    ], false);
    var formula = formulaState.present ? scalarText(formulaState.value).trim() : "";
    if (!hasFormula.known || !formulaState.known) {
      return { known: false, value: "", isFormula: false };
    }
    return {
      known: true,
      value: formula.charAt(0) === "=" ? formula : "",
      isFormula: hasFormula.value === true || formula.charAt(0) === "="
    };
  }

  function readSmartFillProtectedState(cell) {
    var worksheetState = readSmartFillPropertyState(cell, ["Worksheet", "worksheet"], true);
    var explicitlyProtected = readSmartFillBooleanState(cell, ["Protected", "protected"]);
    var locked = readSmartFillBooleanState(cell, ["Locked", "locked"]);
    var sheetProtected;
    if (!worksheetState.known || !explicitlyProtected.known || !locked.known) {
      return { known: false, value: false };
    }
    if (explicitlyProtected.value === true) {
      return { known: true, value: true };
    }
    if (locked.value !== true) {
      return { known: true, value: false };
    }
    if (!worksheetState.present || !worksheetState.value) {
      return { known: true, value: true };
    }
    sheetProtected = readSmartFillBooleanState(worksheetState.value, [
      "ProtectContents", "protectContents", "ProtectionMode", "protectionMode",
      "Protected", "protected"
    ]);
    if (!sheetProtected.known) {
      return { known: true, value: true };
    }
    return { known: true, value: sheetProtected.value !== false };
  }

  function readSmartFillHiddenState(cell) {
    var direct = readSmartFillBooleanState(cell, ["Hidden", "hidden"]);
    var rowOwner = readSmartFillPropertyState(cell, ["EntireRow", "entireRow"], true);
    var columnOwner = readSmartFillPropertyState(cell, ["EntireColumn", "entireColumn"], true);
    var rowHidden;
    var columnHidden;
    if (!direct.known || !rowOwner.known || !columnOwner.known) {
      return { known: false, value: false };
    }
    rowHidden = readSmartFillBooleanState(rowOwner.present ? rowOwner.value : null, ["Hidden", "hidden"]);
    columnHidden = readSmartFillBooleanState(columnOwner.present ? columnOwner.value : null, ["Hidden", "hidden"]);
    if (!rowHidden.known || !columnHidden.known) {
      return { known: false, value: false };
    }
    return {
      known: true,
      value: direct.value === true || rowHidden.value === true || columnHidden.value === true
    };
  }

  function classifySmartFillSnapshotValue(text, formula, rawValue, cell) {
    if (formula) {
      return "formula";
    }
    if (!text && (typeof rawValue === "undefined" || rawValue === null || rawValue === "")) {
      return "blank";
    }
    if (typeof rawValue === "boolean") {
      return "boolean";
    }
    if (isDateCell(cell, rawValue)) {
      return "date";
    }
    if (typeof rawValue === "number") {
      return "number";
    }
    if (/^#(?:N\/A|VALUE!|REF!|DIV\/0!|NAME\?|NUM!|NULL!)/i.test(text)) {
      return "error";
    }
    return text ? "text" : "unknown";
  }

  function readSmartFillCellSnapshot(cell) {
    var rawState = readSmartFillPropertyState(cell, ["Value2", "value2", "Value", "value"], false);
    var textState = readSmartFillPropertyState(cell, ["Text", "text"], false);
    var formulaState = readSmartFillFormulaState(cell);
    var mergedState = readSmartFillBooleanState(cell, ["MergeCells", "mergeCells", "Merged", "merged"]);
    var protectedState = readSmartFillProtectedState(cell);
    var hiddenState = readSmartFillHiddenState(cell);
    var rawValue;
    var text;
    if (!rawState.known || !textState.known ||
        !formulaState.known || !mergedState.known || !protectedState.known ||
        !hiddenState.known) {
      return { readable: false };
    }
    if (!rawState.present) {
      text = scalarText(textState.present ? textState.value : "");
      if (text !== "") {
        return { readable: false };
      }
      rawValue = undefined;
    } else {
      rawValue = rawState.value;
      text = scalarText(textState.present ? textState.value : rawValue);
    }
    return {
      readable: true,
      text: text,
      formula: formulaState.value,
      isFormula: formulaState.isFormula,
      isMerged: mergedState.value === true,
      isProtected: protectedState.value === true,
      isHidden: hiddenState.value === true,
      rawValue: rawValue,
      valueType: classifySmartFillSnapshotValue(text, formulaState.value, rawValue, cell)
    };
  }

  function sameSmartFillSnapshot(item, current) {
    if (item && item.originalSnapshot) {
      return sameSmartFillSnapshotState(item.originalSnapshot, current);
    }
    var valueMatches = Boolean(
      item && current && (
        String(item.originalValue || "") === current.text ||
        (current.rawValue != null && String(item.originalValue || "") === String(current.rawValue))
      )
    );
    return Boolean(
      item && current && current.readable &&
      valueMatches &&
      String(item.originalFormula || "") === current.formula &&
      Boolean(item.isFormula) === current.isFormula &&
      Boolean(item.isMerged) === current.isMerged &&
      Boolean(item.isProtected) === current.isProtected &&
      Boolean(item.isHidden) === current.isHidden &&
      (!item.originalValueType || item.originalValueType === current.valueType)
    );
  }

  function sameSmartFillSnapshotState(expected, current) {
    var rawValuesEqual = Boolean(
      expected && current && (
        expected.rawValue === current.rawValue ||
        (expected.valueType === "blank" && current.valueType === "blank")
      )
    );
    if (expected && current && !rawValuesEqual &&
        typeof expected.rawValue === "number" && typeof current.rawValue === "number" &&
        isNaN(expected.rawValue) && isNaN(current.rawValue)) {
      rawValuesEqual = true;
    }
    if (expected && current && !rawValuesEqual &&
        expected.rawValue instanceof Date && current.rawValue instanceof Date &&
        expected.rawValue.getTime() === current.rawValue.getTime()) {
      rawValuesEqual = true;
    }
    var textMatches = Boolean(
      expected.text === current.text ||
      (rawValuesEqual && (expected.valueType === "number" || expected.valueType === "date"))
    );
    return Boolean(expected && current && current.readable && rawValuesEqual &&
      textMatches &&
      expected.formula === current.formula &&
      expected.isFormula === current.isFormula &&
      expected.isMerged === current.isMerged &&
      expected.isProtected === current.isProtected &&
      expected.isHidden === current.isHidden &&
      expected.valueType === current.valueType);
  }

  function smartFillWriteValueMatches(current, value, valueType) {
    if (!current || !current.readable || current.isFormula || current.formula) {
      return false;
    }
    if (valueType === "number") {
      if (current.valueType !== "number" || typeof current.rawValue !== "number") {
        return false;
      }
      if (isNaN(value)) {
        return isNaN(current.rawValue);
      }
      return current.rawValue === value || Math.abs(current.rawValue - value) < 1e-9;
    }
    if (valueType === "text") {
      if (current.valueType !== "text" && current.valueType !== "unknown") {
        return false;
      }
      var expectedStr = String(value);
      var textMatches = current.text === expectedStr || current.text === "'" + expectedStr;
      var rawMatches = typeof current.rawValue === "string" &&
        (current.rawValue === expectedStr || current.rawValue === "'" + expectedStr);
      return textMatches && rawMatches;
    }
    return false;
  }

  function detectExcelSmartFillConflicts(targetItems, getCell, candidateItemIds) {
    var items = Array.isArray(targetItems) ? targetItems : [];
    var conflicts = [];
    var filterActive = Array.isArray(candidateItemIds);
    var candidateIdMap = {};
    if (typeof getCell !== "function") {
      return { hasConflict: false, conflicts: [] };
    }
    if (filterActive) {
      candidateItemIds.forEach(function (id) {
        if (id) {
          candidateIdMap[id] = true;
        }
      });
    }
    items.forEach(function (item) {
      if (filterActive && !candidateIdMap[item.itemId]) {
        return;
      }
      var cell = getCell(item);
      var current;
      if (!cell) {
        conflicts.push({ itemId: item.itemId, address: item.address, reason: "cell_unavailable" });
        return;
      }
      current = readSmartFillCellSnapshot(cell);
      if (!current.readable) {
        conflicts.push({ itemId: item.itemId, address: item.address, reason: "unreadable" });
        return;
      }
      if (current.isFormula || current.formula) {
        conflicts.push({ itemId: item.itemId, address: item.address, reason: "formula_detected" });
        return;
      }
      if (current.isMerged) {
        conflicts.push({ itemId: item.itemId, address: item.address, reason: "merged" });
        return;
      }
      if (current.isProtected) {
        conflicts.push({ itemId: item.itemId, address: item.address, reason: "protected" });
        return;
      }
      if (current.isHidden) {
        conflicts.push({ itemId: item.itemId, address: item.address, reason: "hidden" });
        return;
      }
      if (!sameSmartFillSnapshot(item, current)) {
        conflicts.push({ itemId: item.itemId, address: item.address, reason: "content_changed" });
      }
    });
    return {
      hasConflict: conflicts.length > 0,
      conflicts: conflicts
    };
  }

  function buildExcelSmartFillEditorPreview(data, targets, drafts, options) {
    var items = data && Array.isArray(data.items) ? data.items : [];
    var targetList = Array.isArray(targets) ? targets : [];
    var draftList = Array.isArray(drafts) ? drafts : [];
    var settings = options || {};
    var retryEnabled = settings.retryEnabled !== false;
    var draftById = {};
    var targetById = {};
    var itemById = {};
    var ordered = [];
    var html = [
      '<div class="smart-fill-preview-head">',
      "<strong>智能填写预览</strong>",
      '<span class="field-hint">可编辑、取消勾选或逐项重试；未勾选项不会写入。</span>',
      "</div>"
    ];

    draftList.forEach(function (draft) {
      if (draft && draft.itemId) {
        draftById[draft.itemId] = draft;
      }
    });

    targetList.forEach(function (target) {
      if (target && target.itemId) {
        targetById[target.itemId] = target;
      }
    });

    items.forEach(function (item) {
      if (item && item.itemId) {
        itemById[item.itemId] = item;
      }
    });

    if (targetList.length) {
      targetList.forEach(function (target) {
        if (target && target.itemId) {
          ordered.push(itemById[target.itemId] || target);
        }
      });
    } else {
      ordered = items.slice();
    }

    if (!ordered.length) {
      html.push('<p class="field-hint">未返回可展示的目标结果。</p>');
      return html.join("");
    }

    html.push('<div class="smart-fill-result-list">');
    ordered.forEach(function (item) {
      var itemId = item ? item.itemId : "";
      var target = targetById[itemId] || {};
      var draft = draftById[itemId] || {};
      var address = target.sourceRowLabel || (item && item.sourceRowLabel) || target.address || itemId;
      var status = draft.status || (item ? item.status : "unprocessed");
      var completed = status === "completed";
      var insufficient = status === "insufficient_information";
      var failed = status === "failed";
      var unprocessed = status === "unprocessed";
      var conflict = status === "write_conflict";

      var statusLabel = completed
        ? "可写入"
        : (conflict
          ? "写入冲突"
          : (failed
            ? "失败"
            : (unprocessed ? "未处理" : "信息不足")));

      var statusClass = completed
        ? "is-complete"
        : (conflict
          ? "is-conflict"
          : (failed
            ? "is-failed"
            : (unprocessed ? "is-unprocessed" : "is-insufficient")));

      var value = typeof draft.value !== "undefined"
        ? String(draft.value == null ? "" : draft.value)
        : (completed ? String(item.value == null ? "" : item.value) : "");

      var valueType = draft.valueType || (item && item.valueType) || "text";
      var inputType = valueType === "number" ? "number" : "text";
      var interactive = completed && !conflict;
      var checked = typeof draft.selected !== "undefined"
        ? (interactive && Boolean(draft.selected))
        : interactive;
      var disabledAttr = interactive ? "" : ' disabled="disabled"';

      html.push(
        '<article class="smart-fill-result-item" data-smart-fill-item-id="' + escapeHtml(itemId) + '">',
        '<div class="smart-fill-result-meta">',
        '<label class="smart-fill-result-select">',
        '<input type="checkbox" data-smart-fill-select="' + escapeHtml(itemId) + '"' +
          (checked ? " checked" : "") + disabledAttr + ' aria-label="选择 ' + escapeHtml(address) + '">',
        "<span>" + escapeHtml(address) + "</span>",
        "</label>",
        '<span class="smart-fill-result-status ' + statusClass + '">' + statusLabel + "</span>",
        "</div>",
        '<div class="smart-fill-result-edit">',
        '<input class="smart-fill-result-value" type="' + inputType + '" data-smart-fill-value-input="' +
          escapeHtml(itemId) + '" value="' + escapeHtml(value) + '"' +
          (inputType === "number" ? ' step="any"' : "") +
          disabledAttr +
          ' aria-label="编辑 ' + escapeHtml(address) + '">',
        retryEnabled
          ? ('<button type="button" class="ghost-action mini-button" data-smart-fill-retry="' +
            escapeHtml(itemId) + '">重新生成此项</button>')
          : "",
        "</div>",
        "</article>"
      );
    });
    html.push("</div>");
    return html.join("");
  }

  function validateExcelSmartFillDraft(draft) {
    var value;
    var valueType;
    var codePoints;
    if (!draft || !draft.selected) {
      return { isWriteable: false, valid: true, value: "" };
    }
    value = String(draft.value == null ? "" : draft.value);
    if (!value.trim()) {
      return { isWriteable: false, valid: false, error: "填写内容不能为空" };
    }
    valueType = draft.valueType === "number" ? "number" : "text";
    if (valueType === "number") {
      if (!isFinite(Number(value))) {
        return { isWriteable: false, valid: false, error: "数字格式无效" };
      }
    }
    codePoints = Array.from ? Array.from(value).length : value.length;
    if (codePoints > 2000) {
      return { isWriteable: false, valid: false, error: "单单元格文本超出 2000 字符限制" };
    }
    return {
      isWriteable: true,
      valid: true,
      value: valueType === "number" ? Number(value) : value,
      valueType: valueType,
      codePoints: codePoints
    };
  }

  function calculateExcelSmartFillDraftsSummary(drafts, targetItems) {
    var draftList = Array.isArray(drafts) ? drafts : [];
    var targetList = Array.isArray(targetItems) ? targetItems : [];
    var targetById = {};
    var writableCount = 0;
    var overwriteCount = 0;
    var totalCodePoints = 0;

    targetList.forEach(function (target) {
      if (target && target.itemId) {
        targetById[target.itemId] = target;
      }
    });

    draftList.forEach(function (draft) {
      var validation;
      var target;
      if (!draft || !draft.selected) {
        return;
      }
      validation = validateExcelSmartFillDraft(draft);
      if (validation.isWriteable) {
        writableCount += 1;
        totalCodePoints += validation.codePoints || 0;
        target = targetById[draft.itemId];
        if (target && ["text", "number", "boolean", "date"].indexOf(target.originalValueType) >= 0 &&
            String(target.originalValue || "").trim()) {
          overwriteCount += 1;
        }
      }
    });

    return {
      writableCount: writableCount,
      overwriteCount: overwriteCount,
      totalCodePoints: totalCodePoints,
      canWrite: writableCount > 0 && totalCodePoints <= 200000,
      summaryText: writableCount > 0
        ? "将写入 " + writableCount + " 个单元格；未勾选或信息不足项不会写入。"
        : "尚无可写入的智能填写预览。"
    };
  }

  function writeExcelSmartFillCells(targetItems, results, getCell, options) {
    var items = Array.isArray(targetItems) ? targetItems : [];
    var output = Array.isArray(results) ? results : [];
    var settings = options || {};
    var commitContext = settings.commitContext || (settings.jobId ? settings : null);
    var resultById = {};
    var plans = [];
    var written = [];
    var totalPlanCodePoints = 0;
    var index;

    if (commitContext) {
      if (!commitContext.jobId || typeof commitContext.jobId !== "string" || !commitContext.jobId.trim()) {
        throw new Error("提交映射缺少有效的任务标识。");
      }
      if (!commitContext.workbookId || typeof commitContext.workbookId !== "string" || !commitContext.workbookId.trim()) {
        throw new Error("提交映射缺少有效的工作簿标识。");
      }
      if (!commitContext.sourceSnapshotHash || typeof commitContext.sourceSnapshotHash !== "string" || !commitContext.sourceSnapshotHash.trim()) {
        throw new Error("提交映射缺少有效的来源快照哈希。");
      }
      if (typeof commitContext.itemCount === "number" && commitContext.itemCount !== items.length) {
        throw new Error("提交映射目标单元格数量与实际不符。");
      }
      if (commitContext.targetAddress) {
        var commitAddress = normalizeExcelSmartFillA1Address(commitContext.targetAddress);
        var liveAddress = excelSmartFillItemsAddressRange(items);
        if (commitAddress && liveAddress && commitAddress !== liveAddress) {
          throw new Error("提交映射目标地址与当前选区不符，已拒绝沿用旧绑定。");
        }
      }
      if (commitContext.targetSheetName && items[0] && items[0].sheetName &&
          commitContext.targetSheetName !== items[0].sheetName) {
        throw new Error("提交映射工作表与目标不符。");
      }
    }

    if (items.length !== output.length || typeof getCell !== "function") {
      throw new Error("智能填写结果与目标单元格数量不一致。");
    }
    output.forEach(function (result) {
      if (!result || !result.itemId || resultById[result.itemId]) {
        throw new Error("智能填写结果包含重复或无效的目标标识。");
      }
      resultById[result.itemId] = result;
    });

    for (index = 0; index < items.length; index += 1) {
      var item = items[index];
      var result = resultById[item.itemId];
      var cell;
      var current;
      var strVal;
      var codePoints;
      if (!result) {
        throw new Error("智能填写结果缺少目标单元格。");
      }
      if (result.status === "insufficient_information" || result.status === "failed" || result.status === "unprocessed" || result.skip === true) {
        plans.push({ item: item, cell: null, result: result, current: null, skip: true });
        continue;
      }
      cell = getCell(item);
      if (!cell) {
        throw new Error("目标单元格不可用，已停止写回。");
      }
      current = readSmartFillCellSnapshot(cell);
      if (!current.readable) {
        throw new Error("目标单元格状态无法安全读取，已停止写回。");
      }
      if (item.isFormula || item.isMerged || item.isProtected || item.isHidden ||
          current.isFormula || current.isMerged || current.isProtected || current.isHidden ||
          current.formula) {
        throw new Error("目标区域包含公式、合并、受保护或隐藏单元格，已停止写回。");
      }
      if (!sameSmartFillSnapshot(item, current)) {
        throw new Error("目标单元格内容已变化，请重新生成预览后再写入。");
      }
      if (result.status !== "completed" || (result.valueType !== "text" && result.valueType !== "number")) {
        throw new Error("智能填写结果不完整，已停止写回。");
      }
      if (result.valueType === "number" &&
          (typeof result.value !== "number" || !isFinite(result.value))) {
        throw new Error("智能填写数字结果无效，已停止写回。");
      }
      if (result.valueType === "text") {
        strVal = String(result.value || "");
        if (!strVal.trim()) {
          throw new Error("智能填写文本结果为空，已停止写回。");
        }
        codePoints = Array.from ? Array.from(strVal).length : strVal.length;
        if (codePoints > 2000) {
          throw new Error("智能填写文本超出 2000 字符限制，已停止写回。");
        }
        totalPlanCodePoints += codePoints;
      }
      plans.push({ item: item, cell: cell, result: result, current: current, skip: false });
    }

    if (totalPlanCodePoints > 200000) {
      throw new Error("智能填写总文本超出 200000 字符限制，已停止写回。");
    }

    try {
      plans.forEach(function (plan) {
        var value;
        var storedValue;
        var afterWrite;
        var entry;
        if (plan.skip) {
          return;
        }
        value = plan.result.valueType === "number" ? plan.result.value : String(plan.result.value);
        storedValue = plan.result.valueType === "text" && /^[=+\-@]/.test(value)
          ? "'" + value
          : value;
        entry = {
          address: plan.item.address || plan.item.itemId || "未知地址",
          cell: plan.cell,
          previousValue: plan.current.rawValue,
          previousSnapshot: plan.current
        };
        written.push(entry);
        plan.cell.Value2 = storedValue;
        afterWrite = readSmartFillCellSnapshot(plan.cell);
        if (!afterWrite.readable || !smartFillWriteValueMatches(afterWrite, value, plan.result.valueType)) {
          throw new Error("写回后未能核对目标地址 " + plan.item.address + "。");
        }
      });
    } catch (error) {
      var rollbackFailures = [];
      written.slice().reverse().forEach(function (entry) {
        try {
          var restoreValue = entry.previousValue;
          if (typeof restoreValue === "undefined" || restoreValue === null) {
            restoreValue = "";
          }
          entry.cell.Value2 = restoreValue;
          if (!sameSmartFillSnapshotState(entry.previousSnapshot, readSmartFillCellSnapshot(entry.cell))) {
            rollbackFailures.push(entry.address || "未知地址");
          }
        } catch (rollbackError) {
          rollbackFailures.push(entry.address || "未知地址");
        }
      });
      var compErr;
      if (rollbackFailures.length) {
        compErr = new Error(
          "智能填写写回失败，已尝试恢复已写入单元格；以下地址需要人工核对：" +
          rollbackFailures.join("、")
        );
        compErr.code = "COMPENSATION_FAILED";
        compErr.rollbackFailures = rollbackFailures;
        compErr.manualReviewAddresses = rollbackFailures;
        compErr.cause = error;
        throw compErr;
      }
      compErr = new Error("智能填写写回失败，已尝试恢复已写入单元格。" +
        (error && error.message ? " " + error.message : ""));
      compErr.code = "COMPENSATION_SUCCEEDED";
      compErr.rollbackFailures = [];
      compErr.cause = error;
      throw compErr;
    }
    return {
      writtenCount: written.length,
      skippedCount: plans.filter(function (plan) { return plan.skip; }).length
    };
  }

  function createExcelSelectionWatcher(options) {
    var settings = options || {};
    var refresh = typeof settings.refresh === "function" ? settings.refresh : function () {};
    var getEventSources = typeof settings.getEventSources === "function"
      ? settings.getEventSources
      : function () { return []; };
    var setTimeoutFn = typeof settings.setTimeoutFn === "function"
      ? settings.setTimeoutFn
      : (typeof setTimeout === "function" ? setTimeout : function () { return 0; });
    var clearTimeoutFn = typeof settings.clearTimeoutFn === "function"
      ? settings.clearTimeoutFn
      : (typeof clearTimeout === "function" ? clearTimeout : function () {});
    var intervalMs = typeof settings.intervalMs === "number" ? settings.intervalMs : 2000;
    var eventName = settings.eventName || "SheetSelectionChange";
    var timerId = null;
    var running = false;
    var eventSource = null;
    var eventRegistered = false;

    function safeRefresh() {
      try {
        refresh();
      } catch (error) {
        // Transient ET object failures are retried by the next host event or fallback poll.
      }
    }

    function clearFallback() {
      if (timerId !== null) {
        clearTimeoutFn(timerId);
        timerId = null;
      }
    }

    function scheduleFallback() {
      clearFallback();
      if (!running) {
        return;
      }
      timerId = setTimeoutFn(function () {
        timerId = null;
        if (!running) {
          return;
        }
        safeRefresh();
        scheduleFallback();
      }, intervalMs);
    }

    function handleSelectionChange() {
      if (!running) {
        return;
      }
      safeRefresh();
      scheduleFallback();
    }

    function registerEvent() {
      var sources;
      var index;
      var candidate;
      var result;
      try {
        sources = getEventSources();
      } catch (error) {
        sources = [];
      }
      if (!Array.isArray(sources)) {
        sources = sources ? [sources] : [];
      }
      for (index = 0; index < sources.length; index += 1) {
        candidate = sources[index];
        if (!candidate || typeof candidate.AddApiEventListener !== "function") {
          continue;
        }
        try {
          result = candidate.AddApiEventListener(eventName, handleSelectionChange);
          if (result === false) {
            continue;
          }
          eventSource = candidate;
          eventRegistered = true;
          return true;
        } catch (error) {
          // Try the next compatible WPS ET event entrypoint before falling back to polling.
        }
      }
      eventSource = null;
      eventRegistered = false;
      return false;
    }

    return {
      start: function () {
        if (running) {
          return;
        }
        running = true;
        safeRefresh();
        registerEvent();
        scheduleFallback();
      },
      stop: function () {
        if (!running) {
          return;
        }
        running = false;
        clearFallback();
        if (eventRegistered && eventSource && typeof eventSource.RemoveApiEventListener === "function") {
          try {
            eventSource.RemoveApiEventListener(eventName);
          } catch (error) {
            // Event cleanup differs across WPS ET builds; stopped polling still prevents reads.
          }
        }
        eventSource = null;
        eventRegistered = false;
      },
      isRunning: function () {
        return running;
      },
      isEventRegistered: function () {
        return eventRegistered;
      }
    };
  }

  function canDeleteWorkflowProfile(profile, activeProfileId) {
    return Boolean(profile && profile.id && profile.id !== activeProfileId);
  }

  function workflowProfileStatusText(profile, activeProfileId) {
    if (!profile || !profile.complete) {
      return "配置不完整";
    }
    return profile.id === activeProfileId ? "当前使用" : "可切换";
  }

  function workflowProfileOptionState(profile, activeProfileId) {
    var item = profile || {};
    var active = Boolean(item.id && item.id === activeProfileId);
    var configured = Boolean(item.complete);
    var name = String(item.name || "未命名配置");
    var method = item.accessMethod === "direct_model" ? "模型直连" : "工作流平台";
    return {
      id: String(item.id || ""),
      label: name + " · " + method,
      active: active,
      disabled: !configured
    };
  }

  function formatTaskModelConfigAccessMethod(accessMethod) {
    return accessMethod === "direct_model" ? "模型直连" : "工作流平台";
  }

  function formatTaskModelConfigEntry(profile, view) {
    var status = String((view && view.status) || "ready");
    var result = {
      visibleText: "",
      statusText: "",
      chevron: "›",
      ariaLabel: ""
    };
    if (status === "empty") {
      result.visibleText = "未配置";
      result.statusText = "未配置";
    } else if (status === "loading") {
      result.visibleText = "正在读取";
      result.statusText = "正在读取";
    } else if (status === "loadError") {
      result.visibleText = "配置读取失败";
      result.statusText = "配置读取失败";
    } else if (!profile) {
      result.visibleText = "未配置";
      result.statusText = "未配置";
    } else {
      var accessPart = formatTaskModelConfigAccessMethod(profile.accessMethod);
      result.visibleText = String(profile.name || "未命名配置") + " · " + accessPart;
      if (status === "busy") {
        result.statusText = "正在切换";
      } else if (status === "error") {
        result.statusText = "切换失败";
      } else {
        result.statusText = "已就绪";
      }
    }
    result.ariaLabel = result.statusText === result.visibleText
      ? result.visibleText
      : result.statusText + " " + result.visibleText;
    return result;
  }

  function resolveCurrentTaskModelConfigProfile(data, selectedId) {
    var id = String(selectedId || (data && data.activeProfileId) || "");
    var profiles = data && Array.isArray(data.profiles) ? data.profiles : [];
    var index;
    if (!id) {
      return null;
    }
    for (index = 0; index < profiles.length; index += 1) {
      if (profiles[index] && profiles[index].id === id) {
        return profiles[index];
      }
    }
    var directServices = (data && data.directServices) || [];
    for (index = 0; index < directServices.length; index += 1) {
      if (directServices[index] && directServices[index].id === id) {
        var svc = directServices[index];
        var selection = (data && data.taskModelSelection) || {};
        var effModel = selection.modelName || selection.effectiveModel || svc.defaultModel || "";
        return {
          id: svc.id,
          name: svc.name,
          accessMethod: "direct_model",
          effectiveModel: effModel,
          complete: Boolean(svc.serviceBaseUrl && svc.keyConfigured),
          serviceBaseUrl: svc.serviceBaseUrl,
          keyConfigured: svc.keyConfigured
        };
      }
    }
    return null;
  }

  function buildTaskModelConfigMenuItems(profiles, options) {
    var activeId = options && options.activeProfileId || "";
    var items = [];
    var directServices = (options && options.directServices) || [];
    var taskSelection = options && options.taskModelSelection;

    (profiles || []).forEach(function (profile) {
      var option = workflowProfileOptionState(profile, activeId);
      items.push({
        id: option.id,
        action: "select",
        label: option.label,
        selected: option.active,
        disabled: option.disabled
      });
    });

    directServices.forEach(function (svc) {
      var isCurrent = svc.id === activeId;
      var effModel = (taskSelection && taskSelection.serviceId === svc.id && (taskSelection.modelName || taskSelection.effectiveModel)) || svc.defaultModel || "默认模型";
      var label = (svc.name || "直连服务") + " · 模型直连 · " + effModel;
      items.push({
        id: svc.id,
        action: "select",
        label: label,
        selected: isCurrent,
        disabled: !svc.keyConfigured || !svc.serviceBaseUrl
      });
    });

    items.push({
      id: "manage",
      action: "manage",
      label: "管理配置",
      selected: false,
      disabled: false
    });
    return items;
  }

  function resolveTaskModelConfigViewStatus(input) {
    var view = input || {};
    if (view.mutationBusy) {
      return "busy";
    }
    if ((view.statusByTask || {})[view.taskType] === "error") {
      return "error";
    }
    if (!view.hasLoaded) {
      return "loading";
    }
    if (view.loadError) {
      return "loadError";
    }
    if (!view.hasProfile) {
      return "empty";
    }
    return "ready";
  }

  function evaluateTaskModelConfigSwitch(request) {
    var input = request || {};
    var previousId = String(input.previousId || "");
    var requestedId = String(input.requestedId || "");
    if (input.busy || input.mutationBusy) {
      return { allowed: false, reason: "busy", nextSelectionId: previousId, restoreFocus: true };
    }
    if (input.profileComplete === false) {
      return { allowed: false, reason: "incomplete", nextSelectionId: previousId, restoreFocus: true };
    }
    if (!requestedId || requestedId === previousId) {
      return { allowed: false, reason: "unchanged", nextSelectionId: previousId, restoreFocus: false };
    }
    return { allowed: true, reason: "activate", nextSelectionId: requestedId, restoreFocus: false };
  }

  function rollbackTaskModelConfigSwitch(snapshot) {
    var input = snapshot || {};
    return {
      selectionId: String(input.previousId || ""),
      visibleText: String(input.previousLabel || ""),
      restoreFocus: true,
      statusText: "切换失败"
    };
  }

  function reduceTaskModelConfigMenuKey(state, key) {
    var current = state || {};
    var itemCount = Number(current.itemCount || 0);
    var highlightedIndex = Number(current.highlightedIndex);
    if (key === "Open") {
      var start = Number(current.highlightedIndex);
      if (!(start >= 0 && start < itemCount)) {
        start = 0;
      }
      return {
        open: true,
        itemCount: itemCount,
        highlightedIndex: start,
        action: "open",
        restoreFocus: false
      };
    }
    if (!current.open) {
      return {
        open: false,
        itemCount: itemCount,
        highlightedIndex: highlightedIndex,
        action: null,
        restoreFocus: false
      };
    }
    if (key === "ArrowDown") {
      if (highlightedIndex < itemCount - 1) {
        highlightedIndex += 1;
      }
      return {
        open: true,
        itemCount: itemCount,
        highlightedIndex: highlightedIndex,
        action: null,
        restoreFocus: false
      };
    }
    if (key === "ArrowUp") {
      if (highlightedIndex > 0) {
        highlightedIndex -= 1;
      }
      return {
        open: true,
        itemCount: itemCount,
        highlightedIndex: highlightedIndex,
        action: null,
        restoreFocus: false
      };
    }
    if (key === "Enter") {
      var item = (current.items || [])[highlightedIndex] || {};
      if (item.action === "manage") {
        return {
          open: false,
          itemCount: itemCount,
          highlightedIndex: highlightedIndex,
          action: "manage",
          restoreFocus: false
        };
      }
      return {
        open: false,
        itemCount: itemCount,
        highlightedIndex: highlightedIndex,
        action: "select",
        selectedIndex: highlightedIndex,
        restoreFocus: true
      };
    }
    if (key === "Escape") {
      return {
        open: false,
        itemCount: itemCount,
        highlightedIndex: -1,
        action: "close",
        restoreFocus: true
      };
    }
    return {
      open: true,
      itemCount: itemCount,
      highlightedIndex: highlightedIndex,
      restoreFocus: false
    };
  }

  function validateWorkflowProfileDraft(draft, mode) {
    var value = draft || {};
    var name = String(value.name || "").trim();
    var note = String(value.note || "").trim();
    var apiKey = String(value.apiKey || "").trim();
    if (!name) {
      return { ok: false, field: "name", message: "请输入模型配置名称。" };
    }
    if (name.length > 40) {
      return { ok: false, field: "name", message: "模型配置名称不能超过 40 个字。" };
    }
    if (note.length > 200) {
      return { ok: false, field: "note", message: "模型配置备注不能超过 200 个字。" };
    }
    return { ok: true, name: name, note: note, apiKey: apiKey };
  }

  function validateDirectServiceDraft(draft, mode) {
    var input = draft || {};
    var name = String(input.name || "").trim();
    var url = String(input.serviceBaseUrl || "").trim();
    var apiKey = (input.apiKey !== undefined ? String(input.apiKey) : (input.key !== undefined ? String(input.key) : "")).trim();
    var isNew = input.isNew !== undefined ? Boolean(input.isNew) : (mode === "create");
    var keyConfigured = Boolean(input.keyConfigured);

    function fail(msg) {
      return { valid: false, ok: false, error: msg, message: msg };
    }

    if (!name) {
      return fail("请输入配置名称。");
    }
    if (name.length > 40) {
      return fail("配置名称不能超过 40 个字符。");
    }
    if (/[\x00-\x1f\x7f]/.test(name)) {
      return fail("配置名称不能包含控制字符。");
    }
    if (!url) {
      return fail("请输入服务地址。");
    }
    if (!/^https?:\/\//i.test(url)) {
      return fail("服务地址必须以 http:// 或 https:// 开头。");
    }
    if (isNew && !keyConfigured && !apiKey) {
      return fail("新建直连服务必须配置 API Key。");
    }
    if (apiKey && /[\x00-\x1f\x7f]/.test(apiKey)) {
      return fail("API Key 不能包含控制字符。");
    }
    return { valid: true, ok: true, error: "", message: "" };
  }

  function getDirectServiceCatalogState(service) {
    var value = service || {};
    var nested = value.modelCatalog && typeof value.modelCatalog === "object"
      ? value.modelCatalog
      : {};
    var models = Array.isArray(nested.models)
      ? nested.models.slice()
      : (Array.isArray(value.modelList) ? value.modelList.slice() : []);
    var fetchedAt = nested.fetchedAt || value.modelListFetchedAt || null;
    var expiresAt = nested.expiresAt || value.modelListExpiresAt || null;
    var status = String(nested.status || value.modelListStatus || "").trim();
    var cacheStatus = String(nested.cacheStatus || value.modelListCacheStatus || "").trim();
    var fetchStatus = String(nested.fetchStatus || value.modelListFetchStatus || "").trim();
    if (!status && !cacheStatus && !fetchStatus && !fetchedAt && models.length) {
      status = "available";
      cacheStatus = "valid";
      fetchStatus = "success";
    }
    if (!status) {
      if (cacheStatus === "valid") {
        status = models.length ? "available" : "empty";
      } else if (cacheStatus === "expired" || fetchedAt) {
        status = "expired";
      } else {
        status = "unavailable";
      }
    }
    if (!cacheStatus) {
      cacheStatus = status === "available" || status === "empty" ? "valid" : (status === "expired" ? "expired" : "empty");
    }
    if (!fetchStatus) {
      fetchStatus = fetchedAt ? "success" : "not_attempted";
    }
    var manualModelAllowed = nested.manualModelAllowed !== undefined
      ? Boolean(nested.manualModelAllowed)
      : (value.manualModelAllowed !== undefined
        ? Boolean(value.manualModelAllowed)
        : cacheStatus !== "valid" || status === "empty");
    var usableForSelection = nested.usableForSelection !== undefined
      ? Boolean(nested.usableForSelection)
      : status === "available" && models.length > 0;
    return {
      status: status,
      cacheStatus: cacheStatus,
      fetchStatus: fetchStatus,
      models: models,
      fetchedAt: fetchedAt,
      expiresAt: expiresAt,
      lastAttemptAt: nested.lastAttemptAt || value.modelListLastAttemptAt || null,
      lastError: nested.lastError || value.modelListError || null,
      manualModelAllowed: manualModelAllowed,
      usableForSelection: usableForSelection
    };
  }

  function isDirectServiceManualModelAllowed(service) {
    return getDirectServiceCatalogState(service).manualModelAllowed;
  }

  function validateTaskModelSelectionDraft(draft, context) {
    var input = draft || {};
    var serviceId = String(input.serviceId || "").trim();
    if (!serviceId) {
      return { valid: false, ok: false, error: "请选择共享直连服务。" };
    }
    if (input.temperature !== undefined && input.temperature !== null && input.temperature !== "") {
      var t = Number(input.temperature);
      if (isNaN(t) || t < 0 || t > 2) {
        return { valid: false, ok: false, error: "温度参数必须在 0 到 2 之间。" };
      }
    }
    if (input.maxOutputTokens !== undefined && input.maxOutputTokens !== null && input.maxOutputTokens !== "") {
      var m = Number(input.maxOutputTokens);
      if (isNaN(m) || m < 0 || Math.floor(m) !== m) {
        return { valid: false, ok: false, error: "最大输出 Token 必须是非负整数，0 或空表示不限。" };
      }
    }
    if (input.contextWindowTokens !== undefined && input.contextWindowTokens !== null && input.contextWindowTokens !== "") {
      var c = Number(input.contextWindowTokens);
      if (isNaN(c) || c < 0 || Math.floor(c) !== c) {
        return { valid: false, ok: false, error: "上下文容量必须是非负整数，0 或空表示不限。" };
      }
    }
    if (input.customModel) {
      var customName = String(input.modelName || "").trim();
      if (!customName) {
        return { valid: false, ok: false, error: "自定义模型名称不能为空。" };
      }
      var customService = context && context.service;
      if (customService) {
        var customCatalog = getDirectServiceCatalogState(customService);
        if (!customCatalog.manualModelAllowed || customCatalog.usableForSelection) {
          return { valid: false, ok: false, error: "模型目录可用时不能使用高级手填模型。" };
        }
      }
    } else if (context && context.service) {
      var selectedCatalog = getDirectServiceCatalogState(context.service);
      var selectedName = String(input.modelName || "").trim();
      if (selectedCatalog.status === "expired") {
        return { valid: false, ok: false, error: "模型目录已过期，请先刷新目录。" };
      }
      if (selectedCatalog.cacheStatus === "invalidated") {
        return { valid: false, ok: false, error: "模型目录已因服务地址或 API Key 变更失效，请先刷新目录。" };
      }
      if (selectedCatalog.status === "empty" || selectedCatalog.status === "unavailable") {
        return { valid: false, ok: false, error: "模型目录当前不可用，请先刷新目录。" };
      }
      if (selectedCatalog.usableForSelection && selectedName && selectedCatalog.models.indexOf(selectedName) < 0) {
        return { valid: false, ok: false, error: "所选模型已从最新目录移除，请重新选择。" };
      }
    }
    return { valid: true, ok: true, error: "" };
  }

  function validateDirectTaskSelectionReadiness(selection, service, taskStatus) {
    var current = selection || {};
    var svc = (service && service.service) ? service.service : service;
    var status = taskStatus || {};
    var serviceId = String(current.serviceId || (svc && svc.id) || "").trim();
    var modelName = String(current.modelName || (svc && svc.defaultModel) || "").trim();
    var customModel = Boolean(current.customModel);
    var reason;
    var draftResult;

    if (status.accessMethod && status.accessMethod !== "direct_model") {
      return { valid: true, ok: true, applicable: false, error: "" };
    }
    if (!serviceId || !svc) {
      return { valid: false, ok: false, applicable: true, error: "直连服务状态尚未加载，请刷新设置后重试。" };
    }

    draftResult = validateTaskModelSelectionDraft(
      {
        serviceId: serviceId,
        modelName: modelName,
        customModel: customModel
      },
      { service: svc }
    );
    if (!draftResult.ok) {
      return {
        valid: false,
        ok: false,
        applicable: true,
        error: draftResult.error || "当前模型目录状态不允许提交任务。"
      };
    }

    if (current.modelAvailable === false || current.modelAvailability === "unverified") {
      reason = String(current.modelUnavailableReason || current.modelAvailability || "");
      if (reason === "cache_expired" || reason === "expired") {
        return { valid: false, ok: false, applicable: true, error: "模型目录已过期，请先刷新目录。" };
      }
      if (reason === "catalog_usable") {
        return { valid: false, ok: false, applicable: true, error: "模型目录当前可用，不能使用高级手填模型；请从目录选择。" };
      }
      if (reason === "validation_required" || reason === "unverified") {
        return { valid: false, ok: false, applicable: true, error: "高级手填模型尚未通过真实任务调用验证，请先验证模型。" };
      }
      if (reason === "catalog_unavailable" || reason === "catalog_empty") {
        return { valid: false, ok: false, applicable: true, error: "模型目录当前不可用；请刷新目录，或使用高级手填并验证真实任务调用。" };
      }
      if (reason === "disappeared") {
        return { valid: false, ok: false, applicable: true, error: "所选模型已从最新目录移除，请重新选择。" };
      }
      return { valid: false, ok: false, applicable: true, error: "当前模型不可用，不能发起新任务；请重新选择模型。" };
    }

    return { valid: true, ok: true, applicable: true, error: "" };
  }

  function shouldActivateNewWorkflowProfile(profileCount, requested) {
    return Number(profileCount || 0) === 0 || Boolean(requested);
  }

  var DIRECT_SERVICE_TASK_LABELS = {
    "excel.analysis": "表格智能分析",
    "excel.formula_assistant": "表格公式助手",
    "excel.smart_fill": "表格智能填写",
    "word.smart_write": "文字智能编写",
    "word.smart_imitation": "文字智能仿写",
    "word.document_review": "文字文档审查",
    "word.format_review": "文字排版审查",
    "ppt.slide_assistant": "幻灯片智能助手",
    "ppt.structure_review": "幻灯片结构审查"
  };

  function formatReferencedTasks(tasks) {
    if (!Array.isArray(tasks) || !tasks.length) {
      return "";
    }
    return tasks.map(function (t) {
      return DIRECT_SERVICE_TASK_LABELS[t] || t;
    }).join("、");
  }

  function evaluateDirectServiceDelete(service) {
    var s = service || {};
    var referenced = Array.isArray(s.referencedTasks) ? s.referencedTasks : [];
    if (referenced.length > 0) {
      return {
        canDelete: false,
        referencedTasks: referenced,
        reason: "in_use",
        message: "该服务正被以下任务使用：" + formatReferencedTasks(referenced) + "，无法删除。请先在对应任务中切换或解除引用。"
      };
    }
    return {
      canDelete: true,
      referencedTasks: [],
      reason: "",
      message: ""
    };
  }

  function evaluateDirectServiceUrlImpact(service, draftUrl) {
    var s = service || {};
    var origUrl = String(s.serviceBaseUrl || "").trim();
    var newUrl = String(draftUrl || "").trim();
    var isModified = Boolean(origUrl && newUrl && origUrl !== newUrl);
    var referenced = Array.isArray(s.referencedTasks) ? s.referencedTasks : [];
    var warning = isModified && referenced.length > 0
      ? "修改服务地址将影响以下任务：" + formatReferencedTasks(referenced) + "。保存后这些任务将立即调用新地址。"
      : "";
    var res = new String(warning);
    res.isModified = isModified;
    res.referencedCount = referenced.length;
    res.referencedTasks = referenced;
    res.warning = warning;
    res.message = warning;
    return res;
  }

  function isDirectServiceRevisionConflict(error) {
    if (!error) {
      return false;
    }
    var code = String(error.adapterCode || error.code || (error.data && error.data.code) || "");
    var msg = String(error.message || "");
    var status = error.status || error.statusCode;
    return code === "DIRECT_SERVICE_REVISION_CONFLICT" || status === 409 || msg.indexOf("冲突") !== -1 || msg.indexOf("conflict") !== -1;
  }

  function normalizeExcelReportList(value) {
    if (Array.isArray(value)) {
      return value.map(function (item) {
        return String(item || "").trim();
      }).filter(Boolean);
    }
    if (typeof value === "string" && value.trim()) {
      return [value.trim()];
    }
    return [];
  }

  function buildExcelAnalysisMarkdown(data) {
    var report = (data && data.structuredReport) || {};
    var findings = normalizeExcelReportList(report.findings);
    var risks = normalizeExcelReportList(report.risks);
    var actions = normalizeExcelReportList(report.actions);
    return [
      "## 数据概览",
      report.overview || "未返回数据概览。",
      "",
      "## 关键发现",
      findings.length ? findings.map(function (item) { return "- " + item; }).join("\n") : "- 未返回关键发现。",
      "",
      "## 风险异常",
      risks.length ? risks.map(function (item) { return "- " + item; }).join("\n") : "- 未返回风险异常。",
      "",
      "## 建议动作",
      actions.length ? actions.map(function (item) { return "- " + item; }).join("\n") : "- 未返回建议动作。"
    ].join("\n");
  }

  function presentExcelAnalysisResultView(input) {
    var source = input || {};
    var result = source.result || {};
    var view = source.view === "plain" ? "plain" : "preview";
    var reportMarkdown = buildExcelAnalysisMarkdown(result);
    var plainText = result.plainText || "";
    if (view === "plain") {
      return {
        presentation: "source",
        displayMarkdown: plainText,
        html: "",
        sourceText: plainText,
        copyText: plainText,
        viewLabels: { preview: "分析报告", plain: "汇报段落" }
      };
    }
    return {
      presentation: "rendered",
      displayMarkdown: reportMarkdown,
      html: renderMarkdown(reportMarkdown),
      sourceText: "",
      copyText: reportMarkdown,
      viewLabels: { preview: "分析报告", plain: "汇报段落" }
    };
  }

  function shouldShowExcelResultViewSwitch(mode) {
    return mode === "excelAnalysis";
  }

  var _workbookSessionMap = typeof WeakMap === "function" ? new WeakMap() : null;
  var _workbookSessionByIdentity = {};
  var _workbookSessionByWindow = {};
  var _workbookIdentityByWindow = {};
  var _workbookIdentityBySession = {};
  var _workbookSessionGeneration = 0;

  function hashDocumentIdentity(value, seed) {
    var text = String(value || "");
    var hash = seed >>> 0;
    var index;
    for (index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
      hash >>>= 0;
    }
    return ("00000000" + hash.toString(16)).slice(-8);
  }

  function getWorkbookWindowHandle(workbook) {
    var windows = safeRead(workbook, "Windows") || safeRead(workbook, "windows");
    var windowObject;
    var handle;
    if (typeof windows === "function") {
      windows = safeCall(windows, workbook);
    }
    windowObject = getCollectionItem(windows, 1);
    handle = safeRead(windowObject, "Hwnd");
    if (typeof handle === "undefined" || handle === null) {
      handle = safeRead(windowObject, "HWND");
    }
    if (typeof handle === "function") {
      handle = safeCall(handle, windowObject);
    }
    handle = String(handle === null || typeof handle === "undefined" ? "" : handle).trim();
    return handle && handle !== "0" ? handle : "";
  }

  function getWorkbookIdentityKey(workbook) {
    var fullName = "";
    var name = "";
    var path = "";
    var identity;
    try {
      fullName = workbook.FullName || workbook.fullName || "";
    } catch (e) {}
    try {
      name = workbook.Name || workbook.name || "";
    } catch (e) {}
    try {
      path = workbook.Path || workbook.path || "";
    } catch (e) {}
    fullName = String(fullName || "").trim().replace(/\\/g, "/");
    name = String(name || "").trim();
    path = String(path || "").trim().replace(/\\/g, "/");
    identity = fullName || name;
    if (!identity) {
      return "";
    }
    return (path || /\//.test(fullName) ? "full:" : "name:") + identity;
  }

  function makeStableDocumentSessionId(identity) {
    if (!identity) {
      return "";
    }
    return "doc_session_v2_" +
      hashDocumentIdentity(identity, 2166136261) +
      hashDocumentIdentity(identity, 2246822507) +
      "_" + identity.length.toString(36);
  }

  function getDocumentSessionId(workbook) {
    var identityKey;
    var windowHandle;
    var previousWindowIdentity;
    var ownerIdentity;
    var stableSessionId;
    var existing = null;
    if (!workbook) {
      return "doc_session_default";
    }
    identityKey = getWorkbookIdentityKey(workbook);
    windowHandle = getWorkbookWindowHandle(workbook);
    previousWindowIdentity = windowHandle ? _workbookIdentityByWindow[windowHandle] : "";
    if (previousWindowIdentity && identityKey && previousWindowIdentity !== identityKey) {
      existing = _workbookSessionByWindow[windowHandle] || "";
      if (_workbookSessionByIdentity[previousWindowIdentity] === existing) {
        delete _workbookSessionByIdentity[previousWindowIdentity];
      }
    }
    if (identityKey && _workbookSessionByIdentity[identityKey]) {
      existing = _workbookSessionByIdentity[identityKey];
    } else if (windowHandle && _workbookSessionByWindow[windowHandle]) {
      existing = _workbookSessionByWindow[windowHandle];
    }
    if (existing) {
      if (identityKey) {
        _workbookSessionByIdentity[identityKey] = existing;
      }
      if (windowHandle) {
        _workbookSessionByWindow[windowHandle] = existing;
        _workbookIdentityByWindow[windowHandle] = identityKey || previousWindowIdentity || "";
      }
      _workbookIdentityBySession[existing] = identityKey || previousWindowIdentity || ("window:" + windowHandle);
      return existing;
    }
    stableSessionId = makeStableDocumentSessionId(
      identityKey || (windowHandle ? "window:" + windowHandle : "")
    );
    ownerIdentity = stableSessionId ? _workbookIdentityBySession[stableSessionId] : "";
    while (stableSessionId && ownerIdentity && ownerIdentity !== identityKey) {
      _workbookSessionGeneration += 1;
      stableSessionId = makeStableDocumentSessionId(
        (identityKey || "window:" + windowHandle) +
        "|window:" + (windowHandle || "none") +
        "|generation:" + _workbookSessionGeneration
      );
      ownerIdentity = _workbookIdentityBySession[stableSessionId];
    }
    if (stableSessionId) {
      if (identityKey) {
        _workbookSessionByIdentity[identityKey] = stableSessionId;
      }
      if (windowHandle) {
        _workbookSessionByWindow[windowHandle] = stableSessionId;
        _workbookIdentityByWindow[windowHandle] = identityKey || "";
      }
      _workbookIdentityBySession[stableSessionId] = identityKey || ("window:" + windowHandle);
      return stableSessionId;
    }
    try {
      existing = workbook.__ai_wps_doc_session__;
    } catch (e) {}
    if (existing && typeof existing === "string") {
      return existing;
    }
    if (_workbookSessionMap && typeof workbook === "object") {
      try {
        existing = _workbookSessionMap.get(workbook);
      } catch (e) {}
      if (existing && typeof existing === "string") {
        return existing;
      }
    }
    var token = "doc_session_" + Math.random().toString(36).slice(2, 10) + "_" + Date.now().toString(36);
    try {
      workbook.__ai_wps_doc_session__ = token;
    } catch (e) {}
    if (_workbookSessionMap && typeof workbook === "object") {
      try {
        _workbookSessionMap.set(workbook, token);
      } catch (e) {}
    }
    return token;
  }

  function getDocumentDisplayName(workbook) {
    if (!workbook) {
      return "未命名工作簿.xlsx";
    }
    var name = "";
    try {
      name = workbook.Name || workbook.name || "";
    } catch (e) {}
    if (name) {
      var nameParts = String(name).split(/[/\\]/);
      return nameParts[nameParts.length - 1] || "未命名工作簿.xlsx";
    }
    var fullName = "";
    try {
      fullName = workbook.FullName || workbook.fullName || "";
    } catch (e) {}
    if (fullName) {
      var parts = String(fullName).split(/[/\\]/);
      return parts[parts.length - 1] || "未命名工作簿.xlsx";
    }
    return "未命名工作簿.xlsx";
  }

  function makeTaskSlotKey(host, taskType, docSessionId) {
    return [host || "et", taskType || "excel.smart_fill", docSessionId || "default"].join("::");
  }

  function isTaskSlotBusy(slots, host, taskType, docSessionId) {
    if (!slots || typeof slots !== "object") {
      return false;
    }
    var key = makeTaskSlotKey(host, taskType, docSessionId);
    return Boolean(slots[key]);
  }

  function claimTaskSlot(slots, host, taskType, docSessionId, jobId) {
    if (!slots || typeof slots !== "object") {
      return;
    }
    var key = makeTaskSlotKey(host, taskType, docSessionId);
    slots[key] = {
      jobId: jobId || "",
      claimedAt: Date.now()
    };
  }

  function releaseTaskSlot(slots, host, taskType, docSessionId, jobId) {
    if (!slots || typeof slots !== "object") {
      return;
    }
    var key = makeTaskSlotKey(host, taskType, docSessionId);
    if (!slots[key]) {
      return;
    }
    if (!jobId || slots[key].jobId === jobId) {
      delete slots[key];
    }
  }

  function renderSmartFillHistoryList(items) {
    var list = Array.isArray(items) ? items : [];
    if (!list.length) {
      return '<div class="excel-history-empty">暂无成功历史记录。</div>';
    }
    var html = '<div class="excel-history-list">';
    for (var i = 0; i < list.length; i += 1) {
      var item = list[i];
      var id = escapeHtml(item.id || "");
      var docName = escapeHtml(item.documentDisplayName || "未命名工作簿");
      var timeStr = escapeHtml(item.completedAt ? new Date(item.completedAt).toLocaleString("zh-CN") : "刚刚");
      var result = item.result || {};
      var count = (result.items && result.items.length) || result.processedItemCount || 0;
      var snippetText = "已生成 " + count + " 项填写内容";
      if (Array.isArray(result.items) && result.items.length > 0) {
        var sampleLabels = [];
        for (var j = 0; j < Math.min(3, result.items.length); j += 1) {
          var sampleItem = result.items[j];
          var rowIdx = sampleItem.sourceRowIndex || (j + 1);
          var label = "第" + rowIdx + "行";
          sampleLabels.push(label + ": " + (sampleItem.value || ""));
        }
        if (sampleLabels.length) {
          snippetText += " (" + sampleLabels.join("；") + (result.items.length > 3 ? "..." : "") + ")";
        }
      }

      html += '<div class="excel-history-card" data-history-id="' + id + '">';
      html += '  <div class="excel-history-card-header">';
      html += '    <span class="excel-history-doc-name">' + docName + '</span>';
      html += '    <span class="excel-history-time">' + timeStr + '</span>';
      html += '  </div>';
      html += '  <div class="excel-history-card-title">智能填写成果</div>';
      html += '  <div class="excel-history-card-snippet">' + escapeHtml(snippetText) + '</div>';
      html += '  <div class="excel-history-card-actions">';
      html += '    <button type="button" class="btn btn-secondary btn-sm btn-history-view" data-history-id="' + id + '">查看</button>';
      html += '    <button type="button" class="btn btn-secondary btn-sm btn-history-copy" data-history-id="' + id + '">复制</button>';
      html += '    <button type="button" class="btn btn-secondary btn-sm btn-history-delete" data-history-id="' + id + '">删除</button>';
      html += '  </div>';
      html += '</div>';
    }
    html += '</div>';
    return html;
  }

  function renderExcelAnalysisHistoryList(items) {
    var list = Array.isArray(items) ? items : [];
    if (!list.length) {
      return '<div class="excel-history-empty">暂无成功历史记录。</div>';
    }
    var html = '<div class="excel-history-list">';
    for (var i = 0; i < list.length; i += 1) {
      var item = list[i];
      var id = escapeHtml(item.id || "");
      var docName = escapeHtml(item.documentDisplayName || "未命名工作簿");
      var timeStr = escapeHtml(item.completedAt ? new Date(item.completedAt).toLocaleString("zh-CN") : "刚刚");
      var result = item.result || {};
      var report = result.structuredReport || {};
      var overview = report.overview || result.plainText || "";
      var snippetText = overview ? (overview.length > 80 ? overview.slice(0, 80) + "..." : overview) : "智能分析报告";

      html += '<div class="excel-history-card" data-history-id="' + id + '">';
      html += '  <div class="excel-history-card-header">';
      html += '    <span class="excel-history-doc-name">' + docName + '</span>';
      html += '    <span class="excel-history-time">' + timeStr + '</span>';
      html += '  </div>';
      html += '  <div class="excel-history-card-title">智能分析成果</div>';
      html += '  <div class="excel-history-card-snippet">' + escapeHtml(snippetText) + '</div>';
      html += '  <div class="excel-history-card-actions">';
      html += '    <button type="button" class="btn btn-secondary btn-sm btn-history-view" data-history-id="' + id + '">查看</button>';
      html += '    <button type="button" class="btn btn-secondary btn-sm btn-history-copy" data-history-id="' + id + '">复制</button>';
      html += '    <button type="button" class="btn btn-secondary btn-sm btn-history-delete" data-history-id="' + id + '">删除</button>';
      html += '  </div>';
      html += '</div>';
    }
    html += '</div>';
    return html;
  }

  function renderExcelFormulaHistoryList(items) {
    var list = Array.isArray(items) ? items : [];
    if (!list.length) {
      return '<div class="excel-history-empty">暂无成功历史记录。</div>';
    }
    var html = '<div class="excel-history-list">';
    for (var i = 0; i < list.length; i += 1) {
      var item = list[i];
      var id = escapeHtml(item.id || "");
      var docName = escapeHtml(item.documentDisplayName || "未命名工作簿");
      var timeStr = escapeHtml(item.completedAt ? new Date(item.completedAt).toLocaleString("zh-CN") : "刚刚");
      var result = item.result || {};
      var mode = result.mode || "generate";
      var title = mode === "explain" ? "公式解释成果" : "公式推荐成果";
      var formula = result.primaryFormula || result.copyText || "";
      var snippetText = formula || result.explanation || "已生成公式";

      html += '<div class="excel-history-card" data-history-id="' + id + '">';
      html += '  <div class="excel-history-card-header">';
      html += '    <span class="excel-history-doc-name">' + docName + '</span>';
      html += '    <span class="excel-history-time">' + timeStr + '</span>';
      html += '  </div>';
      html += '  <div class="excel-history-card-title">' + title + '</div>';
      html += '  <div class="excel-history-card-snippet">' + escapeHtml(snippetText) + '</div>';
      html += '  <div class="excel-history-card-actions">';
      html += '    <button type="button" class="btn btn-secondary btn-sm btn-history-view" data-history-id="' + id + '">查看</button>';
      html += '    <button type="button" class="btn btn-secondary btn-sm btn-history-copy" data-history-id="' + id + '">复制</button>';
      html += '    <button type="button" class="btn btn-secondary btn-sm btn-history-delete" data-history-id="' + id + '">删除</button>';
      html += '  </div>';
      html += '</div>';
    }
    html += '</div>';
    return html;
  }

  return {
    normalizeText: normalizeText,
    escapeHtml: escapeHtml,
    renderMarkdown: renderMarkdown,
    buildExcelAnalysisMarkdown: buildExcelAnalysisMarkdown,
    presentExcelAnalysisResultView: presentExcelAnalysisResultView,
    shouldShowExcelResultViewSwitch: shouldShowExcelResultViewSwitch,
    buildInlineWritebackRuns: buildInlineWritebackRuns,
    buildMarkdownWritebackBlocks: buildMarkdownWritebackBlocks,
    hasStructuredSmartWriteContent: hasStructuredSmartWriteContent,
    shouldUseStructuredSmartWriteResult: shouldUseStructuredSmartWriteResult,
    formatSmartWriteResult: formatSmartWriteResult,
    buildSmartWritePreviewModel: buildSmartWritePreviewModel,
    renderReadableFormatReview: renderReadableFormatReview,
    buildDocumentReviewRecord: buildDocumentReviewRecord,
    getEffectiveSelectionText: getEffectiveSelectionText,
    getWritableSelection: getWritableSelection,
    resolveRewriteScope: resolveRewriteScope,
    canApplyRewriteToSelection: canApplyRewriteToSelection,
    readCollectionCount: readCollectionCount,
    getCollectionItem: getCollectionItem,
    getParagraphCollection: getParagraphCollection,
    collectParagraphs: collectParagraphs,
    collectParagraphsFromSelectionSources: collectParagraphsFromSelectionSources,
    collectParagraphsFromText: collectParagraphsFromText,
    readDocumentText: readDocumentText,
    toSafeString: toSafeString,
    buildDocumentStructure: buildDocumentStructure,
    normalizeWorkflowProfileData: normalizeWorkflowProfileData,
    getActiveWorkflowProfileName: getActiveWorkflowProfileName,
    deriveModelInterfaceState: deriveModelInterfaceState,
    normalizeAdapterHealth: normalizeAdapterHealth,
    createSettingsRefreshController: createSettingsRefreshController,
    extractExcelFormulaSelection: extractExcelFormulaSelection,
    inspectExcelSmartFillSourceSelection: inspectExcelSmartFillSourceSelection,
    extractExcelSmartFillSourcePayload: extractExcelSmartFillSourcePayload,
    extractExcelSmartFillSourcePayloadYielding: extractExcelSmartFillSourcePayloadYielding,
    analyzeExcelSmartFillSourceRangeYielding: analyzeExcelSmartFillSourceRangeYielding,
    runChunkedSteps: runChunkedSteps,
    sliceExcelSmartFillSourceForRetry: sliceExcelSmartFillSourceForRetry,
    canRetryExcelSmartFillFromFrozenSource: canRetryExcelSmartFillFromFrozenSource,
    displayExcelSmartFillSourceAddress: displayExcelSmartFillSourceAddress,
    createExcelSmartFillItemId: createExcelSmartFillItemId,
    requireExcelSmartFillInstruction: requireExcelSmartFillInstruction,
    validateExcelSmartFillInstruction: validateExcelSmartFillInstruction,
    buildExcelSmartFillReadonlyPreview: buildExcelSmartFillReadonlyPreview,
    buildExcelSmartFillEditorPreview: buildExcelSmartFillEditorPreview,
    validateExcelSmartFillDraft: validateExcelSmartFillDraft,
    calculateExcelSmartFillDraftsSummary: calculateExcelSmartFillDraftsSummary,
    detectExcelSmartFillConflicts: detectExcelSmartFillConflicts,
    createExcelSmartFillPreview: createExcelSmartFillPreview,
    consumeExcelSmartFillPreview: consumeExcelSmartFillPreview,
    returnToExcelSmartFillEdit: returnToExcelSmartFillEdit,
    buildExcelSmartFillEditFingerprint: buildExcelSmartFillEditFingerprint,
    syncExcelSmartFillPreviewWithInputs: syncExcelSmartFillPreviewWithInputs,
    markExcelSmartFillPreviewTargetRejected: markExcelSmartFillPreviewTargetRejected,
    clearExcelSmartFillPreviewTargetError: clearExcelSmartFillPreviewTargetError,
    resetExcelSmartFillDraftWriteConflicts: resetExcelSmartFillDraftWriteConflicts,
    markExcelSmartFillPreviewWriteFailed: markExcelSmartFillPreviewWriteFailed,
    describeExcelSmartFillPreviewLifecycle: describeExcelSmartFillPreviewLifecycle,
    resolveExcelSmartFillLifecycleControls: resolveExcelSmartFillLifecycleControls,
    buildExcelSmartFillLifecyclePreview: buildExcelSmartFillLifecyclePreview,
    startNewExcelSmartFill: startNewExcelSmartFill,
    sanitizeRestoredExcelSmartFillState: sanitizeRestoredExcelSmartFillState,
    finalizeExcelSmartFillWriteSuccess: finalizeExcelSmartFillWriteSuccess,
    validateExcelSmartFillTarget: validateExcelSmartFillTarget,
    inspectExcelSmartFillTargetSelection: inspectExcelSmartFillTargetSelection,
    mapExcelSmartFillPreviewToTarget: mapExcelSmartFillPreviewToTarget,
    writeExcelSmartFillCells: writeExcelSmartFillCells,
    createExcelSelectionWatcher: createExcelSelectionWatcher,
    canDeleteWorkflowProfile: canDeleteWorkflowProfile,
    workflowProfileStatusText: workflowProfileStatusText,
    workflowProfileOptionState: workflowProfileOptionState,
    formatTaskModelConfigAccessMethod: formatTaskModelConfigAccessMethod,
    formatTaskModelConfigEntry: formatTaskModelConfigEntry,
    resolveCurrentTaskModelConfigProfile: resolveCurrentTaskModelConfigProfile,
    buildTaskModelConfigMenuItems: buildTaskModelConfigMenuItems,
    resolveTaskModelConfigViewStatus: resolveTaskModelConfigViewStatus,
    evaluateTaskModelConfigSwitch: evaluateTaskModelConfigSwitch,
    rollbackTaskModelConfigSwitch: rollbackTaskModelConfigSwitch,
    reduceTaskModelConfigMenuKey: reduceTaskModelConfigMenuKey,
    validateWorkflowProfileDraft: validateWorkflowProfileDraft,
    shouldActivateNewWorkflowProfile: shouldActivateNewWorkflowProfile,
    validateDirectServiceDraft: validateDirectServiceDraft,
    formatReferencedTasks: formatReferencedTasks,
    evaluateDirectServiceDelete: evaluateDirectServiceDelete,
    evaluateDirectServiceUrlImpact: evaluateDirectServiceUrlImpact,
    isDirectServiceRevisionConflict: isDirectServiceRevisionConflict,
    getDirectServiceCatalogState: getDirectServiceCatalogState,
    isDirectServiceManualModelAllowed: isDirectServiceManualModelAllowed,
    validateTaskModelSelectionDraft: validateTaskModelSelectionDraft,
    validateDirectTaskSelectionReadiness: validateDirectTaskSelectionReadiness,
    getDocumentSessionId: getDocumentSessionId,
    getDocumentDisplayName: getDocumentDisplayName,
    makeTaskSlotKey: makeTaskSlotKey,
    isTaskSlotBusy: isTaskSlotBusy,
    claimTaskSlot: claimTaskSlot,
    releaseTaskSlot: releaseTaskSlot,
    renderSmartFillHistoryList: renderSmartFillHistoryList,
    renderExcelAnalysisHistoryList: renderExcelAnalysisHistoryList,
    renderExcelFormulaHistoryList: renderExcelFormulaHistoryList
  };
});
