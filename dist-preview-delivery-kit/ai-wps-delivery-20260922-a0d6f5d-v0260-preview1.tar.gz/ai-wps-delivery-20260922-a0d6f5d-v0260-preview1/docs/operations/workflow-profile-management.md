# AI-WPS 模型配置管理

## 适用范围

九类任务使用两种接入方式：工作流平台按功能独立配置；模型直连使用共享直连服务。Word、Excel、PPT 只显示当前宿主已有功能的选项卡，互不交叉：

- Word：智能编写、智能仿写、文档审查、格式审查。
- Excel：智能分析、公式助手、智能填写。
- PPT：智能总结、结构审查。

工作流平台每项任务可保存多个配置，任务页只显示字段完整的配置。选择后立即生效，但不会改变已提交后台任务的认证和参数快照。模型直连的服务地址和 API Key 在设置首页统一维护，见 `shared-direct-service.md`。

## 接入方式

### 工作流平台

用于兼容提供类 Dify Chat API 的工作流平台。每个功能的配置独立保存：

- 配置名称和可选备注；
- 服务地址；
- API Key；
- 固定应用路径 `/chat-messages`。

Adapter 继续兼容旧版 `inputs.query` 和新版顶层 `query/files` 输入方式。界面和日志不把具体平台品牌作为通用功能名称。

### 模型直连

用于兼容 OpenAI Chat Completions 协议的模型网关。已知目标包括 GLM 5.2 和 DeepSeek V4 Flash。共享直连服务在同一 Adapter 运行环境只录入一次服务地址和 API Key；默认模型和任务模型均从该服务返回的模型目录中选择，九类任务各自保存温度、Token、图片参数。固定应用路径为 `/chat/completions`。操作步骤见 `shared-direct-service.md`，模型目录见 `direct-service-model-catalog.md`。

Adapter 将对应任务的版本化 System Prompt 与用户输入分别放入 `system`、`user` 消息。System Prompt 位于 `adapter_service/system_prompts/`，启动和交付构建会按清单哈希校验。

“最大输出 Token”和“上下文容量”在任务选择中保持选填，`0` 或留空表示不设置任务级限制；正整数不设置产品级上限。格式审查在字段留空时只按精确模型标识查询随版本离线交付的能力表；当前登记 `deepseek-v4-flash`、`deepseek-v4-pro` 和 `glm-5.2`，实际格式语义调用仍受 `4096` Token 任务上限约束。模型标识无法精确匹配时，确定性格式审查继续执行，但模型语义补充要求管理员显式填写该字段。格式审查直连验证见 `word-format-review-direct-validation.md`。

## 新建与验证

工作流平台：

1. 打开当前宿主的“设置”。
2. 选择任务选项卡，点击“新建模型配置”。
3. 填写服务地址、配置名称和对应字段。
4. 工作流平台的 API Key 须输入两次；也可以先保存不完整配置，稍后补充。
5. 完整配置可设为当前，并可执行一次验证调用。

共享直连服务在设置首页新建，Key 只录入一次。任务验证由功能页主动发起，不随服务保存自动执行九类付费调用。

验证调用会真实访问模型后台。失败只记录到当前配置或当前任务选择，不会自动切换到其他配置。

模型直连返回空最终正文时，高级诊断只记录 `finish_reason`、`content` 类型、是否存在推理字段和 Token 用量，不记录正文或推理内容。`MODEL_FINAL_CONTENT_TOKEN_LIMIT` 表示输出预算耗尽后仍无最终正文；`MODEL_FINAL_CONTENT_FILTERED` 表示最终结果被模型内容策略过滤；其它空结果继续使用 `MODEL_FINAL_CONTENT_MISSING`。

对 `word.format_review`，工作流平台验证四类 `format_semantics.v1` 操作；模型直连验证生产格式语义契约的 `classify_role` 操作。验证请求只包含合成候选和快照绑定，不包含用户文档或密钥正文。

## 修改、复制与删除

工作流平台：

- 留空 API Key 保存时，原 Key 保持不变。
- “复制”创建同任务的未激活副本，不复制密钥正文；补齐并验证后再启用。
- 当前配置不能直接删除，应先切换到其他完整配置。
- 删除配置会删除其独立密钥文件，无法恢复。

共享直连服务的替换、清除、修订冲突和引用删除保护见 `shared-direct-service.md`。不得把直连 Key 当作普通文本字段编辑。

## 旧配置迁移

首次启动 `v0.23.0-alpha` 时，原工作流档案会原位迁移为 `workflow_platform` 模型配置，复用原密钥引用，不移动、不覆盖、不删除密钥文件。旧 `/provider/workflow-profiles` API 保留一个版本作为兼容包装。

旧任务直连配置按规范化地址和 Key 指纹合并为共享直连服务，见 `shared-direct-service.md`。`POST/PATCH /provider/model-configurations` 不再接受 `direct_model` 写入。

运行时不再从统一 URL 或统一 Key 回退。不完整配置保留在设置页，不能用于验证或提交。

## 存储与升级保护

- 非密钥配置保存在 `config/adapter.json`。
- API Key 正文保存在 `run/provider_api_keys/`，文件权限为 `0600`。
- 查询、诊断和日志不返回密钥正文。
- 覆盖安装必须备份并恢复 `config/adapter.json`、`run/provider_api_key`、`run/provider_api_keys/` 和写作规范数据库。
- 交付包不得包含开发机的 `adapter.json`、数据库、备份、日志或任何 API Key。

## 故障排查

1. 工作流任务页下拉菜单中不存在目标配置，表示该功能的工作流配置不完整。
2. 直连任务看不到可用服务时，先检查设置首页共享直连服务的地址、Key 和模型目录。
3. 保存后执行“验证调用”，查看耗时和错误摘要；服务验证成功不等于任务验证成功。
4. 在“高级诊断”核对配置 ID、接入方式、请求路径、System Prompt 版本和错误码。
5. 长任务已提交但任务窗格短暂断开时，不要重复提交；重新打开对应任务页，按文档会话恢复未结束任务。活动结果与历史见 `task-result-lifecycle.md`。
