function OnAddinLoad(ribbonUI) {
  if (typeof window.Application.ribbonUI !== "object") {
    window.Application.ribbonUI = ribbonUI;
  }

  if (typeof window.Application.Enum !== "object" && typeof WPS_Enum !== "undefined") {
    window.Application.Enum = WPS_Enum;
  }

  return true;
}

function resolveMode(controlId) {
  var modeMap = {
    btnAiExcelAnalysis: "excelAnalysis",
    btnAiExcelFormulaAssistant: "excelFormulaAssistant",
    btnAiExcelSmartFill: "excelSmartFill",
    btnAiExcelLedger: "excelLedger",
    btnAiSettings: "settings"
  };
  return modeMap[controlId] || "excelAnalysis";
}

var ribbonIconMap = {
  btnAiExcelAnalysis: "assets/icon-excel-analysis.png",
  btnAiExcelFormulaAssistant: "assets/icon-excel-formula-assistant.png",
  btnAiExcelSmartFill: "assets/icon-excel-smart-fill.png",
  btnAiExcelLedger: "assets/icon-excel-material-ledger.png",
  btnAiSettings: "assets/icon-settings.png"
};

function GetImage(control) {
  var controlId = control && (control.Id || control.id);
  return ribbonIconMap[controlId] || "assets/ai-assistant-32.png";
}

function closeCurrentTaskPane() {
  var current = window.Application.WpsAiAssistantTaskPane;
  if (!current) {
    return;
  }

  try {
    current.Visible = false;
  } catch (error) {
    // Some WPS builds expose stale taskpane handles after manual close.
  }
}

function OnAction(control) {
  try {
    var mode = resolveMode(control.Id || control.id);
    var url = location.href.replace(/[^\/]*$/, "");
    closeCurrentTaskPane();
    var taskPane = window.Application.CreateTaskPane(
      url + "taskpane.html?mode=" + encodeURIComponent(mode) + "&build=0.26.0-preview.1-97c21e5ba5a0"
    );
    window.Application.WpsAiAssistantTaskPane = taskPane;
    taskPane.Visible = true;
  } catch (error) {
    window.Application.confirm("错误：" + error.message);
  }

  return true;
}
