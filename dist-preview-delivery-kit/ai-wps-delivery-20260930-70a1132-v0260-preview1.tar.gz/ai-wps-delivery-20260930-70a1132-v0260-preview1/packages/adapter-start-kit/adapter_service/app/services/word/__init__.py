# Word capability services package.
