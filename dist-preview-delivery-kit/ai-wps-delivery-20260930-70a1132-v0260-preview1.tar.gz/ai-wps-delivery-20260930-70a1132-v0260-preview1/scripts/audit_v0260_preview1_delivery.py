#!/usr/bin/env python3
"""Audit the neutral v0.26.0-preview.1 delivery boundary."""

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Set


VERSION = "0.26.0-preview.1"
VERSION_RULE_RE = re.compile(
    r"^AI-WPS-WORD-EXCEL-PPT-0\.26\.0-preview\.1-"
    r"(?P<date>[0-9]{8})-(?P<source>[0-9a-f]{7,40})$"
)
BASELINE_ARCHIVE_RE = re.compile(
    r"^ai-wps-phase1-delivery-[0-9]{8}(?:-[0-9a-f]{7,40})?-v0253\.tar\.gz$"
)
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
EXPECTED_TASKS = frozenset(
    {
        "word.smart_write",
        "word.smart_imitation",
        "word.material_composer",
        "word.document_review",
        "word.format_review",
        "excel.analysis",
        "excel.formula_assistant",
        "excel.smart_fill",
        "excel.material_ledger",
        "ppt.slide_assistant",
        "ppt.structure_review",
        "ppt.material_outline",
        "ppt.template_page",
    }
)
FORBIDDEN_OUTPUT_PATHS = {
    "installer/install_phase1.sh",
    "scripts/phase1_smoke_test.sh",
    "reference-workflows/excel-smart-fill-v1.yml",
}
REQUIRED_OUTPUTS = {
    "README.md",
    "release-manifest.json",
    "release-allowlist.json",
    "installer/install_ai_wps.sh",
    "scripts/ai_wps_smoke_test.sh",
    "scripts/audit_delivery.py",
    "scripts/audit_v0260_preview1_delivery.py",
    "scripts/python38_delivery_runtime_gate.py",
    "scripts/python38_delivery_lifecycle_gate.py",
    "docs/v0260-preview1-target-machine-acceptance.md",
    "docs/v0260-preview1-candidate-status.json",
    "release-file-hashes.json",
}


class DeliveryFailure(RuntimeError):
    pass


def load_json(path: Path, code: str) -> Dict:
    if not path.is_file():
        raise DeliveryFailure(code)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise DeliveryFailure(code) from exc
    if not isinstance(value, dict):
        raise DeliveryFailure(code)
    return value


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def delivery_files(root: Path) -> Set[str]:
    files: Set[str] = set()
    for path in root.rglob("*"):
        if path.is_symlink():
            raise DeliveryFailure(
                "V0260_DELIVERY_SYMLINK_REJECTED {0}".format(
                    path.relative_to(root).as_posix()
                )
            )
        if path.is_file():
            files.add(path.relative_to(root).as_posix())
    return files


def audit_inventory(root: Path, actual: Set[str], allowlist: Dict) -> None:
    if allowlist.get("schemaVersion") != 1:
        raise DeliveryFailure("V0260_ALLOWLIST_SCHEMA_INVALID")
    if allowlist.get("version") != VERSION:
        raise DeliveryFailure("V0260_ALLOWLIST_VERSION_INVALID")
    allowed = set(str(item) for item in allowlist.get("files", []))
    generated = set(str(item) for item in allowlist.get("generatedFiles", []))
    if actual - allowed - generated:
        raise DeliveryFailure(
            "V0260_FILE_NOT_ALLOWLISTED {0}".format(sorted(actual - allowed - generated)[0])
        )
    if allowed - actual:
        raise DeliveryFailure(
            "V0260_ALLOWLISTED_FILE_MISSING {0}".format(sorted(allowed - actual)[0])
        )
    missing_required = sorted(REQUIRED_OUTPUTS - actual)
    if missing_required:
        raise DeliveryFailure("V0260_REQUIRED_OUTPUT_MISSING {0}".format(missing_required[0]))
    forbidden = sorted(
        relative
        for relative in actual
        if relative in FORBIDDEN_OUTPUT_PATHS
        or "/phase1" in "/" + relative.lower()
        or relative.lower().startswith("docs/v025")
        or relative.lower().startswith("scripts/audit_v025")
    )
    if forbidden:
        raise DeliveryFailure("V0260_LEGACY_OUTPUT_PATH {0}".format(forbidden[0]))


def audit_manifest(root: Path, manifest: Dict) -> None:
    if manifest.get("schemaVersion") != 1:
        raise DeliveryFailure("V0260_MANIFEST_SCHEMA_INVALID")
    if manifest.get("product") != "AI-WPS":
        raise DeliveryFailure("V0260_PRODUCT_IDENTITY_INVALID")
    if manifest.get("productChannel") != "preview":
        raise DeliveryFailure("V0260_PRODUCT_CHANNEL_INVALID")
    if manifest.get("version") != VERSION:
        raise DeliveryFailure("V0260_VERSION_INVALID")
    version_rule = str(manifest.get("versionRule", ""))
    version_rule_match = VERSION_RULE_RE.fullmatch(version_rule)
    if version_rule_match is None:
        raise DeliveryFailure("V0260_VERSION_RULE_INVALID")
    if "phase1" in version_rule.lower() or "p1-" in version_rule.lower():
        raise DeliveryFailure("V0260_VERSION_RULE_LEGACY_IDENTITY")
    if manifest.get("releaseDate") != version_rule_match.group("date"):
        raise DeliveryFailure("V0260_RELEASE_DATE_INVALID")

    adapter = manifest.get("adapter", {})
    if adapter.get("version") != VERSION or adapter.get("systemPromptCount") != len(EXPECTED_TASKS):
        raise DeliveryFailure("V0260_ADAPTER_IDENTITY_INVALID")
    if adapter.get("systemPromptManifest") != (
        "packages/adapter-start-kit/adapter_service/system_prompts/manifest.json"
    ):
        raise DeliveryFailure("V0260_PROMPT_MANIFEST_PATH_INVALID")
    format_review = manifest.get("formatReview", {})
    reference_workflows = format_review.get("referenceWorkflows")
    if (
        format_review.get("enabledByDefault") is not True
        or format_review.get("featureSwitch")
        != "AI_WPS_ENABLE_DETERMINISTIC_FORMAT_REVIEW"
        or format_review.get("rulePackManifest") != "format-rule-assets-manifest.json"
        or not isinstance(reference_workflows, list)
        or set(reference_workflows)
        != {
            "reference-workflows/format-semantics-text-v1.yml",
            "reference-workflows/format-semantics-vision-v1.yml",
        }
    ):
        raise DeliveryFailure("V0260_FORMAT_REVIEW_POLICY_INVALID")
    smart_fill_assets = manifest.get("excelSmartFillAssets", {})
    if (
        smart_fill_assets.get("operationsGuide") != "docs/operations/model-excel-smart-fill-contract.md"
        or smart_fill_assets.get("workflowGuide") != "docs/operations/workflow-platform-excel-smart-fill.md"
        or smart_fill_assets.get("referenceWorkflow") != "reference-workflows/excel-smart-fill-v2.yml"
        or smart_fill_assets.get("systemPrompt") != "packages/adapter-start-kit/adapter_service/system_prompts/excel-smart-fill.md"
    ):
        raise DeliveryFailure("V0260_SMART_FILL_ASSETS_INVALID")
    visual_policy = manifest.get("visualPolicy", {})
    if (
        visual_policy.get("enabledByDefault") is not True
        or visual_policy.get("runtimeMasterSwitch")
        != "formatReview.imageSemantics.enabled"
        or visual_policy.get("requiresWpsAcceptance") is not False
        or visual_policy.get("pixelExportWhenDisabled") is not False
        or visual_policy.get("pixelUploadWhenDisabled") is not False
        or visual_policy.get("imageSlotAllocationWhenDisabled") is not False
    ):
        raise DeliveryFailure("V0260_VISUAL_POLICY_INVALID")

    policy = manifest.get("deliveryPolicy", {})
    required_policy = {
        "status": "candidate",
        "sourceAssembly": "explicit-allowlist",
        "allowlist": "release-allowlist.json",
        "fileHashes": "release-file-hashes.json",
        "auditScript": "scripts/audit_delivery.py",
        "candidateAuditScript": "scripts/audit_v0260_preview1_delivery.py",
        "lifecycleGate": "scripts/python38_delivery_lifecycle_gate.py",
        "targetAcceptanceRequired": True,
    }
    if any(policy.get(key) != value for key, value in required_policy.items()):
        raise DeliveryFailure("V0260_DELIVERY_POLICY_INVALID")

    installation = manifest.get("installationPolicy", {})
    expected_installation = {
        "installer": "installer/install_ai_wps.sh",
        "defaultInstallRoot": "$TARGET_HOME/ai-wps",
        "legacyInstallRoot": "$TARGET_HOME/ai-wps-phase1",
        "legacyHandling": "read-only-detect-manual-reinstall-reconfigure",
        "migratesLegacyRuntimeData": False,
        "deletesLegacyInstall": False,
    }
    if installation != expected_installation:
        raise DeliveryFailure("V0260_INSTALLATION_POLICY_INVALID")

    target_acceptance = manifest.get("targetAcceptance", {})
    if (
        manifest.get("targetAcceptanceIssue") != 154
        or target_acceptance.get("status") != "manual-pending"
        or target_acceptance.get("required") is not True
        or target_acceptance.get("doesNotCloseIssue") is not True
    ):
        raise DeliveryFailure("V0260_TARGET_ACCEPTANCE_POLICY_INVALID")

    evidence = manifest.get("candidateEvidence", {})
    if evidence.get("automatedResult") != "candidate":
        raise DeliveryFailure("V0260_CANDIDATE_STATUS_INVALID")
    expected_archive_name = (
        "ai-wps-delivery-{0}-{1}-v0260-preview1.tar.gz".format(
            version_rule_match.group("date"), version_rule_match.group("source")[:7]
        )
    )
    if evidence.get("candidateBuildId") != version_rule:
        raise DeliveryFailure("V0260_CANDIDATE_BUILD_ID_INVALID")
    source_commit = str(evidence.get("sourceCommit", ""))
    source_prefix = version_rule_match.group("source")
    if (
        re.fullmatch(r"[0-9a-f]{7,40}", source_commit) is None
        or not source_commit.startswith(source_prefix)
    ):
        raise DeliveryFailure("V0260_SOURCE_COMMIT_INVALID")
    if evidence.get("archiveName") != expected_archive_name:
        raise DeliveryFailure("V0260_ARCHIVE_IDENTITY_INVALID")
    if evidence.get("archiveChecksumFile") != expected_archive_name + ".sha256":
        raise DeliveryFailure("V0260_ARCHIVE_CHECKSUM_EVIDENCE_INVALID")
    if evidence.get("acceptanceRecord") != "Issue #154":
        raise DeliveryFailure("V0260_ACCEPTANCE_EVIDENCE_INVALID")
    baseline = manifest.get("baseline", {})
    if (
        baseline.get("requiredProductVersion") != "0.25.3-alpha"
        or baseline.get("sourceStatus") != "candidate"
        or not BASELINE_ARCHIVE_RE.fullmatch(str(baseline.get("archiveName", "")))
        or not SHA256_RE.fullmatch(str(baseline.get("archiveSha256", "")))
    ):
        raise DeliveryFailure("V0260_BASELINE_EVIDENCE_INVALID")
    if "phase1" in json.dumps(manifest, ensure_ascii=False).lower():
        # The legacy path and historical baseline archive are intentionally
        # retained for migration guidance and provenance, not current identity.
        manifest_without_legacy = dict(manifest)
        manifest_without_legacy["installationPolicy"] = {}
        manifest_without_legacy["baseline"] = {}
        if "phase1" in json.dumps(manifest_without_legacy, ensure_ascii=False).lower():
            raise DeliveryFailure("V0260_MANIFEST_LEGACY_IDENTITY")


def audit_prompt_manifest(root: Path, manifest: Dict) -> None:
    relative = manifest["adapter"]["systemPromptManifest"]
    path = root / relative
    prompt_manifest = load_json(path, "V0260_PROMPT_MANIFEST_MISSING")
    if prompt_manifest.get("release") != VERSION:
        raise DeliveryFailure("V0260_PROMPT_RELEASE_INVALID")
    tasks = prompt_manifest.get("tasks", {})
    if not isinstance(tasks, dict) or len(tasks) != len(EXPECTED_TASKS):
        raise DeliveryFailure("V0260_PROMPT_TASK_COUNT_INVALID")
    if set(tasks.keys()) != EXPECTED_TASKS:
        raise DeliveryFailure("V0260_PROMPT_TASKS_MISMATCH")
    for name, item in tasks.items():
        if not isinstance(item, dict):
            raise DeliveryFailure("V0260_PROMPT_ENTRY_INVALID {0}".format(name))
        prompt_path = path.parent / str(item.get("file", ""))
        if not prompt_path.is_file() or sha256(prompt_path) != item.get("sha256"):
            raise DeliveryFailure("V0260_PROMPT_HASH_INVALID {0}".format(name))


def audit_plugin_javascript(root: Path) -> None:
    js_files = sorted(root.glob("packages/**/*.js"))
    if not js_files:
        raise DeliveryFailure("V0260_PLUGIN_JS_MISSING")
    for js_path in js_files:
        try:
            result = subprocess.run(
                ["node", "--check", str(js_path)],
                check=False,
                capture_output=True,
                text=True,
            )
        except OSError as exc:
            raise DeliveryFailure("V0260_NODE_CHECK_UNAVAILABLE") from exc
        if result.returncode != 0:
            raise DeliveryFailure(
                "V0260_PLUGIN_JS_SYNTAX_INVALID {0}".format(
                    js_path.relative_to(root).as_posix()
                )
            )


def audit_smart_fill_write_contract(root, plugin_root=None, prompt_path=None):
    plugin = Path(plugin_root) if plugin_root is not None else (
        Path(root) / "packages/wps-ai-assistant-et_1.0.0"
    )
    prompt = Path(prompt_path) if prompt_path is not None else (
        Path(root)
        / "packages/adapter-start-kit/adapter_service/system_prompts/excel-smart-fill.md"
    )
    try:
        html = (plugin / "taskpane.html").read_text(encoding="utf-8")
        js = (plugin / "taskpane.js").read_text(encoding="utf-8")
        helpers_js = (plugin / "taskpane-helpers.js").read_text(encoding="utf-8")
        ribbon = (plugin / "ribbon.xml").read_text(encoding="utf-8")
        prompt_text = prompt.read_text(encoding="utf-8")
    except OSError as exc:
        raise DeliveryFailure("V0260_SMART_FILL_WRITE_MISSING") from exc
    if 'id="btnAiExcelSmartFill"' not in ribbon or "智能填写" not in ribbon:
        raise DeliveryFailure("V0260_SMART_FILL_RIBBON_MISSING")
    if "生成预览" not in html or 'id="btn-copy-result"' not in html:
        raise DeliveryFailure("V0260_SMART_FILL_OUTPUT_ONLY_MISSING")
    if any(
        marker in html
        for marker in (
            'id="btn-write-smart-fill"',
            'id="btn-edit-smart-fill"',
            'id="btn-new-smart-fill"',
            'id="smart-fill-write-summary"',
            "写入内容",
        )
    ):
        raise DeliveryFailure("V0260_SMART_FILL_WRITEBACK_EXPOSED")
    if "撤销" in html or "OnUndo" in js or "OnUndo" in helpers_js:
        raise DeliveryFailure("V0260_SMART_FILL_UNDO_PROMISE")
    if "excel.smart_fill.v2" not in prompt_text:
        raise DeliveryFailure("V0260_SMART_FILL_SCHEMA_MISSING")
    if (
        "buildExcelSmartFillCopyText" not in js
        or "renderExcelSmartFillResult" not in js
        or "请人工核对后复制到对应单元格" not in js
        or "setResult(markdown, buildExcelSmartFillCopyText" not in js
        or "function renderSmartFillCaptureState() {\n    refreshExcelSmartFillSourceSelection();" not in js
    ):
        raise DeliveryFailure("V0260_SMART_FILL_OUTPUT_ONLY_MISSING")
    if (
        'byId("btn-write-smart-fill").addEventListener' in js
        or 'addEventListener("click", writeExcelSmartFillResult)' in js
    ):
        raise DeliveryFailure("V0260_SMART_FILL_WRITEBACK_EXPOSED")
    if any(
        marker in html or marker in js or marker in helpers_js
        for marker in (
            "buildExcelSmartFillDefaultSource",
            "buildSmartFillDefaultSource",
            "sanitizeExcelSmartFillSource",
            "describeExcelSmartFillHostCell",
            "extractExcelSmartFillPayload:",
            "columnHeader",
            "rowContext",
            'id="btn-capture-smart-fill-source"',
            'id="btn-capture-smart-fill-target"',
        )
    ):
        raise DeliveryFailure("V0260_SMART_FILL_LEGACY_FLOW_PRESENT")
    if (
        "extractExcelSmartFillSourcePayload" not in helpers_js
    ):
        raise DeliveryFailure("V0260_SMART_FILL_SOURCE_CONTRACT_MISSING")


def audit_experience_contract(root: Path, packages_root=None) -> None:
    packages = Path(packages_root) if packages_root is not None else Path(root) / "packages"
    plugin_tasks = {
        "wps-ai-assistant_1.0.0": {
            "word.smart_write",
            "word.smart_imitation",
            "word.document_review",
            "word.format_review",
        },
        "wps-ai-assistant-et_1.0.0": {
            "excel.analysis",
            "excel.formula_assistant",
            "excel.smart_fill",
        "excel.material_ledger",
        },
        "wps-ai-assistant-wpp_1.0.0": {
            "ppt.slide_assistant",
            "ppt.structure_review",
        "ppt.material_outline",
        },
    }
    plugin_sources = {}
    try:
        for plugin_name in plugin_tasks:
            plugin = packages / plugin_name
            plugin_sources[plugin_name] = {
                "html": (plugin / "taskpane.html").read_text(encoding="utf-8"),
                "js": (plugin / "taskpane.js").read_text(encoding="utf-8"),
            }
    except OSError as exc:
        raise DeliveryFailure("V0260_EXPERIENCE_CONTRACT_MISSING") from exc

    for sources in plugin_sources.values():
        html = sources["html"]
        if "workflow-profile-select" in html:
            raise DeliveryFailure("V0260_LEGACY_TASK_MODEL_SELECTOR")
        if (
            'id="task-model-config-trigger"' not in html
            or 'id="task-model-config-menu"' not in html
        ):
            raise DeliveryFailure("V0260_TASK_MODEL_COMPACT_ENTRY_MISSING")

    for plugin_name, tasks in plugin_tasks.items():
        js = plugin_sources[plugin_name]["js"]
        if any(task not in js for task in tasks):
            raise DeliveryFailure("V0260_TASK_MODEL_COVERAGE_MISSING")

    word = packages / "wps-ai-assistant_1.0.0"
    word_html = plugin_sources["wps-ai-assistant_1.0.0"]["html"]
    try:
        word_css = (word / "taskpane.css").read_text(encoding="utf-8")
        word_helpers = (word / "taskpane-helpers.js").read_text(encoding="utf-8")
    except OSError as exc:
        raise DeliveryFailure("V0260_FORMAT_REVIEW_EXPERIENCE_MISSING") from exc
    if any(
        marker not in word_html
        for marker in (
            'id="btn-format-review-filter"',
            'id="format-review-filter-panel"',
            'id="btn-format-review-more"',
            'id="format-review-more-menu"',
        )
    ):
        raise DeliveryFailure("V0260_FORMAT_REVIEW_CONTROLS_MISSING")
    if any(
        marker not in word_helpers
        for marker in ("review-location-card", "manual_toc", "suspected-toc-")
    ):
        raise DeliveryFailure("V0260_FORMAT_REVIEW_LOCATION_GROUP_MISSING")
    if any(
        marker not in word_css
        for marker in (
            ".review-location-card",
            "@media (max-width: 320px)",
            "@media (max-width: 420px)",
        )
    ):
        raise DeliveryFailure("V0260_NARROW_VIEWPORT_CONTRACT_MISSING")


def _parse_simple_yaml(text: str) -> dict:
    lines = text.splitlines()
    root: dict = {}
    stack = [(root, -1, None)]

    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            i += 1
            continue

        indent = len(line) - len(line.lstrip(" "))
        while len(stack) > 1 and indent <= stack[-1][1]:
            stack.pop()

        parent, parent_indent, parent_key = stack[-1]

        if stripped.endswith(":") or ":" in stripped:
            parts = stripped.split(":", 1)
            key = parts[0].strip().lstrip("- ")
            val = parts[1].strip() if len(parts) > 1 else ""
            is_list_item = stripped.startswith("- ")

            if val in ("|", ">"):
                block_lines = []
                i += 1
                while i < len(lines):
                    b_line = lines[i]
                    if not b_line.strip():
                        block_lines.append("")
                        i += 1
                        continue
                    b_indent = len(b_line) - len(b_line.lstrip(" "))
                    if b_indent <= indent:
                        break
                    block_lines.append(
                        b_line[indent + 2:] if len(b_line) > indent + 2 else b_line.strip()
                    )
                    i += 1
                block_str = "\n".join(block_lines)
                if isinstance(parent, dict):
                    parent[key] = block_str
                elif isinstance(parent, list):
                    parent.append({key: block_str})
                continue

            if not val:
                next_is_list = False
                for j in range(i + 1, len(lines)):
                    next_s = lines[j].strip()
                    if next_s and not next_s.startswith("#"):
                        if next_s.startswith("- "):
                            next_is_list = True
                        break
                new_container = [] if next_is_list else {}
                if isinstance(parent, dict):
                    parent[key] = new_container
                elif isinstance(parent, list):
                    if is_list_item:
                        new_dict = {key: new_container}
                        parent.append(new_dict)
                        new_container = new_dict
                    else:
                        parent.append(new_container)
                stack.append((new_container, indent, key))
                i += 1
                continue
            else:
                if val.lower() == "true":
                    val_parsed = True
                elif val.lower() == "false":
                    val_parsed = False
                elif val.isdigit():
                    val_parsed = int(val)
                else:
                    val_parsed = val.strip("\"'")

                if isinstance(parent, dict):
                    parent[key] = val_parsed
                elif isinstance(parent, list):
                    if is_list_item:
                        parent.append({key: val_parsed})
                    else:
                        parent.append(val_parsed)
                i += 1
                continue
        elif stripped.startswith("- "):
            item_val = stripped[2:].strip().strip("\"'")
            if isinstance(parent, list):
                parent.append(item_val)
            i += 1
            continue
        i += 1
    return root


def audit_smart_fill_reference_workflow(root: Path) -> None:
    ref_workflow = Path(root) / "reference-workflows/excel-smart-fill-v2.yml"
    if not ref_workflow.is_file():
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_MISSING")
    try:
        ref_text = ref_workflow.read_text(encoding="utf-8")
    except OSError as exc:
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_MISSING") from exc

    try:
        data = _parse_simple_yaml(ref_text)
    except Exception as exc:
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID yaml_syntax") from exc

    if data.get("kind") != "app":
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID kind_must_be_app")
    app_info = data.get("app")
    if not isinstance(app_info, dict) or app_info.get("mode") != "workflow":
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID app_mode_must_be_workflow")
    workflow = data.get("workflow")
    if not isinstance(workflow, dict):
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID workflow_section_missing")
    if workflow.get("contract_version") != "excel.smart_fill.v2":
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID contract_version_mismatch")

    output = workflow.get("output")
    if not isinstance(output, dict) or output.get("variable") != "answer" or output.get("type") != "json":
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID output_contract_invalid")

    schema = workflow.get("schema")
    if not isinstance(schema, dict) or schema.get("type") != "object":
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID schema_missing_or_not_object")
    required = schema.get("required", [])
    if not ("schemaVersion" in required and "items" in required):
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID schema_required_missing")
    properties = schema.get("properties", {})
    if not isinstance(properties, dict):
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID schema_properties_invalid")
    schema_ver = properties.get("schemaVersion", {})
    if schema_ver.get("enum") != ["excel.smart_fill.v2"] and "excel.smart_fill.v2" not in schema_ver.get("enum", []):
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID schema_version_enum_mismatch")

    items_prop = properties.get("items", {})
    items_def = items_prop.get("items", {}) if isinstance(items_prop, dict) else {}
    item_req = items_def.get("required", [])
    for field in ("itemId", "status", "valueType", "value"):
        if field not in item_req:
            raise DeliveryFailure(f"V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID item_missing_required_{field}")

    if not str(workflow.get("system_prompt", "")).strip():
        raise DeliveryFailure("V0260_SMART_FILL_REFERENCE_WORKFLOW_INVALID empty_system_prompt")


def audit_installer(root: Path) -> None:
    installer = root / "installer/install_ai_wps.sh"
    content = installer.read_text(encoding="utf-8")
    required_markers = (
        'INSTALL_ROOT="${AI_WPS_INSTALL_ROOT:-$TARGET_HOME/ai-wps}"',
        'LEGACY_PHASE1_INSTALL_ROOT="$TARGET_HOME/ai-wps-phase1"',
        "legacy_phase1_install_detected=true",
        "legacy_phase1_action=read_only",
        "manual_reinstall_required=true",
        "manual_reconfigure_required=true",
        "legacy_runtime_data_migrated=false",
        "legacy_install_deleted=false",
        "ai_wps_install_start=true",
        "ai_wps_install_done=true",
        "preview_path_conflicts_with_legacy",
        "preview_existing_install_manifest_required",
        "preview_existing_install_current_pointer_required",
        "preview_existing_install_release_required",
        "preview_existing_install_manifest_invalid",
    )
    for marker in required_markers:
        if marker not in content:
            raise DeliveryFailure("V0260_INSTALLER_CONTRACT_MISSING {0}".format(marker))
    if "legacy_runtime_state_exists; then" in content or "--legacy-root" in content:
        raise DeliveryFailure("V0260_LEGACY_MIGRATION_ENABLED")
    if 'rm -rf "$LEGACY_PHASE1_INSTALL_ROOT"' in content:
        raise DeliveryFailure("V0260_LEGACY_DELETE_ENABLED")


def audit_lifecycle(root: Path) -> None:
    lifecycle = root / "scripts/python38_delivery_lifecycle_gate.py"
    content = lifecycle.read_text(encoding="utf-8")
    for marker in ("installer/install_ai_wps.sh", "ai_wps_install_done=true"):
        if marker not in content:
            raise DeliveryFailure("V0260_LIFECYCLE_CONTRACT_MISSING {0}".format(marker))
    if any(
        marker in content
        for marker in (
            "install_phase1.sh",
            "phase1_install_done=true",
            "audit_phase1_delivery.py",
        )
    ):
        raise DeliveryFailure("V0260_LIFECYCLE_IDENTITY_INVALID")


def audit_current_identity_references(root: Path) -> None:
    excluded = "scripts/audit_v0260_preview1_delivery.py"
    forbidden = (
        "installer/install_phase1.sh",
        "scripts/phase1_smoke_test.sh",
        "phase1_install_start=true",
        "phase1_install_done=true",
        "phase1_smoke_start=true",
        "phase1_smoke_done=true",
        "Phase 1 WPS AI assistant",
        "Formal Phase 1 WPS AI assistant plugin.",
    )
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.relative_to(root).as_posix() == excluded:
            continue
        if path.suffix.lower() not in {".css", ".html", ".js", ".json", ".md", ".py", ".sh", ".txt", ".xml", ".yml"}:
            continue
        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        if any(marker in content for marker in forbidden):
            raise DeliveryFailure(
                "V0260_CURRENT_IDENTITY_LEAK {0}".format(path.relative_to(root).as_posix())
            )


def audit_status(root: Path, manifest: Dict) -> None:
    status = load_json(root / "docs/v0260-preview1-candidate-status.json", "V0260_STATUS_MISSING")
    records = status.get("records")
    evidence = manifest.get("candidateEvidence", {})
    if status.get("version") != VERSION or not isinstance(records, list) or len(records) != 1:
        raise DeliveryFailure("V0260_STATUS_SCHEMA_INVALID")
    record = records[0]
    for key in ("candidateBuildId", "archiveName", "archiveChecksumFile", "sourceCommit"):
        if record.get(key) != evidence.get(key) and not (
            key == "archiveChecksumFile"
            and record.get(key) == evidence.get(key)
        ):
            raise DeliveryFailure("V0260_STATUS_EVIDENCE_MISMATCH {0}".format(key))
    if record.get("status") != "candidate":
        raise DeliveryFailure("V0260_STATUS_NOT_CANDIDATE")


def has_versioned_asset_reference(
    content: str,
    filename: str,
    cache_identity: str,
) -> bool:
    pattern = (
        r"(?:src|href)=[\"'](?:\./)?"
        + re.escape(filename)
        + r"\?v="
        + re.escape(cache_identity)
        + r"[\"']"
    )
    return re.search(pattern, content) is not None


def audit_plugin_cache_identity(root: Path, manifest: Dict) -> None:
    source_commit = str(manifest.get("candidateEvidence", {}).get("sourceCommit", ""))
    if re.fullmatch(r"[0-9a-f]{7,40}", source_commit) is None:
        raise DeliveryFailure("V0260_PLUGIN_CACHE_IDENTITY_INVALID source_commit")
    cache_identity = "{0}-{1}".format(VERSION, source_commit[:12])
    plugin_names = (
        "wps-ai-assistant_1.0.0",
        "wps-ai-assistant-et_1.0.0",
        "wps-ai-assistant-wpp_1.0.0",
    )
    for plugin_name in plugin_names:
        plugin = root / "packages" / plugin_name
        try:
            taskpane_html = (plugin / "taskpane.html").read_text(encoding="utf-8")
            taskpane_js = (plugin / "taskpane.js").read_text(encoding="utf-8")
            ribbon_js = (plugin / "ribbon.js").read_text(encoding="utf-8")
            index_html = (plugin / "index.html").read_text(encoding="utf-8")
        except OSError as exc:
            raise DeliveryFailure(
                "V0260_PLUGIN_CACHE_IDENTITY_INVALID {0}".format(plugin_name)
            ) from exc
        if any(
            not has_versioned_asset_reference(
                taskpane_html,
                filename,
                cache_identity,
            )
            for filename in (
                "taskpane.css",
                "taskpane.js",
                "taskpane-helpers.js",
            )
        ):
            raise DeliveryFailure(
                "V0260_PLUGIN_CACHE_IDENTITY_INVALID {0} taskpane".format(plugin_name)
            )
        if 'FRONTEND_BUILD_VERSION = "{0}"'.format(cache_identity) not in taskpane_js:
            raise DeliveryFailure(
                "V0260_PLUGIN_CACHE_IDENTITY_INVALID {0} frontend".format(plugin_name)
            )
        if '&build={0}"'.format(cache_identity) not in ribbon_js:
            raise DeliveryFailure(
                "V0260_PLUGIN_CACHE_IDENTITY_INVALID {0} ribbon".format(plugin_name)
            )
        if plugin_name == "wps-ai-assistant_1.0.0":
            try:
                main_js = (plugin / "main.js").read_text(encoding="utf-8")
            except OSError as exc:
                raise DeliveryFailure(
                    "V0260_PLUGIN_CACHE_IDENTITY_INVALID {0} main".format(plugin_name)
                ) from exc
            if not has_versioned_asset_reference(
                index_html,
                "main.js",
                cache_identity,
            ) or any(
                not has_versioned_asset_reference(main_js, filename, cache_identity)
                for filename in (
                    "taskpane-helpers.js",
                    "ribbon.js",
                    "taskpane.js",
                )
            ):
                raise DeliveryFailure(
                    "V0260_PLUGIN_CACHE_IDENTITY_INVALID {0} bootstrap".format(plugin_name)
                )
        elif not has_versioned_asset_reference(
            index_html,
            "ribbon.js",
            cache_identity,
        ):
            raise DeliveryFailure(
                "V0260_PLUGIN_CACHE_IDENTITY_INVALID {0} bootstrap".format(plugin_name)
            )


def audit_hashes(root: Path) -> None:
    path = root / "release-file-hashes.json"
    if not path.is_file():
        raise DeliveryFailure("V0260_FILE_HASH_MANIFEST_MISSING")
    hashes = load_json(path, "V0260_FILE_HASH_MANIFEST_INVALID")
    if hashes.get("version") != VERSION or hashes.get("algorithm") != "sha256":
        raise DeliveryFailure("V0260_FILE_HASH_MANIFEST_INVALID")
    actual = delivery_files(root) - {"release-file-hashes.json"}
    expected = hashes.get("files", {})
    if set(expected) != actual:
        raise DeliveryFailure("V0260_FILE_HASH_INVENTORY_MISMATCH")
    for relative, digest in expected.items():
        if not SHA256_RE.fullmatch(str(digest)) or sha256(root / relative) != digest:
            raise DeliveryFailure("V0260_FILE_HASH_MISMATCH {0}".format(relative))


def audit_archive_checksum(
    archive: Path, checksum_file: Path, expected_name: Optional[str]
) -> None:
    if not archive.is_file() or not checksum_file.is_file():
        raise DeliveryFailure("V0260_ARCHIVE_CHECKSUM_MISSING")
    fields = checksum_file.read_text(encoding="utf-8").strip().split()
    if len(fields) != 2 or not SHA256_RE.fullmatch(fields[0]):
        raise DeliveryFailure("V0260_ARCHIVE_CHECKSUM_FORMAT_INVALID")
    if fields[1] != (expected_name or archive.name):
        raise DeliveryFailure("V0260_ARCHIVE_CHECKSUM_NAME_MISMATCH")
    if fields[0] != sha256(archive):
        raise DeliveryFailure("V0260_ARCHIVE_CHECKSUM_MISMATCH")


def audit_streaming_and_rollback_contract(root: Path) -> None:
    stream_module = (
        root
        / "packages/adapter-start-kit/adapter_service/app/services/direct_text_stream.py"
    )
    if not stream_module.is_file():
        raise DeliveryFailure("V0260_STREAMING_MODULE_MISSING")

    runtime_config = root / "docs/operations/runtime-config.md"
    if not runtime_config.is_file():
        raise DeliveryFailure("V0260_RUNTIME_CONFIG_DOC_MISSING")
    config_text = runtime_config.read_text(encoding="utf-8")
    for marker in (
        "AI_WPS_ENABLE_DIRECT_STREAMING",
        "streamingCapability",
        "512 KiB",
        "5 MiB",
        "MODEL_RESPONSE_SIZE_LIMIT",
        "providerOutcome",
        "providerFirstVisibleMs",
    ):
        if marker not in config_text:
            raise DeliveryFailure(
                "V0260_STREAMING_RUNTIME_CONFIG_MISSING {0}".format(marker)
            )

    acceptance_doc = root / "docs/v0260-preview1-target-machine-acceptance.md"
    if not acceptance_doc.is_file():
        raise DeliveryFailure("V0260_TARGET_ACCEPTANCE_DOC_MISSING")
    acceptance_text = acceptance_doc.read_text(encoding="utf-8")
    if "交互流式、毫秒诊断与回滚目标机验收" not in acceptance_text:
        raise DeliveryFailure("V0260_STREAMING_ACCEPTANCE_SECTION_MISSING")

    word_taskpane = root / "packages/wps-ai-assistant_1.0.0/taskpane.js"
    if not word_taskpane.is_file():
        raise DeliveryFailure("V0260_WORD_TASKPANE_MISSING")
    taskpane_text = word_taskpane.read_text(encoding="utf-8")
    for marker in (
        "pollWritingJobEvents",
        "stopCurrentConsumer",
        "status === 404",
        "writingJobUsesEvents(job)",
        "writingJobUsesEvents(jobRecord)",
        "writingJobUsesEvents(active)",
    ):
        if marker not in taskpane_text:
            raise DeliveryFailure(
                "V0260_STREAMING_FALLBACK_CONTRACT_MISSING {0}".format(marker)
            )

    adapter_root = root / "packages/adapter-start-kit/adapter_service"
    probe_env = dict(os.environ)
    probe_env["PYTHONDONTWRITEBYTECODE"] = "1"
    probe_env["PYTHONPATH"] = str(adapter_root) + os.pathsep + probe_env.get(
        "PYTHONPATH", ""
    )
    probe = subprocess.run(
        [
            sys.executable,
            "-c",
            (
                "import json, logging, os, threading; "
                "from unittest.mock import patch; "
                "logging.getLogger().addHandler(logging.NullHandler()); "
                "from app.core.models import WordDocumentRequest; "
                "from app.services.long_task_coordinator import LongTaskCoordinator; "
                "from app.services.provider_client import ProviderClient; "
                "from app.services.word.writing_jobs import SmartWriteJobStore; "
                "cap_validated={'status':'validated','serviceId':'direct_svc_test',"
                "'serviceRevision':1,'serviceBaseUrl':'https://api.example.test/v1',"
                "'apiKeyFingerprint':'sha256:test','modelName':'model-test',"
                "'testedAt':'2026-09-20T00:00:00Z'}; "
                "cap_not_checked={'status':'not_checked'}; "
                "cap_unsupported={'status':'unsupported'}; "
                "make_worker=lambda cap:type('Worker',(),{"
                "'snapshot_task_auth':lambda self,cap=cap:{'streamingCapability':cap},"
                "'smart_write':lambda self,request,**kwargs:"
                "(threading.Event().wait(5) or {'rewrittenText':'ok'})})(); "
                "payload={'documentId':'audit.docx','scene':'word',"
                "'selectionMode':'selection','clientJobId':'audit-job-12345',"
                "'documentSessionId':'audit-doc','host':'wps',"
                "'content':{'plainText':'audit','paragraphs':[],'headings':[]},"
                "'options':{}}; "
                "request=(WordDocumentRequest.model_validate(payload) "
                "if hasattr(WordDocumentRequest,'model_validate') "
                "else WordDocumentRequest.parse_obj(payload)); "
                "os.environ.pop('AI_WPS_ENABLE_DIRECT_STREAMING',None); "
                "coordinator=LongTaskCoordinator(max_running=1,max_queued=1); "
                "job=SmartWriteJobStore(worker=make_worker(cap_validated),coordinator=coordinator).start("
                "request,'audit-trace'); "
                "assert job.get('streamingEnabled') is True; "
                "stored=coordinator._jobs[('word.smart_write',job['jobId'])]; "
                "assert stored['_allowRunningCancel'] is True; "
                "assert stored['_snapshot']['taskAuth']['directStreamingEnabled'] is True; "
                "payload['clientJobId']='audit-job-not-checked'; "
                "request=(WordDocumentRequest.model_validate(payload) "
                "if hasattr(WordDocumentRequest,'model_validate') "
                "else WordDocumentRequest.parse_obj(payload)); "
                "coordinator=LongTaskCoordinator(max_running=1,max_queued=1); "
                "job=SmartWriteJobStore(worker=make_worker(cap_not_checked),coordinator=coordinator).start("
                "request,'audit-not-checked'); "
                "assert job.get('streamingEnabled') is False; "
                "stored=coordinator._jobs[('word.smart_write',job['jobId'])]; "
                "assert stored['_allowRunningCancel'] is False; "
                "payload['clientJobId']='audit-job-unsupported'; "
                "request=(WordDocumentRequest.model_validate(payload) "
                "if hasattr(WordDocumentRequest,'model_validate') "
                "else WordDocumentRequest.parse_obj(payload)); "
                "coordinator=LongTaskCoordinator(max_running=1,max_queued=1); "
                "job=SmartWriteJobStore(worker=make_worker(cap_unsupported),coordinator=coordinator).start("
                "request,'audit-unsupported'); "
                "assert job.get('streamingEnabled') is False; "
                "stored=coordinator._jobs[('word.smart_write',job['jobId'])]; "
                "assert stored['_allowRunningCancel'] is False; "
                "sent=[]; "
                "response=type('Response',(),{"
                "'headers':{'Content-Type':'application/json'},'status':200,"
                "'__enter__':lambda self:self,'__exit__':lambda self,*args:False,"
                "'read':lambda self,*args:b'{\"choices\":[{\"message\":{\"content\":\"ok\"},\"finish_reason\":\"stop\"}]}'})(); "
                "fake=lambda req,timeout=None:(sent.append(req) or response); "
                "auth={'providerBaseUrl':'https://api.example.test/v1','apiKey':'test',"
                "'modelName':'model-test','streamingCapability':cap_not_checked,"
                "'directStreamingEnabled':True,'contextWindowTokens':100000,"
                "'maxOutputTokens':128}; "
                "mock=patch('app.services.provider_client.urllib_request.urlopen',side_effect=fake); "
                "mock.start(); "
                "ProviderClient()._post_direct_task('word.smart_write','audit-provider',"
                "'audit',auth,30,prompt_asset={'content':'audit','version':'v1','hashPrefix':'hash'}); "
                "mock.stop(); "
                "assert json.loads(sent[0].data.decode('utf-8'))['stream'] is False"
            ),
        ],
        cwd=adapter_root,
        env=probe_env,
        check=False,
        capture_output=True,
        text=True,
        timeout=15,
    )
    if probe.returncode != 0:
        raise DeliveryFailure("V0260_STREAMING_RUNTIME_CONTRACT_FAILED")


def audit(root: Path, archive: Optional[Path], checksum_file: Optional[Path], expected_name: Optional[str]) -> None:
    if not root.is_dir():
        raise DeliveryFailure("V0260_DELIVERY_ROOT_MISSING")
    actual = delivery_files(root)
    manifest = load_json(root / "release-manifest.json", "V0260_MANIFEST_MISSING")
    allowlist = load_json(root / "release-allowlist.json", "V0260_ALLOWLIST_MISSING")
    audit_inventory(root, actual, allowlist)
    audit_manifest(root, manifest)
    audit_prompt_manifest(root, manifest)
    audit_smart_fill_write_contract(root)
    audit_experience_contract(root)
    audit_smart_fill_reference_workflow(root)
    audit_streaming_and_rollback_contract(root)
    audit_installer(root)
    audit_lifecycle(root)
    audit_current_identity_references(root)
    audit_status(root, manifest)
    audit_plugin_cache_identity(root, manifest)
    audit_hashes(root)
    audit_plugin_javascript(root)
    if archive is not None or checksum_file is not None:
        if archive is None or checksum_file is None:
            raise DeliveryFailure("V0260_ARCHIVE_CHECKSUM_PAIR_REQUIRED")
        audit_archive_checksum(archive, checksum_file, expected_name)
    print("v0260_preview1_delivery_audit=passed status=candidate version={0}".format(VERSION))


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("delivery_root", type=Path)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--checksum-file", type=Path)
    parser.add_argument("--expected-archive-name")
    args = parser.parse_args(argv)
    try:
        audit(
            args.delivery_root.resolve(),
            args.archive.resolve() if args.archive else None,
            args.checksum_file.resolve() if args.checksum_file else None,
            args.expected_archive_name,
        )
    except (DeliveryFailure, OSError, ValueError, json.JSONDecodeError) as exc:
        print("v0260_preview1_delivery_audit=failed {0}".format(exc))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
