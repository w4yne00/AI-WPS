#!/usr/bin/env python3
"""Run the v0.26.0-preview.1 delivery and installation lifecycle gate."""

import argparse
import json
import os
import pwd
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
from typing import Callable, Dict, Optional, Tuple


VERSION = "0.26.0-preview.1"
BASELINE_VERSION = "0.25.3-alpha"
SCENARIOS = [
    "runtime_gate",
    "fresh_install",
    "legacy_boundary",
    "preview_upgrade",
]


class LifecycleFailure(RuntimeError):
    pass


def require(condition: bool, code: str) -> None:
    if not condition:
        raise LifecycleFailure(code)


def archive_manifest(archive_path: Path) -> Dict:
    if not archive_path.is_file():
        raise LifecycleFailure("BASELINE_ARCHIVE_MISSING {0}".format(archive_path))
    try:
        with tarfile.open(str(archive_path), "r:gz") as archive:
            member = next(
                item
                for item in archive.getmembers()
                if Path(item.name).name == "release-manifest.json" and item.isfile()
            )
            extracted = archive.extractfile(member)
            require(extracted is not None, "ARCHIVE_MANIFEST_UNREADABLE")
            value = json.loads(extracted.read().decode("utf-8"))
    except (OSError, tarfile.TarError, StopIteration, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise LifecycleFailure("ARCHIVE_MANIFEST_INVALID {0}".format(archive_path.name)) from exc
    require(isinstance(value, dict), "ARCHIVE_MANIFEST_INVALID")
    return value


def audit_delivery(delivery_root: Path) -> None:
    for relative in (
        "scripts/audit_delivery.py",
        "scripts/audit_v0260_preview1_delivery.py",
    ):
        auditor = delivery_root / relative
        require(auditor.is_file(), "DELIVERY_AUDITOR_MISSING {0}".format(relative))
        result = subprocess.run(
            [sys.executable, str(auditor), str(delivery_root)],
            check=False,
            capture_output=True,
            text=True,
        )
        require(
            result.returncode == 0,
            result.stdout.strip() or result.stderr.strip() or "DELIVERY_AUDIT_FAILED",
        )
        print("lifecycle_audit=passed script={0}".format(relative))


def stage_external_installer_dependencies(delivery_root: Path) -> bool:
    external_value = os.environ.get(
        "AI_WPS_PYTHON38_GATE_SITE_PACKAGES", ""
    ).strip()
    if not external_value:
        return False
    external_root = Path(external_value).resolve()
    require(
        external_root.is_dir(),
        "PYTHON38_GATE_DEPENDENCIES_MISSING {0}".format(external_root),
    )
    installer = delivery_root / "installer/install_private_runtime.sh"
    require(installer.is_file(), "PRIVATE_RUNTIME_INSTALLER_MISSING")
    installer.write_text(
        """#!/usr/bin/env bash
set -euo pipefail

RUNTIME_DEPS_DIR="${2:-}"
PRIVATE_RUNTIME_DIR="${4:-}"
EXTERNAL_ROOT="${AI_WPS_PYTHON38_GATE_SITE_PACKAGES:-}"

[ -d "$RUNTIME_DEPS_DIR" ] || exit 1
[ -s "$RUNTIME_DEPS_DIR/requirements-lock.txt" ] || exit 1
[ -d "$EXTERNAL_ROOT" ] || exit 1
[ -n "$PRIVATE_RUNTIME_DIR" ] || exit 1
case "$PRIVATE_RUNTIME_DIR" in
  /*) ;;
  *) exit 1 ;;
esac
[ ! -e "$PRIVATE_RUNTIME_DIR" ] || exit 1
mkdir -p "$PRIVATE_RUNTIME_DIR"
cp -R "$EXTERNAL_ROOT"/. "$PRIVATE_RUNTIME_DIR"/
cp "$RUNTIME_DEPS_DIR/requirements-lock.txt" "$PRIVATE_RUNTIME_DIR/requirements-lock.txt"
printf '%s\n' "private_runtime=ready source=external_gate_fixture path=$PRIVATE_RUNTIME_DIR"
""",
        encoding="utf-8",
    )
    installer.chmod(0o755)
    print("installer_runtime_dependencies=external_fixture")
    return True


def reserve_install_ports(reserve_port: Callable[[], int]) -> Tuple[int, int]:
    port = reserve_port()
    candidate_port = reserve_port()
    while candidate_port == port:
        candidate_port = reserve_port()
    return port, candidate_port


def install_environment(
    root: Path, port: int, candidate_port: int
) -> Dict[str, str]:
    home = root / "home"
    install_root = home / "ai-wps"
    jsaddons = home / "jsaddons"
    target_tools = root / "target-tools"
    home.mkdir(parents=True, exist_ok=True)
    install_root.mkdir(parents=True, exist_ok=True)
    jsaddons.mkdir(parents=True, exist_ok=True)
    target_tools.mkdir(parents=True, exist_ok=True)
    target_home_lookup = target_tools / "getent"
    target_home_lookup.write_text(
        "#!/bin/sh\n"
        'if [ "${1:-}" = "passwd" ] && [ "${2:-}" = "${AI_WPS_TARGET_USER:-}" ]; then\n'
        '  printf \'%s:x:%s:%s::%s:/bin/sh\\n\' "$AI_WPS_TARGET_USER" "$(id -u)" "$(id -g)" "$HOME"\n'
        "  exit 0\n"
        "fi\n"
        "exit 2\n",
        encoding="utf-8",
    )
    target_home_lookup.chmod(0o755)
    environment = dict(os.environ)
    for variable in (
        "SUDO_USER",
        "SUDO_UID",
        "AI_WPS_STATE_DIR",
        "AI_WPS_BACKUP_DIR",
        "AI_WPS_VAR_DIR",
        "AI_WPS_TRANSACTION_FAIL_AFTER",
    ):
        environment.pop(variable, None)
    environment.update(
        {
            "HOME": str(home),
            "AI_WPS_TARGET_USER": pwd.getpwuid(os.getuid()).pw_name,
            "AI_WPS_INSTALL_ROOT": str(install_root),
            "WPS_JSADDONS_DIR": str(jsaddons),
            "PATH": os.pathsep.join(
                (str(target_tools), environment.get("PATH", ""))
            ),
            "AI_WPS_SYSTEMD_SERVICE_FILE": str(root / "no-systemd/ai-wps.service"),
            "AI_WPS_CANDIDATE_PORT": str(candidate_port),
            "PORT": str(port),
            "PYTHON_BIN": sys.executable,
            "PYTHONDONTWRITEBYTECODE": "1",
        }
    )
    return environment


def run_installer(
    delivery_root: Path,
    environment: Dict[str, str],
    expected_returncode: int = 0,
    updates: Optional[Dict[str, str]] = None,
) -> subprocess.CompletedProcess:
    child_environment = dict(environment)
    if updates:
        child_environment.update(updates)
    installer_command = [
        "bash",
        str(delivery_root / "installer/install_ai_wps.sh"),
        "--target-user",
        child_environment["AI_WPS_TARGET_USER"],
    ]
    result = subprocess.run(
        installer_command,
        env=child_environment,
        check=False,
        capture_output=True,
        text=True,
        timeout=300,
    )
    if result.returncode != expected_returncode:
        raise LifecycleFailure(
            "INSTALL_RESULT_INVALID expected={0} actual={1} output={2}".format(
                expected_returncode,
                result.returncode,
                (result.stdout + result.stderr)[-2400:],
            )
        )
    return result


def stop_adapter(environment: Dict[str, str]) -> None:
    install_root = Path(environment["AI_WPS_INSTALL_ROOT"])
    stop_script = install_root / "current/scripts/stop_adapter.sh"
    if stop_script.is_file():
        subprocess.run(
            ["bash", str(stop_script), environment["PORT"]],
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )


def verify_install(environment: Dict[str, str]) -> None:
    install_root = Path(environment["AI_WPS_INSTALL_ROOT"])
    current = install_root / "current"
    release = install_root / "releases" / VERSION
    require(current.is_symlink() and current.samefile(release), "CURRENT_RELEASE_INVALID")
    transactions = list((install_root / "var/transactions").glob("*.json"))
    require(bool(transactions), "TRANSACTION_LOG_MISSING")
    latest = max(transactions, key=lambda path: path.stat().st_mtime_ns)
    payload = json.loads(latest.read_text(encoding="utf-8"))
    require(payload.get("status") == "committed", "TRANSACTION_NOT_COMMITTED")


def legacy_fixture(legacy_root: Path) -> Dict[Path, bytes]:
    (legacy_root / "config").mkdir(parents=True)
    (legacy_root / "run").mkdir()
    fixtures = {
        Path("config/adapter.json"): b'{"providerApiKey":"must-not-be-read"}\n',
        Path("run/provider_api_key"): b"legacy-secret\n",
        Path("run/writing_policies.db"): b"legacy-database",
    }
    for relative, content in fixtures.items():
        path = legacy_root / relative
        path.write_bytes(content)
        path.chmod(0o600)
    return fixtures


def assert_files_unchanged(root: Path, expected: Dict[Path, bytes]) -> None:
    actual = {
        relative: (root / relative).read_bytes()
        for relative in expected
        if (root / relative).is_file()
    }
    require(actual == expected, "LEGACY_DATA_CHANGED")


def run_fresh_install(delivery_root: Path, temp_root: Path, reserve_port) -> None:
    root = temp_root / "fresh"
    environment = install_environment(root, *reserve_install_ports(reserve_port))
    result = run_installer(delivery_root, environment)
    try:
        verify_install(environment)
        require("ai_wps_install_done=true" in result.stdout, "FRESH_INSTALL_NOT_DONE")
    finally:
        stop_adapter(environment)
    print("lifecycle_scenario=fresh_install passed")


def run_legacy_boundary(delivery_root: Path, temp_root: Path, reserve_port) -> None:
    root = temp_root / "legacy-boundary"
    environment = install_environment(root, *reserve_install_ports(reserve_port))
    legacy_root = Path(environment["HOME"]) / "ai-wps-phase1"
    fixtures = legacy_fixture(legacy_root)
    result = run_installer(delivery_root, environment)
    try:
        verify_install(environment)
        for marker in (
            "legacy_phase1_install_detected=true",
            "legacy_phase1_action=read_only",
            "manual_reinstall_required=true",
            "manual_reconfigure_required=true",
            "legacy_runtime_data_migrated=false",
            "legacy_install_deleted=false",
        ):
            require(marker in result.stdout, "LEGACY_BOUNDARY_MARKER_MISSING {0}".format(marker))
        assert_files_unchanged(legacy_root, fixtures)
        new_root = Path(environment["AI_WPS_INSTALL_ROOT"])
        require(
            all(
                b"legacy-secret" not in path.read_bytes()
                for path in new_root.rglob("*")
                if path.is_file()
            ),
            "LEGACY_SECRET_IMPORTED",
        )
    finally:
        stop_adapter(environment)
    print("lifecycle_scenario=legacy_boundary passed")


def run_preview_upgrade(delivery_root: Path, temp_root: Path, reserve_port) -> None:
    root = temp_root / "preview-upgrade"
    environment = install_environment(root, *reserve_install_ports(reserve_port))
    run_installer(delivery_root, environment)
    stop_adapter(environment)
    state_root = Path(environment["AI_WPS_INSTALL_ROOT"]) / "state"
    adapter_path = state_root / "adapter.json"
    adapter_content = b'{"previewSentinel":"preserve-me"}\n'
    adapter_path.write_bytes(adapter_content)
    key_path = state_root / "provider_api_key"
    key_content = b"preview-key-ref\n"
    key_path.write_bytes(key_content)
    key_path.chmod(0o600)

    result = run_installer(delivery_root, environment)
    try:
        verify_install(environment)
        require("ai_wps_install_done=true" in result.stdout, "PREVIEW_UPGRADE_NOT_DONE")
        preserved_config = json.loads(adapter_path.read_text(encoding="utf-8"))
        expected_config = json.loads(adapter_content.decode("utf-8"))
        require(
            isinstance(preserved_config, dict)
            and isinstance(expected_config, dict)
            and all(
                key in preserved_config and preserved_config[key] == value
                for key, value in expected_config.items()
            ),
            "PREVIEW_CONFIG_NOT_PRESERVED",
        )
        require(key_path.read_bytes() == key_content, "PREVIEW_KEY_NOT_PRESERVED")
    finally:
        stop_adapter(environment)
    print("lifecycle_scenario=preview_upgrade passed")


def run_gate(
    archive_path: Path,
    expected_version: str,
    baseline_archive: Path,
    baseline_version: str,
) -> None:
    require(expected_version == VERSION, "PREVIEW_VERSION_REQUIRED")
    require(baseline_version == BASELINE_VERSION, "BASELINE_VERSION_REQUIRED")
    baseline = archive_manifest(baseline_archive)
    require(baseline.get("version") == baseline_version, "BASELINE_VERSION_INVALID")
    require(
        baseline.get("deliveryPolicy", {}).get("status") == "candidate",
        "BASELINE_NOT_CANDIDATE",
    )

    import python38_delivery_runtime_gate as runtime_gate

    runtime_gate.require_python38()
    with tempfile.TemporaryDirectory(prefix="ai-wps-preview1-lifecycle-") as temp_dir:
        temp_root = Path(temp_dir)
        delivery_root = runtime_gate.safe_extract(archive_path, temp_root / "delivery")
        audit_delivery(delivery_root)
        runtime_gate.run_gate(archive_path, expected_version)
        stage_external_installer_dependencies(delivery_root)
        run_fresh_install(delivery_root, temp_root, runtime_gate.reserve_port)
        run_legacy_boundary(delivery_root, temp_root, runtime_gate.reserve_port)
        run_preview_upgrade(delivery_root, temp_root, runtime_gate.reserve_port)
    print("python38_delivery_lifecycle_gate=passed status=candidate")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", nargs="?")
    parser.add_argument("--expected-version")
    parser.add_argument("--baseline-archive", required=False)
    parser.add_argument("--baseline-version", default=BASELINE_VERSION)
    parser.add_argument("--list", action="store_true")
    args = parser.parse_args(argv)
    if args.list:
        print(json.dumps({"scenarios": SCENARIOS}, sort_keys=True))
        return 0
    if not args.archive or not args.expected_version or not args.baseline_archive:
        parser.error("archive, --expected-version, and --baseline-archive are required")
    try:
        run_gate(
            Path(args.archive).resolve(),
            args.expected_version,
            Path(args.baseline_archive).resolve(),
            args.baseline_version,
        )
    except (LifecycleFailure, OSError, ValueError, json.JSONDecodeError, subprocess.TimeoutExpired) as exc:
        print("python38_delivery_lifecycle_gate=failed {0}".format(exc))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
