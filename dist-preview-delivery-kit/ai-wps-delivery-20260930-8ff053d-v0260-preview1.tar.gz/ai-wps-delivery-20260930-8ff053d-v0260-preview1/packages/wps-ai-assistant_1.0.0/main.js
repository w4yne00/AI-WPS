document.write("<script language='javascript' src='taskpane-helpers.js?v=0.26.0-preview.1-8ff053d4701c'></script>");
document.write("<script language='javascript' src='ribbon.js?v=0.26.0-preview.1-8ff053d4701c'></script>");
document.write("<script language='javascript' src='taskpane.js?v=0.26.0-preview.1-8ff053d4701c'></script>");
