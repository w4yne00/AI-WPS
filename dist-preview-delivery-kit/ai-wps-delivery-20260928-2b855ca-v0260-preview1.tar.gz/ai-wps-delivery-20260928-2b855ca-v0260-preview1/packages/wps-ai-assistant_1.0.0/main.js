document.write("<script language='javascript' src='taskpane-helpers.js?v=0.26.0-preview.1-2b855ca7ba3b'></script>");
document.write("<script language='javascript' src='ribbon.js?v=0.26.0-preview.1-2b855ca7ba3b'></script>");
document.write("<script language='javascript' src='taskpane.js?v=0.26.0-preview.1-2b855ca7ba3b'></script>");
