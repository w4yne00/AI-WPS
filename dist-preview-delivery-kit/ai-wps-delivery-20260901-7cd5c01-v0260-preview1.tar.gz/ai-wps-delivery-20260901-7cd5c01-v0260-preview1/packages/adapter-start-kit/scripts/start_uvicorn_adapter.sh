#!/usr/bin/env bash
set -euo pipefail

KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$KIT_ROOT/scripts/runtime_paths.sh"
resolve_adapter_runtime_paths "$KIT_ROOT"
PORT="${1:-18100}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
EXPECTED_VERSION="${EXPECTED_VERSION:-0.26.0-preview.1}"
PRIVATE_RUNTIME_DIR="${AI_WPS_PYTHON_DEPS_DIR:-$KIT_ROOT/python-runtime}"
PRIVATE_RUNTIME_REQUIRED_MARKER="$KIT_ROOT/.release-private-runtime-required"
PID_FILE="$ADAPTER_PID_FILE"
LOG_DIR="$ADAPTER_LOG_DIR"
LOG_FILE="$ADAPTER_LOG_FILE"
HEALTH_URL="http://127.0.0.1:${PORT}/health"

mkdir -p "$ADAPTER_RUN_DIR" "$LOG_DIR" "$ADAPTER_TRANSACTION_DIR"
chmod 700 "$ADAPTER_RUN_DIR" "$LOG_DIR" "$ADAPTER_TRANSACTION_DIR"
if [ -n "${AI_WPS_STATE_DIR:-}" ]; then
  mkdir -p "$AI_WPS_STATE_DIR" "$AI_WPS_BACKUP_DIR"
  chmod 700 "$AI_WPS_STATE_DIR" "$AI_WPS_BACKUP_DIR"
fi

if [ -d "$PRIVATE_RUNTIME_DIR" ]; then
  ADAPTER_PYTHONPATH="$PRIVATE_RUNTIME_DIR"
elif [ "${AI_WPS_REQUIRE_PRIVATE_RUNTIME:-0}" = "1" ] \
  || [ -f "$PRIVATE_RUNTIME_REQUIRED_MARKER" ]; then
  echo "private_runtime_missing=$PRIVATE_RUNTIME_DIR"
  exit 1
else
  ADAPTER_PYTHONPATH="${PYTHONPATH:-}"
fi

if ! PYTHONNOUSERSITE=1 PYTHONPATH="$ADAPTER_PYTHONPATH" \
  "$PYTHON_BIN" -s -c "import uvicorn, fastapi" >/dev/null 2>&1; then
  echo "uvicorn_runtime_missing=true"
  echo "请使用安装器创建并校验发布私有 Python 依赖目录。"
  exit 1
fi

read_health() {
  if command -v curl >/dev/null 2>&1; then
    curl -fsS "$HEALTH_URL" 2>/dev/null || true
  fi
}

detect_mode() {
  printf '%s' "$1" | sed -n 's/.*"mode"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1
}

detect_version() {
  printf '%s' "$1" | sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1
}

kill_pid_if_running() {
  local pid="$1"
  if [ -n "$pid" ] && kill -0 "$pid" >/dev/null 2>&1; then
    kill "$pid" >/dev/null 2>&1 || true
    sleep 1
    if kill -0 "$pid" >/dev/null 2>&1; then
      kill -9 "$pid" >/dev/null 2>&1 || true
    fi
  fi
}

replace_existing_adapter() {
  local health_body="$1"
  local existing_mode
  existing_mode="$(detect_mode "$health_body")"
  echo "existing_adapter_detected=${existing_mode:-unknown} port=$PORT"

  if [ -f "$PID_FILE" ]; then
    kill_pid_if_running "$(cat "$PID_FILE" 2>/dev/null || true)"
    rm -f "$PID_FILE"
  fi

  if command -v lsof >/dev/null 2>&1; then
    for pid in $(lsof -ti TCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true); do
      kill_pid_if_running "$pid"
    done
  elif command -v fuser >/dev/null 2>&1; then
    fuser -k "${PORT}/tcp" >/dev/null 2>&1 || true
    sleep 1
  elif command -v ss >/dev/null 2>&1; then
    for pid in $(ss -ltnp "sport = :$PORT" 2>/dev/null | sed -n 's/.*pid=\([0-9]\+\).*/\1/p' | sort -u); do
      kill_pid_if_running "$pid"
    done
  fi
}

HEALTH_BODY="$(read_health)"
if [ -n "$HEALTH_BODY" ]; then
  CURRENT_MODE="$(detect_mode "$HEALTH_BODY")"
  CURRENT_VERSION="$(detect_version "$HEALTH_BODY")"
  if [ "$CURRENT_MODE" = "uvicorn" ]; then
    if [ "$CURRENT_VERSION" = "$EXPECTED_VERSION" ] && [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" >/dev/null 2>&1; then
      echo "adapter_already_running pid=$(cat "$PID_FILE") port=$PORT mode=uvicorn"
      echo "adapter_health=reachable url=$HEALTH_URL version=${CURRENT_VERSION:-unknown}"
      exit 0
    fi
    echo "adapter_stale_running mode=uvicorn current_version=${CURRENT_VERSION:-unknown} expected_version=$EXPECTED_VERSION port=$PORT"
    replace_existing_adapter "$HEALTH_BODY"
  else
    replace_existing_adapter "$HEALTH_BODY"
  fi
fi

cd "$KIT_ROOT/adapter_service"
nohup env PYTHONNOUSERSITE=1 PYTHONPATH="$ADAPTER_PYTHONPATH" \
  "$PYTHON_BIN" -s -m uvicorn app.main:app --host 127.0.0.1 --port "$PORT" >> "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"
PID="$(cat "$PID_FILE")"

for _ in 1 2 3 4 5 6 7 8; do
  HEALTH_BODY="$(read_health)"
  if [ -n "$HEALTH_BODY" ] && [ "$(detect_mode "$HEALTH_BODY")" = "uvicorn" ] && [ "$(detect_version "$HEALTH_BODY")" = "$EXPECTED_VERSION" ]; then
    echo "adapter_started pid=$PID port=$PORT mode=uvicorn log=$LOG_FILE"
    echo "adapter_health=reachable url=$HEALTH_URL version=$EXPECTED_VERSION"
    exit 0
  fi
  sleep 1
done

echo "adapter_start_failed pid=$PID port=$PORT mode=uvicorn log=$LOG_FILE"
echo "port_hint=如果健康检查仍返回 mode=standalone，说明旧进程仍占用 ${PORT}，请执行 bash scripts/stop_adapter.sh ${PORT} 后重试"
echo "next_step=tail -n 80 '$LOG_FILE'"
exit 1
