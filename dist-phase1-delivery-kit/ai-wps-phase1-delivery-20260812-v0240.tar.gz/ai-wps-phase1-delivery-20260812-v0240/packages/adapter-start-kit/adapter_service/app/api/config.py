from fastapi import APIRouter

from app.core.config import load_settings
from app.core.features import full_document_review_enabled
from app.services.provider_client import ProviderClient

router = APIRouter()


@router.get("/config")
def get_config() -> dict:
    settings = load_settings()
    provider = ProviderClient(settings)
    return {
        "success": True,
        "data": {
            "servicePort": settings.service_port,
            "providerName": settings.provider_name,
            "providerType": settings.provider_type,
            "providerBaseUrl": settings.provider_base_url,
            "providerChatPath": settings.provider_chat_path,
            "providerMode": settings.provider_mode,
            "providerBaseUrlConfigured": bool(settings.provider_base_url.strip()),
            "providerConfigured": provider.is_configured(),
            "providerAuthSource": provider.get_auth_source(),
            "taskApiKeys": provider.build_task_api_key_status(),
            "taskRouteConfiguredCount": 0,
            "taskRoutes": {},
            "logPath": settings.log_path,
            "templateRoot": settings.template_root,
            "timeoutSeconds": settings.timeout_seconds,
            "features": {
                "fullDocumentReviewEnabled": full_document_review_enabled(),
            },
        },
    }
