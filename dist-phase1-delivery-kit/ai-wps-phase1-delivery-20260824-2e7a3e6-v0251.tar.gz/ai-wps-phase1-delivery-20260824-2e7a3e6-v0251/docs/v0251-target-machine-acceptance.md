# v0.25.1 目标机整合验收记录

## 基本信息

- 对应工单：[Issue #59](https://github.com/w4yne00/AI-WPS/issues/59)
- 验收版本：`v0.25.1-alpha`
- 验收范围：麒麟 V10 ARM、目标 WPS、`cloud` 用户环境
- 当前记录状态：`manual-pending`
- 验收人员：
- 验收日期：
- 交付包文件名：
- 交付包 SHA-256：
- v0.25.0 基线包 SHA-256：

本记录是目标机现场填写模板。当前候选包的自动化门禁只能证明候选构建，不能替代麒麟 V10、目标 WPS 和 `cloud` 用户环境中的真实操作。所有现场原始命令输出、截图、目标机编号、账号信息、配置内容、API Key、文档正文和模型原始回复只保留在受控验收记录中，不写入仓库。

## 验收结论规则

- `manual-pending`：尚未在全部目标环境完成，或仍有任一项待验证/阻塞。
- `passed`：下表全部项目均有现场证据，且没有 `blocked`、`failed` 或 `unverified` 项。
- `failed`：任一必测项目失败，或发现升级、只读、隐私或数据生命周期问题。

只有全部必测项为 `passed` 时，才可以把记录状态改为 `passed` 并决定是否关闭 Issue #59。自动化测试、静态审计或候选包构建成功都不能单独改变该状态。

## 必测项目

| 编号 | 验收项目 | 结果（`manual-pending`/`passed`/`failed`） | 现场证据引用（脱敏） | 备注 |
| --- | --- | --- | --- | --- |
| 1 | 从已验收的最新适用 `0.24.x` 版本真实升级；配置、Key 引用、写作规范库、文档审查和回退能力保持 | `manual-pending` |  |  |
| 2 | 全文与选区验证 `60,000`/`120,000` 审查字符、混合字符格式、复杂表格、题注关系、不支持对象和容量拒绝边界 | `manual-pending` |  |  |
| 3 | 验证抽取响应性、两遍指纹、编辑中止、取消、关闭 WPS、Adapter 重启、公平调度、分页、导出和保守定位 | `manual-pending` |  |  |
| 4 | 审查前后 Word 正文、格式、表格及对象摘要一致，证明全链路只读 | `manual-pending` |  |  |
| 5 | 验证 Word 设置页、三宿主任务配置标签及 Excel/PPT Ribbon 图标在常规、窄窗和高 DPI 下可用 | `manual-pending` |  |  |
| 6 | 图片语义总开关保持关闭；现场不导出或外发像素。真实 `SaveAsPicture` 视觉保真度留待未来启用前专项验收，不作为本记录的通过依据 | `manual-pending` |  |  |
| 7 | 日志、诊断和报告不包含正文、图片像素、模型原始回复、API Key 或敏感本地路径 | `manual-pending` |  |  |
| 8 | 真实 WPS 批次同时核对 `characterCount`、`contentSha256`、`structureSha256`、`formatSha256`；普通块含 `images: []`，表格/嵌套表格、cell format、图片元数据和非 BMP 字符均参与对拍 | `manual-pending` |  | 任一 structure/format 漂移或 `DETERMINISTIC_FORMAT_REVIEW_BATCH_HASH_MISMATCH` 均不得进入后台任务 |
| 9 | 只篡改 structure 或 format 声明时均返回 `409 DETERMINISTIC_FORMAT_REVIEW_BATCH_HASH_MISMATCH`，且不启动 reviewer/provider；图片项确认 `pixelExportCount=0`、`pixelUploadCount=0` | `manual-pending` |  |  |

### v2 后台格式审查判定矩阵

以下每一行必须独立执行并记录现场证据；所有合法场景只走
`word.format_review.snapshot.v2` 后台批次，不调用退役同步路由。四项指标对拍必须同时记录
`characterCount`、`contentSha256`、`structureSha256`、`formatSha256` 的 JS/Python 值及是否一致；
`409` 栏记录 HTTP 状态与 Adapter code；后台任务栏记录是否创建/启动 `jobId`，不得以“未报错”代替。

| 用例 | 输入与独立预期 | 四项指标 JS/Python 对拍记录 | 409 记录 | 后台任务记录 |
| --- | --- | --- | --- | --- |
| `OutlineLevel=0` | 段落保留为正文块，规范化 `outlineLevel=0`，不得生成 heading | 四项值：；一致： | 合法输入应无 409；篡改对应 structure/format 声明时记录 `409 DETERMINISTIC_FORMAT_REVIEW_BATCH_HASH_MISMATCH` | 合法输入应启动并记录 `jobId`；篡改输入不得启动 reviewer/provider |
| `OutlineLevel=10` | 按规则归一为 `0`，保留正文语义，不得生成 heading | 四项值：；一致： | 合法输入应无 409；篡改对应 structure/format 声明时记录 `409 DETERMINISTIC_FORMAT_REVIEW_BATCH_HASH_MISMATCH` | 合法输入应启动并记录 `jobId`；篡改输入不得启动 reviewer/provider |
| `OutlineLevel=1..9` | 分别执行 1 至 9 级；每级规范化值与输入相等并生成对应 heading level | 四项值：；一致： | 合法输入应无 409；逐级篡改对应 structure/format 声明时记录 `409 DETERMINISTIC_FORMAT_REVIEW_BATCH_HASH_MISMATCH` | 每级合法输入均应启动并记录 `jobId`；篡改输入不得启动 reviewer/provider |
| `dataStatus=insufficient` 且 reason 非空 | 非空 `insufficientReason` 保留（按协议上限截断），并在格式事实/诊断中可见 | 四项值：；一致： | 合法输入应无 409；篡改 reason/format 后保留原声明时记录 `409 DETERMINISTIC_FORMAT_REVIEW_BATCH_HASH_MISMATCH` | 合法输入应启动并记录 `jobId`；篡改输入不得启动 reviewer/provider |
| 其它 `dataStatus` | 对 `verified`、`mixed`、`unknown`、`read_failed`、`unsupported`、`context_only` 分别执行；`insufficientReason` 必须为空/缺失 | 四项值：；一致： | 合法输入应无 409；篡改 reason/format 后保留原声明时记录 `409 DETERMINISTIC_FORMAT_REVIEW_BATCH_HASH_MISMATCH` | 合法输入应启动并记录 `jobId`；篡改输入不得启动 reviewer/provider |

现场证据引用（脱敏）：

- JS/Python 四项指标对拍：
- 409 响应与 Adapter code：
- 后台 `jobId`、终态和 reviewer/provider 调用计数：

## 现场执行摘要

### 升级、回退和数据保持

- 基线版本及其验收记录：
- 升级前配置/Key/规范库摘要（仅填写数量、版本或不可逆指纹）：
- 升级后配置/Key/规范库摘要：
- 文档审查与回退验证结果：
- Adapter 重启和 WPS 重启后结果：

### Word 全文与选区

- `60,000` 字符全文两遍抽取目标 ≤ 30 秒；现场耗时和任务窗格响应：
- `120,000` 字符全文两遍抽取目标 ≤ 60 秒；现场耗时和任务窗格响应：
- 两遍指纹（内容哈希、结构哈希和格式/对象摘要）一致：
- 选区扩展、范围外隔离和容量拒绝结果：
- 混合字符格式、复杂/嵌套/合并表格、题注关系和不支持对象结果：

### 任务生命周期与报告

- 编辑中止、取消、关闭 WPS、Adapter 重启和网络异常结果：
- 公平调度和交互任务优先结果：
- 分页、筛选、处理状态、Markdown/JSON 导出和保守定位结果：
- 任务终态、报告保留和临时数据清理结果：

### 三宿主 UI 与只读边界

- Word 设置页和任务配置标签结果：
- Excel/PPT Ribbon 图标、任务配置标签结果：
- 常规、窄窗、高 DPI 和键盘操作结果：
- Word 正文、格式、表格、对象摘要前后值：
- Excel/PPT 文档或工作簿摘要前后值（如本轮联测覆盖）：

### 隐私与视觉关闭

- `formatReview.imageSemantics.enabled` 现场值：`false`
- 像素导出槽位、`SaveAsPicture`、像素上传调用计数：
- 日志/诊断/报告脱敏检查结果：
- 受控原始证据保存位置（不得填写 API Key 或用户正文）：

## 发布决定

- 记录状态：`manual-pending`
- 是否允许关闭 Issue #59：否，须待全部目标机必测项目为 `passed`
- 是否允许默认开放图片语义：否；本轮只验收默认关闭及无像素副作用
- 现场遗留问题及跟踪工单：
