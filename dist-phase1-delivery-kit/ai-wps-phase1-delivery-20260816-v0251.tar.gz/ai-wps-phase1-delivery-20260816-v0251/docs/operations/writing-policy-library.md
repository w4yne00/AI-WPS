# 写作规范库管理与恢复

本文面向 AI-WPS Word 插件的管理员和运维人员。写作规范库用于固化组织术语规范与文体规则，当前仅接入智能编写、智能仿写和文档审查；格式审查、Excel 与 PPT 不读取这些条目。

## 范围与生效方式

- **全局术语规范**：适用于智能编写、智能仿写和文档审查。首版术语规范只能选择全局范围。
- **组织文体规则**：可同时选择智能编写、智能仿写和文档审查中的一个或多个任务。
- **组织去模板化规则**：与文体规则独立维护，也可同时选择一个或多个 Word 任务。
- **场景范围**：文体和去模板化规则可同时选择 G企技术材料、网络安全技术材料和党政公文中的一个或多个场景。

新建文体或去模板化规则默认勾选三个 Word 任务和三个规范场景；取消勾选后只在剩余任务与场景的交集内生效。旧数据库中按单任务保存的文体规则会在首次打开时迁移为等价的单任务、全场景规则。

智能编写、智能仿写和文档审查任务窗口均提供“自动匹配 / G企技术材料 / 网络安全技术材料 / 党政公文 / 不使用写作规范”五项选择，并在本机按任务分别记忆。自动匹配采用保守策略：不能可靠判断时只加载 G企技术写作基础规范，不擅自推断为网络安全材料或党政公文。

智能仿写按“保护项、用户本次明确要求、组织术语与组织规则、仿写模板结构与句式意图、预置文体、通用去模板化规则”的顺序处理冲突。模板意图高于预置文体，但不能改变参考素材和用户要求中的事实、数字、责任主体、条款、规范性强度或组织术语；去模板化规则也不能破坏用户明确要求保留的模板结构。

结果区显示本次场景、术语、文体和去模板化规则数量，并在需要时展开“需要核对”和“表达建议”。前者只提示数字、日期、责任主体、条款、明确专有名词、型号标识、规范性强度或标准术语发生变化；仿写模板中的这些事实默认不要求保留，用户明确指定保留的项目除外。后者只提示明确的模板化表达线索。两类检查均不阻断任务原有能力；智能仿写仍只有预览、纯文本和复制，检查失败也不会丢弃模型正文。切换模型工作流不会切换规范库，规范条目由本机 adapter 独立保存。

文档审查把生效术语、文体和去模板化规则注入既有审查提示词，由同一次模型调用识别需要语义判断的文体偏差；adapter 再对原文执行非阻断的确定性术语和模板化表达检查。新增发现按既有 `professional / expression` 问题结构附加原因和建议，并进入初始问题卡片和审查记录预览；与模型返回的同类别、同原文片段问题会去重。整个链路只读，不自动修改 Word 原文，也不增加第二次模型调用。

## 预置规范与组织规范状态

Word 的“设置 → 写作规范库”首先展示随版本发布的四个预置规范包：G企技术写作基础、技术文件文体、网络安全术语和党政公文文体。每个包显示版本、来源、许可证、稳定条目 ID 和规则内容；Git 来源同时显示完整提交，政府制度和国家标准来源显示制度编号或标准号。“管理组织规范”继续进入本机组织数据管理。

预置术语、文体规则和去模板化规则均支持“编辑覆盖、停用预置、恢复预置”：

- 编辑预置项只会在 `writing_policies.db` 中创建或更新组织覆盖，不修改随版本发布的 JSON。
- 停用预置项会保存预置停用记录，使该项不进入匹配结果。
- 恢复预置项会删除当前覆盖或停用记录，重新使用当前安装版本的预置基线。
- 列表明确显示“预置基线、组织覆盖、预置停用”和“已生效、未生效”状态。组织术语列表显示“组织自定义”状态。

adapter 与 standalone adapter 提供相同的查询和预置操作接口：

```text
GET /writing-policies/packs
GET /writing-policies/items?layer=preset&packId=yangqi-tech-writing-base&limit=50&offset=0
GET /writing-policies/items?layer=preset&packId=technical-document-style&limit=50&offset=0
GET /writing-policies/items?layer=preset&packId=cybersecurity-terminology&limit=50&offset=0
GET /writing-policies/items?layer=preset&packId=official-document-style&limit=50&offset=0
GET /writing-policies/items?scope=organization&type=style&limit=50&offset=0
GET /writing-policies/items?scope=organization&type=anti_template&limit=50&offset=0
PUT /writing-policies/preset-overrides/{presetEntryId}
DELETE /writing-policies/preset-overrides/{presetEntryId}
```

`PUT` 请求使用 `operation=override` 并携带对应类型字段时创建组织覆盖，使用 `operation=disabled` 时创建预置停用记录。`DELETE` 删除该预置项当前的组织操作并恢复基线。操作以稳定的预置条目 ID 为键，并在单个 SQLite 写事务中完成。

列表接口的 `limit` 取值为 1–100，默认 50；`offset` 必须为非负整数。响应中的 `count` 是筛选后的总数，`pageCount` 是本页数量，并同时返回 `limit`、`offset` 和 `hasMore`。Word 任务窗每页最多请求并渲染 50 条，预置和组织规范均可通过键盘可操作的上一页、下一页访问后续条目；组织规范搜索继续使用 250 ms 防抖，避免同步遍历或一次渲染完整规则库。

预置包候选、人工门禁和来源处理规则见 [`../writing-policy-sources.md`](../writing-policy-sources.md)。

## 单条维护

Word 的“设置 → 写作规范库”使用“预置规范 / 组织规范”分层切换。组织规范下可继续进入“术语规范 / 文体规则 / 去模板化规则”三级分类；列表支持搜索、新增、修改和删除。导入、CSV 导出、XLSX 导出、完整备份和规范库诊断统一位于次级“更多”页面，不占用首屏。规则编辑器包含名称、规则正文、推荐/不推荐示例、优先级、任务多选、场景多选和上下文关键词，高级字段默认折叠。删除前必须确认，保存冲突时应先检查库内是否已有相同标准写法、别名或规则名称。

组织规则接口示例：

```json
{
  "type": "anti_template",
  "name": "删除空泛铺垫",
  "ruleText": "直接陈述事实、结论和依据。",
  "positiveExample": "经测试，接口平均响应时间为 120 ms。",
  "negativeExample": "在时代发展背景下，经过不懈努力取得成效。",
  "priority": "high",
  "taskTypes": ["word.smart_write", "word.document_review"],
  "sceneIds": ["yangqi", "cybersecurity"],
  "contextKeywords": ["汇报", "验收"],
  "alwaysApply": false,
  "enabled": true
}
```

组织自定义条目和全部预置操作均保存在本机 `writing_policies.db`，关闭并重新打开 adapter 或 WPS 后继续生效。组织自定义术语优先于冲突的预置基线；组织覆盖后的条目在智能编写、智能仿写和文档审查的解析、提示词注入及本地结果检查中使用相同内容。

同一层内出现同名规则时，adapter 使用固定排序裁决：先比较规则层级和优先级，再比较任务精确度、始终应用、名称、稳定 ID 和规范化内容。结果区显示冲突组数、胜出条目 ID 和冲突名称，便于管理员回查；裁决完全在本地完成，不增加第二次模型调用。

## 新增模板

“更多 → 导入并预览”仍可下载 CSV 或 XLSX 新增模板，用于批量创建或更新组织自定义规范。仅接受单个 `.csv` 或 `.xlsx` 文件，文件大小不得超过 **5 MB**；XLSX 只解析标准模板的首个工作表。

模板列固定为：

1. 类型
2. 适用范围
3. 名称
4. 标准写法/规则
5. 别名/禁用写法
6. 推荐示例
7. 不推荐示例
8. 关键词
9. 优先级
10. 始终应用
11. 启用
12. 备注

列表字段使用 `|` 分隔。若内容本身需要字面量 `|`，写作 `\|`；反斜杠写作 `\\`。新增模板继续兼容原 12 列契约；需要维护预置覆盖、停用、恢复或删除时，应先从“更多”页面导出规范往返文件。

## 规范往返

CSV 与 XLSX 往返文件使用同一列契约：

```text
操作,稳定ID,关联预置ID,规范包ID,规范包名称,来源,来源版本,规范包版本,
层级,覆盖状态,类型,适用范围,名称,标准写法/规则,别名/禁用写法,
定义/说明,推荐示例,不推荐示例,关键词,任务范围,场景范围,优先级,始终应用,启用,备注
```

导出范围固定为：

- **当前生效规范**：导出当前启用的预置基线、组织覆盖和组织自定义规范，不包含已停用项。
- **仅组织规范**：导出组织自定义规范、组织覆盖和预置停用记录，适合完整维护现场组织数据。

往返操作语义如下：

- 预置行内容被修改，或“操作”填“修改”：创建或更新组织覆盖，不修改预置 JSON。
- 预置行“操作”填“停用”：创建预置停用记录。
- 预置行“操作”填“恢复”：删除该项当前的组织覆盖或停用记录。
- 无稳定 ID、无关联预置 ID 的新行：“操作”留空或填“新增”，创建组织自定义规范。
- 组织自定义行“操作”填“删除”：删除该稳定 ID 对应的组织规范。
- 从文件中移除一行不代表删除。没有明确“删除”操作时，库内现有行保持不变。

不要修改稳定 ID、关联预置 ID、规范包 ID、层级或类型来转移条目归属。文件中的任务范围和场景范围使用 `|` 分隔的稳定值，例如 `word.smart_write|word.document_review` 和 `yangqi|cybersecurity`。

对应接口为：

```text
GET  /writing-policies/export.csv?scope=effective
GET  /writing-policies/export.csv?scope=organization
GET  /writing-policies/export.xlsx?scope=effective
GET  /writing-policies/export.xlsx?scope=organization
POST /writing-policies/imports/preview
POST /writing-policies/imports/apply
```

## 预览、确认与回滚

导入按“选择文件 → 校验 → 处理冲突 → 应用”执行。预览令牌 10 分钟有效且只能使用一次，过期后需重新选择文件。

- 新增、修改、停用、恢复、删除、冲突和错误会分别计数，并显示对应行号。
- 前台最多展示前 100 条错误和冲突，但统计数是完整总数。
- 术语冲突默认选择**保留库内标准**，也可以跳过该行。
- 预览令牌绑定上传文件的 SHA-256 摘要；应用请求必须携带预览返回的同一摘要。
- 预览中存在错误时禁止应用；冲突项按用户确认的处理方式跳过或保留库内标准。
- 若规范条目或预置操作在预览后被其他维护操作修改，应用会拒绝覆盖并要求重新预览。
- 应用前自动创建 `writing_policies.db.backup-*` 备份，最多保留 3 份。
- 一次应用的全部变更和导入记录在同一个 SQLite 事务中完成；任何写入失败都会完整回滚，不留下部分变更。

## 完整备份

“完整备份”下载 SQLite 数据库快照，包含全部范围、条目标识及时间信息，适合整库恢复。CSV/XLSX 往返文件不能替代完整备份。数据库默认位于：

```text
adapter-start-kit/run/writing_policies.db
```

覆盖安装会保存并恢复主数据库及最多 3 个已有 `writing_policies.db.backup-*` 文件，同时继续保护 API URL、统一 Key 和工作流 Key。

## 降级与诊断

单个预置包缺失、校验失败或版本不兼容时，adapter 跳过该包，继续使用组织规范和其余可用预置包；结果区提示“写作规范暂未完整应用，已继续处理”。组织数据库不可读、迁移失败、规范解析或结果检查异常时，智能编写、智能仿写和文档审查仍继续调用既有模型工作流；规范完全未应用时结果区统一提示“写作规范暂未应用，已继续处理”，不得反馈为模型后台连接失败。

`GET /writing-policies/diagnostics` 只返回阶段、受控错误码、命中规则 ID、预置包 ID/版本、计数、解析耗时、结果检查耗时、总耗时和性能阈值状态，不返回原文、完整规则正文、文件路径、API URL 或 API Key。默认开发机性能阈值为 100 ms；麒麟 V10 验收时设置 `AI_WPS_WRITING_POLICY_PERFORMANCE_TARGET_MS=200`，阈值仅影响诊断和性能回归，不改变任务结果或模型超时。

开发机运行：

```bash
PYTHONPATH=adapter_service python3 -m unittest \
  adapter_service.tests.test_writing_policy_performance -v
```

麒麟 V10 运行：

```bash
AI_WPS_WRITING_POLICY_PERFORMANCE_TARGET_MS=200 \
PYTHONPATH=adapter_service python3 -m unittest \
  adapter_service.tests.test_writing_policy_performance -v
```

现场排查时可以结合该 diagnostics 接口确认失败阶段和是否超过本机阈值。性能诊断不得用于推断模型后台状态。

## 数据库损坏恢复

1. 停止 adapter，避免恢复期间继续写入。
2. adapter 在读取既有数据库失败或迁移前会保留 `writing_policies.db.backup-*` 原始副本；迁移失败时主文件恢复为迁移前字节，不会自动清空或重建。
3. 将损坏的 `writing_policies.db` 改名保留，不要直接删除证据。
4. 优先使用任务窗口下载的完整备份替换主数据库；没有手工备份时，选择最近的 `writing_policies.db.backup-*`。
5. 确认文件属主和权限与 `adapter-start-kit/run/` 下其他文件一致。
6. 启动 adapter，检查 `/writing-policies/summary` 和 `/writing-policies/diagnostics`。
7. 若没有可用数据库，只有在管理员明确移走损坏文件后，才允许重启 adapter 创建新库，再通过标准模板重新导入。

恢复操作不要修改 `config/adapter.json`、`run/provider_api_key` 或 `run/provider_api_keys/`。
