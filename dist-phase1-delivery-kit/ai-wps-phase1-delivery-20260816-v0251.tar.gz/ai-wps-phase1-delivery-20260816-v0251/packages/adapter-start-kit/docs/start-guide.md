# 适配层启动说明

## 目录内容

- `adapter_service/`
- `config/`
- `templates/`
- `scripts/start_adapter.sh`
- `scripts/stop_adapter.sh`
- `scripts/status_adapter.sh`
- `scripts/check_health.sh`
- `scripts/check_environment.sh`
- `scripts/show_logs.sh`
- `scripts/enable_exec_permissions.sh`
- `scripts/restart_adapter.sh`
- `scripts/install_autostart.sh`
- `scripts/uninstall_autostart.sh`

## 首次执行权限修复

如果目标机解压后脚本没有执行权限，可运行：

```bash
bash scripts/enable_exec_permissions.sh
```

如果目标机目录权限较严，需要提权：

```bash
bash scripts/enable_exec_permissions.sh sudo
```

## 启动

```bash
bash scripts/start_adapter.sh 18100
```

说明：

- 如果目标机已安装 `uvicorn`，脚本优先使用 `uvicorn`
- 如果目标机没有 `uvicorn`，脚本会自动降级到 `standalone` 模式
- `standalone` 模式只依赖系统自带 `python3`，适合先打通目标机联调

## 状态

```bash
bash scripts/status_adapter.sh 18100
```

## 一键重启

```bash
bash scripts/restart_adapter.sh 18100
```

这会按顺序执行：

- `stop_adapter.sh`
- `start_adapter.sh`
- `check_health.sh`

## 健康检查

```bash
bash scripts/check_health.sh 18100
```

脚本先检查 `/health/live`，再读取聚合 `/health`。聚合状态为 `ready` 时核心与增强子系统均正常；`degraded` 表示增强能力降级但核心任务仍可用；`recovery` 表示进程存活但业务未就绪，脚本返回非零并提示先备份和导出脱敏诊断。

如果返回 `adapter_health=unreachable`，继续执行：

```bash
bash scripts/show_logs.sh 50
```

## 停止

```bash
bash scripts/stop_adapter.sh 18100
```

## 开机自启动

麒麟 V10 目标机如果每次重启后 adapter 停止，可以安装 systemd 自启动服务：

```bash
bash scripts/install_autostart.sh 18100
```

安装后确认：

```bash
systemctl status ai-wps-adapter.service --no-pager
bash scripts/status_adapter.sh 18100
```

取消自启动：

```bash
bash scripts/uninstall_autostart.sh
```

详细说明见 `docs/autostart-guide.md`。
