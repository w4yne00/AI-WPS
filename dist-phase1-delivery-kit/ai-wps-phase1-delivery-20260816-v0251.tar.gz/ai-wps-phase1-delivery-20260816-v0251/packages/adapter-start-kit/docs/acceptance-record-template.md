# 适配层启动验收记录模板

## 基本信息

- 验证日期：
- 验证人员：
- 终端编号：
- 启动包版本：

## 环境检查

- `machine`：
- `python3_version`：
- `curl_path`：

## 启动检查

- 启动命令：
- 启动结果：
- PID：
- 日志文件路径：

## 健康检查

- `/health/live` 输出：
- `/health/ready` HTTP 状态和输出：
- `/health` 聚合状态（ready/degraded/recovery）：
- `/templates` 是否可访问：

## 问题记录

- 问题 1：
- 问题 2：

## 结论

- 是否通过：
- 后续动作：
