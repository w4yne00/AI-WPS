#!/usr/bin/env bash
set -euo pipefail

PORT="${1:-18100}"
BASE_URL="http://127.0.0.1:${PORT}"
LIVE_URL="$BASE_URL/health/live"
READY_URL="$BASE_URL/health/ready"
HEALTH_URL="$BASE_URL/health"
STATUS_URL="$BASE_URL/provider/status"
ROUTE_URL="$BASE_URL/provider/route-diagnostics"
DEBUG_URL="$BASE_URL/provider/debug-last"

if ! command -v curl >/dev/null 2>&1; then
  echo "curl_missing"
  exit 1
fi

read_endpoint() {
  curl -fsS "$1" 2>/dev/null || true
}

read_http_status() {
  curl -sS -o /dev/null -w '%{http_code}' "$1" 2>/dev/null || true
}

json_value() {
  printf '%s' "$1" | sed -n 's/.*"'"$2"'"[[:space:]]*:[[:space:]]*"\{0,1\}\([^",}]*\)"\{0,1\}.*/\1/p' | head -n 1
}

print_endpoint() {
  local label="$1"
  local url="$2"
  local body
  body="$(read_endpoint "$url")"
  if [ -n "$body" ]; then
    echo "${label}=reachable url=$url"
    printf '%s\n' "$body"
  else
    echo "${label}=unreachable url=$url"
  fi
  echo
}

LIVE_BODY="$(read_endpoint "$LIVE_URL")"
if [ -z "$LIVE_BODY" ]; then
  echo "adapter_health=unreachable url=$LIVE_URL"
  echo "possible_causes=service_not_started|startup_crash|wrong_port|local_firewall"
  echo "next_step_1=bash scripts/status_adapter.sh ${PORT}"
  echo "next_step_2=bash scripts/show_logs.sh 80"
  exit 1
fi

echo "adapter_health=reachable url=$LIVE_URL"
printf '%s\n' "$LIVE_BODY"
echo

HEALTH_BODY="$(read_endpoint "$HEALTH_URL")"
if [ -z "$HEALTH_BODY" ]; then
  echo "adapter_business_status=unknown url=$HEALTH_URL"
  exit 1
fi

READY_HTTP_STATUS="$(read_http_status "$READY_URL")"
if [ "$READY_HTTP_STATUS" != "200" ] && [ "$READY_HTTP_STATUS" != "503" ]; then
  echo "adapter_readiness=unknown http_status=${READY_HTTP_STATUS:-unreachable} url=$READY_URL"
  exit 1
fi

printf '%s\n' "$HEALTH_BODY"
MODE="$(json_value "$HEALTH_BODY" mode)"
VERSION="$(json_value "$HEALTH_BODY" version)"
BUSINESS_STATUS="$(json_value "$HEALTH_BODY" status)"
if [ "$READY_HTTP_STATUS" = "503" ]; then
  BUSINESS_STATUS="recovery"
fi
PROVIDER_CONFIGURED="$(json_value "$HEALTH_BODY" providerConfigured)"
AUTH_SOURCE="$(json_value "$HEALTH_BODY" providerAuthSource)"
echo
echo "adapter_business_status=${BUSINESS_STATUS:-unknown} ready_http_status=$READY_HTTP_STATUS ready_url=$READY_URL"
if [ "$MODE" = "uvicorn" ]; then
  echo "adapter_mode=uvicorn"
  echo "adapter_runtime=fastapi"
elif [ "$MODE" = "standalone" ]; then
  echo "adapter_mode=standalone"
else
  echo "adapter_mode=${MODE:-unknown}"
fi
echo "adapter_version=${VERSION:-unknown}"
echo "provider_configured=${PROVIDER_CONFIGURED:-unknown}"
echo "provider_auth_source=${AUTH_SOURCE:-unknown}"
if [ "$MODE" != "uvicorn" ]; then
  echo "hint=当前不是 uvicorn；执行 bash scripts/restart_adapter.sh ${PORT} 切换到 uvicorn。"
fi
if [ "$BUSINESS_STATUS" = "recovery" ]; then
  echo "hint=Adapter 已存活但业务未就绪；配置变更和模型任务已被阻止，请先备份并导出脱敏诊断。"
  exit 1
fi
if [ "$PROVIDER_CONFIGURED" != "true" ]; then
  echo "hint=provider 未配置完整；真实转发需要同时保存 API URL 和统一 Dify API Key，否则日志会出现 provider=mock。"
fi
echo

print_endpoint "provider_status" "$STATUS_URL"
print_endpoint "provider_route_diagnostics" "$ROUTE_URL"
print_endpoint "provider_debug_last" "$DEBUG_URL"
