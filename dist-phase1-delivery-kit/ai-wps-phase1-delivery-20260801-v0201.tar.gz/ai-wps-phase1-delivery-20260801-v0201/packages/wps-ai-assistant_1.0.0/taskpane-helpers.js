(function (root, factory) {
  var exports = factory();
  root.WpsAiAssistantHelpers = exports;
  if (typeof module === "object" && module.exports) {
    module.exports = exports;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  function normalizeText(text) {
    return String(text || "").replace(/\r/g, "").trim();
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function sanitizeMarkdownUrl(value) {
    var url = String(value || "").trim();
    if (/^(https?:\/\/|mailto:)/i.test(url)) {
      return url;
    }
    return "";
  }

  function renderInlineMarkdown(value) {
    var tokens = [];
    var text = String(value || "");

    function storeToken(html) {
      var token = "\u0000MDTOKEN" + tokens.length + "\u0000";
      tokens.push({ token: token, html: html });
      return token;
    }

    text = text.replace(/`([^`]+)`/g, function (_match, code) {
      return storeToken("<code>" + escapeHtml(code) + "</code>");
    });

    text = text.replace(/(!?)\[([^\]]+)\]\(([^)\s]+)\)/g, function (match, imagePrefix, label, url) {
      var safeUrl = imagePrefix ? "" : sanitizeMarkdownUrl(url);
      if (!safeUrl) {
        return escapeHtml(label || match);
      }
      return storeToken(
        '<a href="' + escapeHtml(safeUrl) + '" target="_blank" rel="noopener noreferrer">' +
        escapeHtml(label) +
        "</a>"
      );
    });

    text = escapeHtml(text)
      .replace(/==([^=\n]+)==/g, '<mark class="smart-diff-highlight">$1</mark>')
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/\*([^*]+)\*/g, "<em>$1</em>");

    tokens.forEach(function (entry) {
      text = text.split(escapeHtml(entry.token)).join(entry.html);
    });
    return text;
  }

  function renderMarkdown(markdown) {
    var lines = String(markdown || "").replace(/\r/g, "").split("\n");
    var html = [];
    var paragraph = [];
    var listType = "";
    var inCode = false;
    var codeLang = "";
    var codeLines = [];
    var tableRows = [];

    function closeList() {
      if (listType) {
        html.push("</" + listType + ">");
        listType = "";
      }
    }

    function flushParagraph() {
      if (paragraph.length) {
        closeList();
        html.push("<p>" + paragraph.map(renderInlineMarkdown).join("<br>") + "</p>");
        paragraph = [];
      }
    }

    function splitTableRow(line) {
      var value = String(line || "").trim();
      if (value.charAt(0) === "|") {
        value = value.slice(1);
      }
      if (value.charAt(value.length - 1) === "|") {
        value = value.slice(0, -1);
      }
      return value.split("|").map(function (cell) {
        return cell.trim();
      });
    }

    function isTableSeparator(line) {
      var cells = splitTableRow(line);
      return cells.length > 0 && cells.every(function (cell) {
        return /^:?-{3,}:?$/.test(cell);
      });
    }

    function isTableLine(line) {
      return /\|/.test(line || "");
    }

    function flushTable() {
      if (tableRows.length < 2 || !isTableSeparator(tableRows[1])) {
        tableRows.forEach(function (row) {
          paragraph.push(row.trim());
        });
        tableRows = [];
        return;
      }

      flushParagraph();
      closeList();
      var headers = splitTableRow(tableRows[0]);
      var bodyRows = tableRows.slice(2);
      html.push('<div class="markdown-table-wrap"><table><thead><tr>');
      headers.forEach(function (cell) {
        html.push("<th>" + renderInlineMarkdown(cell) + "</th>");
      });
      html.push("</tr></thead><tbody>");
      bodyRows.forEach(function (row) {
        html.push("<tr>");
        splitTableRow(row).forEach(function (cell) {
          html.push("<td>" + renderInlineMarkdown(cell) + "</td>");
        });
        html.push("</tr>");
      });
      html.push("</tbody></table></div>");
      tableRows = [];
    }

    function openList(nextType) {
      flushParagraph();
      if (listType !== nextType) {
        closeList();
        html.push("<" + nextType + ">");
        listType = nextType;
      }
    }

    lines.forEach(function (line) {
      var codeFence = line.match(/^```([A-Za-z0-9_-]*)\s*$/);
      var heading = line.match(/^(#{1,6})\s+(.+)$/);
      var unordered = line.match(/^\s*[-*+]\s+(.+)$/);
      var ordered = line.match(/^\s*\d+\.\s+(.+)$/);
      var quote = line.match(/^>\s?(.+)$/);
      var divider = /^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/.test(line);

      if (inCode) {
        if (codeFence) {
          html.push(
            '<pre><code' +
            (codeLang ? ' class="language-' + escapeHtml(codeLang) + '"' : "") +
            ">" +
            escapeHtml(codeLines.join("\n")) +
            "</code></pre>"
          );
          inCode = false;
          codeLang = "";
          codeLines = [];
          return;
        }
        codeLines.push(line);
        return;
      }

      if (tableRows.length && !isTableLine(line)) {
        flushTable();
      }

      if (codeFence) {
        flushTable();
        flushParagraph();
        closeList();
        inCode = true;
        codeLang = codeFence[1] || "";
        codeLines = [];
        return;
      }

      if (!line.trim()) {
        flushTable();
        flushParagraph();
        closeList();
        return;
      }

      if (isTableLine(line)) {
        tableRows.push(line);
        return;
      }

      if (heading) {
        flushTable();
        flushParagraph();
        closeList();
        html.push(
          "<h" + heading[1].length + ">" +
          renderInlineMarkdown(heading[2]) +
          "</h" + heading[1].length + ">"
        );
        return;
      }

      if (divider) {
        flushTable();
        flushParagraph();
        closeList();
        html.push("<hr>");
        return;
      }

      if (unordered) {
        flushTable();
        openList("ul");
        html.push("<li>" + renderInlineMarkdown(unordered[1]) + "</li>");
        return;
      }

      if (ordered) {
        flushTable();
        openList("ol");
        html.push("<li>" + renderInlineMarkdown(ordered[1]) + "</li>");
        return;
      }

      if (quote) {
        flushTable();
        flushParagraph();
        closeList();
        html.push("<blockquote>" + renderInlineMarkdown(quote[1]) + "</blockquote>");
        return;
      }

      paragraph.push(line.trim());
    });

    if (inCode) {
      html.push(
        '<pre><code' +
        (codeLang ? ' class="language-' + escapeHtml(codeLang) + '"' : "") +
        ">" +
        escapeHtml(codeLines.join("\n")) +
        "</code></pre>"
      );
    }
    flushTable();
    flushParagraph();
    closeList();

    return html.join("\n");
  }

  function stripInlineMarkdownForWriteback(value) {
    return String(value || "")
      .replace(/`([^`]+)`/g, "$1")
      .replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1")
      .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
      .replace(/\*\*([^*]+)\*\*/g, "$1")
      .replace(/\*([^*]+)\*/g, "$1")
      .replace(/\*{1,3}/g, "");
  }

  function buildInlineWritebackRuns(value) {
    var runs = [];
    var source = String(value || "");
    var pattern = /\*\*([^*]+)\*\*/g;
    var lastIndex = 0;
    var match;

    while ((match = pattern.exec(source)) !== null) {
      if (match.index > lastIndex) {
        runs.push({
          text: stripInlineMarkdownForWriteback(source.slice(lastIndex, match.index)),
          bold: false
        });
      }
      runs.push({
        text: stripInlineMarkdownForWriteback(match[1]),
        bold: true
      });
      lastIndex = pattern.lastIndex;
    }

    if (lastIndex < source.length) {
      runs.push({
        text: stripInlineMarkdownForWriteback(source.slice(lastIndex)),
        bold: false
      });
    }

    return runs.filter(function (run) {
      return Boolean(run.text);
    });
  }

  function buildMarkdownWritebackBlocks(markdown) {
    var lines = String(markdown || "").replace(/\r/g, "").split("\n");
    var blocks = [];
    var paragraph = [];
    var inCode = false;
    var codeLines = [];

    function pushBlock(type, text, extras) {
      var cleanText = stripInlineMarkdownForWriteback(text);
      var block;
      var key;
      if (!cleanText) {
        return;
      }
      block = {
        type: type,
        text: cleanText,
        runs: buildInlineWritebackRuns(text)
      };
      extras = extras || {};
      for (key in extras) {
        if (Object.prototype.hasOwnProperty.call(extras, key)) {
          block[key] = extras[key];
        }
      }
      blocks.push(block);
    }

    function flushParagraph() {
      if (!paragraph.length) {
        return;
      }
      pushBlock("paragraph", paragraph.join("\n"));
      paragraph = [];
    }

    lines.forEach(function (line) {
      var codeFence = line.match(/^```([A-Za-z0-9_-]*)\s*$/);
      var heading = line.match(/^(#{1,6})\s+(.+)$/);
      var unordered = line.match(/^\s*[-*+]\s+(.+)$/);
      var ordered = line.match(/^\s*(\d+)\.\s+(.+)$/);
      var divider = /^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/.test(line);

      if (inCode) {
        if (codeFence) {
          pushBlock("paragraph", codeLines.join("\n"));
          inCode = false;
          codeLines = [];
          return;
        }
        codeLines.push(line);
        return;
      }

      if (codeFence) {
        flushParagraph();
        inCode = true;
        codeLines = [];
        return;
      }

      if (!line.trim()) {
        flushParagraph();
        return;
      }

      if (divider) {
        flushParagraph();
        return;
      }

      if (heading) {
        flushParagraph();
        pushBlock("heading", heading[2], { level: heading[1].length });
        return;
      }

      if (unordered) {
        flushParagraph();
        pushBlock("unorderedListItem", unordered[1]);
        return;
      }

      if (ordered) {
        flushParagraph();
        pushBlock("orderedListItem", ordered[2], { ordinal: Number(ordered[1]) });
        return;
      }

      paragraph.push(line.trim());
    });

    if (inCode) {
      pushBlock("paragraph", codeLines.join("\n"));
    }
    flushParagraph();
    return blocks;
  }

  function hasStructuredSmartWriteContent(value) {
    var text = String(value || "").replace(/\r/g, "\n");
    var lines = text.split("\n");
    var nonEmpty = lines.filter(function (line) {
      return Boolean(line.trim());
    });

    if (!text.trim()) {
      return false;
    }
    if (/(^|\n)\s{0,3}#{1,6}\s+\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*[-*+•·]\s+\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*\d+[.)．、]\s+\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*[一二三四五六七八九十]+[、.．]\s*\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*[（(][一二三四五六七八九十\d]+[）)]\s*\S/.test(text)) {
      return true;
    }
    if (/(^|\n)\s*第[一二三四五六七八九十\d]+[章节条]\s*\S/.test(text)) {
      return true;
    }
    if (/\*\*[^*\n]+\*\*/.test(text)) {
      return true;
    }
    if (/\|.+\|/.test(text) && /(^|\n)\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*(\n|$)/.test(text)) {
      return true;
    }
    if (nonEmpty.length >= 2 && nonEmpty.some(function (line) {
      return line.split("\t").length >= 2;
    })) {
      return true;
    }
    return false;
  }

  function shouldUseStructuredSmartWriteResult(originalText, rewrittenText) {
    return hasStructuredSmartWriteContent(originalText) || hasStructuredSmartWriteContent(rewrittenText);
  }

  function getSmartWriteParagraphs(value) {
    return String(value || "")
      .replace(/\r/g, "\n")
      .split(/\n+/)
      .map(function (line) {
        return line.trim();
      })
      .filter(Boolean);
  }

  function normalizeSmartWriteLineBreaks(value) {
    return String(value || "")
      .replace(/\r/g, "\n")
      .replace(/[ \t]+\n/g, "\n")
      .replace(/\n[ \t]+/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function breakInlineSmartWriteStructure(value) {
    var text = normalizeSmartWriteLineBreaks(value);
    var boundary = "([。！？；;!?””）\\)])";
    var patterns = [
      new RegExp(boundary + "\\s*(#{1,6}\\s+\\S)", "g"),
      new RegExp(boundary + "\\s*([一二三四五六七八九十]+[、.．]\\s*\\S)", "g"),
      new RegExp(boundary + "\\s*([（(][一二三四五六七八九十\\d]+[）)]\\s*\\S)", "g"),
      new RegExp(boundary + "\\s*(第[一二三四五六七八九十\\d]+[章节条]\\s*\\S)", "g"),
      new RegExp(boundary + "\\s*(\\d+[.)．、]\\s+\\S)", "g"),
      new RegExp(boundary + "\\s*([-*+•·]\\s+\\S)", "g")
    ];
    patterns.forEach(function (pattern) {
      text = text.replace(pattern, "$1\n\n$2");
    });
    return normalizeSmartWriteLineBreaks(text);
  }

  function splitSmartWriteSentences(value) {
    var text = normalizeSmartWriteLineBreaks(value);
    var matches = text.match(/[^。！？；!?;]+[。！？；!?;]*/g);
    if (!matches || !matches.length) {
      return text ? [text] : [];
    }
    return matches.map(function (sentence) {
      return sentence.trim();
    }).filter(Boolean);
  }

  function distributeSmartWriteSentences(sentences, targetCount) {
    var paragraphs = [];
    var totalLength = 0;
    var consumedLength = 0;
    var sentenceIndex = 0;
    var lengthIndex;

    for (lengthIndex = 0; lengthIndex < sentences.length; lengthIndex += 1) {
      totalLength += sentences[lengthIndex].length;
    }

    for (var paragraphIndex = 0; paragraphIndex < targetCount; paragraphIndex += 1) {
      var remainingParagraphs = targetCount - paragraphIndex;
      var paragraphSentences = [];
      var targetLength = totalLength * (paragraphIndex + 1) / targetCount;

      if (remainingParagraphs === 1) {
        paragraphSentences = sentences.slice(sentenceIndex);
        sentenceIndex = sentences.length;
      } else {
        while (sentenceIndex < sentences.length - (remainingParagraphs - 1)) {
          paragraphSentences.push(sentences[sentenceIndex]);
          consumedLength += sentences[sentenceIndex].length;
          sentenceIndex += 1;
          if (consumedLength >= targetLength) {
            break;
          }
        }
      }

      if (paragraphSentences.length) {
        paragraphs.push(paragraphSentences.join(""));
      }
    }

    return paragraphs.filter(Boolean);
  }

  function formatSmartWriteResult(originalText, rewrittenText) {
    var normalized = normalizeSmartWriteLineBreaks(rewrittenText);
    var originalParagraphs;
    var targetCount;
    var structuredText;
    var sentences;
    var distributed;

    if (!normalized) {
      return "";
    }
    if (getSmartWriteParagraphs(normalized).length >= 2) {
      return normalized;
    }

    structuredText = breakInlineSmartWriteStructure(normalized);
    if (getSmartWriteParagraphs(structuredText).length >= 2) {
      return structuredText;
    }

    originalParagraphs = getSmartWriteParagraphs(originalText);
    if (originalParagraphs.length < 2) {
      return normalized;
    }

    targetCount = Math.min(originalParagraphs.length, 6);
    sentences = splitSmartWriteSentences(normalized);
    if (sentences.length < targetCount) {
      return normalized;
    }

    distributed = distributeSmartWriteSentences(sentences, targetCount);
    return distributed.length >= 2 ? distributed.join("\n\n") : normalized;
  }

  function normalizeSmartWriteComparisonLine(value) {
    return String(value || "").replace(/\s+/g, "").trim();
  }

  function sanitizeSmartWriteHighlightText(value) {
    return String(value || "").replace(/==/g, "＝");
  }

  function getSmartWriteCommonPrefixLength(left, right) {
    var index = 0;
    var maxLength = Math.min(left.length, right.length);
    while (index < maxLength && left.charAt(index) === right.charAt(index)) {
      index += 1;
    }
    return index;
  }

  function getSmartWriteCommonSuffixLength(left, right, prefixLength) {
    var suffixLength = 0;
    var maxLength = Math.min(left.length, right.length) - prefixLength;
    while (
      suffixLength < maxLength &&
      left.charAt(left.length - 1 - suffixLength) === right.charAt(right.length - 1 - suffixLength)
    ) {
      suffixLength += 1;
    }
    return suffixLength;
  }

  function markSmartWriteInsertedSegment(value) {
    return value ? "==" + sanitizeSmartWriteHighlightText(value) + "==" : "";
  }

  function markSmartWriteDiffSegments(originalText, rewrittenText) {
    var original = String(originalText || "");
    var rewritten = String(rewrittenText || "");
    var originalLength = original.length;
    var rewrittenLength = rewritten.length;
    var matrixSize = originalLength * rewrittenLength;
    var dp;
    var i;
    var j;
    var pieces = [];
    var pending = "";

    if (!rewrittenLength) {
      return "";
    }
    if (!originalLength) {
      return markSmartWriteInsertedSegment(rewritten);
    }
    if (matrixSize > 40000) {
      return markSmartWriteInsertedSegment(rewritten);
    }

    dp = new Array(originalLength + 1);
    for (i = 0; i <= originalLength; i += 1) {
      dp[i] = new Array(rewrittenLength + 1).fill(0);
    }

    for (i = originalLength - 1; i >= 0; i -= 1) {
      for (j = rewrittenLength - 1; j >= 0; j -= 1) {
        if (original.charAt(i) === rewritten.charAt(j)) {
          dp[i][j] = dp[i + 1][j + 1] + 1;
        } else {
          dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1]);
        }
      }
    }

    function flushPending() {
      if (pending) {
        pieces.push(markSmartWriteInsertedSegment(pending));
        pending = "";
      }
    }

    i = 0;
    j = 0;
    while (j < rewrittenLength) {
      if (i < originalLength && original.charAt(i) === rewritten.charAt(j)) {
        flushPending();
        pieces.push(rewritten.charAt(j));
        i += 1;
        j += 1;
      } else if (i < originalLength && (j >= rewrittenLength || dp[i + 1][j] >= dp[i][j + 1])) {
        i += 1;
      } else {
        pending += rewritten.charAt(j);
        j += 1;
      }
    }
    flushPending();

    return pieces.join("");
  }

  function markSmartWriteChangedText(originalValue, rewrittenValue) {
    var rewritten = String(rewrittenValue || "");
    var original = String(originalValue || "");
    var edgeMatch = rewritten.match(/^(\s*)([\s\S]*?)(\s*)$/);
    var leading = edgeMatch ? edgeMatch[1] : "";
    var body = edgeMatch ? edgeMatch[2] : rewritten;
    var trailing = edgeMatch ? edgeMatch[3] : "";
    var originalBody = original.trim();
    var prefixLength;
    var suffixLength;
    var changedStart;
    var changedEnd;
    var changedText;
    var originalChangedText;

    if (!body || normalizeSmartWriteComparisonLine(original) === normalizeSmartWriteComparisonLine(rewritten)) {
      return rewritten;
    }

    prefixLength = getSmartWriteCommonPrefixLength(originalBody, body);
    suffixLength = getSmartWriteCommonSuffixLength(originalBody, body, prefixLength);
    changedStart = prefixLength;
    changedEnd = body.length - suffixLength;
    changedText = body.slice(changedStart, changedEnd);
    originalChangedText = originalBody.slice(prefixLength, originalBody.length - suffixLength);

    if (!changedText) {
      return rewritten;
    }

    return leading +
      body.slice(0, changedStart) +
      markSmartWriteDiffSegments(originalChangedText, changedText) +
      body.slice(changedEnd) +
      trailing;
  }

  function getSmartWriteComparableLineText(line) {
    var text = String(line || "");
    var match = text.match(/^(\s*#{1,6}\s+)(.+)$/) ||
      text.match(/^(\s*[-*+]\s+)(.+)$/) ||
      text.match(/^(\s*\d+\.\s+)(.+)$/) ||
      text.match(/^(>\s?)(.+)$/);
    return match ? match[2] : text;
  }

  function markSmartWriteTableLine(originalLine, line) {
    var originalCells = String(originalLine || "").split("|");
    return String(line || "").split("|").map(function (cell, index) {
      var trimmed = cell.trim();
      if (!trimmed || /^:?-{3,}:?$/.test(trimmed)) {
        return cell;
      }
      return markSmartWriteChangedText(originalCells[index] || "", cell);
    }).join("|");
  }

  function markSmartWriteComparisonLine(originalLine, line) {
    var text = String(line || "");
    var originalText = String(originalLine || "");
    var tableSeparator = /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(text);
    var match;
    if (!text.trim()) {
      return text;
    }
    if (tableSeparator) {
      return text;
    }
    if (text.indexOf("|") >= 0) {
      return markSmartWriteTableLine(originalText, text);
    }
    match = text.match(/^(\s*#{1,6}\s+)(.+)$/);
    if (match) {
      return match[1] + markSmartWriteChangedText(getSmartWriteComparableLineText(originalText), match[2]);
    }
    match = text.match(/^(\s*[-*+]\s+)(.+)$/);
    if (match) {
      return match[1] + markSmartWriteChangedText(getSmartWriteComparableLineText(originalText), match[2]);
    }
    match = text.match(/^(\s*\d+\.\s+)(.+)$/);
    if (match) {
      return match[1] + markSmartWriteChangedText(getSmartWriteComparableLineText(originalText), match[2]);
    }
    match = text.match(/^(>\s?)(.+)$/);
    if (match) {
      return match[1] + markSmartWriteChangedText(getSmartWriteComparableLineText(originalText), match[2]);
    }
    return markSmartWriteChangedText(originalText, text);
  }

  function buildHighlightedSmartWriteResult(originalText, rewrittenText) {
    var originalLines = normalizeSmartWriteLineBreaks(originalText)
      .split("\n")
      .map(function (line) {
        return line.trim();
      })
      .filter(Boolean);
    var rewrittenLines = normalizeSmartWriteLineBreaks(rewrittenText).split("\n");
    var originalIndex = 0;
    return rewrittenLines.map(function (line) {
      var cleanLine = line.trim();
      var originalLine;
      var changed;
      if (!cleanLine) {
        return line;
      }
      originalLine = originalLines[originalIndex] || "";
      changed = normalizeSmartWriteComparisonLine(cleanLine) !== normalizeSmartWriteComparisonLine(originalLine);
      originalIndex += 1;
      return changed ? markSmartWriteComparisonLine(originalLine, line) : line;
    }).join("\n");
  }

  function buildSmartWritePreviewModel(result) {
    var source = result || {};
    var originalText = normalizeSmartWriteLineBreaks(source.originalText || "");
    var rewrittenText = formatSmartWriteResult(originalText, source.rewrittenText || "");
    var hasOriginal = Boolean(originalText);
    var highlightedText = hasOriginal ? buildHighlightedSmartWriteResult(originalText, rewrittenText) : rewrittenText;
    var comparisonMarkdown = "";

    if (hasOriginal && rewrittenText) {
      comparisonMarkdown = [
        "### 原文",
        "",
        originalText,
        "",
        "### 智能编写结果",
        "",
        highlightedText
      ].join("\n");
    } else {
      comparisonMarkdown = rewrittenText;
    }

    return {
      previewMarkdown: rewrittenText,
      plainText: rewrittenText,
      comparisonMarkdown: comparisonMarkdown,
      hasOriginal: hasOriginal,
      hasStructuredResult: shouldUseStructuredSmartWriteResult(originalText, rewrittenText)
    };
  }

  var FORMAT_REVIEW_GROUP_ORDER = [
    "page_setup",
    "heading",
    "body_text",
    "paragraph",
    "caption_note",
    "other"
  ];
  var FORMAT_REVIEW_GROUP_TEXT = {
    page_setup: "页面设置",
    heading: "标题层级",
    body_text: "正文格式",
    paragraph: "段落格式",
    caption_note: "图表题/注释",
    other: "其他格式项"
  };
  var FORMAT_REVIEW_ROLE_TEXT = {
    document_title: "文档标题",
    heading1: "一级标题",
    heading2: "二级标题",
    heading3: "三级标题",
    heading4: "四级标题",
    caption: "图表题",
    note: "无编号注",
    numbered_note: "有编号注",
    list1_numbered: "一级编号列项",
    list1_plain: "一级无编号列项",
    list2_numbered: "二级编号列项",
    list2_plain: "二级无编号列项",
    appendix_title: "附录标题",
    appendix_heading1: "附录一级标题",
    appendix_heading2: "附录二级标题",
    appendix_heading3: "附录三级标题",
    table_body: "表正文",
    body: "正文",
    page_setup: "页面设置"
  };
  var FORMAT_REVIEW_RULE_TEXT = {
    page_setup: "页面设置",
    style_name: "段落样式",
    font_name: "字体",
    font_size: "字号",
    line_spacing: "行距",
    alignment: "对齐方式",
    first_line_indent: "首行缩进"
  };
  var FORMAT_REVIEW_TEMPLATE_TEXT = {
    "technical-file-format-requirements": "技术文件格式及书写要求",
    "general-office": "通用办公文档格式"
  };
  var FORMAT_REVIEW_STYLE_TEXT = {
    Normal: "正文样式（Normal）",
    Body: "正文样式（Body）",
    body: "正文样式",
    "heading 1": "一级标题样式（heading 1）",
    "heading 2": "二级标题样式（heading 2）",
    "heading 3": "三级标题样式（heading 3）",
    "heading 4": "四级标题样式（heading 4）",
    Caption: "图表题样式（Caption）",
    caption: "图表题样式（caption）"
  };
  var FORMAT_REVIEW_ALIGNMENT_TEXT = {
    left: "左对齐",
    center: "居中",
    right: "右对齐",
    justify: "两端对齐",
    justified: "两端对齐",
    distribute: "分散对齐",
    distributed: "分散对齐",
    "0": "左对齐",
    "1": "居中",
    "2": "右对齐",
    "3": "两端对齐",
    "4": "分散对齐"
  };
  var FORMAT_REVIEW_FONT_TEXT = {
    simsun: "宋体",
    "songti sc": "宋体",
    "songti": "宋体",
    "宋体": "宋体",
    simhei: "黑体",
    "黑体": "黑体",
    kaiti: "楷体",
    "楷体": "楷体",
    fangsong: "仿宋",
    "仿宋": "仿宋"
  };
  var FORMAT_REVIEW_SIZE_TEXT = {
    "22": "二号",
    "18": "小二",
    "16": "三号",
    "15": "小三",
    "14": "四号",
    "12": "小四",
    "10.5": "五号",
    "9": "小五"
  };

  function formatReviewGroupItems(items, getKey) {
    var grouped = {};
    (items || []).forEach(function (item) {
      var key = getKey(item) || "other";
      if (!grouped[key]) {
        grouped[key] = [];
      }
      grouped[key].push(item);
    });
    return grouped;
  }

  function getFormatReviewGroup(issue) {
    var ruleId = String((issue && issue.ruleId) || "");
    var role = String((issue && issue.role) || "");
    if (ruleId === "page_setup") {
      return "page_setup";
    }
    if (role.indexOf("heading") >= 0 || role.indexOf("title") >= 0) {
      return "heading";
    }
    if (ruleId === "style_name" || ruleId === "font_name" || ruleId === "font_size") {
      return "body_text";
    }
    if (ruleId === "line_spacing" || ruleId === "alignment" || ruleId === "first_line_indent") {
      return "paragraph";
    }
    if (role.indexOf("caption") >= 0 || role.indexOf("note") >= 0 || ruleId.indexOf("caption") >= 0 || ruleId.indexOf("note") >= 0) {
      return "caption_note";
    }
    return "other";
  }

  function formatAiFallbackReason(reason) {
    var reasonText = {
      no_paragraphs: "未读取到正文段落，未调用模型后台；请确认当前文档对象能暴露正文段落或全文文本。",
      provider_not_configured: "统一 API URL 或格式审查任务 API Key 未形成可用配置，已使用本地模板规则。",
      dify_response_not_role_json: "模型后台未返回段落角色 JSON，已使用本地模板规则。",
      provider_request_failed: "模型后台请求失败，已使用本地模板规则。",
      dify_response_no_valid_roles: "模型后台返回的角色无效，已使用本地模板规则。",
      dify_returned_no_roles: "模型后台未返回有效段落角色，已使用本地模板规则。",
      ai_budget_limited: "文档段落较多，AI 角色识别仅处理前 40 段；其余段落已使用本地模板规则。"
    };
    return reasonText[reason] || (reason ? "未记录的 AI 兜底原因，已使用本地模板规则。" : "");
  }

  function formatReviewRole(role) {
    return FORMAT_REVIEW_ROLE_TEXT[String(role || "")] || "未识别角色";
  }

  function formatReviewRule(ruleId) {
    return FORMAT_REVIEW_RULE_TEXT[String(ruleId || "")] || "其他格式项";
  }

  function formatReviewTemplate(templateId) {
    return FORMAT_REVIEW_TEMPLATE_TEXT[String(templateId || "")] || "当前格式模板";
  }

  function parseFormatReviewNumber(value) {
    var match = String(value || "").match(/-?\d+(?:\.\d+)?/);
    return match ? Number(match[0]) : null;
  }

  function formatReviewFontName(value) {
    var raw = String(value || "").trim();
    var normalized = raw.toLowerCase();
    return FORMAT_REVIEW_FONT_TEXT[normalized] || FORMAT_REVIEW_FONT_TEXT[raw] || raw || "未读取";
  }

  function formatReviewFontSize(value) {
    var numeric = parseFormatReviewNumber(value);
    var key;
    var label;
    if (numeric === null || isNaN(numeric)) {
      return String(value || "").trim() || "未读取";
    }
    key = String(Math.round(numeric * 10) / 10).replace(/\.0$/, "");
    label = FORMAT_REVIEW_SIZE_TEXT[key];
    return label ? label + "（" + key + "pt）" : key + "pt";
  }

  function formatReviewStyleName(value) {
    var raw = String(value || "").trim();
    return FORMAT_REVIEW_STYLE_TEXT[raw] || raw || "未读取";
  }

  function formatReviewAlignment(value) {
    var raw = String(value || "").trim();
    var key = raw.toLowerCase();
    return FORMAT_REVIEW_ALIGNMENT_TEXT[key] || FORMAT_REVIEW_ALIGNMENT_TEXT[raw] || raw || "未读取";
  }

  function formatReviewLineSpacing(value) {
    var numeric = parseFormatReviewNumber(value);
    if (numeric === null || isNaN(numeric)) {
      return String(value || "").trim() || "未读取";
    }
    if (Math.abs(numeric - 1) < 0.01) {
      return "单倍行距（1倍）";
    }
    if (Math.abs(numeric - 1.5) < 0.01) {
      return "1.5 倍行距";
    }
    return numeric + " 倍行距";
  }

  function formatReviewIndent(value) {
    var numeric = parseFormatReviewNumber(value);
    if (numeric === null || isNaN(numeric)) {
      return String(value || "").trim() || "未读取";
    }
    if (Math.abs(numeric) < 0.01) {
      return "无首行缩进";
    }
    if (Math.abs(numeric - 480) <= 20 || Math.abs(numeric - 640) <= 20) {
      return "首行缩进 2 字符（约 " + numeric + " twips）";
    }
    return "首行缩进约 " + numeric + " twips";
  }

  function formatReviewPageSetup(value) {
    var raw = String(value || "").trim();
    if (!raw || raw === "{}") {
      return "未读取";
    }
    if (raw.charAt(0) !== "{") {
      return raw;
    }
    try {
      var data = JSON.parse(raw);
      var parts = [];
      if (data.paperSize || data.PaperSize) {
        parts.push("纸张：" + (data.paperSize || data.PaperSize));
      }
      if (data.marginTop || data.marginBottom || data.marginLeft || data.marginRight) {
        parts.push(
          "页边距：上 " + (data.marginTop || "未读") +
          "、下 " + (data.marginBottom || "未读") +
          "、左 " + (data.marginLeft || "未读") +
          "、右 " + (data.marginRight || "未读")
        );
      }
      return parts.length ? parts.join("；") : raw;
    } catch (error) {
      return raw;
    }
  }

  function formatReviewValue(ruleId, value, isExpected) {
    var rule = String(ruleId || "");
    if (rule === "font_name") {
      return isExpected ? "宋体" : formatReviewFontName(value);
    }
    if (rule === "font_size") {
      return isExpected ? "小四（12pt）" : formatReviewFontSize(value);
    }
    if (rule === "style_name") {
      return formatReviewStyleName(value);
    }
    if (rule === "alignment") {
      return formatReviewAlignment(value);
    }
    if (rule === "line_spacing") {
      return formatReviewLineSpacing(value);
    }
    if (rule === "first_line_indent") {
      return formatReviewIndent(value);
    }
    if (rule === "page_setup") {
      return isExpected ? "A4 页面及模板页边距" : formatReviewPageSetup(value);
    }
    return String(value || "").trim() || (isExpected ? "按模板要求" : "未读取");
  }

  function normalizeFormatReviewSuggestion(issue) {
    var rule = String((issue && issue.ruleId) || "");
    var suggestion = String((issue && issue.suggestion) || "").trim();
    if (rule === "font_size") {
      return "字号调整为小四。";
    }
    if (rule === "font_name") {
      return "字体调整为宋体。";
    }
    if (rule === "alignment") {
      var expected = formatReviewAlignment(issue && issue.expectedValue);
      return "对齐方式调整为" + expected + "。";
    }
    if (rule === "style_name") {
      return "按" + formatReviewRole(issue && issue.role) + "套用模板样式。";
    }
    if (rule === "line_spacing") {
      var lineSpacing = parseFormatReviewNumber(issue && issue.expectedValue);
      if (lineSpacing !== null && !isNaN(lineSpacing)) {
        if (Math.abs(lineSpacing - 1) < 0.01) {
          return "行距调整为单倍行距。";
        }
        return "行距调整为 " + lineSpacing + " 倍。";
      }
      return "按模板要求调整行距。";
    }
    if (rule === "first_line_indent") {
      return "按模板要求调整首行缩进。";
    }
    if (rule === "page_setup") {
      return suggestion.replace(/^建议/, "") || "按模板设置页面和页边距。";
    }
    return suggestion || "按模板要求调整。";
  }

  function formatReviewParagraphLabel(issue) {
    if (!issue || issue.ruleId === "page_setup" || issue.paragraphIndex === 0) {
      return "页面";
    }
    return "P" + (issue.paragraphIndex || 0);
  }

  function formatReviewIssueTitle(issue) {
    return formatReviewParagraphLabel(issue) + " " +
      formatReviewRole(issue.role) + " - " +
      (issue.message || (formatReviewRule(issue.ruleId) + "不符合模板要求。")).replace(/。$/, "");
  }

  function describeFormatReviewProvider(value) {
    var provider = String(value || "local");
    if (provider === "local") {
      return "本地规则";
    }
    if (provider === "mock") {
      return "模拟服务";
    }
    if (provider.indexOf("enterprise-dify-chat") === 0) {
      return "AI 辅助 + 本地规则";
    }
    return "外部服务";
  }

  function summarizeFormatReviewDistribution(grouped) {
    var parts = [];
    FORMAT_REVIEW_GROUP_ORDER.forEach(function (group) {
      var count = grouped[group] ? grouped[group].length : 0;
      if (count) {
        parts.push(FORMAT_REVIEW_GROUP_TEXT[group] + " " + count);
      }
    });
    return parts.length ? parts.join("、") : "无";
  }

  function renderReadableFormatReview(data) {
    var summary = data && data.summary ? data.summary : {};
    var issues = data && data.issues ? data.issues : [];
    var grouped = formatReviewGroupItems(issues, getFormatReviewGroup);
    var lines = [
      "格式审查结果",
      "",
      "## 审查概览",
      "",
      "- 检查范围：" + (summary.scope === "selection" ? "选中内容" : "全文"),
      "- 问题总数：" + (summary.issueCount || issues.length || 0),
      "- 扫描段落：" + (typeof summary.paragraphCount !== "undefined" ? summary.paragraphCount : "未统计"),
      "- 问题分布：" + summarizeFormatReviewDistribution(grouped),
      "- 识别来源：" + describeFormatReviewProvider(summary.provider),
      "",
      "以下仅显示需要调整的格式项，正文内容不会在检查中改写。",
      ""
    ];

    if (!issues.length) {
      lines.push("当前范围未发现明显格式问题。");
      lines.push("");
      lines.push("## 诊断信息");
      lines.push("");
      lines.push("- 模板：" + formatReviewTemplate(summary.templateId));
      lines.push("- 识别来源：" + describeFormatReviewProvider(summary.provider));
      return lines.join("\n").trim();
    }

    lines.push("## 优先处理清单");
    lines.push("");
    lines.push("| 段落 | 问题类型 | 当前值 | 模板要求 | 建议 |");
    lines.push("| --- | --- | --- | --- | --- |");
    issues.slice(0, 12).forEach(function (issue) {
      lines.push(
        "| " + formatReviewParagraphLabel(issue) +
        " | " + formatReviewRule(issue.ruleId) +
        " | " + formatReviewValue(issue.ruleId, issue.currentValue, false) +
        " | " + formatReviewValue(issue.ruleId, issue.expectedValue, true) +
        " | " + normalizeFormatReviewSuggestion(issue) +
        " |"
      );
    });
    if (issues.length > 12) {
      lines.push("");
      lines.push("优先处理清单仅展示前 12 项；完整问题见下方详细分组。");
    }
    lines.push("");
    lines.push("## 详细问题");
    lines.push("");
    FORMAT_REVIEW_GROUP_ORDER.forEach(function (group) {
      var groupIssues = grouped[group] || [];
      if (!groupIssues.length) {
        return;
      }
      lines.push("### " + FORMAT_REVIEW_GROUP_TEXT[group] + "（" + groupIssues.length + "）");
      lines.push("");
      groupIssues.forEach(function (issue) {
        lines.push("#### " + formatReviewIssueTitle(issue));
        lines.push("- 现状：" + formatReviewValue(issue.ruleId, issue.currentValue, false));
        lines.push("- 要求：" + formatReviewValue(issue.ruleId, issue.expectedValue, true));
        lines.push("- 建议：" + normalizeFormatReviewSuggestion(issue));
        lines.push("");
      });
    });

    lines.push("## 诊断信息");
    lines.push("");
    lines.push("- 模板：" + formatReviewTemplate(summary.templateId));
    lines.push("- 识别来源：" + describeFormatReviewProvider(summary.provider));
    if (typeof summary.aiClassifiedParagraphCount !== "undefined") {
      lines.push(
        "- AI 识别段落：" + (summary.aiClassifiedParagraphCount || 0) +
        "；本地兜底段落：" + (summary.localFallbackParagraphCount || 0)
      );
    }
    if (summary.aiInvalidRoleCount || summary.aiOutOfBatchCount) {
      lines.push(
        "- AI 无效角色：" + (summary.aiInvalidRoleCount || 0) +
        "；越界段落：" + (summary.aiOutOfBatchCount || 0)
      );
    }
    var aiFallbackText = formatAiFallbackReason(summary.aiFallbackReason);
    if (aiFallbackText) {
      lines.push("- AI 兜底原因：" + aiFallbackText);
    }
    return lines.join("\n").trim();
  }

  var DOCUMENT_REVIEW_CATEGORY_TEXT = {
    typo: "错别字",
    expression: "语言表达",
    logic: "逻辑表达",
    fluency: "通畅性",
    professional: "专业性"
  };
  var DOCUMENT_REVIEW_STATUS_TEXT = {
    pending: "待处理",
    done: "已处理",
    ignored: "已忽略"
  };

  function buildDocumentReviewRecord(data, statusByIndex) {
    var source = data || {};
    var issues = source.issues || [];
    var statuses = statusByIndex || {};
    var counts = {
      pending: 0,
      done: 0,
      ignored: 0
    };
    var lines = [
      "文档审查处理记录",
      "",
      "## 处理概览",
      "",
      "- 审查摘要：" + (source.summary || "未提供"),
      "- 问题总数：" + issues.length
    ];

    issues.forEach(function (_, index) {
      var status = statuses[String(index)] || "pending";
      if (!Object.prototype.hasOwnProperty.call(counts, status)) {
        status = "pending";
      }
      counts[status] += 1;
    });

    lines.push("- 待处理：" + counts.pending);
    lines.push("- 已处理：" + counts.done);
    lines.push("- 已忽略：" + counts.ignored);
    lines.push("");

    if (!issues.length) {
      lines.push("未发现需要处理的问题。");
      return lines.join("\n").trim();
    }

    lines.push("## 问题清单");
    lines.push("");
    issues.forEach(function (issue, index) {
      var status = statuses[String(index)] || "pending";
      if (!DOCUMENT_REVIEW_STATUS_TEXT[status]) {
        status = "pending";
      }
      lines.push(
        "### " + (index + 1) + ". " +
        (DOCUMENT_REVIEW_CATEGORY_TEXT[issue.category] || "其他问题") +
        "（" + DOCUMENT_REVIEW_STATUS_TEXT[status] + "）"
      );
      lines.push("- 位置：" + (issue.location || "未标注"));
      lines.push("- 原文：" + (issue.originalText || issue.original_text || "未提供"));
      lines.push("- 问题：" + (issue.problem || "未提供"));
      lines.push("- 建议：" + (issue.suggestion || "未提供"));
      if (issue.suggestedRewrite || issue.suggested_rewrite) {
        lines.push("- 建议改写：" + (issue.suggestedRewrite || issue.suggested_rewrite));
      }
      lines.push("");
    });

    return lines.join("\n").trim();
  }

  function getEffectiveSelectionText(selectionOrSources) {
    if (!selectionOrSources) {
      return "";
    }
    if (Array.isArray(selectionOrSources)) {
      for (var i = 0; i < selectionOrSources.length; i += 1) {
        var value = getEffectiveSelectionText(selectionOrSources[i]);
        if (value) {
          return value;
        }
      }
      return "";
    }
    return normalizeText(
      selectionOrSources.Text ||
      (selectionOrSources.Range && selectionOrSources.Range.Text) ||
      (selectionOrSources.TextRange && selectionOrSources.TextRange.Text) ||
      ""
    );
  }

  function getWritableSelection(sources) {
    for (var i = 0; i < sources.length; i += 1) {
      var selection = sources[i];
      if (!selection) {
        continue;
      }
      if (typeof selection.Text !== "undefined") {
        return selection;
      }
      if (selection.Range && typeof selection.Range.Text !== "undefined") {
        return selection;
      }
    }
    return null;
  }

  function resolveRewriteScope(options) {
    var selectionText = normalizeText(options.selectionText);
    if (options.requireSelection && !selectionText) {
      return {
        ok: false,
        selectionMode: "selection",
        scopeLabel: "当前范围：全文",
        message: "请先用鼠标选中一段文字，再执行改写或续写。"
      };
    }

    if (selectionText) {
      return {
        ok: true,
        selectionMode: "selection",
        scopeLabel: "当前范围：选中文本",
        selectedText: selectionText
      };
    }

    return {
      ok: true,
      selectionMode: "document",
      scopeLabel: "当前范围：全文"
    };
  }

  function canApplyRewriteToSelection(originalText, currentSelectionText) {
    if (!normalizeText(currentSelectionText)) {
      return {
        ok: false,
        message: "当前未检测到有效选区，无法安全写回改写结果。"
      };
    }

    if (normalizeText(originalText) !== normalizeText(currentSelectionText)) {
      return {
        ok: false,
        message: "选区已变化，请重新选中原文后再应用改写结果。"
      };
    }

    return { ok: true };
  }

  function resolveScalarValue(value, depth) {
    var resolved = typeof value === "function" ? safeCall(value, null) : value;
    var keys;
    var index;
    var nested;
    var primitive;
    depth = depth || 0;
    if (typeof resolved === "undefined" || resolved === null) {
      return resolved;
    }
    if (typeof resolved === "string" || typeof resolved === "number" || typeof resolved === "boolean") {
      return resolved;
    }
    if (depth >= 3 || Array.isArray(resolved) || typeof resolved !== "object") {
      return undefined;
    }
    keys = ["value", "Value", "text", "Text"];
    for (index = 0; index < keys.length; index += 1) {
      nested = safeRead(resolved, keys[index]);
      if (typeof nested !== "undefined" && nested !== null) {
        return resolveScalarValue(nested, depth + 1);
      }
    }
    if (typeof resolved.valueOf === "function" && resolved.valueOf !== Object.prototype.valueOf) {
      primitive = safeCall(resolved.valueOf, resolved);
      if (primitive !== resolved) {
        return resolveScalarValue(primitive, depth + 1);
      }
    }
    if (typeof resolved.toString === "function" && resolved.toString !== Object.prototype.toString) {
      primitive = safeCall(resolved.toString, resolved);
      if (primitive && primitive !== "[object Object]") {
        return primitive;
      }
    }
    return undefined;
  }

  function normalizeNumber(value) {
    var resolved = resolveScalarValue(value);
    if (resolved === null || typeof resolved === "undefined" || resolved === "") {
      return null;
    }
    var numeric = Number(resolved);
    return isNaN(numeric) ? null : numeric;
  }

  function normalizeFontSize(value) {
    var numeric = normalizeNumber(value);
    return numeric && numeric > 0 ? numeric : null;
  }

  function normalizeAlignmentValue(value, fallback) {
    var resolved = resolveScalarValue(value);
    var text;
    var map = {
      "0": "left",
      "1": "center",
      "2": "right",
      "3": "justify",
      "4": "distribute",
      left: "left",
      center: "center",
      centered: "center",
      centre: "center",
      right: "right",
      justify: "justify",
      justified: "justify",
      distributed: "distribute",
      distribute: "distribute",
      "左对齐": "left",
      "居中": "center",
      "居中对齐": "center",
      "右对齐": "right",
      "两端对齐": "justify",
      "分散对齐": "distribute",
      wdalignparagraphleft: "left",
      wdalignparagraphcenter: "center",
      wdalignparagraphright: "right",
      wdalignparagraphjustify: "justify",
      wdalignparagraphdistribute: "distribute"
    };
    if (typeof resolved === "undefined" || resolved === null || resolved === "") {
      return fallback || "";
    }
    text = String(resolved).trim();
    return map[text.toLowerCase()] || map[text] || text;
  }

  function firstDefined() {
    for (var i = 0; i < arguments.length; i += 1) {
      if (typeof arguments[i] !== "undefined" && arguments[i] !== null) {
        return arguments[i];
      }
    }
    return null;
  }

  function normalizePositiveInteger(value) {
    var numeric = Number(value);
    if (isNaN(numeric) || numeric <= 0) {
      return null;
    }
    return Math.floor(numeric);
  }

  function normalizeCollectOptions(options) {
    var source = typeof options === "number" ? { maxParagraphs: options } : (options || {});
    return {
      maxParagraphs: normalizePositiveInteger(source.maxParagraphs),
      maxParagraphTextLength: normalizePositiveInteger(source.maxParagraphTextLength),
      avoidFallbackTextRead: Boolean(source.avoidFallbackTextRead)
    };
  }

  function limitTextLength(value, maxLength) {
    var text = String(value || "");
    if (maxLength && text.length > maxLength) {
      return text.slice(0, maxLength);
    }
    return text;
  }

  function safeRead(object, key) {
    if (!object) {
      return undefined;
    }
    try {
      return object[key];
    } catch (error) {
      return undefined;
    }
  }

  function safeCall(fn, thisArg) {
    if (typeof fn !== "function") {
      return undefined;
    }
    try {
      return fn.call(thisArg);
    } catch (error) {
      return undefined;
    }
  }

  function resolveRange(object) {
    var range = firstDefined(safeRead(object, "Range"), safeRead(object, "range"));
    return typeof range === "function" ? safeCall(range, object) : range;
  }

  function normalizeParagraphText(text) {
    return String(text || "")
      .replace(/\u0007/g, "")
      .replace(/\r/g, "\n")
      .replace(/\n+$/g, "");
  }

  function toSafeString(value, fallback) {
    var resolved = resolveScalarValue(value);
    if (typeof resolved === "undefined" || resolved === null) {
      return fallback || "";
    }
    if (typeof resolved === "string") {
      return resolved;
    }
    if (typeof resolved === "number" || typeof resolved === "boolean") {
      return String(resolved);
    }
    return fallback || "";
  }

  function normalizeInteger(value) {
    var numeric = normalizeNumber(typeof value === "function" ? safeCall(value, null) : value);
    if (numeric === null) {
      return null;
    }
    return Math.round(numeric);
  }

  function readText(object) {
    var range = resolveRange(object);
    return normalizeParagraphText(toSafeString(firstDefined(
      safeRead(object, "Text"),
      safeRead(object, "text"),
      safeRead(range, "Text"),
      safeRead(range, "text"),
      safeRead(safeRead(object, "TextRange"), "Text"),
      safeRead(safeRead(range, "TextRange"), "Text")
    )));
  }

  function readDocumentText(document) {
    var content = safeRead(document, "Content") || safeRead(document, "content");
    var range = resolveRange(document);
    return normalizeParagraphText(toSafeString(firstDefined(
      safeRead(document, "Text"),
      safeRead(document, "text"),
      safeRead(content, "Text"),
      safeRead(content, "text"),
      safeRead(range, "Text"),
      safeRead(range, "text")
    )));
  }

  function readStyleName(paragraph) {
    var range = resolveRange(paragraph);
    var style = firstDefined(
      safeRead(paragraph, "Style"),
      safeRead(paragraph, "style"),
      safeRead(range, "Style"),
      safeRead(range, "style")
    );
    if (typeof style === "string") {
      return style;
    }
    return toSafeString(firstDefined(
      safeRead(paragraph, "StyleNameLocal"),
      safeRead(paragraph, "styleName"),
      safeRead(paragraph, "StyleName"),
      safeRead(range, "StyleNameLocal"),
      safeRead(range, "StyleName"),
      safeRead(style, "NameLocal"),
      safeRead(style, "Name"),
      "Body"
    ), "Body");
  }

  function readFont(paragraph) {
    var range = resolveRange(paragraph);
    return firstDefined(
      safeRead(paragraph, "Font"),
      safeRead(range, "Font"),
      {}
    );
  }

  function readParagraphFormat(paragraph) {
    var range = resolveRange(paragraph);
    return firstDefined(
      safeRead(paragraph, "ParagraphFormat"),
      safeRead(range, "ParagraphFormat"),
      {}
    );
  }

  function readCollectionCount(collection) {
    if (!collection) {
      return 0;
    }
    var count = typeof collection.length === "number" ? collection.length : null;
    if (count === null) {
      count = typeof collection.Count === "function" ? safeCall(collection.Count, collection) : safeRead(collection, "Count");
    }
    if (typeof count === "undefined" || count === null) {
      count = typeof collection.count === "function" ? safeCall(collection.count, collection) : safeRead(collection, "count");
    }
    count = Number(count);
    return isNaN(count) || count < 0 ? 0 : count;
  }

  function getCollectionItem(collection, oneBasedIndex) {
    if (!collection || oneBasedIndex < 1) {
      return null;
    }
    var zeroBasedIndex = oneBasedIndex - 1;
    if (typeof collection.length === "number" && collection[zeroBasedIndex]) {
      return collection[zeroBasedIndex];
    }
    if (typeof collection.Item === "function") {
      return safeCall(function () { return collection.Item(oneBasedIndex); }, collection);
    }
    if (typeof collection.item === "function") {
      return safeCall(function () { return collection.item(oneBasedIndex); }, collection);
    }
    return collection[oneBasedIndex] || collection[zeroBasedIndex] || null;
  }

  function getParagraphCollection(document) {
    var content = safeRead(document, "Content") || safeRead(document, "content");
    var range = resolveRange(document);
    return firstDefined(
      safeRead(document, "Paragraphs"),
      safeRead(document, "paragraphs"),
      safeRead(content, "Paragraphs"),
      safeRead(content, "paragraphs"),
      safeRead(range, "Paragraphs"),
      safeRead(range, "paragraphs"),
      []
    );
  }

  function collectParagraphsFromText(text, options) {
    var collectOptions = normalizeCollectOptions(options);
    var normalized = String(text || "").replace(/\r/g, "\n");
    if (!normalized.trim()) {
      return [];
    }
    var lines = normalized.split(/\n+/).map(function (line) {
      return line.trim();
    }).filter(Boolean);
    if (collectOptions.maxParagraphs) {
      lines = lines.slice(0, collectOptions.maxParagraphs);
    }
    return lines.map(function (line, index) {
      return {
        index: index + 1,
        text: limitTextLength(line, collectOptions.maxParagraphTextLength),
        styleName: "Normal",
        fontName: "",
        fontSize: null,
        bold: false,
        italic: false,
        underline: null,
        alignment: "",
        outlineLevel: 0,
        lineSpacing: null,
        firstLineIndent: null,
        spaceBefore: null,
        spaceAfter: null,
        leftIndent: null,
        rightIndent: null
      };
    });
  }

  function collectParagraphs(document, options) {
    var collectOptions = normalizeCollectOptions(options);
    var collection = getParagraphCollection(document);
    var count = readCollectionCount(collection);
    if (collectOptions.maxParagraphs) {
      count = Math.min(count, collectOptions.maxParagraphs);
    }
    var items = [];
    for (var i = 1; i <= count; i += 1) {
      var paragraph = getCollectionItem(collection, i);
      if (!paragraph) {
        continue;
      }
      var font = readFont(paragraph);
      var paragraphFormat = readParagraphFormat(paragraph);
      items.push({
        index: i,
        text: limitTextLength(readText(paragraph), collectOptions.maxParagraphTextLength),
        styleName: readStyleName(paragraph),
        fontName: toSafeString(firstDefined(safeRead(font, "NameFarEast"), safeRead(font, "Name")), ""),
        fontSize: normalizeFontSize(safeRead(font, "Size")),
        bold: Boolean(safeRead(font, "Bold")),
        italic: Boolean(safeRead(font, "Italic")),
        underline: normalizeInteger(firstDefined(safeRead(font, "Underline"), null)),
        alignment: normalizeAlignmentValue(safeRead(paragraphFormat, "Alignment"), ""),
        outlineLevel: normalizeInteger(firstDefined(safeRead(paragraphFormat, "OutlineLevel"), 0)),
        lineSpacing: normalizeNumber(firstDefined(safeRead(paragraphFormat, "LineSpacing"), safeRead(paragraphFormat, "lineSpacing"), null)),
        firstLineIndent: normalizeNumber(firstDefined(safeRead(paragraphFormat, "FirstLineIndent"), safeRead(paragraphFormat, "firstLineIndent"), null)),
        spaceBefore: normalizeNumber(firstDefined(safeRead(paragraphFormat, "SpaceBefore"), safeRead(paragraphFormat, "spaceBefore"), null)),
        spaceAfter: normalizeNumber(firstDefined(safeRead(paragraphFormat, "SpaceAfter"), safeRead(paragraphFormat, "spaceAfter"), null)),
        leftIndent: normalizeNumber(firstDefined(safeRead(paragraphFormat, "LeftIndent"), safeRead(paragraphFormat, "leftIndent"), null)),
        rightIndent: normalizeNumber(firstDefined(safeRead(paragraphFormat, "RightIndent"), safeRead(paragraphFormat, "rightIndent"), null))
      });
    }
    if (items.length) {
      return items;
    }
    if (collectOptions.avoidFallbackTextRead) {
      return [];
    }
    return collectParagraphsFromText(readDocumentText(document), collectOptions);
  }

  function collectParagraphsFromSelectionSources(selectionSources, selectedText, options) {
    var sources = Array.isArray(selectionSources) ? selectionSources : [selectionSources];
    var collectOptions = normalizeCollectOptions(options);
    var paragraphs;
    var index;
    for (index = 0; index < sources.length; index += 1) {
      if (!sources[index]) {
        continue;
      }
      paragraphs = collectParagraphs(sources[index], {
        maxParagraphs: collectOptions.maxParagraphs,
        maxParagraphTextLength: collectOptions.maxParagraphTextLength,
        avoidFallbackTextRead: true
      });
      if (paragraphs.length) {
        return paragraphs;
      }
    }
    return collectParagraphsFromText(selectedText, options);
  }

  function buildDocumentStructure(options) {
    var paragraphs = options.paragraphs || [];
    var headings = options.headings || [];
    return {
      doc_name: options.documentId || "unnamed.docx",
      template_id: options.templateId || "general-office",
      selection_mode: options.selectionMode || "document",
      page_setup: options.pageSetup || {},
      paragraphs: paragraphs.map(function (paragraph) {
        return {
          index: paragraph.index,
          text: paragraph.text || "",
          style_name: paragraph.styleName || paragraph.style_name || "",
          font_family: paragraph.fontName || paragraph.font_family || "",
          font_size_pt: normalizeFontSize(firstDefined(paragraph.fontSize, paragraph.font_size_pt)),
          bold: Boolean(paragraph.bold),
          italic: Boolean(paragraph.italic),
          underline: paragraph.underline || null,
          alignment: normalizeAlignmentValue(paragraph.alignment, ""),
          outline_level: normalizeNumber(firstDefined(paragraph.outlineLevel, paragraph.outline_level)),
          line_spacing: normalizeNumber(firstDefined(paragraph.lineSpacing, paragraph.line_spacing)),
          first_line_indent: normalizeNumber(firstDefined(paragraph.firstLineIndent, paragraph.first_line_indent)),
          space_before: normalizeNumber(firstDefined(paragraph.spaceBefore, paragraph.space_before)),
          space_after: normalizeNumber(firstDefined(paragraph.spaceAfter, paragraph.space_after)),
          left_indent: normalizeNumber(firstDefined(paragraph.leftIndent, paragraph.left_indent)),
          right_indent: normalizeNumber(firstDefined(paragraph.rightIndent, paragraph.right_indent))
        };
      }),
      headings: headings.map(function (heading) {
        return {
          level: heading.level || heading.outlineLevel || 0,
          text: heading.text || "",
          paragraph_index: heading.paragraphIndex || heading.index || null
        };
      }),
      tables: options.tables || [],
      captions: options.captions || [],
      capabilities: {
        page_setup_extracted: Boolean(options.pageSetup && Object.keys(options.pageSetup).length),
        paragraph_style_extracted: paragraphs.length > 0,
        table_extracted: Boolean(options.tables && options.tables.length),
        header_footer_extracted: false
      }
    };
  }

  function normalizeWorkflowProfileData(data, taskType) {
    var source = data && typeof data === "object" ? data : {};
    var profiles = Array.isArray(source.profiles) ? source.profiles : [];
    var normalized = profiles.filter(function (profile) {
      return profile && profile.taskType === taskType && profile.id;
    }).map(function (profile) {
      return {
        id: String(profile.id),
        taskType: taskType,
        name: String(profile.name || "未命名工作流"),
        note: String(profile.note || ""),
        keyConfigured: Boolean(profile.keyConfigured),
        createdAt: String(profile.createdAt || ""),
        updatedAt: String(profile.updatedAt || "")
      };
    });
    var activeId = String(source.activeProfileId || "");
    var activeExists = normalized.some(function (profile) {
      return profile.id === activeId;
    });
    return {
      taskType: taskType,
      activeProfileId: activeExists ? activeId : "",
      profileCount: normalized.length,
      profiles: normalized
    };
  }

  function getActiveWorkflowProfileName(data) {
    var profiles = data && Array.isArray(data.profiles) ? data.profiles : [];
    var activeId = data ? data.activeProfileId : "";
    var index;
    for (index = 0; index < profiles.length; index += 1) {
      if (profiles[index].id === activeId) {
        return profiles[index].name;
      }
    }
    return "尚未配置";
  }

  function deriveModelInterfaceState(input) {
    var source = input || {};
    var taskTypes = Array.isArray(source.taskTypes) ? source.taskTypes : [];
    var profilesByTask = source.profilesByTask || {};
    var readyCount = 0;
    var totalCount = taskTypes.length;
    var taskIndex;
    var profileIndex;
    var data;
    var profiles;

    if (source.detectable === false) {
      return { code: "unavailable", label: "无法检测", readyCount: 0, totalCount: totalCount };
    }

    for (taskIndex = 0; taskIndex < taskTypes.length; taskIndex += 1) {
      data = profilesByTask[taskTypes[taskIndex]] || {};
      profiles = Array.isArray(data.profiles) ? data.profiles : [];
      for (profileIndex = 0; profileIndex < profiles.length; profileIndex += 1) {
        if (profiles[profileIndex]
          && profiles[profileIndex].id === data.activeProfileId
          && profiles[profileIndex].keyConfigured) {
          readyCount += 1;
          break;
        }
      }
    }

    if (!String(source.providerBaseUrl || "").trim() || totalCount === 0 || readyCount === 0) {
      return { code: "unconfigured", label: "未配置", readyCount: readyCount, totalCount: totalCount };
    }
    if (readyCount === totalCount) {
      return { code: "ready", label: "已就绪", readyCount: readyCount, totalCount: totalCount };
    }
    return {
      code: "partial",
      label: "部分就绪 · " + readyCount + "/" + totalCount,
      readyCount: readyCount,
      totalCount: totalCount
    };
  }

  function createSettingsRefreshController(options) {
    var settings = options || {};
    var refresh = typeof settings.refresh === "function" ? settings.refresh : function () {};
    var setIntervalFn = typeof settings.setIntervalFn === "function"
      ? settings.setIntervalFn
      : (typeof setInterval === "function" ? setInterval : function () { return 0; });
    var clearIntervalFn = typeof settings.clearIntervalFn === "function"
      ? settings.clearIntervalFn
      : (typeof clearInterval === "function" ? clearInterval : function () {});
    var intervalMs = typeof settings.intervalMs === "number" ? settings.intervalMs : 30000;
    var timerId = null;

    return {
      start: function () {
        if (timerId !== null) {
          return;
        }
        refresh();
        timerId = setIntervalFn(refresh, intervalMs);
      },
      stop: function () {
        if (timerId === null) {
          return;
        }
        clearIntervalFn(timerId);
        timerId = null;
      },
      isRunning: function () {
        return timerId !== null;
      }
    };
  }

  function createWordSelectionWatcher(options) {
    var settings = options || {};
    var refresh = typeof settings.refresh === "function" ? settings.refresh : function () {};
    var getEventSource = typeof settings.getEventSource === "function"
      ? settings.getEventSource
      : function () { return null; };
    var setTimeoutFn = typeof settings.setTimeoutFn === "function"
      ? settings.setTimeoutFn
      : (typeof setTimeout === "function" ? setTimeout : function () { return 0; });
    var clearTimeoutFn = typeof settings.clearTimeoutFn === "function"
      ? settings.clearTimeoutFn
      : (typeof clearTimeout === "function" ? clearTimeout : function () {});
    var intervalMs = typeof settings.intervalMs === "number" ? settings.intervalMs : 2000;
    var eventName = settings.eventName || "WindowSelectionChange";
    var timerId = null;
    var running = false;
    var eventSource = null;
    var eventRegistered = false;

    function safeRefresh() {
      try {
        refresh();
      } catch (error) {
        // Transient COM access failures are retried by the next host event or fallback poll.
      }
    }

    function handleSelectionChange() {
      if (!running) {
        return;
      }
      safeRefresh();
      scheduleFallback();
    }

    function registerEvent() {
      var result;
      try {
        eventSource = getEventSource();
      } catch (error) {
        eventSource = null;
      }
      if (!eventSource || typeof eventSource.AddApiEventListener !== "function") {
        eventSource = null;
        return false;
      }
      try {
        result = eventSource.AddApiEventListener(eventName, handleSelectionChange);
        eventRegistered = result !== false;
      } catch (error) {
        eventSource = null;
        eventRegistered = false;
      }
      return eventRegistered;
    }

    function clearFallback() {
      if (timerId !== null) {
        clearTimeoutFn(timerId);
        timerId = null;
      }
    }

    function scheduleFallback() {
      clearFallback();
      if (!running) {
        return;
      }
      timerId = setTimeoutFn(function () {
        timerId = null;
        if (!running) {
          return;
        }
        safeRefresh();
        scheduleFallback();
      }, intervalMs);
    }

    return {
      start: function () {
        if (running) {
          return;
        }
        running = true;
        safeRefresh();
        registerEvent();
        scheduleFallback();
      },
      stop: function () {
        if (!running) {
          return;
        }
        running = false;
        clearFallback();
        if (eventRegistered && eventSource && typeof eventSource.RemoveApiEventListener === "function") {
          try {
            eventSource.RemoveApiEventListener(eventName);
          } catch (error) {
            // Event cleanup varies across WPS WebView builds; stopping polling still prevents reads.
          }
        }
        eventSource = null;
        eventRegistered = false;
      },
      isRunning: function () {
        return running;
      },
      isEventRegistered: function () {
        return eventRegistered;
      }
    };
  }

  function canDeleteWorkflowProfile(profile, activeProfileId) {
    return Boolean(profile && profile.id && profile.id !== activeProfileId);
  }

  function workflowProfileStatusText(profile, activeProfileId) {
    if (!profile || !profile.keyConfigured) {
      return "密钥未配置";
    }
    return profile.id === activeProfileId ? "当前使用" : "可切换";
  }

  function workflowProfileOptionState(profile, activeProfileId) {
    var item = profile || {};
    var active = Boolean(item.id && item.id === activeProfileId);
    var configured = Boolean(item.keyConfigured);
    var name = String(item.name || "未命名工作流");
    return {
      id: String(item.id || ""),
      label: (active ? "✓ " : "") + name + (configured ? "" : "（Key 未配置）"),
      active: active,
      disabled: !configured
    };
  }

  function validateWorkflowProfileDraft(draft, mode) {
    var value = draft || {};
    var name = String(value.name || "").trim();
    var note = String(value.note || "").trim();
    var apiKey = String(value.apiKey || "").trim();
    if (!name) {
      return { ok: false, field: "name", message: "请输入工作流名称。" };
    }
    if (name.length > 40) {
      return { ok: false, field: "name", message: "工作流名称不能超过 40 个字。" };
    }
    if (note.length > 200) {
      return { ok: false, field: "note", message: "工作流备注不能超过 200 个字。" };
    }
    if (mode === "create" && !apiKey) {
      return { ok: false, field: "apiKey", message: "请输入工作流 API Key。" };
    }
    return { ok: true, name: name, note: note, apiKey: apiKey };
  }

  function shouldActivateNewWorkflowProfile(profileCount, requested) {
    return Number(profileCount || 0) === 0 || Boolean(requested);
  }

  function normalizeWritingPolicyUsageCount(value) {
    var number = Number(value);
    if (!isFinite(number) || number < 0) {
      return 0;
    }
    return Math.floor(number);
  }

  function normalizeWritingPolicyUsage(value) {
    var source;
    var matchedItems;
    var conflicts;
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return null;
    }
    source = value;
    matchedItems = Array.isArray(source.matchedItems) ? source.matchedItems : [];
    conflicts = Array.isArray(source.conflicts) ? source.conflicts : [];
    return {
      applied: Boolean(source.applied),
      degraded: Boolean(source.degraded),
      degradedReason: String(source.degradedReason || ""),
      requestedScene: normalizeWritingPolicyScene(source.requestedScene),
      scene: normalizeWritingPolicyScene(source.scene),
      sceneLabel: String(source.sceneLabel || "").trim(),
      autoFallback: Boolean(source.autoFallback),
      packName: String(source.packName || "").trim(),
      packNames: (Array.isArray(source.packNames) ? source.packNames : [])
        .map(function (item) {
          return String(item || "").trim();
        })
        .filter(Boolean)
        .slice(0, 4),
      presetVersion: String(source.presetVersion || "").trim(),
      termMatchCount: normalizeWritingPolicyUsageCount(source.termMatchCount),
      styleRuleCount: normalizeWritingPolicyUsageCount(source.styleRuleCount),
      antiTemplateRuleCount: normalizeWritingPolicyUsageCount(source.antiTemplateRuleCount),
      truncatedCount: normalizeWritingPolicyUsageCount(source.truncatedCount),
      conflictCount: normalizeWritingPolicyUsageCount(source.conflictCount),
      conflicts: conflicts.filter(function (item) {
        return item && String(item.name || "").trim();
      }).slice(0, 20).map(function (item) {
        return {
          name: String(item.name || "").trim().slice(0, 120),
          winnerId: String(item.winnerId || "").slice(0, 128),
          itemIds: (Array.isArray(item.itemIds) ? item.itemIds : [])
            .map(function (itemId) {
              return String(itemId || "").slice(0, 128);
            })
            .filter(Boolean)
            .slice(0, 20)
        };
      }),
      matchedItems: matchedItems.filter(function (item) {
        return item &&
          (item.type === "term" || item.type === "style" || item.type === "anti_template") &&
          String(item.name || "").trim();
      }).slice(0, 20).map(function (item) {
        return {
          id: String(item.id || ""),
          type: item.type,
          name: String(item.name || "").trim()
        };
      })
    };
  }

  function normalizeWritingPolicyScene(value) {
    var scene = String(value || "").trim();
    return ["auto", "yangqi", "cybersecurity", "official", "disabled"].indexOf(scene) >= 0
      ? scene
      : "auto";
  }

  function writingPolicySceneStorageKey(taskType) {
    return "ai-wps:writing-policy-scene:" + String(taskType || "word.smart_write");
  }

  function normalizeWritingPolicyAuditFinding(value) {
    var source = value && typeof value === "object" ? value : {};
    return {
      code: String(source.code || "").slice(0, 80),
      tier: /^(T1|T2|T3)$/.test(String(source.tier || "")) ? String(source.tier) : "",
      label: String(source.label || "").trim().slice(0, 80),
      message: String(source.message || "").trim().slice(0, 240),
      evidence: String(source.evidence || "").trim().slice(0, 80)
    };
  }

  function normalizeWritingPolicyAudit(value) {
    var source;
    var needsReview;
    var expressionSuggestions;
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return null;
    }
    source = value;
    needsReview = Array.isArray(source.needsReview) ? source.needsReview : [];
    expressionSuggestions = Array.isArray(source.expressionSuggestions)
      ? source.expressionSuggestions
      : [];
    return {
      enabled: source.enabled !== false,
      passed: Boolean(source.passed),
      degraded: Boolean(source.degraded),
      degradedReason: String(source.degradedReason || "").trim().slice(0, 240),
      summary: String(source.summary || "").trim().slice(0, 240),
      needsReview: needsReview.slice(0, 12).map(normalizeWritingPolicyAuditFinding),
      expressionSuggestions: expressionSuggestions
        .slice(0, 12)
        .map(normalizeWritingPolicyAuditFinding)
    };
  }

  function writingPolicyAuditFindingText(value) {
    var finding = normalizeWritingPolicyAuditFinding(value);
    var text = finding.label || finding.message || "请核对该项内容";
    if (finding.label && finding.message) {
      text += "：" + finding.message;
    }
    if (finding.evidence) {
      text += "（" + finding.evidence + "）";
    }
    return text;
  }

  function writingPolicyPageState(offset, total, pageCount, pageSize) {
    var safePageSize = Number(pageSize);
    var safeTotal = Math.max(0, Number(total) || 0);
    var safeOffset = Math.max(0, Number(offset) || 0);
    var safePageCount = Math.max(0, Number(pageCount) || 0);
    if (!isFinite(safePageSize) || safePageSize < 1) {
      safePageSize = 50;
    }
    safePageSize = Math.floor(safePageSize);
    safeOffset = safeTotal
      ? Math.min(
        safeOffset,
        Math.floor((safeTotal - 1) / safePageSize) * safePageSize
      )
      : 0;
    safePageCount = Math.min(safePageCount, safePageSize, Math.max(0, safeTotal - safeOffset));
    return {
      offset: safeOffset,
      start: safeTotal ? safeOffset + 1 : 0,
      end: safeOffset + safePageCount,
      total: safeTotal,
      hasPrevious: safeOffset > 0,
      hasNext: safeOffset + safePageCount < safeTotal,
      label: safeTotal
        ? String(safeOffset + 1) + "–" + String(safeOffset + safePageCount) +
          " / " + String(safeTotal)
        : "0 / 0"
    };
  }

  function writingPolicyUsageSummary(value, taskType) {
    var usage = normalizeWritingPolicyUsage(value);
    var action;
    var summary;
    if (!usage) {
      return "";
    }
    if (!usage.applied) {
      return "写作规范暂未应用，已继续处理";
    }
    if (usage.degraded) {
      return "写作规范暂未完整应用，已继续处理";
    }
    action = taskType === "word.document_review" ? "已检查" : "已应用";
    if (usage.sceneLabel) {
      summary = "写作规范：" + action + " " + usage.sceneLabel + "（" +
        usage.termMatchCount + " 条术语、" + usage.styleRuleCount +
        " 条文体规则、" + usage.antiTemplateRuleCount + " 条去模板化规则）";
    } else if (usage.packName && usage.presetVersion) {
      summary = "写作规范：" + action + " " + usage.packName + " v" +
        usage.presetVersion + "（" +
        (usage.termMatchCount + usage.styleRuleCount) + " 条规则）";
    } else {
      summary = "写作规范：" + action + " " + usage.termMatchCount +
        " 条术语、" + usage.styleRuleCount + " 条文体规则";
    }
    if (usage.conflictCount) {
      summary += "；检测到 " + usage.conflictCount + " 组同层冲突，已按优先级裁决";
    }
    return summary;
  }

  function writingPolicyUsageDetails(value) {
    var usage = normalizeWritingPolicyUsage(value);
    var details;
    if (!usage) {
      return [];
    }
    details = usage.matchedItems.map(function (item) {
      var label = item.type === "term"
        ? "术语"
        : (item.type === "anti_template" ? "去模板化规则" : "文体规则");
      return label + "：" + item.name;
    });
    usage.conflicts.forEach(function (item) {
      details.push("冲突提示：" + item.name + "（已采用 " + item.winnerId + "）");
    });
    return details;
  }

  function validateWritingPolicyDraft(value) {
    var draft = value && typeof value === "object" ? value : {};
    var type = String(draft.type || "");
    var scope = String(draft.scope || "");
    if (type !== "term" && type !== "style" && type !== "anti_template") {
      return { ok: false, field: "type", message: "请选择规范类型。" };
    }
    if (type === "term" && scope !== "global") {
      return { ok: false, field: "scope", message: "企业术语首版仅支持全局范围。" };
    }
    if (type === "term" && !String(draft.preferredText || "").trim()) {
      return { ok: false, field: "preferredText", message: "请输入标准写法。" };
    }
    if (type !== "term" && !String(draft.name || "").trim()) {
      return { ok: false, field: "name", message: "请输入规则名称。" };
    }
    if (type !== "term" && !String(draft.ruleText || "").trim()) {
      return { ok: false, field: "ruleText", message: "请输入写作规则。" };
    }
    if (type !== "term" && (!Array.isArray(draft.taskTypes) || !draft.taskTypes.length)) {
      return { ok: false, field: "taskTypes", message: "请至少选择一个 Word 任务。" };
    }
    if (type !== "term" && (!Array.isArray(draft.sceneIds) || !draft.sceneIds.length)) {
      return { ok: false, field: "sceneIds", message: "请至少选择一个规范场景。" };
    }
    return { ok: true, field: "", message: "" };
  }

  function writingPolicyConflictField(error) {
    var code = String(error && error.adapterCode || "").toUpperCase();
    if (code === "TERM_TEXT_CONFLICT") {
      return "preferredText";
    }
    if (code === "STYLE_NAME_CONFLICT") {
      return "name";
    }
    return "";
  }

  function nextWritingPolicyTabIndex(currentIndex, key, count) {
    var total = Math.max(0, Math.floor(Number(count) || 0));
    var current = Math.max(0, Math.min(total - 1, Math.floor(Number(currentIndex) || 0)));
    if (!total) {
      return -1;
    }
    if (key === "Home") {
      return 0;
    }
    if (key === "End") {
      return total - 1;
    }
    if (key === "ArrowRight") {
      return (current + 1) % total;
    }
    if (key === "ArrowLeft") {
      return (current - 1 + total) % total;
    }
    return current;
  }

  function formatWritingPolicyUpdatedAt(value) {
    var text = String(value || "").trim();
    var date;
    var formatted;
    if (!text) {
      return "尚无更新时间";
    }
    date = new Date(text);
    if (!isFinite(date.getTime())) {
      return "最近更新：" + text;
    }
    try {
      formatted = new Intl.DateTimeFormat("zh-CN", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false
      }).format(date);
    } catch (error) {
      formatted = text;
    }
    return "最近更新：" + formatted;
  }

  function writingPolicyItemStateLabel(item, layer) {
    var source = item && typeof item === "object" ? item : {};
    var state = String(source.organizationState || "");
    if (layer === "preset") {
      if (state === "overridden") {
        return "组织覆盖 · " + (source.effective === false ? "未生效" : "已生效");
      }
      if (state === "disabled") {
        return "预置停用 · 未生效";
      }
      return "预置基线 · " + (source.effective === false ? "未生效" : "已生效");
    }
    return "组织自定义 · " + (source.enabled === false ? "未生效" : "已生效");
  }

  function normalizeWritingPolicyPriority(value) {
    var text = String(value == null ? "" : value).trim().toLowerCase();
    var numeric;
    if (text === "high" || text === "medium" || text === "low") {
      return text;
    }
    numeric = Number(value);
    if (!isFinite(numeric)) {
      return "medium";
    }
    return numeric >= 67 ? "high" : numeric >= 34 ? "medium" : "low";
  }

  function validateWritingPolicyImportFile(file) {
    var name = String(file && file.name || "").toLowerCase();
    var size = Number(file && file.size);
    if (!/\.(csv|xlsx)$/.test(name)) {
      return { ok: false, message: "请选择 CSV 或 XLSX 文件。" };
    }
    if (!isFinite(size) || size < 0 || size > 5 * 1024 * 1024) {
      return { ok: false, message: "导入文件不能超过 5 MB。" };
    }
    return { ok: true, message: "" };
  }

  function buildWritingPolicyImportRequest(file, contentBase64) {
    return {
      fileName: String(file && file.name || ""),
      mimeType: String(file && file.type || "application/octet-stream"),
      sizeBytes: Math.max(0, Math.floor(Number(file && file.size) || 0)),
      contentBase64: String(contentBase64 || "")
    };
  }

  function normalizeWritingPolicyConflictDecision(value) {
    return value === "skip" ? "skip" : "keep_existing";
  }

  function writingPolicyImportRowLabel(value) {
    var row = Math.max(0, Math.floor(Number(value && (value.row || value.rowNumber)) || 0));
    var message = String(value && value.message || "").trim();
    if (/^第\s*\d+\s*行/.test(message)) {
      return message;
    }
    return (row ? "第 " + row + " 行：" : "") + (message || "该行无法导入。");
  }

  function normalizeWritingPolicyImportPreview(value) {
    var source = value && typeof value === "object" ? value : {};
    var errors = Array.isArray(source.errors) ? source.errors : [];
    var conflicts = Array.isArray(source.conflicts) ? source.conflicts : [];
    var changes = Array.isArray(source.changes) ? source.changes : [];
    function totalCount(value, fallback) {
      var number = Number(value);
      return isFinite(number) && number >= 0 ? Math.floor(number) : fallback;
    }
    return {
      previewToken: String(source.previewToken || ""),
      fileDigest: String(source.fileDigest || ""),
      stats: {
        newCount: totalCount(source.newCount, 0),
        modifyCount: totalCount(source.modifyCount, totalCount(source.updateCount, 0)),
        disableCount: totalCount(source.disableCount, 0),
        restoreCount: totalCount(source.restoreCount, 0),
        deleteCount: totalCount(source.deleteCount, 0),
        conflictCount: totalCount(source.conflictCount, conflicts.length),
        errorCount: totalCount(source.errorCount, errors.length)
      },
      changes: changes.slice(0, 100).map(function (item) {
        return {
          rowNumber: normalizeWritingPolicyUsageCount(item && (item.rowNumber || item.row)),
          action: String(item && item.action || ""),
          name: String(item && item.name || "")
        };
      }),
      errors: errors.slice(0, 100).map(function (item) {
        return {
          row: normalizeWritingPolicyUsageCount(item && (item.row || item.rowNumber)),
          message: writingPolicyImportRowLabel(item)
        };
      }),
      conflicts: conflicts.slice(0, 100).map(function (item) {
        return {
          rowNumber: normalizeWritingPolicyUsageCount(item && (item.rowNumber || item.row)),
          message: writingPolicyImportRowLabel(item),
          incomingName: String(item && item.incomingName || ""),
          existingName: String(item && item.existingName || ""),
          decision: "keep_existing"
        };
      })
    };
  }

  function writingPolicyImportCountLabel(label, totalCount, visibleCount) {
    var total = Math.max(0, Math.floor(Number(totalCount) || 0));
    var visible = Math.max(0, Math.floor(Number(visibleCount) || 0));
    if (visible < total) {
      return String(label || "") + "（显示前 " + visible + " 条，共 " + total + " 条）";
    }
    return String(label || "") + "（共 " + total + " 条）";
  }

  function buildWritingPolicyImportApplyRequest(preview) {
    var source = preview && typeof preview === "object" ? preview : {};
    var conflicts = Array.isArray(source.conflicts) ? source.conflicts : [];
    return {
      previewToken: String(source.previewToken || ""),
      fileDigest: String(source.fileDigest || ""),
      acceptedConflictRows: conflicts.map(function (item) {
        return {
          rowNumber: Math.max(0, Math.floor(Number(item && item.rowNumber) || 0)),
          decision: normalizeWritingPolicyConflictDecision(item && item.decision)
        };
      }).filter(function (item) {
        return item.rowNumber > 0;
      })
    };
  }

  function isWritingPolicyPreviewExpired(error) {
    var code = String(error && error.adapterCode || "").toUpperCase();
    return Boolean(error && (error.httpStatus === 404 || error.httpStatus === 410)) ||
      code === "IMPORT_PREVIEW_NOT_FOUND" || code === "IMPORT_PREVIEW_EXPIRED";
  }

  return {
    normalizeText: normalizeText,
    escapeHtml: escapeHtml,
    renderMarkdown: renderMarkdown,
    buildInlineWritebackRuns: buildInlineWritebackRuns,
    buildMarkdownWritebackBlocks: buildMarkdownWritebackBlocks,
    hasStructuredSmartWriteContent: hasStructuredSmartWriteContent,
    shouldUseStructuredSmartWriteResult: shouldUseStructuredSmartWriteResult,
    formatSmartWriteResult: formatSmartWriteResult,
    buildSmartWritePreviewModel: buildSmartWritePreviewModel,
    renderReadableFormatReview: renderReadableFormatReview,
    buildDocumentReviewRecord: buildDocumentReviewRecord,
    getEffectiveSelectionText: getEffectiveSelectionText,
    getWritableSelection: getWritableSelection,
    resolveRewriteScope: resolveRewriteScope,
    canApplyRewriteToSelection: canApplyRewriteToSelection,
    readCollectionCount: readCollectionCount,
    getCollectionItem: getCollectionItem,
    getParagraphCollection: getParagraphCollection,
    collectParagraphs: collectParagraphs,
    collectParagraphsFromSelectionSources: collectParagraphsFromSelectionSources,
    collectParagraphsFromText: collectParagraphsFromText,
    readDocumentText: readDocumentText,
    toSafeString: toSafeString,
    buildDocumentStructure: buildDocumentStructure,
    normalizeWorkflowProfileData: normalizeWorkflowProfileData,
    getActiveWorkflowProfileName: getActiveWorkflowProfileName,
    deriveModelInterfaceState: deriveModelInterfaceState,
    createSettingsRefreshController: createSettingsRefreshController,
    createWordSelectionWatcher: createWordSelectionWatcher,
    canDeleteWorkflowProfile: canDeleteWorkflowProfile,
    workflowProfileStatusText: workflowProfileStatusText,
    workflowProfileOptionState: workflowProfileOptionState,
    validateWorkflowProfileDraft: validateWorkflowProfileDraft,
    shouldActivateNewWorkflowProfile: shouldActivateNewWorkflowProfile,
    normalizeWritingPolicyUsage: normalizeWritingPolicyUsage,
    normalizeWritingPolicyScene: normalizeWritingPolicyScene,
    writingPolicySceneStorageKey: writingPolicySceneStorageKey,
    normalizeWritingPolicyAudit: normalizeWritingPolicyAudit,
    writingPolicyAuditFindingText: writingPolicyAuditFindingText,
    writingPolicyPageState: writingPolicyPageState,
    writingPolicyUsageSummary: writingPolicyUsageSummary,
    writingPolicyUsageDetails: writingPolicyUsageDetails,
    validateWritingPolicyDraft: validateWritingPolicyDraft,
    writingPolicyConflictField: writingPolicyConflictField,
    nextWritingPolicyTabIndex: nextWritingPolicyTabIndex,
    formatWritingPolicyUpdatedAt: formatWritingPolicyUpdatedAt,
    writingPolicyItemStateLabel: writingPolicyItemStateLabel,
    normalizeWritingPolicyPriority: normalizeWritingPolicyPriority,
    validateWritingPolicyImportFile: validateWritingPolicyImportFile,
    buildWritingPolicyImportRequest: buildWritingPolicyImportRequest,
    normalizeWritingPolicyConflictDecision: normalizeWritingPolicyConflictDecision,
    writingPolicyImportRowLabel: writingPolicyImportRowLabel,
    normalizeWritingPolicyImportPreview: normalizeWritingPolicyImportPreview,
    writingPolicyImportCountLabel: writingPolicyImportCountLabel,
    buildWritingPolicyImportApplyRequest: buildWritingPolicyImportApplyRequest,
    isWritingPolicyPreviewExpired: isWritingPolicyPreviewExpired
  };
});
